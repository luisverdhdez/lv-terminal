#!/usr/bin/env python3
"""
Panel web para tradier_bot.py (se ve en Safari). Solo LEE bot.log y trades.csv.

Ademas arranca el bot solo (lunes a viernes 9:35 hora de Nueva York) y tiene
botones Iniciar / Detener. Lee el token de ~/.tradier_env (lo crea instalar.sh).

Uso manual:   python3 monitor_web.py      y abre  http://localhost:8765
Automatico:   ejecuta  ./instalar.sh  una sola vez.
"""
import csv
import html
import json
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime, time as dtime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

import avisos
import fundamentales
import gestor
import portafolio
import market
import license as lic
import reportes
import escaner
import senales
import sombra_op
import sombra
import condor
import condor_mensual
import condor_noche
import condor_real
import condor_real_h
import pnl_rec
import filtros
import setup_wizard
import tasty
import trading
import stream
import uso
import prefs
import updater
import pf
import comisiones
import swing
import sombra2
import pausa
import lineas

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "bot.log")
CSV_PATH = os.path.join(BASE, "trades.csv")
PORT = 8765
LOG_LINES = 25
ENV_FILE = os.environ.get("TRADIER_ENV_FILE", os.path.expanduser("~/.tradier_env"))
ET = ZoneInfo("America/New_York")
AUTO_START = dtime(9, 35)   # el bot espera solo hasta su hora de entradas (9:45)
AUTO_END = dtime(14, 30)
BOT = {"started_day": None, "stopped_day": None, "msg": ""}
LOCK = threading.Lock()

try:
    from tradier_bot import Config
    DAILY_MAX_LOSS = Config().daily_max_loss  # mismo limite que usa el bot
except Exception:
    DAILY_MAX_LOSS = 135.0


# ───────────── lectura de datos ─────────────
def read_lines():
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, encoding="utf-8", errors="replace") as f:
        return [ln.rstrip("\n") for ln in f]


def read_trades(today):
    pnls = []
    if os.path.exists(CSV_PATH):
        with open(CSV_PATH, newline="", encoding="utf-8", errors="replace") as f:
            for row in csv.DictReader(f):
                if row.get("fecha") == today:
                    try:
                        pnls.append(float(row["pnl_usd"]))
                    except (KeyError, ValueError):
                        pass
    return pnls


def read_all_trades():
    rows = []
    if os.path.exists(CSV_PATH):
        with open(CSV_PATH, newline="", encoding="utf-8", errors="replace") as f:
            for row in csv.DictReader(f):
                try:
                    rows.append((row["fecha"], row.get("hora", ""), float(row["pnl_usd"])))
                except (KeyError, ValueError):
                    pass
    return rows


def bot_running():
    try:
        r = subprocess.run(["pgrep", "-f", "tradier_bot.py"], capture_output=True, text=True)
        return r.returncode == 0
    except FileNotFoundError:   # Windows: sin pgrep, se revisa el proceso que abrio la terminal
        p = BOT.get("proc")
        return bool(p and p.poll() is None)
    except Exception:
        return None


def load_env():
    """Lee ~/.tradier_env (lineas  export CLAVE="valor"  o  CLAVE=valor)."""
    env = {}
    try:
        with open(ENV_FILE, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln or ln.startswith("#"):
                    continue
                if ln.startswith("export "):
                    ln = ln[7:]
                if "=" not in ln:
                    continue
                k, v = ln.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return env


def lic_blocked():
    """Texto de error si la licencia falta o vencio (y este programa exige licencia); None si todo bien."""
    if not lic.required():
        return None
    r = lic.current()
    return None if r["ok"] else (r["error"] or "Licencia no válida") + " Actívala en ⚙ Cuentas (http://localhost:8765/setup)."


def lic_order_block(path, body):
    """Con licencia vencida NO se abren posiciones nuevas, pero SI se puede cerrar, cancelar y el gestor sigue cuidando lo abierto."""
    msg = lic_blocked()
    if not msg:
        return None
    sides = [str(l.get("side", "")) for l in (body.get("legs") or [])]
    if path == "/api/order" and not all(s.endswith("_to_close") for s in sides):
        return msg
    if path == "/api/roll":
        return msg   # un roll abre una posicion nueva
    if path == "/api/scalp" and body.get("side") != "sell_to_close":
        return msg
    if path == "/api/stock_order" and body.get("side") not in ("sell", "buy_to_cover"):
        return msg
    return None


def robot_cfg(e=None):
    """En que cuenta opera el robot (papel por defecto) y con que limites. REAL solo si lo activaste en /setup."""
    return setup_wizard.robot_settings(setup_wizard.read_env(ENV_FILE) if e is None else
                                       [f'export {k}="{v}"' for k, v in e.items()])


def sync_robot_paths():
    """bot.log / trades.csv (papel) o bot_live.log / trades_live.csv (REAL), segun la cuenta del robot."""
    global LOG_PATH, CSV_PATH
    sfx = "_live" if robot_cfg()["account"] == "live" else ""
    LOG_PATH = os.path.join(BASE, f"bot{sfx}.log")
    CSV_PATH = os.path.join(BASE, f"trades{sfx}.csv")


def env_ok():
    e = load_env()
    if robot_cfg(e)["account"] == "live":
        return bool(e.get("TRADIER_LIVE_TOKEN") and e.get("TRADIER_LIVE_ACCOUNT_ID"))
    return bool(e.get("TRADIER_TOKEN") and e.get("TRADIER_ACCOUNT_ID"))


def env_any():
    """Hay AL MENOS una cuenta configurada (papel, real o cuenta 2). Para registrar operaciones y P&L basta con una:
    antes se exigia la de papel y quien solo tenia la REAL no veia sus operaciones de hoy."""
    e = load_env()
    return bool((e.get("TRADIER_TOKEN") and e.get("TRADIER_ACCOUNT_ID")) or
                (e.get("TRADIER_LIVE_TOKEN") and e.get("TRADIER_LIVE_ACCOUNT_ID")) or
                (e.get("TRADIER_H_TOKEN") and e.get("TRADIER_H_ACCOUNT_ID")))


def start_bot():
    with LOCK:
        if bot_running():
            return True, "El bot ya está corriendo"
        lb = lic_blocked()
        if lb:
            BOT["msg"] = lb
            return False, lb
        if not env_ok():
            BOT["msg"] = "El robot necesita su cuenta (papel o real): agrégala en ⚙ Cuentas (http://localhost:8765/setup)"
            return False, BOT["msg"]
        full = dict(os.environ)
        env_f = load_env()
        full.update(env_f)
        rc = robot_cfg(env_f)
        sync_robot_paths()
        if rc["account"] == "live":
            # el robot usa la cuenta REAL: token y cuenta reales, topes propios y simulacion hasta que lo actives
            full.update({"TRADIER_TOKEN": env_f["TRADIER_LIVE_TOKEN"], "TRADIER_ACCOUNT_ID": env_f["TRADIER_LIVE_ACCOUNT_ID"],
                         "TRADIER_ENV": "live", "CONFIRM_LIVE": "YES", "DRY_RUN": "0" if rc["send"] else "1",
                         "BOT_QTY": str(rc["qty"]), "BOT_DAILY_MAX_LOSS": f'{rc["max_loss"]:g}',
                         "BOT_MAX_TRADES": str(rc.get("max_trades", 3))})
        else:
            full["TRADIER_ENV"] = "sandbox"
            full.pop("CONFIRM_LIVE", None)
        if rc.get("mtf"):
            full["BOT_MTF"] = "1"   # filtro Corona 1·3·5 (mas selectivo)
        else:
            full.pop("BOT_MTF", None)
        cmd = [sys.executable, os.path.join(BASE, "tradier_bot.py")]
        if os.path.exists("/usr/bin/caffeinate"):
            cmd = ["/usr/bin/caffeinate", "-i"] + cmd  # evita que la Mac se duerma mientras corre
        out = open(os.path.join(BASE, "bot_stdout.log"), "a")
        BOT["proc"] = subprocess.Popen(cmd, cwd=BASE, env=full, stdout=out, stderr=out)
        BOT["started_day"] = datetime.now(ET).strftime("%Y-%m-%d")
        BOT["msg"] = ""
        return True, "Bot iniciado"


def stop_bot():
    with LOCK:
        BOT["stopped_day"] = datetime.now(ET).strftime("%Y-%m-%d")  # que no se reinicie solo hoy
        try:
            subprocess.run(["pkill", "-f", "tradier_bot.py"])
        except FileNotFoundError:   # Windows no tiene pkill
            p = BOT.get("proc")
            if p:
                p.terminate()
        return True, "Bot detenido"


def scheduler():
    """Arranca el bot una vez al dia (lun-vie) dentro de la ventana, salvo que lo hayas detenido."""
    while True:
        try:
            now = datetime.now(ET)
            today = now.strftime("%Y-%m-%d")
            rc = robot_cfg()
            if (now.weekday() < 5 and AUTO_START <= now.time() < AUTO_END
                    and (rc["account"] != "live" or rc["auto"])   # en REAL no arranca solo salvo que lo marques
                    and BOT["started_day"] != today and BOT["stopped_day"] != today):
                start_bot()
        except Exception as e:
            BOT["msg"] = f"Error del arranque automático: {e}"
        time.sleep(30)


def summarize(lines, pnls, today):
    td = [ln for ln in lines if ln.startswith(today)]
    signals = [ln for ln in td if " Señal " in ln]
    near = [ln for ln in signals if "cerca=True" in ln]
    mode_dry = None
    for ln in td:
        if " Inicio. " in ln:
            mode_dry = "dry_run=True" in ln
    last_pos = max((i for i, ln in enumerate(td) if "Posicion:" in ln), default=-1)
    last_close = max((i for i, ln in enumerate(td) if "Operacion cerrada" in ln), default=-1)
    position = td[last_pos].split("Posicion:", 1)[1].strip() if last_pos > last_close else None
    return {
        "signals": len(signals),
        "near": len(near),
        "chosen": sum("Contrato elegido" in ln for ln in td),
        "dry_buys": sum("Compraria" in ln for ln in td),
        "dry": mode_dry,
        "sandbox": any("Modo SANDBOX" in ln for ln in td),
        "position": position,
        "trades": len(pnls),
        "wins": sum(1 for p in pnls if p > 0),
        "pnl": sum(pnls),
        "limit_hit": any("Limite de perdida diaria" in ln for ln in td),
    }


SIGNAL_RE = re.compile(r"^\d{4}-\d{2}-\d{2} (\d{2}:\d{2}:\d{2})\S* \w+ Señal (BUY|SELL) en ([\d.]+) \(.*cerca=(True|False)")
OCC_RE = re.compile(r"^([A-Z]{1,6})(\d{2})(\d{2})(\d{2})([CP])(\d{8})$")


def occ_pretty(occ):
    m = OCC_RE.match(occ or "")
    if not m:
        return occ
    return f"{m.group(1)} {m.group(3)}/{m.group(4)}/{m.group(2)} {int(m.group(6)) / 1000:g} {'Call' if m.group(5) == 'C' else 'Put'}"


def et_shift(day, hms):
    """Hora del log (hora local de tu Mac) -> segundos 'de reloj de Nueva York' como usa el grafico."""
    try:
        d = datetime.strptime(day + " " + hms, "%Y-%m-%d %H:%M:%S").astimezone()
        return int(d.timestamp() + d.astimezone(ZoneInfo("America/New_York")).utcoffset().total_seconds())
    except Exception:
        return None


def pos_levels(lines, today):
    """Posicion abierta del robot: precio de SPY al entrar, entrada/stop de la opcion y stop actual.
    El stop en SPY es una estimacion: (entrada - stop) / delta."""
    td = [ln for ln in lines if ln.startswith(today)]
    lp = max((i for i, ln in enumerate(td) if "Posicion:" in ln), default=-1)
    lc = max((i for i, ln in enumerate(td) if "Operacion cerrada" in ln), default=-1)
    if lp < 0 or lc > lp:
        return None
    m = re.search(r"Posicion: (\d+) x (\S+) entrada ([\d.]+), stop ([\d.]+)", td[lp])
    if not m:
        return None
    stop = float(m.group(4)); entry = float(m.group(3)); occ = m.group(2)
    spy = side = delta = None
    for ln in td[:lp]:
        g = SIGNAL_RE.match(ln)
        if g:
            side, spy = g.group(2), float(g.group(3)); delta = None
        d = re.search(r"Contrato elegido: \S+ strike [\d.]+ delta ([\d.]+)", ln)
        if d:
            delta = float(d.group(1))
    for ln in td[lp + 1:]:
        u = re.search(r"Stop (?:sube a|recreado en) ([\d.]+)", ln)
        if u:
            stop = float(u.group(1))
    if spy is None:
        return None
    dl = delta if delta and delta > 0.05 else 0.30
    sgn = 1 if side == "BUY" else -1
    return {"side": side, "spy": spy, "occ": occ_pretty(occ), "entry": entry, "stop": stop, "delta": dl,
            "stop_spy": round(spy - sgn * (entry - stop) / dl, 2), "trail": stop >= entry}


def entries_today(lines, today):
    """Una fila por señal de hoy: que hizo el robot con ella (ignorada, simulada, entro, cerro con P&L)."""
    out, cur = [], None
    for ln in lines:
        if not ln.startswith(today):
            continue
        m = SIGNAL_RE.match(ln)
        if m:
            cur = {"t": m.group(1), "bt": et_shift(today, m.group(1)), "side": m.group(2), "px": float(m.group(3)), "near": m.group(4) == "True",
                   "res": "Sin acción", "pnl": None}
            out.append(cur)
            continue
        if cur is None:
            continue
        if "Ignorada:" in ln:
            cur["res"] = "Ignorada: " + ln.split("Ignorada:", 1)[1].strip()
        elif "Ningun contrato cumple" in ln:
            cur["res"] = "Sin contrato válido (delta/spread)"
        elif "[DRY_RUN] Compraria" in ln:
            m2 = re.search(r"Compraria (\d+) x (\S+) a ([\d.]+)", ln)
            if m2:
                cur["res"] = f"SIMULADA (dry run): compraría {m2.group(1)} × {occ_pretty(m2.group(2))} a ${m2.group(3)}"
        elif "Posicion:" in ln:
            m2 = re.search(r"Posicion: (\d+) x (\S+) entrada ([\d.]+), stop ([\d.]+)", ln)
            if m2:
                cur["res"] = f"ENTRÓ: {m2.group(1)} × {occ_pretty(m2.group(2))} a ${m2.group(3)} (stop ${m2.group(4)})"
        elif "Entrada no ejecutada" in ln:
            cur["res"] = "Entrada no ejecutada (se canceló)"
        elif "Operacion cerrada" in ln:
            m2 = re.search(r"cerrada: (-?[\d.]+) USD \((.*)\)", ln)
            if m2:
                cur["pnl"] = float(m2.group(1))
                cur["res"] += f" → cerró ({m2.group(2)})"
    return out


ACCT = {"v": None}


def acct_refresher():
    """Cada 4 s consulta a Tradier el P&L de la cuenta (papel o real, segun el selector), en segundo plano."""
    while True:
        live = trading.MODE["live"]
        try:
            v = trading.summary(load_env()) if env_any() else {"error": "Falta configurar el token"}
        except Exception as e:
            v = {"error": str(e)[:160]}
        ACCT["v"], ACCT["live"] = v, live
        for _ in range(4):   # si cambias de papel a real (o al reves) refresca enseguida
            time.sleep(1)
            if trading.MODE["live"] != live:
                break


def pretty_event(ln):
    """Linea de bot.log -> (titulo, texto) si es una apertura/cierre/alerta que merece aviso."""
    if "Posicion:" in ln:
        m = re.search(r"Posicion: (\d+) x (\S+) entrada ([\d.]+), stop ([\d.]+)", ln)
        if m:
            return "🟢 Robot ABRIÓ posición", f"{m.group(1)} × {occ_pretty(m.group(2))} a ${m.group(3)} (stop ${m.group(4)})"
    elif "Operacion cerrada" in ln:
        m = re.search(r"cerrada: (-?[\d.]+) USD \((.*)\)", ln)
        if m:
            v = float(m.group(1))
            return ("✅ " if v >= 0 else "🔻 ") + "Robot CERRÓ posición", f"P&L {'+' if v >= 0 else '-'}${abs(v):.2f} ({m.group(2)})"
    elif "Limite de perdida diaria" in ln:
        return "⛔ Límite de pérdida diaria", "El robot no operará más hoy."
    elif "Vendidos" in ln:
        return "Robot: parcial", ln.split("INFO", 1)[-1].strip()
    return None


def notify_watcher():
    """Vigila bot.log y avisa cuando el robot abre o cierra una posicion (empieza desde el final del archivo)."""
    pos = os.path.getsize(LOG_PATH) if os.path.exists(LOG_PATH) else 0
    cur, last_err = LOG_PATH, 0.0
    while True:
        time.sleep(3)
        try:
            if LOG_PATH != cur:   # cambiaste la cuenta del robot: empieza desde el final del otro archivo
                cur = LOG_PATH
                pos = os.path.getsize(LOG_PATH) if os.path.exists(LOG_PATH) else 0
            if not os.path.exists(LOG_PATH):
                continue
            size = os.path.getsize(LOG_PATH)
            if size < pos:
                pos = 0
            if size == pos:
                continue
            with open(LOG_PATH, "rb") as f:
                f.seek(pos)
                chunk = f.read(size - pos)
            nl = chunk.rfind(b"\n")
            if nl < 0:
                continue
            pos += nl + 1
            env = load_env()
            for ln in chunk[:nl].decode("utf-8", "replace").splitlines():
                ev = pretty_event(ln)
                if ev is None and " ERROR " in ln and time.time() - last_err > 300:
                    last_err = time.time()
                    ev = ("⚠️ Error en el robot", ln.split("ERROR", 1)[-1].strip()[:200])
                if ev:
                    avisos.send(env, *ev)
        except Exception:
            pass


def robot_windows_today():
    """Ventanas en que el robot REAL opero hoy (segun bot_live.log): [(contrato, desde, hasta)] en segundos.
    Entrada: desde que elige el contrato hasta 40 s despues. Posicion: desde 'Posicion:' hasta 'Operacion cerrada' + 60 s.
    Asi tus ordenes manuales en el MISMO contrato pero a otra hora siguen contando como manuales."""
    out, today, cur = [], datetime.now(ET).strftime("%Y-%m-%d"), None
    try:
        with open(os.path.join(BASE, "bot_live.log"), encoding="utf-8", errors="replace") as f:
            for ln in f:
                if not ln.startswith(today):
                    continue
                try:
                    ts = datetime.strptime(ln[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=ET).timestamp()
                except ValueError:
                    continue
                if "Contrato elegido: " in ln:
                    occ = ln.split("Contrato elegido: ")[1].split()[0]
                    out.append((occ, ts - 5, ts + 40))
                elif "Posicion: " in ln and " x " in ln:
                    cur = (ln.split(" x ", 1)[1].split()[0], ts - 5)
                elif "Operacion cerrada" in ln and cur:
                    out.append((cur[0], cur[1], ts + 60))
                    cur = None
        if cur:   # posicion todavia abierta
            out.append((cur[0], cur[1], time.time() + 60))
    except OSError:
        pass
    return out


def is_robot_order(windows):
    return lambda occ, ts: ts is not None and any(occ == o and a <= ts <= b for o, a, b in windows)


def manual_sync_loop():
    """Guarda en manual_trades.csv las ordenes manuales ejecutadas y avisa de cada una."""
    while True:
        time.sleep(5)   # las ordenes del panel se revisan cada 5 s; las de otras plataformas, cada 15 s en horario
        try:
            if not env_any():
                continue
            env = load_env()
            r = trading.sync_manual(env, is_robot_order(robot_windows_today()))
            for f in r["new"]:
                avisos.send(env, (("🟣 " + trading.acct_name(env, "H").upper() + " · ") if f.get("live") == "H" else "🔴 REAL · " if f.get("live") else "") + ("Orden ejecutada (fuera del panel)" if f.get("fuera") else "Orden manual ejecutada"),
                            f"{f['lado'].replace('_', ' ')} {int(f['cantidad'])} × {occ_pretty(f['opcion'])} a ${f['precio']:.2f}")
        except Exception:
            pass


def level(line):
    if " ERROR " in line:
        return "err"
    if " WARNING " in line:
        return "warn"
    if "Operacion cerrada" in line or " Señal " in line:
        return "bold"
    return ""


def snapshot(src="robot", rng="hoy"):
    src = src if src in ("robot", "manual", "all") else "robot"
    rng = rng if rng in ("hoy", "semana", "mes", "todo") else "hoy"
    lines = read_lines()
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    # Lo del robot solo se muestra en la vista de SU cuenta: robot en papel -> vista PAPEL; robot en real -> vista REAL.
    same_acct = (trading.MODE["live"] is True) if robot_cfg()["account"] == "live" else (trading.MODE["live"] is False)   # el robot del SPY nunca opera la cuenta 2
    vlines = lines if same_acct else []
    s = summarize(vlines, read_trades(today) if same_acct else [], today)
    s["bot_pnl"] = s["pnl"]          # P&L del robot hoy: para el limite de perdida
    rows = reportes.load_rows(BASE, src, trading.MODE["live"])
    tdy = [r for r in rows if r["fecha"] == today]
    tp = [r["pnl"] for r in tdy]
    s["src"], s["rng"] = src, rng
    s["trades"], s["wins"], s["pnl"] = len(tp), sum(1 for p in tp if p > 0), sum(tp)
    wk = reportes.in_range(rows, "semana", today)
    s["week"] = sum(r["pnl"] for r in wk)
    s["month"] = sum(r["pnl"] for r in reportes.in_range(rows, "mes", today))
    gains, losses = sum(p for p in tp if p > 0), -sum(p for p in tp if p < 0)
    s["pf"] = (gains / losses) if losses else None
    cum, c = [], 0.0
    for p in tp:
        c += p
        cum.append(round(c, 2))
    s["curve"] = cum
    s["metrics"] = reportes.metrics(reportes.in_range(rows, rng, today))
    try:   # comisiones reales de Tradier repartidas entre tus operaciones del periodo
        cd = comisiones.get(load_env(), trading.MODE["live"]) if env_any() else None
        cm = comisiones.total(reportes.in_range(rows, rng, today), cd)
        s["metrics"]["comm"] = cm
        s["metrics"]["net"] = None if cm is None else round((s["metrics"].get("total") or 0) - cm, 2)
    except Exception:  # noqa: BLE001
        s["metrics"]["comm"] = s["metrics"]["net"] = None
    s["notif"] = avisos.channels(load_env())
    s["running"] = bot_running()
    s["env_ok"] = env_ok()
    s["msg"] = BOT["msg"]
    rc = robot_cfg()
    s["robot"] = rc
    s["limit"] = rc["max_loss"] if rc["account"] == "live" else DAILY_MAX_LOSS
    s["now"] = now.strftime("%Y-%m-%d %H:%M:%S")
    s["ny"] = datetime.now(ZoneInfo("America/New_York")).strftime("%H:%M:%S")
    s["log"] = [{"t": ln, "c": level(ln)} for ln in lines[-LOG_LINES:]]
    s["entries"] = entries_today(vlines, today)
    s["pos"] = pos_levels(vlines, today)
    s["robot_here"] = same_acct
    s["acct"] = ACCT["v"] if ACCT.get("live") == trading.MODE["live"] else None   # nunca muestres el P&L de la otra cuenta
    return s


# ───────────── página ─────────────
PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}
.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px 20px;margin-bottom:14px}
h1{margin:0;font-size:24px;color:var(--ok);letter-spacing:.04em}
.pill{border:1px solid var(--ok);color:var(--ok);border-radius:99px;padding:5px 12px;font-size:12px;font-weight:700;letter-spacing:.06em}
.pill.bad{border-color:var(--bad);color:var(--bad)}.pill.warn{border-color:var(--warn);color:var(--warn)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:14px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--ok);border-radius:14px;padding:18px}
.card.c2{border-left-color:var(--warn)}.card.c3{border-left-color:var(--cy)}.card.bad{border-left-color:var(--bad)}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:6px}
.big{font-size:38px;font-weight:700}
.sub{display:flex;flex-wrap:wrap;gap:14px;color:var(--mut);font-size:13px;border-top:1px solid var(--line);margin-top:12px;padding-top:10px}
.sub b{color:var(--tx)}
.ok{color:var(--ok)}.bad{color:var(--bad)}.warn{color:var(--warn)}
.row{display:flex;justify-content:space-between;padding:4px 0}
h2{font-size:16px;margin:0 0 10px}
.two{display:grid;grid-template-columns:2fr 1fr;gap:14px}
@media(max-width:800px){.two{grid-template-columns:1fr}}
pre{margin:0;max-height:300px;overflow:auto;font:12.5px ui-monospace,Menlo,monospace;white-space:pre-wrap;word-break:break-word}
pre div{padding:3px 0;border-bottom:1px solid var(--line)}
.err{color:var(--bad)}.wl{color:var(--warn)}.bl{color:var(--ok)}
.btn{background:transparent;border:1px solid var(--ok);color:var(--ok);border-radius:8px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer}
.btn.stop{border-color:var(--bad);color:var(--bad)}.btn:hover{background:rgba(255,255,255,.06)}
#msg{color:var(--warn);margin-top:8px;font-size:13px}
.pst{width:100%;border-collapse:collapse;font-size:13px}.pst th{color:var(--mut);font-weight:600;text-align:right;padding:4px 8px;border-bottom:1px solid var(--line)}
.pst td{text-align:right;padding:8px;border-bottom:1px solid var(--line)}.pst th:first-child,.pst td:first-child{text-align:left}
.pst-kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:10px 0}.pst-kv div{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:8px 10px}
.pst-kv span{display:block;font-size:11px;color:var(--mut);letter-spacing:.06em}.pst-kv b{font-size:18px}
.pst .xb{border:1px solid var(--cy);color:var(--cy);background:transparent;border-radius:8px;padding:5px 12px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
.pst .xb.alt{border-color:var(--warn);color:var(--warn)}
.tf{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:5px 12px;cursor:pointer;font-weight:700}
.tf.on{color:var(--tx);border-color:var(--cy)}
.tf.go{border-color:var(--ok);color:var(--ok)}.tf.go.on{background:#10372d}
#tk{position:absolute;top:6px;right:70px;width:300px;max-height:640px;overflow-y:auto;z-index:5;background:rgba(12,12,15,.96);border:1px solid var(--ok);border-radius:12px;padding:12px;box-shadow:0 8px 30px rgba(0,0,0,.6)}
#tk.wide{width:min(760px,calc(100% - 90px));max-height:86vh}
.tkh{display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px}
.tkl{display:block;color:var(--mut);font-size:11px;letter-spacing:.06em;margin:4px 0 2px}
.sw{display:flex;gap:4px;align-items:stretch}.sw input{flex:1;min-width:0}
.stp{flex:none;width:30px;border:1px solid var(--line);background:#08080a;color:var(--tx);border-radius:8px;font-size:16px;font-weight:700;cursor:pointer;line-height:1;padding:0;user-select:none;touch-action:manipulation}
.stp:hover{border-color:var(--cy);color:var(--cy)}.stp:active{background:#1c1c22}
input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{opacity:1}
#tk select,#tk input{width:100%;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px;font-size:13px;box-sizing:border-box}
.tkbuy{width:100%;padding:11px;border:0;border-radius:9px;font-weight:800;font-size:14px;cursor:pointer;color:#04120d;background:var(--ok)}
.tkbuy.put{background:var(--bad);color:#1a0509}.tkbuy:disabled{opacity:.5;cursor:default}
.tkr{display:flex;justify-content:space-between;align-items:center;gap:4px;padding:4px 0;border-top:1px solid var(--line)}
.tkr button{padding:3px 7px;font-size:11px}
@media(max-width:700px){#tk{right:6px;left:6px;width:auto}}
#gb{border:1px solid var(--line);border-radius:10px;padding:8px;margin-top:6px;background:#000000}
#gb .gi{border-top:1px solid var(--line);padding:6px 0;font-size:12px}#gb .gi:first-child{border-top:0}
#gb .gc{display:grid;grid-template-columns:1fr 1fr;gap:4px 8px}#gb .gc label{font-size:11px;color:var(--mut);display:block}
#gb .gc input[type=number],#gb .gc input[type=text]{padding:4px;font-size:12px}#gb .ck{display:flex;gap:4px;align-items:center;font-size:12px}#gb .ck input{width:auto}
#panes{display:grid;gap:6px;height:660px}
#panes.l2{grid-template-columns:1fr 1fr}#panes.l2v{grid-template-rows:1fr 1fr;height:900px}
#panes.l3{grid-template-columns:1fr 1fr 1fr}#panes.l4{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;height:900px}
.pane{display:flex;flex-direction:column;min-width:0;min-height:0;background:#0c0c0f;border:1px solid var(--line);border-radius:8px;overflow:hidden}

.pane{position:relative}.pleg{position:absolute;left:6px;top:4px;z-index:11;display:flex;flex-direction:column;gap:2px;pointer-events:none;font:11px ui-monospace,Menlo,monospace;max-width:70%}
.pl{display:flex;gap:5px;align-items:center;background:rgba(12,12,15,.72);border-radius:5px;padding:1px 5px;color:#cfd8ea;pointer-events:auto;width:fit-content}.pl.off{opacity:.45}.pl i{width:8px;height:8px;border-radius:50%;display:inline-block}
.pl b{font-weight:600;color:#fff}.pl button{background:none;border:0;color:#7d8aa5;cursor:pointer;padding:0 2px;font-size:11px;display:none}.pl:hover button{display:inline}.pl button:hover{color:#fff}
.pmenu{position:absolute;top:34px;right:6px;width:min(360px,calc(100% - 12px));max-height:calc(100% - 44px);overflow:auto;z-index:40;background:#0c0c0f;border:1px solid #2b4a6b;border-radius:10px;padding:10px;box-shadow:0 8px 30px rgba(0,0,0,.6);font-size:12px}
.pmh{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.pms{color:#7d8aa5;font-size:11px;letter-spacing:.06em;margin:8px 0 4px;text-transform:uppercase}
.pmg{display:flex;flex-wrap:wrap;gap:5px}.pmenu button{background:#16161b;border:1px solid #202027;color:#e6ecf5;border-radius:7px;padding:4px 9px;cursor:pointer;font-size:12px}.pmenu button:hover{border-color:#5cc8ff}
.pmr{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:6px 0;border-top:1px solid #202027}.pmr label{display:flex;gap:4px;align-items:center;color:#9fb0cc}.pmr input[type=number]{width:56px;background:#000000;color:#e6ecf5;border:1px solid #202027;border-radius:6px;padding:3px 5px}.pmr input[type=color]{width:30px;height:24px;padding:0;border:1px solid #202027;background:none}
.pane.act{border-color:#2b4a6b}.pane:fullscreen{border:0;border-radius:0}.pane:-webkit-full-screen{border:0;border-radius:0}
.ph{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:4px 6px;border-bottom:1px solid var(--line)}
.psym{width:96px;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:6px;padding:4px 6px;font:700 13px ui-monospace,Menlo,monospace;text-transform:uppercase}
.ptf{display:flex;gap:3px;flex-wrap:wrap}.tf.sm{padding:3px 7px;font-size:12px}
.pinfo{color:var(--mut);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;max-width:100%;line-height:16px;height:16px}
.pb{flex:1;display:flex;min-height:0}
.ptools{width:36px;display:flex;flex-direction:column;align-items:center;gap:2px;padding:4px 0;border-right:1px solid var(--line);background:#08080a;overflow-y:auto}
.tl{width:28px;height:27px;border:1px solid transparent;border-radius:6px;background:transparent;color:#9fb0cc;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;flex:none}
.tl:hover{background:#1c1c22}.tl.on{border-color:#f5c542;color:#f5c542;background:rgba(245,197,66,.1)}.tsep{width:22px;border-top:1px solid var(--line);margin:3px 0}
.pcd{position:absolute;z-index:11;display:none;font:700 11px ui-monospace,Menlo,monospace;text-align:center;color:#04120d;border-radius:3px;padding:2px 0;pointer-events:none;box-sizing:border-box}
.pc{position:relative;flex:1;min-width:0;isolation:isolate}
.mac{display:inline-flex;gap:3px;align-items:center;margin-left:-8px}.mac input[type=color]{width:22px;height:18px;padding:0;border:1px solid var(--line);background:none;cursor:pointer}.mac select{background:#0c0c0f;color:var(--mut);border:1px solid var(--line);border-radius:4px;font:11px ui-monospace,Menlo,monospace;padding:0 2px;height:18px}
.pst{position:absolute;top:6px;left:50%;transform:translateX(-50%);z-index:30;display:none;flex-wrap:wrap;gap:6px;align-items:center;max-width:96%;background:#16161b;border:1px solid #2c2c36;border-radius:9px;padding:5px 9px;font:11px ui-monospace,Menlo,monospace;color:#9fb0cc;box-shadow:0 4px 14px rgba(0,0,0,.5)}
.pst b{color:#e6ecf5;font-weight:700}.pst .sg{display:flex;gap:2px;align-items:center}.pst .sep{width:1px;height:18px;background:#2c2c36}
.pst button{background:#0c0c0f;color:#c9d4e6;border:1px solid #2c2c36;border-radius:5px;padding:2px 6px;font:11px ui-monospace,Menlo,monospace;cursor:pointer;min-width:24px}
.pst button.on{background:#5cc8ff;color:#06101e;border-color:#5cc8ff}.pst input[type=range]{width:70px;accent-color:#5cc8ff}
.pst input[type=color]{width:26px;height:22px;padding:0;border:1px solid #2c2c36;background:none}.pst input[type=text]{width:110px;background:#0c0c0f;color:#e6ecf5;border:1px solid #2c2c36;border-radius:5px;padding:2px 5px;font:11px ui-monospace,Menlo,monospace}.plw{position:absolute;inset:0;z-index:0}.pdr{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:10}
#panes.l5{grid-template-columns:repeat(6,1fr);grid-template-rows:1fr 1fr;height:900px}
#panes.l5 .pane:nth-child(-n+3){grid-column:span 2}#panes.l5 .pane:nth-child(n+4){grid-column:span 3}
#gcard:fullscreen,#gcard:-webkit-full-screen{background:var(--bg);margin:0;border:0;border-radius:0;padding:10px;display:flex;flex-direction:column;overflow:auto;width:100vw;height:100vh}
#gcard:fullscreen #gwrap,#gcard:-webkit-full-screen #gwrap{flex:1;min-height:0}
#gcard:fullscreen #panes,#gcard:-webkit-full-screen #panes{height:100%!important}
#layMenu{display:none;position:absolute;top:34px;left:40px;z-index:30;background:#0c0c0f;border:1px solid var(--line);border-radius:10px;padding:6px;min-width:210px;box-shadow:0 8px 30px rgba(0,0,0,.6)}
.lmi{display:flex;gap:10px;align-items:center;padding:8px 10px;border-radius:8px;cursor:pointer;color:var(--tx)}.lmi:hover{background:#1c1c22}.lmi.on{color:#f5c542;background:rgba(245,197,66,.08)}
.foot{color:var(--mut);font-size:12px;margin-top:10px}
svg#chart{width:100%;height:190px;display:block}
.pbar{display:inline-block;position:relative;width:140px;height:8px;border-radius:4px;background:linear-gradient(90deg,rgba(255,93,108,.55),rgba(255,192,77,.35) 50%,rgba(79,240,183,.55));vertical-align:middle}
.pbar i{position:absolute;top:-3px;width:3px;height:14px;background:#fff;border-radius:2px;margin-left:-1px}
.pbl{display:flex;justify-content:space-between;width:140px;font-size:10px;color:#7d8aa5;margin-top:3px}
tr.pr-warn td{background:rgba(255,192,77,.10)}tr.pr-bad td{background:rgba(255,93,108,.16)}
</style><script src="https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js"></script>
</head><body><main>
<header>
 <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><h1 class="mono" title="Luis Verduzco Options Terminal">LV OPTIONS TERMINAL</h1><span class="pill" id="pill">…</span>
  <button class="btn" id="bstart" onclick="act('start')">Iniciar</button><button class="btn stop" id="bstop" onclick="act('stop')">Detener</button><button class="btn" id="bupd" onclick="updClick()" title="Buscar e instalar la versión nueva de la terminal" style="border-color:var(--cy);color:var(--cy)">🔄 Actualizar</button><span class="mono" id="updmsg" style="font-size:12px;color:var(--mut)"></span></div>
 <div class="mono" style="color:var(--mut)"><a href="/market" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none">Market →</a><a href="/setup" style="color:var(--mut);font-weight:700;margin-right:18px;text-decoration:none" title="Cuentas de Tradier">⚙ Cuentas</a><a href="/portafolio" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none">Portafolio →</a><a href="/escaner" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none" title="Escáner de swing: cruce de la SMA 50 + put credit spread a 45 días">Escáner →</a><a href="/swing" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none" title="Swing en acciones: 4 patrones, prueba hacia atrás y modo sombra">Swing →</a><a href="/senales" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none" title="Modo sombra: todas las señales del indicador y qué hizo SPY después">Señales →</a><a href="/sombra" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none" title="Modo sombra: qué están haciendo los procesos y qué van diciendo los resultados">Modo sombra →</a><a href="/fundamentales" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none">Fundamentales →</a><a href="/trade" style="color:var(--cy);font-weight:700;margin-right:18px;text-decoration:none">Trading manual →</a><a href="https://discord.com/app" target="lvdiscord" rel="noopener" style="color:#8b95ff;font-weight:700;margin-right:18px;text-decoration:none" title="Abre Discord en UNA pestaña de tu navegador junto a la terminal (siempre la misma pestaña). Discord no permite mostrarse dentro de otra página.">💬 Discord →</a>TU MAC: <b id="now" style="color:var(--tx)"></b> &nbsp; NUEVA YORK: <b id="ny" style="color:var(--cy)"></b></div>
</header>
<div class="mono" style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px"><span style="color:var(--mut);font-size:12px;letter-spacing:.08em">REPORTE:</span><span id="srcs"></span></div>
<div class="grid">
 <div class="card" id="c1"><div class="lbl" id="c1l">P&amp;L ROBOT (HOY)</div><div class="big mono" id="pnl">…</div>
  <div class="sub"><span>Operaciones: <b id="trades"></b></span><span>Win rate: <b id="wr"></b></span><span>Profit factor: <b id="pf"></b></span></div>
  <div class="bad" id="limitmsg" style="font-weight:700;margin-top:8px"></div></div>
 <div class="card c3"><div class="lbl" id="replbl">REPORTE (SEGÚN trades.csv)</div>
  <div class="row mono"><span>Hoy</span><b id="r_day"></b></div>
  <div class="row mono"><span>Esta semana</span><b id="r_wk"></b></div>
  <div class="row mono"><span>Este mes</span><b id="r_mo"></b></div>
  <div class="sub"><span>Límite diario: <b class="bad" id="lim"></b></span></div></div>
 <div class="card c2"><div class="lbl">SEÑALES HOY</div>
  <div class="row"><span>Señales</span><b id="signals"></b></div>
  <div class="row"><span>Cerca de HH/LL</span><b id="near"></b></div>
  <div class="row"><span>Contratos elegidos</span><b id="chosen"></b></div>
  <div class="row"><span>Compras simuladas</span><b id="dry_buys"></b></div></div>
</div>
<div id="position" style="display:none"></div>
<div class="card c3" id="poscard" style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div class="lbl" id="acctposl">POSICIONES</div><span class="grpbar"></span></div>
 <div class="pst-kv" id="posum"></div>
 <div style="overflow-x:auto"><table class="pst"><thead><tr><th>Estrategia</th><th>Exp. (DTE)</th><th>Cant.</th><th>Entrada</th><th>Cierre ahora</th><th>P&amp;L</th><th>Delta</th><th>Theta/día</th><th>Vega</th><th>Stop ◄ ahora ► Objetivo</th><th></th></tr></thead><tbody id="pos"><tr><td colspan="11" style="color:var(--mut)">Cargando…</td></tr></tbody></table></div>
 <div class="mono" id="posnote" style="color:var(--mut);font-size:12px;margin-top:8px"></div>
 <details id="gdet" style="margin-top:14px"><summary id="gdet_s" style="cursor:pointer;color:var(--cy);font-weight:700;font-size:13px;letter-spacing:.04em">🤖 GESTOR · vigila y cierra tus posiciones con tus reglas</summary><div id="acct_g" class="mono" style="font-size:13px;margin-top:8px"></div></details>
 <div class="sub" style="margin-top:10px"><span id="mode"></span></div></div>
<div class="card c3" id="gcard" style="margin-bottom:14px">
 <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px">
  <div class="lbl" style="margin:0">GRÁFICOS EN VIVO · dibuja con las herramientas de la izquierda de cada gráfico</div>
  <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;position:relative">
   <button class="tf" id="linkBtn" onclick="toggleLink()" title="Con el enlace activo, al cambiar el símbolo en un gráfico cambian todos. El intervalo es independiente en cada gráfico.">🔗</button>
   <button class="tf" id="layBtn" onclick="layMenu()">Diseño ▾</button><div id="layMenu"></div>
   <label class="mono" style="font-size:12px;color:var(--mut)" title="Color de los dibujos nuevos (y del dibujo seleccionado)">Color <input type="color" id="dcol" value="#f5c542" onchange="dcolChange()" style="width:30px;height:24px;padding:0;border:1px solid var(--line);background:none;vertical-align:middle"></label>
   <button class="tf go" id="lnBtn" onclick="lnToggle()" title="Robot de líneas SPY: pones ENTRADA, STOP y GANANCIA en la gráfica del SPY y él opera el credit spread 0DTE de 3 puntos (solo papel en esta terminal)">🎯 Robot de líneas SPY</button>
   <button class="tf" id="posBtn" onclick="posToggle()" title="Dibuja en los gráficos el breakeven y los strikes de tus posiciones abiertas (spreads e iron condors incluidos), a vencimiento">📍 Posición</button>
   <button class="tf" onclick="toggleFS()" title="Pantalla completa con todos los gráficos (elige 1 a 5 en Diseño)">⛶ Pantalla completa</button>
   <button class="tf" id="gBadge" onclick="if(!T.open)toggleT()" title="Gestor automático de posiciones manuales">🤖 Gestor: …</button>
   <button class="tf go" id="tfT" onclick="toggleT()">⚡ Trading</button></div></div>
 <div class="mono" style="display:flex;flex-wrap:wrap;gap:14px;font-size:12px;margin-bottom:6px;color:var(--mut)">
  <label><input type="checkbox" id="o_sig" checked onchange="optSave()"> Buy / Sell</label>
  <label><input type="checkbox" id="o_crown" checked onchange="optSave()"> 👑 Corona 1·3·5</label>
  <label><input type="checkbox" id="o_zz" checked onchange="optSave()"> ZigZag HH/LL</label>
  <label><input type="checkbox" id="o_or" checked onchange="optSave()"> Banda 15 min (ORH/ORL)</label>
  <label><input type="checkbox" id="o_ema" checked onchange="optSave()"> <b id="l_ema" style="color:#f5a03a">EMA 20</b></label><span class="mac"><input type="color" id="c_ema" value="#f5a03a" oninput="maSet()" title="Color de la EMA 20"><select id="w_ema" onchange="maSet()" title="Grosor de la EMA 20"><option>1</option><option selected>2</option><option>3</option><option>4</option></select></span>
  <label><input type="checkbox" id="o_sma" checked onchange="optSave()"> <b id="l_sma" style="color:#5cc8ff">SMA 50</b></label><span class="mac"><input type="color" id="c_sma" value="#5cc8ff" oninput="maSet()" title="Color de la SMA 50"><select id="w_sma" onchange="maSet()" title="Grosor de la SMA 50"><option>1</option><option selected>2</option><option>3</option><option>4</option></select></span>
  <label><input type="checkbox" id="o_bot" checked onchange="optSave()"> Entradas del robot</label>
  <label title="Niveles de gamma (GEX) de las cadenas de opciones: call wall, put wall y gamma flip. Mismo horizonte que elijas en Trading manual (45 días o solo hoy)"><input type="checkbox" id="o_gex" checked onchange="optSave();gexAll()"> 🧲 <b style="color:#ffa726">Gamma</b> (call/put wall, flip, ⭐ clave)</label>
  <label title="Tiempo que le queda a la vela actual, debajo del precio"><input type="checkbox" id="o_cd" checked onchange="optSave()"> ⏱ Cuenta regresiva de la vela</label>
  <label title="Velas de premarket (desde las 4:00) y aftermarket (hasta las 20:00) en acciones y ETFs, más tenues. Los índices como SPX no cotizan fuera de horario."><input type="checkbox" id="o_ext" onchange="extSet()"> 🌙 Premarket y aftermarket</label></div>
 <div style="position:relative" id="gwrap">
 <div id="lnBox" style="display:none;border:1px solid #7a3cff;border-radius:10px;padding:10px 12px;margin:0 0 8px;background:rgba(122,60,255,.06)"></div>
 <div id="panes" class="l1"></div><datalist id="symlist"></datalist>
 <div id="tk" style="display:none">
  <div class="tkh"><b>⚡ ORDEN RÁPIDA <span id="tk_mode" style="color:var(--warn)">· PAPEL</span></b><span style="cursor:pointer" onclick="toggleT()">✕</span></div>
  <div style="display:flex;gap:6px;margin-bottom:8px"><button class="tf on" id="tkt_o" onclick="tkTab('o')" style="flex:1">Opción rápida</button><button class="tf" id="tkt_s" onclick="tkTab('s')" style="flex:1" title="Constructor de spreads e iron condors, sin salir del gráfico (solo cuenta de papel por ahora)">Estrategias</button></div>
  <div id="tk_opt">
  <div class="mono" id="tk_spot" style="color:var(--mut);margin-bottom:6px"></div>
  <div style="color:var(--mut);font-size:10px;margin-bottom:6px" title="Los atajos no envían nada solos: siempre aparece el cuadro Sí / No">Atajos: T abre/cierra · C / P · B M A precio · ↑ ↓ strike · Enter comprar · Esc cerrar</div>
  <div style="display:flex;gap:6px;margin-bottom:6px"><button class="tf on" id="tk_c" onclick="tkSide('C')" style="flex:1">CALL ▲</button><button class="tf" id="tk_p" onclick="tkSide('P')" style="flex:1">PUT ▼</button></div>
  <label class="tkl">Expiración</label><select id="tk_exp" onchange="tkExp()"></select>
  <label class="tkl">Strike</label><div style="display:flex;gap:4px"><button class="tf" onclick="tkStep(-1)">−</button><select id="tk_k" onchange="tkPick()" style="flex:1"></select><button class="tf" onclick="tkStep(1)">+</button></div>
  <div class="mono" id="tk_q" style="margin:6px 0;font-size:12px"></div>
  <div style="display:flex;gap:6px"><div style="flex:1"><label class="tkl">Contratos</label><div class="sw"><button type="button" class="stp" data-for="tk_qty" data-d="-1" data-min="1" data-max="10" data-dec="0" title="Restar">−</button><input id="tk_qty" type="number" min="1" max="10" value="1" oninput="tkCost()"><button type="button" class="stp" data-for="tk_qty" data-d="1" data-min="1" data-max="10" data-dec="0" title="Sumar">+</button></div></div>
   <div style="flex:1"><label class="tkl">Precio límite</label><div class="sw"><button type="button" class="stp" data-for="tk_px" data-d="-0.01" data-min="0.01" data-max="50" data-dec="2" title="Restar">−</button><input id="tk_px" type="number" step="0.01" min="0.01" oninput="tkManual()"><button type="button" class="stp" data-for="tk_px" data-d="0.01" data-min="0.01" data-max="50" data-dec="2" title="Sumar">+</button></div></div></div>
  <div style="display:flex;gap:6px;margin:6px 0"><button class="tf" onclick="tkRef('bid')" style="flex:1">Bid</button><button class="tf on" id="tk_rm" onclick="tkRef('mid')" style="flex:1">Mid</button><button class="tf" onclick="tkRef('ask')" style="flex:1">Ask</button></div>
  <button id="tk_buy" class="tkbuy" onclick="tkBuy()">COMPRAR</button>
  <div class="mono" id="tk_msg" style="margin-top:6px;font-size:12px;min-height:16px"></div>
  <div class="tkl" style="margin-top:8px">TUS POSICIONES (opciones sueltas)</div><div id="tk_pos" class="mono" style="font-size:12px"></div>
  <div class="tkl" style="margin-top:8px">ÓRDENES ABIERTAS</div><div id="tk_ord" class="mono" style="font-size:12px"></div>
  <div class="tkl" style="margin-top:8px">🤖 GESTOR AUTOMÁTICO <span id="g_state" style="color:var(--ok)"></span></div>
  <div id="gb">
   <div class="mono" style="color:var(--mut);font-size:11px;margin-bottom:6px">Cada compra que hagas aquí queda vigilada: el gestor la cierra con tus reglas (objetivo con orden límite; stop a mercado). Solo funciona con el panel abierto en tu Mac.</div>
   <div id="g_list"></div>
   <details style="margin-top:6px"><summary style="cursor:pointer;color:var(--cy);font-size:12px">Reglas en dólares (para compras nuevas)</summary>
    <div class="mono" style="color:var(--mut);font-size:11px;margin:6px 0">Los montos son POR CONTRATO: se multiplican por los contratos abiertos.</div>
    <div class="gc">
     <div><label>Stop: pérdida máx. ($/contrato)</label><input type="number" id="g_stop" step="5" min="1" oninput="gAtSync()"></div>
     <div><label>Objetivo: ganancia ($/contrato)</label><input type="number" id="g_tp" step="5" min="1" oninput="gAtSync()"></div>
     <div style="grid-column:1/3"><label>Al llegar al objetivo…</label><select id="g_at" onchange="gAtSync()"><option value="trail">Seguir dentro con trailing (cazar más)</option><option value="close">Cerrar y cobrar</option></select></div>
     <div id="g_trw" style="grid-column:1/3"><label>Trailing: cerrar si devuelve ($/contrato) desde el máximo</label><input type="number" id="g_trl" step="5" min="1" oninput="gAtSync()"></div>
     <div class="ck" style="grid-column:1/3"><input type="checkbox" id="g_hon"><span>Cerrar a las</span><input type="text" id="g_hex" style="width:64px" placeholder="15:45"><span>NY (solo si vence hoy)</span></div>
     <div class="ck" style="grid-column:1/3"><input type="checkbox" id="g_auto"><span>Vigilar automáticamente cada compra nueva</span></div>
    </div>
    <div class="mono" id="g_ex" style="color:var(--mut);font-size:11px;margin-top:6px"></div>
    <div style="display:flex;gap:6px;margin-top:6px"><button class="tf go" style="flex:1" onclick="gSave()">Guardar reglas</button><button class="tf" id="g_pause" style="flex:1" onclick="gPause()">Pausar todo</button></div>
    <div class="mono" id="g_msg" style="font-size:11px;margin-top:4px;min-height:14px"></div>
   </details>
   <div id="g_log" class="mono" style="color:var(--mut);font-size:11px;margin-top:6px"></div>
  </div>
  </div>
  <div id="tk_str" style="display:none"><div id="tk_strmsg" class="mono" style="color:var(--warn);font-size:12px;margin-bottom:6px"></div><iframe id="tk_if" title="Constructor de estrategias" style="width:100%;height:min(640px,72vh);border:0;border-radius:8px;background:#000000"></iframe></div>
 </div>
 </div>
 <div class="sub" style="font-size:12px"><span><b style="color:#ff5d6c">━</b> HH (máx. 20 velas)</span><span><b style="color:#4ff0b7">━</b> LL (mín. 20 velas)</span><span><b style="color:#5cc8ff">━</b> entrada del robot (SPY)</span><span style="color:#52a97f">▲ Buy</span><span style="color:#9a7bff">▼ Sell</span><span>👑 verde/roja = 1m, 3m y 5m coinciden</span><span><b style="color:#ffc04d">╌</b> stop / trailing (≈ en SPY)</span><span>▲▼ señales del robot</span><span id="ch_hint" style="color:var(--cy)"></span><span id="ch_msg"></span></div>
</div>
<div class="two">
 <div class="card c3" style="overflow-x:auto"><div class="lbl">ENTRADAS DEL ROBOT HOY</div>
  <table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr style="color:var(--mut);text-align:left"><th>Hora</th><th>Señal</th><th>SPY</th><th>Cerca HH/LL</th><th>Qué hizo el robot</th><th style="text-align:right">Resultado</th></tr></thead>
  <tbody id="entries"><tr><td colspan="6" style="color:var(--mut)">Sin señales hoy</td></tr></tbody></table></div>
 <div class="card c2"><div class="lbl" id="a_lbl">CUENTA DE PAPEL · ROBOT + MANUAL</div>
  <div class="row mono"><span>Realizado hoy</span><b id="a_real">–</b></div>
  <div class="row mono"><span>P&amp;L abierto ahora</span><b id="a_open">–</b></div>
  <div class="row mono"><span>Total cuenta (hoy)</span><b id="a_tot">–</b></div>
  <div class="row mono"><span>Robot (trades.csv)</span><b id="a_bot">–</b></div>
  <div class="row mono"><span>Manual (estimado)</span><b id="a_man">–</b></div>
  <div class="mono" id="a_note" style="color:var(--mut);font-size:12px;margin-top:8px"></div></div>
</div>
<div class="card c2" style="margin-bottom:14px">
 <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px">
  <div class="lbl" style="margin:0">MÉTRICAS DE RENDIMIENTO · <span id="m_src"></span></div>
  <div><span id="rngs"></span> <button class="tf" onclick="expo('xlsx')">⬇ Excel</button> <button class="tf" onclick="expo('pdf')">⬇ PDF</button></div></div>
 <div id="m_grid" class="mono" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px"></div>
 <div class="lbl" style="margin-top:14px">ACIERTOS POR HORA DEL DÍA (hora de tu Mac)</div><div id="m_hours" class="mono" style="font-size:12px"></div>
 <div class="sub" style="margin-top:12px"><span>Avisos activos: <b id="n_ch">–</b></span><button class="tf" onclick="notifTest()">🔔 Probar aviso</button><span id="n_msg"></span>
  <span style="color:var(--mut)">Para tu celular: agrega TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID (o DISCORD_WEBHOOK_URL / SLACK_WEBHOOK_URL) a ~/.tradier_env</span></div>
</div>
<div class="two">
 <div class="card c3"><h2>RENDIMIENTO ACUMULADO DE HOY</h2><svg id="chart" viewBox="0 0 600 190" preserveAspectRatio="none"></svg></div>
 <div class="card"><h2 class="mono ok">TERMINAL LOGS</h2><pre id="log">Esperando bot.log…</pre></div>
</div>
<div id="msg"></div>
<div class="foot" id="foot">Datos reales de bot.log y trades.csv. Se actualiza cada 2 segundos.</div>
</main>
<script>
/* botones − / + con repeticion al mantener presionado */
(function(){let t=null,iv=null;
  const go=b=>{const e=document.getElementById(b.dataset.for);if(!e)return;const d=+b.dataset.d,mn=+b.dataset.min,mx=+b.dataset.max,dec=+b.dataset.dec||0;
    let v=Math.round(((+e.value||0)+d)*1e4)/1e4;v=Math.min(mx,Math.max(mn,v));e.value=dec?v.toFixed(dec):String(Math.round(v));
    e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new Event("change",{bubbles:true}))};
  const stop=()=>{clearTimeout(t);clearInterval(iv);t=iv=null};
  document.addEventListener("pointerdown",e=>{const b=e.target.closest(".stp");if(!b)return;e.preventDefault();stop();go(b);t=setTimeout(()=>{iv=setInterval(()=>go(b),90)},450)});
  ["pointerup","pointercancel","blur"].forEach(x=>window.addEventListener(x,stop));
  document.addEventListener("pointerleave",stop,true)})();
const $=id=>document.getElementById(id);
let SRC="robot",RNG="hoy";
const SRCN={robot:"ROBOT",manual:"MANUAL",all:"COMBINADO"},RNGN={hoy:"Hoy",semana:"Semana",mes:"Mes",todo:"Todo"};
function drawSel(){$("srcs").innerHTML=Object.keys(SRCN).map(k=>'<button class="tf'+(k===SRC?" on":"")+'" onclick="setSrc(\''+k+'\')">'+SRCN[k].charAt(0)+SRCN[k].slice(1).toLowerCase()+"</button>").join(" ");
  $("rngs").innerHTML=Object.keys(RNGN).map(k=>'<button class="tf'+(k===RNG?" on":"")+'" onclick="setRng(\''+k+'\')">'+RNGN[k]+"</button>").join(" ")}
function setSrc(k){SRC=k;lsSet("src",k);drawSel();tick()}
function setRng(k){RNG=k;lsSet("rng",k);drawSel();tick()}
function expo(t){const q="?src="+SRC+"&rng="+RNG;location.href=(t==="xlsx"?"/report.xlsx":"/report.pdf")+q}
async function notifTest(){$("n_msg").textContent="Enviando…";try{const r=await fetch("/notify_test",{method:"POST"});const j=await r.json();$("n_msg").textContent=j.res.join(" · ")}catch(e){$("n_msg").textContent="Error: "+e}}
const fx=(v,d=2)=>v==null?"–":v.toFixed(d);
function paintMetrics(s){const m=s.metrics;$("m_src").textContent=SRCN[s.src]+" · "+RNGN[s.rng].toUpperCase();
  $("n_ch").textContent=(s.notif&&s.notif.length)?s.notif.join(", "):"ninguno";
  const T=(l,v,c)=>'<div style="border:1px solid var(--line);border-radius:10px;padding:8px 10px"><div style="color:var(--mut);font-size:11px">'+l+'</div><div class="'+(c||"")+'" style="font-size:18px;font-weight:700">'+v+"</div></div>";
  $("m_grid").innerHTML=[T("Operaciones",m.n),T("Aciertos",m.win_rate==null?"–":Math.round(100*m.win_rate)+"%  ("+m.wins+"/"+m.n+")"),
    T("P&L total",money(m.total),cls(m.total)),
    T("Comisiones pagadas",m.comm==null?"cargando…":"-$"+m.comm.toFixed(2),m.comm?"bad":""),
    T("P&L − comisiones",m.net==null?"cargando…":money(m.net),m.net==null?"":cls(m.net)),T("Ganancia promedio",m.avg_win==null?"–":money(m.avg_win),"ok"),
    T("Pérdida promedio",m.avg_loss==null?"–":money(-m.avg_loss),"bad"),T("Risk/Reward real",m.payoff==null?"–":fx(m.payoff)+" : 1"),
    T("Profit factor",fx(m.pf)),T("Expectativa / op.",m.expectancy==null?"–":money(m.expectancy),cls(m.expectancy)),
    T("Máx. drawdown",m.max_dd?money(-m.max_dd):"$0.00",m.max_dd?"bad":""),T("Racha máx. de pérdidas",m.max_losing_streak),
    T("Capital invertido total",m.cap_total==null?"–":"$"+m.cap_total.toLocaleString("en-US",{maximumFractionDigits:0})),
    T("Capital prom. / operación",m.cap_avg==null?"–":"$"+m.cap_avg.toFixed(0)),
    T("Retorno s/ capital invertido",m.roc_total==null?"–":(m.roc_total*100).toFixed(2)+"%",m.roc_total==null?"":cls(m.roc_total)),
    T("Retorno prom. / operación",m.roc_avg==null?"–":(m.roc_avg*100).toFixed(1)+"%",m.roc_avg==null?"":cls(m.roc_avg)),
    T("Sharpe (diario, anual.)",m.sharpe==null?"n/d (5+ días)":fx(m.sharpe)),T("Mejor / peor",(m.best==null?"–":money(m.best))+" / "+(m.worst==null?"–":money(m.worst)))].join("");
  $("m_hours").innerHTML=m.by_hour.length?m.by_hour.map(b=>{const w=Math.round(100*b.wr);return '<div style="display:flex;align-items:center;gap:8px;margin:3px 0"><span style="width:48px">'+String(b.h).padStart(2,"0")+':00</span><span style="flex:0 0 160px;background:#1c1c22;border-radius:4px;height:12px;overflow:hidden"><i style="display:block;height:12px;width:'+w+'%;background:'+(w>=50?"#4ff0b7":"#ff5d6c")+'"></i></span><span style="width:130px">'+w+"% ("+b.wins+"/"+b.n+')</span><span class="'+cls(b.pnl)+'">'+money(b.pnl)+"</span></div>"}).join(""):'<span style="color:var(--mut)">Sin operaciones en este periodo</span>'}
/* ===== GRAFICOS: 1-4 paneles, buscador de simbolos, herramientas de dibujo ===== */
const TFS=[["1","1m"],["5","5m"],["15","15m"],["60","1h"],["240","4h"],["D","1D"],["W","1S"],["M","1M"]];const DLY=tf=>tf==="D"||tf==="W"||tf==="M";
const lsGet=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const SYMRE=/^([A-Z][A-Z.\-]{0,5}|\/(ES|MES|NQ|YM|RTY|SPX))$/;   // /ES = futuros del S&P 500 (casi 24 h)
const SVG=(p,extra)=>'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"'+(extra||"")+">"+p+"</svg>";
const LAYOUTS={"1":{n:1,t:"1 gráfico",i:'<rect x="4" y="4" width="16" height="16" rx="2"/>'},
  "2":{n:2,t:"2 gráficos",i:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 4v16"/>'},
  "2v":{n:2,t:"2 gráficos apilados",i:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 12h16"/>'},
  "3":{n:3,t:"3 gráficos",i:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M15 4v16"/>'},
  "4":{n:4,t:"4 gráficos",i:'<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>'},
  "5":{n:5,t:"5 gráficos",i:'<rect x="3" y="4" width="5" height="7" rx="1"/><rect x="9.5" y="4" width="5" height="7" rx="1"/><rect x="16" y="4" width="5" height="7" rx="1"/><rect x="3" y="13" width="8" height="7" rx="1"/><rect x="13" y="13" width="8" height="7" rx="1"/>'}};
const TOOLS=[["cursor","Cursor / seleccionar y mover dibujos",'<path d="M6 3l12 9-6 1.5L9 20z"/>'],
  ["pen","Lápiz: mantén apretado el clic y dibuja a mano (Esc o clic derecho para salir)",'<path d="M4 20l1.2-4.6L15.8 4.8a1.7 1.7 0 0 1 2.4 0l1 1a1.7 1.7 0 0 1 0 2.4L8.6 18.8z"/><path d="M13.8 6.8l3.4 3.4"/>'],
  ["trend","Línea de tendencia",'<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M7.5 16.5L16.5 7.5"/>'],
  ["hline","Línea horizontal",'<path d="M3 12h6M15 12h6"/><circle cx="12" cy="12" r="2"/>'],
  ["vline","Línea vertical",'<path d="M12 3v6M12 15v6"/><circle cx="12" cy="12" r="2"/>'],
  ["arrow","Flecha",'<path d="M5 19L19 5M19 5h-7M19 5v7"/>'],
  ["channel","Canal paralelo (3 clics)",'<path d="M3 14L16 4M8 21L21 11"/><path d="M3 14l5 7M16 4l5 7" stroke-dasharray="2 2"/>'],
  ["rect","Rectángulo",'<rect x="4" y="6" width="16" height="12" rx="1"/>'],
  ["ellipse","Elipse",'<ellipse cx="12" cy="12" rx="9" ry="6"/>'],
  ["fib","Retroceso de Fibonacci",'<path d="M3 5h18M3 10h18M3 15h18M3 20h18"/><path d="M5 20L19 5" stroke-dasharray="2 2"/>']];
const LORDER=["1","2","2v","3","4","5"];
function toggleFS(){const r=$("gcard"),fe=document.fullscreenElement||document.webkitFullscreenElement;
  if(fe){(document.exitFullscreen||document.webkitExitFullscreen).call(document)}
  else{const f=r.requestFullscreen||r.webkitRequestFullscreen;if(f){const p=f.call(r);if(p&&p.catch)p.catch(()=>{})}}}
document.addEventListener("fullscreenchange",()=>{PANES.forEach(p=>{p.dirty=true})});
document.addEventListener("webkitfullscreenchange",()=>{PANES.forEach(p=>{p.dirty=true})});
const NPTS={pen:1e9,trend:2,hline:1,vline:1,arrow:2,channel:3,rect:2,ellipse:2,fib:2};
const FIB=[0,0.236,0.382,0.5,0.618,0.786,1];
let LAYOUT=lsGet("layout","1"),LINK=lsGet("link","1")==="1",PANES=[],ACTIVE=null,LAST=null;
if(!LAYOUTS[LAYOUT])LAYOUT="1";
const DR={};
function drGet(sym){if(!DR[sym]){let a=[];try{a=JSON.parse(lsGet("dr_"+sym,"[]"))}catch(e){}DR[sym]=Array.isArray(a)?a:[]}return DR[sym]}
function drSave(sym){lsSet("dr_"+sym,JSON.stringify(drGet(sym)));PANES.forEach(p=>{if(p.sym===sym)p.dirty=true})}
function dstGet(){let o={};try{o=JSON.parse(lsGet("dstyle","{}"))||{}}catch(e){}return{w:o.w||2,dash:o.dash||"s",op:o.op==null?1:o.op,fill:o.fill==null?0.12:o.fill,ext:o.ext||"n"}}
function dstSet(x){const o=Object.assign(dstGet(),x);lsSet("dstyle",JSON.stringify(o));PANES.forEach(p=>{p.stK=null})}
function hexA(h,a){const m=/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h||"");return m?"rgba("+parseInt(m[1],16)+","+parseInt(m[2],16)+","+parseInt(m[3],16)+","+a+")":h}
function segD(px,py,x1,y1,x2,y2){const dx=x2-x1,dy=y2-y1,L=dx*dx+dy*dy;let t=L?((px-x1)*dx+(py-y1)*dy)/L:0;t=Math.max(0,Math.min(1,t));return Math.hypot(px-(x1+t*dx),py-(y1+t*dy))}
const OPTK=["sig","crown","ema","sma","bot","zz","or","cd","gex"];
const extOn=()=>{const e=document.getElementById("o_ext");return !!(e&&e.checked)};
function extSet(){lsSet("o_ext",extOn()?"1":"0");PANES.forEach(p=>p.load(true))}
const RTH=t=>{const m=t%86400;return m>=34200&&m<57600};
/* precios en tiempo real (streaming de Tradier, solo cuentas reales): el servidor los empuja y la vela se mueve al instante */
let ES=null,ESK="",ESON=false,ESTS={},ESMSG="",ESP={};
function esOpen(){const syms=[...new Set(PANES.map(p=>p.sym))].sort().join(",");if(!syms)return;
  if(ES&&syms===ESK&&ES.readyState!==2)return;ESK=syms;if(ES)try{ES.close()}catch(e){}
  ES=new EventSource("/api/stream?syms="+encodeURIComponent(syms));
  ES.onmessage=e=>{let d;try{d=JSON.parse(e.data)}catch(x){return}const was=ESON;ESON=!!d.on;ESMSG=d.msg||"";
    for(const s in (d.p||{})){const px=d.p[s];ESTS[s]=Date.now();ESP[s]=[px,Date.now()];PANES.forEach(p=>{if(p.sym===s)p.live(px)})}
    if(was!==ESON)PANES.forEach(p=>p.badge&&p.badge())};
  ES.onerror=()=>{ESON=false}}
setInterval(esOpen,2000);
/* niveles de gamma por simbolo (se calculan en el servidor; aqui solo se piden cada minuto) */
const GXM={};let GXT=null;const gxSym=s=>(s==="/SPX"||s==="SPXW")?"SPX":s;
function gexTxt(sym){if(!$("o_gex").checked)return"";const g=GXM[gxSym(sym)];if(!g)return"";if(g.loading)return" · 🧲 calculando gamma…";if(g.error)return" · 🧲 "+g.error;
  return" · 🧲 gamma "+(g.h?g.h+" días":"de hoy")+": ⭐"+g.key+" · CW "+g.call_wall+" · PW "+g.put_wall+(g.flip?" · flip "+Math.round(g.flip):"")}
function gexLines(sym){const g=GXM[gxSym(sym)];if(!g||g.error||g.loading)return[];const out=[];
  if(g.call_wall)out.push([g.call_wall,"#4ff0b7","CALL WALL",3]);if(g.put_wall)out.push([g.put_wall,"#ff5d6c","PUT WALL",3]);if(g.flip)out.push([g.flip,"#ffa726","GAMMA FLIP",1]);if(g.key)out.push([g.key,"#ffd23f","⭐ STRIKE CLAVE",2]);
  return out}
async function gexAll(){clearTimeout(GXT);if(!$("o_gex").checked){PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}
  let h=0;try{const v=localStorage.getItem("gexh");if(v!==null)h=+v}catch(e){}let again=false;
  for(const s of [...new Set(PANES.map(p=>gxSym(p.sym)))]){if(!s||s[0]==="/")continue;
    try{const j=await getj("/api/gex?sym="+encodeURIComponent(s)+"&h="+h);GXM[s]=j;if(j.loading||j.updating)again=true}catch(e){}}
  PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});GXT=setTimeout(gexAll,again?5000:60000)}
setTimeout(gexAll,1500);
function optSave(){OPTK.forEach(k=>lsSet("o_"+k,$("o_"+k).checked?"1":"0"));applyOpts()}
function optLoad(){SRC=lsGet("src","robot");RNG=lsGet("rng","hoy");if(!SRCN[SRC])SRC="robot";if(!RNGN[RNG])RNG="hoy";drawSel();OPTK.forEach(k=>{$("o_"+k).checked=lsGet("o_"+k,"1")==="1"});$("o_ext").checked=lsGet("o_ext","0")==="1"}
function applyOpts(){PANES.forEach(p=>p.applyOpts())}
/* colores y grosor de las medias moviles (se guardan en este navegador) */
function maGet(){return{ce:lsGet("c_ema","#f5a03a"),cs:lsGet("c_sma","#5cc8ff"),we:+lsGet("w_ema","2")||2,ws:+lsGet("w_sma","2")||2}}
function maPaint(){const m=maGet();$("c_ema").value=m.ce;$("c_sma").value=m.cs;$("w_ema").value=String(m.we);$("w_sma").value=String(m.ws);$("l_ema").style.color=m.ce;$("l_sma").style.color=m.cs}
function maSet(){lsSet("c_ema",$("c_ema").value);lsSet("c_sma",$("c_sma").value);lsSet("w_ema",$("w_ema").value);lsSet("w_sma",$("w_sma").value);maPaint();applyOpts()}
class Band{constructor(){this.r=[];this.show=true;this.req=null;this.ch=null;this.se=null}
  attached(p){this.ch=p.chart;this.se=p.series;this.req=p.requestUpdate}detached(){}updateAllViews(){}
  paneViews(){const me=this;return[{zOrder:()=>"bottom",renderer:()=>({draw(t){if(!me.show||!me.ch)return;
    t.useBitmapCoordinateSpace(sc=>{const c=sc.context;c.fillStyle="rgba(63,154,138,0.14)";
      for(const b of me.r){const x1=me.ch.timeScale().timeToCoordinate(b.t1),x2=me.ch.timeScale().timeToCoordinate(b.t2),y1=me.se.priceToCoordinate(b.hi),y2=me.se.priceToCoordinate(b.lo);
        if(x1==null||x2==null||y1==null||y2==null)continue;
        c.fillRect(Math.round(x1*sc.horizontalPixelRatio),Math.round(y1*sc.verticalPixelRatio),Math.max(1,Math.round((x2-x1)*sc.horizontalPixelRatio)),Math.round((y2-y1)*sc.verticalPixelRatio))}})}})}]}}

class Pane{
  constructor(i,sym,tf){this.i=i;this.sym=sym;this.tf=tf;this.bars=[];this.cd=null;this.pl=[];this.first=true;this.gen=0;this.inflight=false;
    this.tool="cursor";this.pts=[];this.hover=null;this.sel=null;this.dirty=true;this.sig="";this.step=60;this.srT=null;this.build()}
  build(){
    const root=document.createElement("div");root.className="pane";
    root.innerHTML='<div class="ph"><input class="psym" list="symlist" spellcheck="false" autocomplete="off" title="Escribe un símbolo o el nombre de una empresa y elige de la lista"><span class="ptf"></span><span class="pinfo mono"></span>'+
      '<span style="margin-left:auto;display:flex;gap:4px"><button class="tf pind" title="Indicadores (RSI, MACD, Bollinger, VWAP, medias…)">ƒx</button><button class="tf pcam" title="Descargar captura (con tus dibujos)">📷</button><button class="tf pfs" title="Pantalla completa">⛶</button></span></div>'+
      '<div class="pb"><div class="ptools"></div><div class="pc"><div class="plw"></div><canvas class="pdr"></canvas><div class="pst"></div><div class="pcd" title="Tiempo que le queda a la vela actual"></div></div></div>';
    const q=s=>root.querySelector(s);
    this.el={root:root,sym:q(".psym"),tfs:q(".ptf"),info:q(".pinfo"),tools:q(".ptools"),pc:q(".pc"),lw:q(".plw"),cv:q(".pdr"),cd:q(".pcd"),cam:q(".pcam"),fs:q(".pfs"),ind:q(".pind"),st:q(".pst")};
    this.el.sym.value=this.sym;this.drawTf();this.buildTools()}
  drawTf(){this.el.tfs.innerHTML=TFS.map(t=>'<button class="tf sm'+(t[0]===this.tf?" on":"")+'" data-tf="'+t[0]+'">'+t[1]+"</button>").join("")}
  buildTools(){
    const T=this.el.tools;
    T.innerHTML=TOOLS.map(t=>'<button class="tl'+(t[0]===this.tool?" on":"")+'" data-t="'+t[0]+'" title="'+t[1]+'">'+SVG(t[2])+"</button>").join("")+
      '<div class="tsep"></div><button class="tl" data-a="del" title="Borrar el dibujo seleccionado (o tecla Suprimir)">'+SVG('<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>')+'</button>'+
      '<button class="tl" data-a="clr" title="Borrar todos los dibujos de este símbolo">'+SVG('<path d="M6 6l12 12M18 6L6 18"/>')+"</button>"}
  syncTools(){this.el.tools.querySelectorAll("[data-t]").forEach(b=>b.classList.toggle("on",b.dataset.t===this.tool));
    this.el.cv.style.pointerEvents=this.tool==="cursor"?"none":"auto";this.el.cv.style.cursor=this.tool==="cursor"?"":"crosshair"}
  init(){
    const E=this.el,me=this;
    if(!window.LightweightCharts){E.info.textContent="No cargó la librería del gráfico (¿sin internet?)";return}
    const ch=this.chart=LightweightCharts.createChart(E.lw,{layout:{background:{color:"#0c0c0f"},textColor:"#9fb0cc"},grid:{vertLines:{color:"#1c1c22"},horzLines:{color:"#1c1c22"}},
      rightPriceScale:{borderColor:"#202027"},timeScale:{borderColor:"#202027",timeVisible:true,secondsVisible:false,rightOffset:6},crosshair:{mode:0},autoSize:true,
      handleScroll:{mouseWheel:false,pressedMouseMove:false,horzTouchDrag:true,vertTouchDrag:false},
      handleScale:{mouseWheel:false,pinch:true,axisPressedMouseMove:false,axisDoubleClickReset:true}});
    this.setAct=on=>{ch.applyOptions({handleScroll:{mouseWheel:on,pressedMouseMove:on,horzTouchDrag:true,vertTouchDrag:false},
      handleScale:{mouseWheel:on,pinch:true,axisPressedMouseMove:on,axisDoubleClickReset:true}});
      E.pc.style.outline=on?"1px solid #5cc8ff":"none";const h=$("ch_hint");if(h)h.textContent=on?"Zoom con la rueda activo · sal del gráfico para volver a desplazar la página":"Haz clic en un gráfico para activar el zoom con la rueda del mouse"};
    this.cs=ch.addCandlestickSeries({upColor:"#4ff0b7",downColor:"#ff5d6c",borderVisible:false,wickUpColor:"#4ff0b7",wickDownColor:"#ff5d6c",priceLineVisible:false});   // sin la linea punteada del precio (la etiqueta en el eje sí queda)
    this.es=ch.addLineSeries({color:"#f5a03a",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
    this.ss=ch.addLineSeries({color:"#5cc8ff",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
    this.zz=ch.addLineSeries({color:"#3b5bff",lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
    this.oh=ch.addLineSeries({color:"#868993",lineWidth:1,priceLineVisible:false,lastValueVisible:true,title:"ORH"});
    this.ol=ch.addLineSeries({color:"#868993",lineWidth:1,priceLineVisible:false,lastValueVisible:true,title:"ORL"});
    this.om=ch.addLineSeries({color:"#868993",lineWidth:1,lineStyle:2,priceLineVisible:false,lastValueVisible:false});
    try{this.band=new Band();this.cs.attachPrimitive(this.band)}catch(e){this.band=null}
    this.vs=ch.addHistogramSeries({priceFormat:{type:"volume"},priceScaleId:""});
    this.vs.priceScale().applyOptions({scaleMargins:{top:0.82,bottom:0}});
    this.setAct(false);this.indInit();
    /* encabezado */
    E.sym.addEventListener("focus",()=>E.sym.select());
    E.sym.addEventListener("input",()=>this.search());
    E.sym.addEventListener("change",()=>{const v=E.sym.value.trim().toUpperCase();if(SYMRE.test(v))setSymbol(this,v);else{E.sym.value=this.sym;E.info.textContent="Símbolo no válido"}});
    E.sym.addEventListener("keydown",e=>{if(e.key==="Enter")E.sym.blur()});
    E.tfs.addEventListener("click",e=>{const b=e.target.closest("[data-tf]");if(b)this.setTf(b.dataset.tf)});
    E.cam.onclick=()=>this.shot();
    E.fs.onclick=()=>toggleFS();
    E.tools.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;ACTIVE=this;
      if(b.dataset.t)this.setTool(b.dataset.t);else if(b.dataset.a==="del")this.delSel();else if(b.dataset.a==="clr")this.clearAll()});
    /* zoom con la rueda solo tras hacer clic; seleccion y arrastre de dibujos */
    E.pc.addEventListener("mouseleave",()=>this.setAct(false));
    /* recuerda el zoom (cuantas velas se ven y el espacio a la derecha) por grafico y temporalidad */
    ch.timeScale().subscribeVisibleLogicalRangeChange(r=>{if(!r||this.first)return;clearTimeout(this.zt);
      this.zt=setTimeout(()=>{const n=this.cs.data().length;if(n>1&&r.to>r.from)lsSet("zoom"+this.i+"_"+this.tf,JSON.stringify({w:+(r.to-r.from).toFixed(2),r:+(r.to-(n-1)).toFixed(2)}))},500)});
    E.st.addEventListener("mousedown",e=>e.stopPropagation());E.st.addEventListener("input",e=>this.stEv(e));E.st.addEventListener("change",e=>this.stEv(e));E.st.addEventListener("click",e=>this.stEv(e));
    E.st.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.dataset&&e.target.dataset.k==="price"){e.preventDefault();e.target.blur()}});
    E.pc.addEventListener("mousedown",e=>{if(window.LN&&LN.pick&&e.button===0&&lnSymOk(this.sym)&&!e.target.closest(".pst")){   // robot de lineas: poniendo entrada / stop / ganancia
        const r=this.rel(e),pr=this.cs.coordinateToPrice(r.y);if(pr!=null){lnPickAt(+pr.toFixed(2))}e.stopPropagation();e.preventDefault();return}
      if(e.target.closest(".pst"))return;ACTIVE=this;
      if(window.LN&&e.button===0&&this.tool==="cursor"&&lnSymOk(this.sym)){const h=this.lnHit(this.rel(e).y);if(h){this.lnDrag(h,e);e.stopPropagation();e.preventDefault();return}}   // arrastrar una linea del robot
PANES.forEach(p=>p.el.root.classList.toggle("act",p===this));this.setAct(true);
      if(this.tool!=="cursor"||e.button!==0)return;
      const r=this.rel(e),h=this.hit(r.x,r.y);
      if(h){this.sel=h.d.id;this.dirty=true;this.startDrag(h.d,h.idx,e);e.stopPropagation();e.preventDefault();return}
      else if(this.sel){this.sel=null;this.dirty=true}
      /* arrastrar arriba/abajo: se suelta la escala automatica para poder mover el precio (como TradingView).
         Si solo diste clic o moviste a los lados, vuelve a la escala automatica. Doble clic en los numeros de la derecha = volver a ajustar */
      const ps=this.cs.priceScale(),ax=ps.width();
      if(r.x<E.lw.clientWidth-ax){const was=ps.options().autoScale,y0=e.clientY;let moved=false;
        ps.applyOptions({autoScale:false});
        const mv=ev=>{if(Math.abs(ev.clientY-y0)>4)moved=true};
        const up=()=>{window.removeEventListener("mousemove",mv,true);window.removeEventListener("mouseup",up,true);if(was&&!moved)ps.applyOptions({autoScale:true})};
        window.addEventListener("mousemove",mv,true);window.addEventListener("mouseup",up,true)}},true);
    E.pc.addEventListener("mousemove",e=>{if(this.tool!=="cursor"||this.dragging)return;const r=this.rel(e);
      if(window.LN&&lnSymOk(this.sym)&&this.lnHit(r.y)){E.lw.style.cursor="ns-resize";return}
      E.lw.style.cursor=this.hit(r.x,r.y)?"pointer":""});
    E.cv.addEventListener("mousemove",e=>{this.hover=this.pt(e);this.dirty=true});
    E.cv.addEventListener("click",e=>this.click(e));
    E.cv.addEventListener("mousedown",e=>{if(this.tool!=="pen"||e.button!==0)return;const p0=this.pt(e);if(!p0)return;e.preventDefault();   /* 25-nov: lapiz */
      const r0=this.rel(e);let last=r0;this.pts=[p0];this.hover=null;this.dragging=true;this.dirty=true;
      const mv=ev=>{const r=this.rel(ev);if(Math.hypot(r.x-last.x,r.y-last.y)<3||this.pts.length>=800)return;const q=this.pt(ev);if(!q)return;last=r;this.pts.push(q);this.dirty=true};
      const up=()=>{window.removeEventListener("mousemove",mv,true);window.removeEventListener("mouseup",up,true);this.dragging=false;
        const P=this.pts.slice();this.pts=[];this.dirty=true;if(P.length<2)return;
        const d=Object.assign({id:"d"+Date.now().toString(36)+Math.random().toString(36).slice(2,5),type:"pen",pts:P.map(q=>({t:q.t,p:Math.round(q.p*1000)/1000})),color:this.color()},dstGet());
        drGet(this.sym).push(d);drSave(this.sym)};   /* el lapiz sigue puesto para el siguiente trazo */
      window.addEventListener("mousemove",mv,true);window.addEventListener("mouseup",up,true)});
    E.cv.addEventListener("contextmenu",e=>{e.preventDefault();this.escape()});
    this.syncTools()}
  destroy(){try{this.chart&&this.chart.remove()}catch(e){}this.el.root.remove()}
  /* ---------- simbolo / intervalo ---------- */
  setTf(tf){this.tf=tf;lsSet("ptf"+this.i,tf);if(this.i===0)lsSet("tf",tf);this.drawTf();this.reload()}
  reload(){this.gen++;this.inflight=false;this.first=true;this.sel=null;this.pts=[];this.hover=null;this.clearData();
    this.msg("⏳ Cargando "+this.sym+" · "+({"1":"1 min","5":"5 min","15":"15 min","60":"1 hora","240":"4 horas","D":"1 día","W":"1 semana","M":"1 mes"}[this.tf]||this.tf)+"… (si Tradier tarda, puede tomar unos segundos)");this.load(true)}
  clearData(){if(!this.chart)return;[this.cs,this.es,this.ss,this.zz,this.oh,this.ol,this.om,this.vs].forEach(s=>s.setData([]));this.cs.setMarkers([]);this.indEmpty&&this.indEmpty();
    if(this.band){this.band.r=[];this.band.req&&this.band.req()}this.pl.forEach(l=>{try{this.cs.removePriceLine(l)}catch(e){}});this.pl=[];this.plSig=null;this.bars=[];this.cd=null;this.dirty=true}
  search(){clearTimeout(this.srT);const q=this.el.sym.value.trim();if(!q)return;
    this.srT=setTimeout(async()=>{try{const j=await getj("/api/search?q="+encodeURIComponent(q));
      if(j.results)$("symlist").innerHTML=j.results.map(r=>'<option value="'+esc(r.sym)+'" label="'+esc(r.name+(r.ex?" · "+r.ex:""))+'"></option>').join("")}catch(e){}},250)}
  msg(t){if(this.el.info.textContent!==t){this.el.info.textContent=t;this.el.info.title=t}}   // un solo renglon: el grafico no cambia de alto
  /* ---------- datos ---------- */
  /* precio en vivo: mueve la ultima vela (o abre la siguiente) sin esperar la recarga completa */
  live(px){
    if(!this.cs||!this.bars||!this.bars.length||!(px>0))return;
    const B=this.bars,last=B[B.length-1];
    if(!DLY(this.tf)){const now=nyNow(),st=this.step||60;
      if(now>=last.time+st){const k=Math.floor((now-last.time)/st);
        if(nyMin(now)>=(extOn()?1200:960))return;   // aunque falten velas de Tradier, el precio en vivo siempre se ve   // hueco raro (o ya cerro el mercado): espero la recarga completa
        const nb={time:last.time+k*st,open:px,high:px,low:px,close:px,volume:0};B.push(nb);this.cs.update(nb);return}}
    last.close=px;if(px>last.high)last.high=px;if(px<last.low)last.low=px;
    this.cs.update({time:last.time,open:last.open,high:last.high,low:last.low,close:last.close})}
  async load(reset){
    if(!this.chart||(this.inflight&&!reset))return;
    const gen=this.gen;this.inflight=true;
    try{
      const r=await fetch("/api/candles?i="+this.tf+"&sym="+encodeURIComponent(this.sym)+(extOn()?"&ext=1":""),{cache:"no-store"});
      let c;try{c=JSON.parse(await r.text())}catch(x){   // respuesta cortada (Tradier muy lento o se cortó la conexión): reintenta solo
        if(gen===this.gen){this.msg("⏳ Tradier está tardando en mandar las velas; reintentando…");if(!this.bars.length)setTimeout(()=>{if(gen===this.gen)this.load(true)},3000)}return}
      if(gen!==this.gen)return;
      if(c.error){if(this.bars.length){this.msg("⏳ Tradier tardó en mandar las velas; sigo con las últimas ("+String(c.error).slice(0,60)+")");return}
        this.msg(c.error+" · reintentando…");setTimeout(()=>{if(gen===this.gen&&!this.bars.length)this.load(true)},4000);return}
      if(!c.bars||!c.bars.length){if(this.bars.length)return;   // lista vacia un momento: no apagar la grafica
        if(!c.fut){this.msg("⏳ Tradier no mandó velas todavía; reintentando…");setTimeout(()=>{if(gen===this.gen&&!this.bars.length)this.load(true)},3000);return}}
      if(!reset&&this.bars.length&&c.bars&&c.bars.length&&!DLY(this.tf)){   // el historial de Tradier llega unos segundos atrasado
        const lt=c.bars[c.bars.length-1].time;for(const b of this.bars)if(b.time>lt)c.bars.push(Object.assign({},b))}
      const orr=c.or||{h:[],l:[],m:[],brk:[],bands:[]};
      this.cd=c;this.bars=c.bars;
      const ds=[];for(let i=Math.max(1,c.bars.length-30);i<c.bars.length;i++){const d=c.bars[i].time-c.bars[i-1].time;if(d>0)ds.push(d)}
      this.step=ds.length?Math.min.apply(null,ds):60;
      this.oh.setData(orr.h);this.ol.setData(orr.l);this.om.setData(orr.m);if(this.band){this.band.r=orr.bands;this.band.req&&this.band.req()}
      this.zz.setData((c.zz||[]).filter((p,i,a)=>i===a.length-1||a[i+1].time!==p.time).map((p,i)=>({time:p.time,value:p.price,color:i===0?"#3b5bff":(p.hi?"#3b5bff":"#ef5b57")})));
      this.es.setData(c.ema||[]);this.ss.setData(c.sma||[]);
      this.cs.setData(c.bars.map(b=>{const o={time:b.time,open:b.open,high:b.high,low:b.low,close:b.close};
        if(c.ext&&!RTH(b.time)){const up=b.close>=b.open,col=up?"rgba(79,240,183,.32)":"rgba(255,93,108,.32)";o.color=col;o.wickColor=col;o.borderColor=col}return o}));   // premarket / aftermarket mas tenues
      this.vs.setData(c.bars.map(b=>({time:b.time,value:b.volume,color:b.close>=b.open?"rgba(79,240,183,.35)":"rgba(255,93,108,.35)"})));
      {const lp=(typeof ESP!=="undefined")&&ESP[this.sym];if(lp&&Date.now()-lp[1]<5000)this.live(lp[0])}   // sin parpadeo: el precio del streaming va encima de la ultima vela de inmediato
      this.lines(c);this.applyOpts();this.indData();
      const sp=ESP[this.sym];if(sp&&Date.now()-sp[1]<3000)this.live(sp[0]);   // y vuelve a poner el precio en vivo enseguida
      if(reset||this.first){
        const N={"1":120,"5":100,"15":90,"60":90,"240":70,"D":120,"W":104,"M":60}[this.tf]||100,n=c.bars.length;
        this.cs.priceScale().applyOptions({autoScale:true});
        let z=null;try{z=JSON.parse(lsGet("zoom"+this.i+"_"+this.tf,"null"))}catch(e){}
        if(z&&z.w>=5&&z.w<=5000&&Math.abs(z.r)<=500){const to=n-1+z.r;this.chart.timeScale().setVisibleLogicalRange({from:to-z.w,to})}   // como lo dejaste
        else this.chart.timeScale().setVisibleLogicalRange({from:Math.max(-1,n-N),to:n+6});
        this.first=false}
      const l=c.bars[c.bars.length-1];
      this.msg(l?(c.fut?(c.real?"🟢 /SPX · "+l.close.toFixed(2)+" · horario normal: SPX OFICIAL de Tradier en tiempo real (fuera de horario vuelve al estimado con /ES)":"🌙 "+this.sym+" · "+c.fut+" · "+l.close.toFixed(2)+" · Yahoo, ~10 min de retraso · casi 24 h · solo para ver"+(this.sym==="/SPX"?" (estimado, no es el índice oficial)":" (NO es el SPX)")):this.sym+" "+l.close.toFixed(2)+" · "+(LIVE?"cuenta REAL"+(ESON?" · ⚡ tiempo real (streaming)":""):"papel ~15 min de retraso")+gexTxt(this.sym)+(c.yahoo?" · 📡 velas de respaldo (Yahoo)":""))+(c.vol_proxy?" · volumen y VWAP con el de "+c.vol_proxy+" (el índice no tiene volumen)":""):"Sin velas para "+this.sym+" (mercado cerrado, símbolo sin datos o sin permiso)");
      this.dirty=true;
    }catch(e){if(gen===this.gen)this.msg("Error del gráfico: "+e)}
    finally{if(gen===this.gen)this.inflight=false}}
  applyOpts(){if(!this.chart)return;const m=maGet();this.es.applyOptions({visible:$("o_ema").checked,color:m.ce,lineWidth:m.we});this.ss.applyOptions({visible:$("o_sma").checked,color:m.cs,lineWidth:m.ws});
    const on=$("o_or").checked;[this.oh,this.ol,this.om].forEach(x=>x.applyOptions({visible:on}));if(this.band){this.band.show=on;this.band.req&&this.band.req()}
    this.zz.applyOptions({visible:$("o_zz").checked});this.marks()}
  lines(c){
    const want=[],add=(p,col,t,st)=>{if(p!=null)want.push([p,col,t,st])};
    if($("o_gex").checked)gexLines(this.sym).forEach(x=>add(x[0],x[1],x[2],x[3]));   // (ya no se dibujan las lineas HH/LL)
    if(window.LN&&lnSymOk(this.sym))lnLines().forEach(x=>add(x[0],x[1],x[2],x[3]));
    const p=this.sym==="SPY"&&LAST&&LAST.pos;
    if(p){add(p.spy,"#5cc8ff","ENTRADA "+p.side,0);add(p.stop_spy,"#ffc04d",(p.trail?"TRAILING":"STOP")+" ≈ opción "+p.stop.toFixed(2),1)}
    posLines(this.sym).forEach(x=>add(x[0],x[1],x[2],x[3]));
    const sig=JSON.stringify(want);if(sig===this.plSig&&this.pl.length===want.length)return;this.plSig=sig;
    this.pl.forEach(l=>{try{this.cs.removePriceLine(l)}catch(e){}});
    this.pl=want.map(x=>this.cs.createPriceLine({price:x[0],color:x[1],lineWidth:1,lineStyle:x[3],axisLabelVisible:true,title:x[2]}))}
  snap(t){let b=null;for(const x of this.bars){if(x.time<=t)b=x.time;else break}return b}
  marks(){
    if(!this.chart)return;const CD=this.cd,out=[],seen=new Set();
    const add=(t,m)=>{if(t==null)return;const k=t+m.position+m.text;if(seen.has(k))return;seen.add(k);out.push(Object.assign({time:t},m))};
    if(CD&&$("o_sig").checked)CD.signals.forEach(g=>{const buy=g.side==="BUY";add(g.time,{position:buy?"belowBar":"aboveBar",shape:buy?"arrowUp":"arrowDown",color:buy?"#52a97f":"#9a7bff",text:buy?"Buy":"Sell"})});
    if(CD&&$("o_crown").checked)CD.crowns.forEach(c=>{const up=c.dir==="UP";add(this.snap(c.time),{position:up?"belowBar":"aboveBar",shape:"circle",color:up?"#4ff0b7":"#ff5d6c",text:"👑"})});
    if(CD&&$("o_or").checked&&CD.or)CD.or.brk.forEach(g=>{const up=g.dir==="UP";add(g.time,{position:up?"belowBar":"aboveBar",shape:up?"arrowUp":"arrowDown",color:up?"#3f9a8a":"#3b5bff",text:"OR"+(up?"↑":"↓"),size:2})});
    if(CD&&$("o_zz").checked)(CD.zz||[]).forEach(p=>{const hl=p.label==="HH"||p.label==="LH";
      add(p.time,{position:p.hi?"aboveBar":"belowBar",shape:"circle",color:p.hi?"#ef5b57":"#6f8bff",text:p.label,size:0})});
    if(this.sym==="SPY"&&$("o_bot").checked)((LAST&&LAST.entries)||[]).forEach(e=>{if(e.bt==null||!/ENTR|SIMUL/.test(e.res))return;
      add(this.snap(e.bt),{position:e.side==="BUY"?"belowBar":"aboveBar",shape:"square",color:"#5cc8ff",text:"BOT "+e.side})});
    out.sort((a,b)=>a.time-b.time);this.cs.setMarkers(out)}
  /* ---------- tiempo/precio <-> pantalla (los dibujos se anclan a tiempo y precio) ---------- */
  tl(t){const B=this.bars,n=B.length;if(!n)return null;
    if(t<=B[0].time)return (t-B[0].time)/(n>1?B[1].time-B[0].time:60);
    if(t>=B[n-1].time)return n-1+(t-B[n-1].time)/this.step;
    let lo=0,hi=n-1;while(hi-lo>1){const m=(lo+hi)>>1;if(B[m].time<=t)lo=m;else hi=m}
    return lo+(t-B[lo].time)/(B[hi].time-B[lo].time)}
  lt(l){const B=this.bars,n=B.length;if(!n)return 0;
    if(l<=0)return Math.round(B[0].time+l*(n>1?B[1].time-B[0].time:60));
    if(l>=n-1)return Math.round(B[n-1].time+(l-(n-1))*this.step);
    const i=Math.floor(l);return Math.round(B[i].time+(l-i)*(B[i+1].time-B[i].time))}
  px(q){const l=this.tl(q.t);return{x:l==null?null:this.chart.timeScale().logicalToCoordinate(l),y:this.cs.priceToCoordinate(q.p)}}
  rel(e){const r=this.el.lw.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
  plot(){const w=this.el.lw.clientWidth,h=this.el.lw.clientHeight;let pw=56,th=28;
    try{pw=this.chart.priceScale("right").width()||56}catch(e){}try{th=this.chart.timeScale().height()||28}catch(e){}
    return{w:Math.max(10,w-pw),h:Math.max(10,h-th)}}
  pt(e){if(!this.bars.length)return null;const r=this.rel(e);if(r.x>this.plot().w||r.y>this.plot().h)return null;
    const l=this.chart.timeScale().coordinateToLogical(r.x),p=this.cs.coordinateToPrice(r.y);
    return(l==null||p==null)?null:{t:this.lt(l),p:p}}
  color(){return $("dcol").value||"#f5c542"}
  /* ---------- crear dibujos ---------- */
  setTool(t){this.tool=t;this.pts=[];this.hover=null;if(t!=="cursor")this.sel=null;this.syncTools();this.dirty=true}
  click(e){
    if(this.tool==="cursor"||this.tool==="pen")return;const p=this.pt(e);if(!p)return;
    this.pts.push(p);
    if(this.pts.length>=NPTS[this.tool]){
      const d=Object.assign({id:"d"+Date.now().toString(36)+Math.random().toString(36).slice(2,5),type:this.tool,pts:this.pts.slice(),color:this.color()},dstGet());
      drGet(this.sym).push(d);drSave(this.sym);this.setTool("cursor");this.sel=d.id}
    this.dirty=true}
  escape(){if(this.pts.length){this.pts=[];this.hover=null}else if(this.tool!=="cursor")this.setTool("cursor");else this.sel=null;this.dirty=true}
  delSel(){if(!this.sel)return;const a=drGet(this.sym),i=a.findIndex(d=>d.id===this.sel);if(i>=0){a.splice(i,1);drSave(this.sym)}this.sel=null;this.dirty=true}
  clearAll(){const a=drGet(this.sym);if(!a.length)return;if(!confirm("¿Borrar los "+a.length+" dibujo(s) de "+this.sym+"?"))return;a.length=0;drSave(this.sym);this.sel=null;this.dirty=true}
  setColor(c){if(!this.sel)return;const d=drGet(this.sym).find(x=>x.id===this.sel);if(d){d.color=c;drSave(this.sym)}}
  /* ---------- seleccionar y mover ---------- */
  chBase(d){const A=d.pts[0],B=d.pts[1],C=d.pts[2],lA=this.tl(A.t),lB=this.tl(B.t),lC=this.tl(C.t);return lB===lA?A.p:A.p+(B.p-A.p)*(lC-lA)/(lB-lA)}
  /* lineas del robot: cual esta bajo el mouse (a 6 px) y arrastrarla arriba/abajo */
  lnHit(y){if(!this.cs||!window.LN)return null;let best=null;
    for(const o of LN.ops){const keys=o.status==="esperando"?["entry","stop","tp"]:o.status==="dentro"?["stop","tp"]:[];
      for(const k of keys){const v=(LN.drag&&LN.drag.id===o.id&&LN.drag.k===k)?LN.drag.v:o[k],yy=this.cs.priceToCoordinate(v);
        if(yy!=null&&Math.abs(yy-y)<=6&&(!best||Math.abs(yy-y)<best.d))best={id:o.id,k:k,d:Math.abs(yy-y),o:o}}}
    return best}
  lnDrag(h,e){const me=this,o=h.o;LN.drag={id:o.id,k:h.k,v:o[h.k]};me.dragging=true;
    const mv=ev=>{const r=me.rel(ev),pr=me.cs.coordinateToPrice(r.y);if(pr==null)return;LN.drag.v=Math.round(pr*4)/4;PANES.forEach(p=>{if(p.cd&&lnSymOk(p.sym))p.lines(p.cd)})};
    const up=async()=>{window.removeEventListener("mousemove",mv,true);window.removeEventListener("mouseup",up,true);me.dragging=false;
      const d=LN.drag;LN.drag=null;if(!d||d.v===o[d.k]){PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}
      const nv={entry:o.entry,stop:o.stop,tp:o.tp};nv[d.k]=d.v;
      const ok=o.dir==="alcista"?(nv.tp>nv.entry&&nv.entry>nv.stop):(nv.tp<nv.entry&&nv.entry<nv.stop);
      if(!ok){notify("✖ Así se voltearía la operación (la ganancia y el stop deben quedar de lados opuestos de la entrada). Regresé la línea.");PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}
      o[d.k]=d.v;PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});
      const j=await post("/api/lineas",{id:o.id,action:"set",[d.k==="entry"?"entry":d.k==="stop"?"stop":"tp"]:d.v});
      if(j.error)notify("✖ "+j.error);else notify("✓ "+({entry:"Entrada",stop:"Stop",tp:"Ganancia"}[d.k])+" movida a "+d.v);LN.sig=null;lnLoad()};
    window.addEventListener("mousemove",mv,true);window.addEventListener("mouseup",up,true)}
  pt(e){if(!this.bars.length)return null;const r=this.rel(e);if(r.x>this.plot().w||r.y>this.plot().h)return null;
    const l=this.chart.timeScale().coordinateToLogical(r.x),p=this.cs.coordinateToPrice(r.y);
    return(l==null||p==null)?null:{t:this.lt(l),p:p}}
  color(){return $("dcol").value||"#f5c542"}
  /* ---------- crear dibujos ---------- */
  setTool(t){this.tool=t;this.pts=[];this.hover=null;if(t!=="cursor")this.sel=null;this.syncTools();this.dirty=true}
  click(e){
    if(this.tool==="cursor"||this.tool==="pen")return;const p=this.pt(e);if(!p)return;
    this.pts.push(p);
    if(this.pts.length>=NPTS[this.tool]){
      const d=Object.assign({id:"d"+Date.now().toString(36)+Math.random().toString(36).slice(2,5),type:this.tool,pts:this.pts.slice(),color:this.color()},dstGet());
      drGet(this.sym).push(d);drSave(this.sym);this.setTool("cursor");this.sel=d.id}
    this.dirty=true}
  escape(){if(this.pts.length){this.pts=[];this.hover=null}else if(this.tool!=="cursor")this.setTool("cursor");else this.sel=null;this.dirty=true}
  delSel(){if(!this.sel)return;const a=drGet(this.sym),i=a.findIndex(d=>d.id===this.sel);if(i>=0){a.splice(i,1);drSave(this.sym)}this.sel=null;this.dirty=true}
  clearAll(){const a=drGet(this.sym);if(!a.length)return;if(!confirm("¿Borrar los "+a.length+" dibujo(s) de "+this.sym+"?"))return;a.length=0;drSave(this.sym);this.sel=null;this.dirty=true}
  setColor(c){if(!this.sel)return;const d=drGet(this.sym).find(x=>x.id===this.sel);if(d){d.color=c;drSave(this.sym)}}
  /* ---------- seleccionar y mover ---------- */
  chBase(d){const A=d.pts[0],B=d.pts[1],C=d.pts[2],lA=this.tl(A.t),lB=this.tl(B.t),lC=this.tl(C.t);return lB===lA?A.p:A.p+(B.p-A.p)*(lC-lA)/(lB-lA)}
  hit(x,y){
    const arr=drGet(this.sym);
    if(this.sel){const d=arr.find(q=>q.id===this.sel);if(d&&d.type!=="pen"){const P=d.pts.map(q=>this.px(q));
      for(let i=0;i<P.length;i++)if(P[i].x!=null&&P[i].y!=null&&Math.hypot(P[i].x-x,P[i].y-y)<=8)return{d:d,idx:i}}}
    for(let k=arr.length-1;k>=0;k--)if(this.near(arr[k],x,y))return{d:arr[k],idx:-1};
    return null}
  near(d,x,y){
    const P=d.pts.map(q=>this.px(q));if(P.some(q=>q.x==null||q.y==null))return false;const T=6,pl=this.plot();
    switch(d.type){
      case"trend":case"arrow":return segD(x,y,P[0].x,P[0].y,P[1].x,P[1].y)<T;
      case"pen":for(let k=1;k<P.length;k++)if(segD(x,y,P[k-1].x,P[k-1].y,P[k].x,P[k].y)<T)return true;return false;
      case"hline":return Math.abs(y-P[0].y)<T;
      case"vline":return Math.abs(x-P[0].x)<T;
      case"rect":{const x1=Math.min(P[0].x,P[1].x),x2=Math.max(P[0].x,P[1].x),y1=Math.min(P[0].y,P[1].y),y2=Math.max(P[0].y,P[1].y);
        return(x>=x1-T&&x<=x2+T&&(Math.abs(y-y1)<T||Math.abs(y-y2)<T))||(y>=y1-T&&y<=y2+T&&(Math.abs(x-x1)<T||Math.abs(x-x2)<T))}
      case"ellipse":{const cx=(P[0].x+P[1].x)/2,cy=(P[0].y+P[1].y)/2,rx=Math.abs(P[0].x-P[1].x)/2,ry=Math.abs(P[0].y-P[1].y)/2;if(rx<2||ry<2)return false;
        return Math.abs(Math.hypot((x-cx)/rx,(y-cy)/ry)-1)*Math.min(rx,ry)<T}
      case"channel":{if(segD(x,y,P[0].x,P[0].y,P[1].x,P[1].y)<T)return true;if(d.pts.length<3)return false;
        const off=d.pts[2].p-this.chBase(d),y1=this.cs.priceToCoordinate(d.pts[0].p+off),y2=this.cs.priceToCoordinate(d.pts[1].p+off);
        return y1!=null&&y2!=null&&segD(x,y,P[0].x,y1,P[1].x,y2)<T}
      case"fib":{const xa=Math.min(P[0].x,P[1].x)-T,xb=Math.max(P[0].x,P[1].x)+T;if(x<xa||x>xb)return false;
        return FIB.some(lv=>{const yy=this.cs.priceToCoordinate(d.pts[1].p+(d.pts[0].p-d.pts[1].p)*lv);return yy!=null&&Math.abs(y-yy)<T})}}
    return false}
  startDrag(d,idx,e){
    if(d.lock)return;   // dibujo bloqueado: se puede seleccionar pero no mover
    const r0=this.rel(e),ts=this.chart.timeScale(),l0=ts.coordinateToLogical(r0.x),p0=this.cs.coordinateToPrice(r0.y);
    const orig=JSON.parse(JSON.stringify(d.pts)),off0=d.type==="channel"&&d.pts.length>=3?d.pts[2].p-this.chBase(d):0;
    this.dragging=true;
    const mv=ev=>{const r=this.rel(ev),l=ts.coordinateToLogical(r.x),p=this.cs.coordinateToPrice(r.y);if(l==null||p==null||l0==null||p0==null)return;
      if(idx>=0){d.pts[idx]={t:this.lt(l),p:p};
        if(d.type==="channel"&&idx!==2)d.pts[2].p=this.chBase(d)+off0}
      else{const dl=l-l0,dp=p-p0;d.pts=orig.map(q=>({t:this.lt(this.tl(q.t)+dl),p:q.p+dp}))}
      this.dirty=true};
    const up=()=>{document.removeEventListener("mousemove",mv);this.dragging=false;drSave(this.sym)};
    document.addEventListener("mousemove",mv);document.addEventListener("mouseup",up,{once:true})}
  /* ---------- cuenta regresiva de la vela (hora de Nueva York; velas ancladas a las 9:30) ---------- */
  cd2(){
    const E=this.el.cd;if(!E)return;
    if(!this.chart||!this.bars.length||!$("o_cd").checked||this.tf==="W"||this.tf==="M"){E.style.display="none";return}
    const n=nyClock(),IDX=["SPX","NDX","RUT","VIX","XSP","DJX"].includes(String(this.sym||"").toUpperCase());
    const ext=!n.open&&(n.pre||n.post)&&this.tf!=="D"&&!IDX&&(typeof extOn==="function"&&extOn());   // 🌙 premarket / aftermarket
    if(!n.open&&!ext){E.style.display="none";return}
    const step=this.tf==="D"?23400:({"1":60,"5":300,"15":900,"60":3600,"240":14400}[this.tf]||60);
    const a0=ext?(n.pre?14400:57600):34200,len=ext?(n.pre?19800:14400):23400;   // premarket 4:00-9:30 · aftermarket 16:00-20:00
    const s=n.sec-a0,end=Math.min((Math.floor(s/step)+1)*step,len),rem=Math.max(0,end-s);
    const lb=this.bars[this.bars.length-1],y=this.cs.priceToCoordinate(lb.close),pl=this.plot(),W=this.el.lw.clientWidth;
    if(y==null||y<0||y>pl.h){E.style.display="none";return}
    const h=Math.floor(rem/3600),mi=Math.floor(rem%3600/60),se=rem%60,p2=v=>String(v).padStart(2,"0");
    const txt=h?h+":"+p2(mi)+":"+p2(se):p2(mi)+":"+p2(se);
    if(E.textContent!==txt)E.textContent=txt;
    E.style.display="block";E.style.left=pl.w+"px";E.style.width=Math.max(40,W-pl.w)+"px";
    E.style.top=(y+10+18>pl.h?y-28:y+10)+"px";E.style.background=lb.close>=lb.open?"#4ff0b7":"#ff5d6c"}
  /* ---------- dibujar ---------- */
  /* ---------- barra de estilo del dibujo (grosor, tipo de linea, transparencia, relleno, texto, extender, bloquear) ---------- */
  stTarget(){return this.sel?drGet(this.sym).find(x=>x.id===this.sel):null}
  stRender(){const E=this.el.st,d=this.stTarget(),newT=this.tool!=="cursor"?this.tool:null;
    if(!d&&!newT){E.style.display="none";return}
    const S=d||Object.assign({color:this.color()},dstGet()),type=d?d.type:newT,w=S.w||2,dash=S.dash||"s",op=S.op==null?1:S.op,fill=S.fill==null?0.12:S.fill;
    const B=(k,v,t,ti)=>'<button data-k="'+k+'" data-v="'+v+'" class="'+(String(S[k]==null?{w:2,dash:"s",ext:"n"}[k]:S[k])===String(v)?"on":"")+'"'+(ti?' title="'+ti+'"':"")+'>'+t+'</button>';
    let h='<span>'+(d?"<b>Dibujo</b>":"<b>Nuevo</b>")+'</span><input type="color" data-k="color" value="'+(S.color||"#f5c542")+'" title="Color">'
      +'<span class="sep"></span><span class="sg" title="Grosor">'+[1,2,3,4,6].map(v=>B("w",v,v+"px")).join("")+'</span>'
      +'<span class="sep"></span><span class="sg" title="Tipo de línea">'+B("dash","s","━","Continua")+B("dash","d","╍","Guiones")+B("dash","o","┈","Puntos")+'</span>'
      +'<span class="sep"></span><span class="sg" title="Transparencia de la línea">Opac <input type="range" data-k="op" min="10" max="100" step="5" value="'+Math.round(op*100)+'"><span>'+Math.round(op*100)+'%</span></span>';
    if(["rect","ellipse","channel"].includes(type))h+='<span class="sep"></span><span class="sg" title="Transparencia del relleno">Relleno <input type="range" data-k="fill" min="0" max="80" step="2" value="'+Math.round(fill*100)+'"><span>'+Math.round(fill*100)+'%</span></span>';
    if(["trend","arrow","channel"].includes(type))h+='<span class="sep"></span><span class="sg" title="Extender la línea">'+B("ext","n","—","Sin extender")+B("ext","r","→","Extender a la derecha")+B("ext","b","↔","Extender a los dos lados")+'</span>';
    if(type==="hline"){const pv=d&&d.pts[0]?(+d.pts[0].p).toFixed(2):"";   /* 25-nov: escribir el precio exacto de la linea */
      h+='<span class="sep"></span><span class="sg" title="'+(d?"Escribe el precio y pulsa Enter: la línea se mueve ahí":"Escribe el precio y pulsa Enter: la línea se pone ahí")+'">Precio <input type="number" data-k="price" step="0.01" min="0" inputmode="decimal" placeholder="'+(d?"":"ej. 705.50")+'" value="'+pv+'" style="width:84px"'+(d&&d.lock?" disabled":"")+'></span>'}
    if(type==="hline")h+='<span class="sep"></span>'+B("nolbl",S.nolbl?"1":"0",S.nolbl?"Sin precio":"Con precio","Mostrar u ocultar la etiqueta de precio");
    h+='<span class="sep"></span><input type="text" data-k="txt" placeholder="Texto…" value="'+esc(S.txt||"").replace(/"/g,"&quot;")+'" title="Texto que se muestra junto al dibujo">';
    if(d)h+='<span class="sep"></span>'+B("lock",d.lock?"1":"0",d.lock?"🔒":"🔓",d.lock?"Bloqueado (no se mueve): clic para desbloquear":"Bloquear para no moverlo por error")+'<button data-a="dup" title="Duplicar">⧉</button><button data-a="def" title="Usar este estilo para los dibujos nuevos">★ Predeterminado</button><button data-a="del" title="Borrar">🗑</button>';
    E.innerHTML=h;E.style.display="flex"}
  stEv(e){const t=e.target,k=t.dataset.k,a=t.dataset.a;if(!k&&!a)return;
    if(k==="price"){if(e.type!=="change")return;const v=Math.round(parseFloat(String(t.value).replace(",","."))*100)/100;
      if(!(v>0)){notify("Escribe un precio válido");return}
      const d=this.stTarget();
      if(d){if(d.lock){notify("🔒 La línea está bloqueada: desbloquéala para moverla");return}d.pts[0].p=v;drSave(this.sym);t.value=v.toFixed(2)}
      else if(this.tool==="hline"&&this.bars.length){const nd=Object.assign({id:"d"+Date.now().toString(36)+Math.random().toString(36).slice(2,5),type:"hline",
          pts:[{t:this.lt(this.bars.length-1),p:v}],color:this.color()},dstGet());drGet(this.sym).push(nd);drSave(this.sym);this.setTool("cursor");this.sel=nd.id}
      this.dirty=true;return}
    if(e.type==="click"&&(t.tagName==="INPUT"))return;
    if((e.type==="input"||e.type==="change")&&t.tagName!=="INPUT")return;
    const d=this.stTarget();
    if(a==="del"){this.delSel();this.stK=null;return}
    if(a==="dup"&&d){const c=JSON.parse(JSON.stringify(d));c.id="d"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);c.lock=false;
      c.pts.forEach(q=>{q.p=q.p*1.001});drGet(this.sym).push(c);drSave(this.sym);this.sel=c.id;this.stK=null;this.dirty=true;return}
    if(a==="def"&&d){dstSet({w:d.w,dash:d.dash,op:d.op,fill:d.fill,ext:d.ext});if(d.color){$("dcol").value=d.color}notify("★ Los dibujos nuevos usarán este estilo");return}
    let v=t.type==="range"?(+t.value)/100:(t.tagName==="BUTTON"?t.dataset.v:t.value);   // los botones guardan su valor en data-v
    if(k==="w")v=+v;if(k==="lock")v=t.dataset.v!=="1";if(k==="nolbl")v=t.dataset.v!=="1";
    if(d){d[k]=v;drSave(this.sym);if(k==="color")$("dcol").value=v}
    else if(k==="color")$("dcol").value=v;else if(k!=="txt")dstSet({[k]:v});
    if(t.type==="range"){const sp=t.nextElementSibling;if(sp)sp.textContent=Math.round(v*100)+"%";this.dirty=true;return}
    if(t.type==="text"||t.type==="color"){this.dirty=true;return}
    this.stRender();this.dirty=true}
  frame(){
    const sk=(this.sel||"")+"|"+this.tool;if(sk!==this.stK){this.stK=sk;this.stRender()}
    else if(this.sel){const pi=this.el.st.querySelector('input[data-k="price"]');if(pi&&document.activeElement!==pi){const d=this.stTarget();
      if(d&&d.pts[0]){const v=(+d.pts[0].p).toFixed(2);if(pi.value!==v)pi.value=v}}}
    if(!this.chart||!this.bars.length){if(this.dirty&&this.chart){this.draw();this.dirty=false}return}
    const ts=this.chart.timeScale(),lc=this.bars[this.bars.length-1].close;
    const sig=[ts.logicalToCoordinate(0),ts.logicalToCoordinate(50),this.cs.priceToCoordinate(lc),this.cs.priceToCoordinate(lc*1.01),this.el.lw.clientWidth,this.el.lw.clientHeight,this.bars.length].join("|");
    if(sig===this.sig&&!this.dirty)return;
    this.sig=sig;this.dirty=false;this.draw()}
  draw(){
    const cv=this.el.cv,W=this.el.lw.clientWidth,H=this.el.lw.clientHeight,dpr=window.devicePixelRatio||1;
    if(cv.width!==Math.round(W*dpr)||cv.height!==Math.round(H*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr)}
    const c=cv.getContext("2d");c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,W,H);
    if(!this.bars.length)return;
    const pl=this.plot();c.save();c.beginPath();c.rect(0,0,pl.w,pl.h);c.clip();
    for(const d of drGet(this.sym))this.paint(c,d,d.id===this.sel,pl);
    if(this.tool!=="cursor"){const pts=this.pts.concat(this.hover?[this.hover]:[]);if(pts.length)this.paint(c,Object.assign({type:this.tool,pts:pts,color:this.color()},dstGet()),false,pl)}
    c.restore()}
  paint(c,d,sel,pl){
    const P=d.pts.map(q=>this.px(q));if(!P.length||P.some(q=>q.x==null||q.y==null))return;
    const col=d.color||"#f5c542",W=(d.w||2)+(sel?0.5:0),DASH=d.dash==="d"?[8,5]:d.dash==="o"?[2,4]:[],OP=d.op==null?1:d.op,FILL=d.fill==null?0.12:d.fill;
    const ext=(a,b)=>{if(!d.ext||d.ext==="n"||a.x===b.x)return[a,b];const m=(b.y-a.y)/(b.x-a.x),R={x:pl.w,y:a.y+m*(pl.w-a.x)},L={x:0,y:a.y-m*a.x};
      return d.ext==="b"?(a.x<b.x?[L,R]:[R,L]):(b.x>a.x?[a,R]:[a,L])};
    const line=(a,b,noext)=>{const q=noext?[a,b]:ext(a,b);c.beginPath();c.moveTo(q[0].x,q[0].y);c.lineTo(q[1].x,q[1].y);c.stroke()};
    c.lineWidth=W;c.strokeStyle=col;c.fillStyle=col;c.setLineDash(DASH);c.globalAlpha=OP;c.font="11px ui-monospace,Menlo,monospace";
    const tag=(txt,x,y)=>{const w=c.measureText(txt).width+8;c.fillStyle=col;c.fillRect(x,y-8,w,16);c.fillStyle="#0a0a0d";c.fillText(txt,x+4,y+4);c.fillStyle=col};
    switch(d.type){
      case"trend":if(P.length>=2)line(P[0],P[1]);break;
      case"pen":if(P.length>=2){c.save();c.lineJoin="round";c.lineCap="round";c.beginPath();c.moveTo(P[0].x,P[0].y);for(let k=1;k<P.length;k++)c.lineTo(P[k].x,P[k].y);c.stroke();c.restore()}break;
      case"arrow":if(P.length>=2){line(P[0],P[1]);c.setLineDash([]);const a=Math.atan2(P[1].y-P[0].y,P[1].x-P[0].x),L=12;
        c.beginPath();c.moveTo(P[1].x,P[1].y);c.lineTo(P[1].x-L*Math.cos(a-0.45),P[1].y-L*Math.sin(a-0.45));c.lineTo(P[1].x-L*Math.cos(a+0.45),P[1].y-L*Math.sin(a+0.45));c.closePath();c.fill()}break;
      case"hline":c.beginPath();c.moveTo(0,P[0].y);c.lineTo(pl.w,P[0].y);c.stroke();if(!d.nolbl){c.setLineDash([]);tag(d.pts[0].p.toFixed(2),Math.max(2,pl.w-62),P[0].y)}break;
      case"vline":c.beginPath();c.moveTo(P[0].x,0);c.lineTo(P[0].x,pl.h);c.stroke();break;
      case"rect":if(P.length>=2){const x=Math.min(P[0].x,P[1].x),y=Math.min(P[0].y,P[1].y),w=Math.abs(P[1].x-P[0].x),h=Math.abs(P[1].y-P[0].y);
        c.save();c.globalAlpha=1;c.fillStyle=hexA(col,FILL);c.fillRect(x,y,w,h);c.restore();c.strokeRect(x,y,w,h)}break;
      case"ellipse":if(P.length>=2){const cx=(P[0].x+P[1].x)/2,cy=(P[0].y+P[1].y)/2,rx=Math.abs(P[1].x-P[0].x)/2,ry=Math.abs(P[1].y-P[0].y)/2;
        if(rx>0.5&&ry>0.5){c.beginPath();c.ellipse(cx,cy,rx,ry,0,0,Math.PI*2);c.save();c.globalAlpha=1;c.fillStyle=hexA(col,FILL);c.fill();c.restore();c.stroke()}}break;
      case"channel":if(P.length>=2){
        if(P.length<3){line(P[0],P[1]);break}
        const off=d.pts[2].p-this.chBase(d),y1=this.cs.priceToCoordinate(d.pts[0].p+off),y2=this.cs.priceToCoordinate(d.pts[1].p+off);
        if(y1==null||y2==null){line(P[0],P[1]);break}
        c.beginPath();c.moveTo(P[0].x,P[0].y);c.lineTo(P[1].x,P[1].y);c.lineTo(P[1].x,y2);c.lineTo(P[0].x,y1);c.closePath();c.save();c.globalAlpha=1;c.fillStyle=hexA(col,FILL);c.fill();c.restore();
        line(P[0],P[1]);line({x:P[0].x,y:y1},{x:P[1].x,y:y2});
        c.save();c.setLineDash([5,4]);c.globalAlpha=0.6*OP;c.lineWidth=Math.max(1,W-1);line({x:P[0].x,y:(P[0].y+y1)/2},{x:P[1].x,y:(P[1].y+y2)/2});c.restore()}break;
      case"fib":if(P.length>=2){const xa=Math.min(P[0].x,P[1].x),xb=Math.max(P[0].x,P[1].x);
        FIB.forEach((lv,k)=>{const pr=d.pts[1].p+(d.pts[0].p-d.pts[1].p)*lv,yy=this.cs.priceToCoordinate(pr);if(yy==null)return;
          c.globalAlpha=(lv===0||lv===1?1:0.75)*OP;c.beginPath();c.moveTo(xa,yy);c.lineTo(xb,yy);c.lineWidth=Math.max(1,W*0.75);c.stroke();c.globalAlpha=OP;
          c.fillStyle=col;c.fillText(lv+"  ("+pr.toFixed(2)+")",xa+4,yy-3)});
        c.setLineDash([4,4]);c.lineWidth=1;line(P[0],P[1],true);c.setLineDash([])}break}
    c.globalAlpha=1;c.setLineDash([]);
    if(d.txt){c.font="bold 12px ui-monospace,Menlo,monospace";const tx=d.type==="hline"?8:d.type==="vline"?P[0].x+6:Math.min(P[0].x,(P[1]||P[0]).x),ty=d.type==="vline"?16:Math.min(P[0].y,(P[1]||P[0]).y)-7;
      c.lineWidth=3;c.strokeStyle="#000";c.strokeText(d.txt,tx,ty);c.fillStyle=col;c.fillText(d.txt,tx,ty);c.lineWidth=W;c.strokeStyle=col}
    if(d.lock&&sel){c.font="12px sans-serif";c.fillStyle=col;c.fillText("🔒",P[0].x+8,P[0].y-8)}
    if(sel){c.setLineDash([]);P.forEach((q,i)=>{if(d.type==="hline"&&i>0)return;if(d.type==="pen"&&i>0&&i<P.length-1)return;c.beginPath();c.arc(q.x,q.y,5,0,Math.PI*2);c.fillStyle="#0c0c0f";c.fill();c.lineWidth=2;c.strokeStyle=col;c.stroke()})}}
  shot(){
    try{const s=this.chart.takeScreenshot(),o=document.createElement("canvas");o.width=s.width;o.height=s.height;const x=o.getContext("2d");
      x.drawImage(s,0,0);x.drawImage(this.el.cv,0,0,s.width,s.height);
      const a=document.createElement("a");a.download=this.sym+"_"+this.tf+".png";a.href=o.toDataURL("image/png");a.click()}catch(e){this.msg("No se pudo capturar: "+e)}}
}
/* ---------- panel de graficos ---------- */
function setSymbol(p,sym){
  const targets=LINK?PANES:[p];
  targets.forEach(q=>{q.sym=sym;lsSet("psym"+q.i,sym);q.el.sym.value=sym;if(q.indReload&&q.chart)q.indReload();q.reload()})}
function buildPanes(){
  PANES.forEach(p=>p.destroy());PANES=[];
  const L=LAYOUTS[LAYOUT],host=$("panes");host.className="l"+LAYOUT;host.innerHTML="";
  for(let i=0;i<L.n;i++){
    let sym=lsGet("psym"+i,"SPY"),tf=lsGet("ptf"+i,i===0?lsGet("tf","1"):["1","5","15","60","240"][i]);
    if(!SYMRE.test(sym))sym="SPY";if(!TFS.some(t=>t[0]===tf))tf="1";
    const p=new Pane(i,sym,tf);host.appendChild(p.el.root);p.init();PANES.push(p)}
  ACTIVE=PANES[0];PANES.forEach(p=>p.load(true));drawLayoutBtn()}
function setLayout(k){LAYOUT=k;lsSet("layout",k);$("layMenu").style.display="none";buildPanes()}
function drawLayoutBtn(){$("layBtn").innerHTML=SVG(LAYOUTS[LAYOUT].i,' style="vertical-align:middle"')+" "+LAYOUTS[LAYOUT].t+" ▾";
  $("layMenu").innerHTML=LORDER.map(k=>'<div class="lmi'+(k===LAYOUT?" on":"")+'" onclick="setLayout(\''+k+'\')">'+SVG(LAYOUTS[k].i)+"<span>"+LAYOUTS[k].t+"</span></div>").join("");
  $("linkBtn").className="tf"+(LINK?" on":"");$("linkBtn").textContent=LINK?"🔗 Símbolo sincronizado":"🔗 Símbolos independientes"}
function layMenu(){const m=$("layMenu");m.style.display=m.style.display==="block"?"none":"block"}
let POSON=lsGet("pos","0")==="1",POSD=null;
function beOf(legs){   // breakevens A VENCIMIENTO de un grupo de patas {type,strike,qty,cost}; cost = base de costo total (corta = negativa)
  const f=S=>legs.reduce((a,l)=>a+l.qty*100*Math.max(0,l.type==="C"?S-l.strike:l.strike-S)-l.cost,0);
  const ks=[0,...legs.map(l=>l.strike)].sort((a,b)=>a-b),out=[];
  for(let i=0;i<ks.length-1;i++){const x=ks[i],y=ks[i+1];if(x===y)continue;const fx=f(x),fy=f(y);if(Math.abs(fx)<1e-9)out.push(x);else if(fx*fy<0)out.push(x+(0-fx)*(y-x)/(fy-fx))}
  const L=ks[ks.length-1],f0=f(L),sl=f(L+1)-f0;if(Math.abs(f0)<1e-9)out.push(L);else if(sl!==0&&f0*sl<0)out.push(L-f0/sl);
  return [...new Set(out.filter(v=>v>0).map(v=>+v.toFixed(2)))].sort((a,b)=>a-b)}
function posGroups(){const g={};((POSD&&POSD.legs)||[]).forEach(l=>{if(!l.qty)return;const k=l.root+"|"+l.exp;(g[k]=g[k]||{root:l.root,exp:l.exp,legs:[]}).legs.push(l)});return Object.values(g)}
function posLines(sym){const out=[];if(!POSON)return out;
  posGroups().forEach(g=>{if(g.root.replace(/W$/,"")!==sym&&g.root!==sym)return;
    const tag=g.exp.slice(5).replace("-","/");
    beOf(g.legs).forEach(p=>out.push([p,"#ffd24d","BE "+tag,0]));
    g.legs.forEach(l=>out.push([l.strike,l.qty<0?"#ff8a65":"#6fd3a5",(l.qty>0?"+":"")+l.qty+"× "+l.strike+l.type,3]))});
  return out}
async function posRefresh(){if(!POSON)return;
  try{POSD=await getj("/api/positions");if(POSD.error)throw 0}catch(e){POSD=null}
  const n=posGroups().length;$("posBtn").textContent="📍 Posición"+(POSD?(n?" · "+n:" · sin posiciones"):" · error");
  PANES.forEach(p=>{if(p.cd)p.lines(p.cd)})}
function posToggle(){POSON=!POSON;lsSet("pos",POSON?"1":"0");posPaint();if(POSON)posRefresh();else{$("posBtn").textContent="📍 Posición";PANES.forEach(p=>{if(p.cd)p.lines(p.cd)})}}
function posPaint(){$("posBtn").classList.toggle("go",POSON)}
posPaint();if(POSON)posRefresh();setInterval(posRefresh,8000);
function vname(v){return v.t==="P"?(v.s.strike>v.l.strike?"Put Credit Spread":"Put Debit Spread"):(v.s.strike<v.l.strike?"Call Credit Spread":"Call Debit Spread")}
function mkGroup(exp,vs,q){
  const legs=[];
  for(const v of vs)for(const l of [v.s,v.l])legs.push({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,q:v.q,frac:v.q/Math.abs(l.qty),l});
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0)*x.frac,0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark===null||x.l.mark===undefined)okv=false;else val+=x.sg*x.l.mark*x.q*100}
  const gr=k=>legs.reduce((a,x)=>a+((x.l[k]===null||x.l[k]===undefined)?0:x.sg*x.l[k]*x.q*100),0);
  let name;
  if(vs.length===2){const ps=vs.find(v=>v.t==="P").s.strike,cs=vs.find(v=>v.t==="C").s.strike;name=ps===cs?"Iron Fly":"Iron Condor"}
  else name=vname(vs[0]);
  return{name,exp,q,legs,entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,
    delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),strikes:legs.map(x=>x.strike).join(" / ")};
}
// Tradier no guarda que patas van juntas (solo cuantas unidades hay de cada opcion).
// Se empareja cada vendida con una comprada del mismo tipo minimizando la distancia total entre strikes.
function matchUnits(su,lu){
  const sw=su.length<=lu.length,A=sw?su:lu,B=sw?lu:su;
  if(!A.length)return[];
  const pair=(a,b)=>sw?[a,b]:[b,a];
  if(B.length<=6){
    let best=null,bc=1e18;const used=new Array(B.length).fill(false),cur=[];
    (function rec(i,c){
      if(c>=bc)return;
      if(i===A.length){bc=c;best=cur.slice();return}
      for(let j=0;j<B.length;j++){if(used[j])continue;used[j]=true;cur[i]=j;rec(i+1,c+Math.abs(A[i].strike-B[j].strike));used[j]=false}
    })(0,0);
    return A.map((a,i)=>pair(a,B[best[i]]));
  }
  const free=B.slice(),res=[];
  for(const a of A){let bi=0;for(let j=1;j<free.length;j++)if(Math.abs(free[j].strike-a.strike)<Math.abs(free[bi].strike-a.strike))bi=j;res.push(pair(a,free[bi]));free.splice(bi,1)}
  return res;
}
function groupPositions(legs){return grpApply(legs,groupAuto)}
function groupAuto(legs){
  const byExp={};for(const l of legs)(byExp[(l.root||"")+"|"+l.exp]=byExp[(l.root||"")+"|"+l.exp]||[]).push({...l,rem:Math.abs(l.qty)});
  const groups=[],loose=[];
  for(const key in byExp){
    const L=byExp[key],exp=L[0].exp,sym=L[0].root||"",verts=[];
    for(const t of ["P","C"]){
      const su=[],lu=[];
      for(const l of L.filter(x=>x.type===t)){const n=Math.floor(l.rem);for(let i=0;i<n;i++)(l.qty<0?su:lu).push(l)}
      const mp=new Map();
      for(const [s,c] of matchUnits(su,lu)){
        const key=s.occ+">"+c.occ;if(!mp.has(key))mp.set(key,{t,s,l:c,q:0});
        mp.get(key).q++;s.rem--;c.rem--;
      }
      for(const v of mp.values())verts.push(v);
    }
    const used=new Set(),pc=verts.filter(v=>v.t==="P"&&v.s.strike>v.l.strike),cc=verts.filter(v=>v.t==="C"&&v.s.strike<v.l.strike);
    for(const p of pc){const c=cc.find(x=>!used.has(x)&&x.q===p.q);if(c){used.add(p);used.add(c);groups.push(Object.assign(mkGroup(exp,[p,c],p.q),{sym}))}}
    for(const v of verts)if(!used.has(v))groups.push(Object.assign(mkGroup(exp,[v],v.q),{sym}));
    for(const l of L)if(l.rem>0)loose.push(l);
  }
  return{groups,loose};
}
const sgnc=v=>v===null||v===undefined?"":(v>0?"ok":v<0?"bad":"");
const usd=v=>v===null||v===undefined?"–":(v>=0?"+":"-")+"$"+Math.abs(v).toFixed(2);
/* ---- semaforo y barra de progreso stop -> objetivo (usa las reglas del gestor de cada posicion) ---- */
let GIT=[];
async function gestItems(){try{const r=await fetch("/api/gestor",{cache:"no-store"});const j=await r.json();return(j.items||[]).filter(i=>i.status==="activa"&&acctOf(i.live)===(window.ACCT||"paper"))}catch(e){return[]}}
function gestFor(occs){const k=occs.slice().sort().join("|");return GIT.find(i=>(i.legs||[]).slice().sort().join("|")===k)||null}
function gestState(it){if(!it||it.pnl==null||it.stop_pnl==null||it.tp_pnl==null)return null;
  const s=it.stop_pnl,t=it.tp_pnl,p=it.pnl,f=Math.max(0,Math.min(1,(p-s)/(t-s)));
  let st="ok";if(p<=s)st="bad";else if(p<=s*0.8||p>=t*0.85)st="warn";return{f,st,s,t,p}}
function rowCls(occs){const g=gestState(gestFor(occs));return g&&g.st!=="ok"?' class="pr-'+g.st+'"':""}
function barCell(occs){const g=gestState(gestFor(occs));
  if(!g)return'<td style="color:#7d8aa5;font-size:11px">sin gestor</td>';
  return'<td><span class="pbar"><i style="left:'+(g.f*100).toFixed(1)+'%"></i></span><div class="pbl"><span>'+usd(g.s)+'</span><span>'+usd(g.t)+'</span></div></td>'}

function dte(exp){const et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  return Math.round((new Date(exp+"T00:00:00")-new Date(et.getFullYear(),et.getMonth(),et.getDate()))/86400000)}

const pretty=o=>nm(o||"");let PGR=[];
window.GRP_RENDER=()=>apRefresh();
let AP_EMPTY=0,ACCT_OK=false;
async function apRefresh(){const tb=$("pos");if(!tb)return;
  try{const j=await getj("/api/positions");if(j.error)throw new Error(j.error);
    $("acctposl").textContent="POSICIONES · CUENTA "+(LIVE?"REAL":"DE PAPEL")+" (robot + manuales)";
    window.GRP_OSETS=j.osets||[];const R=groupPositions(j.legs.filter(l=>l.qty));PGR=R.groups;GIT=await gestItems();
    for(const g of PGR){if(Math.abs(g.entryNet||0)<0.005){const it=gestFor(g.legs.map(x=>x.occ));   // Tradier a veces da costo 0: uso la entrada del gestor
      if(it&&it.entry){const e=it.kind==="credit"?it.entry:-it.entry;g.entryNet=e;if(g.closeNow!==null)g.pnl=(e-g.closeNow)*100*g.q}}}
    if(window.smoothG)smoothG(PGR);
    if(!PGR.length&&!R.loose.length&&tb._ok&&++AP_EMPTY<3)return;   // lista vacia un instante (falla de Tradier): espera a confirmarlo
    if(!PGR.length&&!R.loose.length){tb._ok=false;tb.innerHTML='<tr><td colspan="11" style="color:var(--mut)">Sin posiciones</td></tr>';$("posum").innerHTML="";$("posnote").textContent="";return}
    let tp=0,td=0,tt=0,rows="";
    PGR.forEach((g,i)=>{if(g.pnl!==null)tp+=g.pnl;td+=g.delta;tt+=g.theta;const cn=g.closeNow;
      rows+='<tr'+rowCls(g.legs.map(x=>x.occ))+'><td>'+grpChk(g.legs.map(x=>x.occ))+'<b>'+(g.sym?g.sym+" ":"")+g.name+'</b><br><span style="color:var(--mut)">'+g.strikes+'</span></td><td>'+g.exp+' ('+dte(g.exp)+')</td><td>'+g.q+'</td>'
       +'<td>'+(g.entryNet>=0?"Crédito ":"Débito ")+Math.abs(g.entryNet).toFixed(2)+'</td>'
       +'<td>'+(cn===null?"–":(cn>=0?"Débito ":"Crédito ")+Math.abs(cn).toFixed(2))+'</td>'
       +'<td class="'+sgnc(g.pnl)+'"'+(g.stale?' title="Precio de Tradier no confiable en este momento (apertura): se muestra el último P&L bueno"':'')+'><b>'+usd(g.pnl)+(g.stale?' ⏳':'')+'</b></td><td>'+g.delta.toFixed(1)+'</td><td class="'+sgnc(g.theta)+'">'+usd(g.theta)+'</td><td>'+g.vega.toFixed(1)+'</td>'
       +barCell(g.legs.map(x=>x.occ))+'<td style="white-space:nowrap">'+grpSplitBtn(g.legs.map(x=>x.occ))+' <a class="xb" href="/trade#close='+encodeURIComponent(g.exp+"|"+g.strikes+"|"+g.q)+'" title="Abre Trading manual con esta posición lista para cerrar (vista previa y confirmación)">Cerrar</a></td></tr>'});
    for(const l of R.loose){const pnl=l.mark==null?null:l.mark*l.qty*100-(l.cost||0),d=(l.delta||0)*l.qty*100,t=(l.theta||0)*l.qty*100;
      if(pnl!==null)tp+=pnl;td+=d;tt+=t;
      const btn=l.qty>0&&l.root==="SPY"?'<button class="xb" onclick="tkSell(\''+l.occ+"',"+l.qty+",'market',0)\">Cerrar a mercado</button>":"";
      rows+='<tr'+rowCls([l.occ])+'><td>'+grpChk([l.occ])+'<b>Pata suelta</b><br><span style="color:var(--mut)">'+esc(pretty(l.occ))+'</span></td><td>'+l.exp+' ('+dte(l.exp)+')</td><td>'+l.qty+'</td><td colspan="2" style="color:var(--mut)">'+(l.cost==null?"–":"Costo $"+(+l.cost).toFixed(2))+'</td><td class="'+sgnc(pnl)+'"><b>'+usd(pnl)+'</b></td><td>'+d.toFixed(1)+'</td><td class="'+sgnc(t)+'">'+usd(t)+'</td><td>–</td>'+barCell([l.occ])+'<td style="white-space:nowrap">'+grpLooseBtn(l)+btn+'</td></tr>'}
    AP_EMPTY=0;tb._ok=true;if(tb._h!==rows){tb.innerHTML=rows;tb._h=rows}
    const sp=j.spots||{},ks=Object.keys(sp);
    $("posum").innerHTML='<div><span>'+(ks.length>1?"PRECIOS AHORA":(ks[0]||"SPY")+" AHORA")+'</span><b>'+(ks.length>1?ks.map(k=>k+" "+sp[k].toFixed(2)).join(" · "):(j.spot==null?"–":j.spot.toFixed(2)))+'</b></div><div><span>P&amp;L TOTAL ABIERTO</span><b class="'+sgnc(tp)+'">'+usd(tp)+'</b></div><div title="Dólares que ganas o pierdes por cada punto que se mueve el subyacente"><span>DELTA NETA ($/punto)</span><b>'+td.toFixed(1)+'</b></div><div><span>THETA NETA / DÍA</span><b class="'+sgnc(tt)+'">'+usd(tt)+'</b></div>'+(typeof moveBox==="function"?moveBox(j.legs,j.spots):"");
    $("posnote").textContent="P&L con el precio medio (bid+ask)/2 de cada opción; griegas de Tradier por contrato×100. «Cerrar» abre Trading manual con esa posición cargada para cerrarla con vista previa."+(R.loose.length?" Las patas sueltas de otras expiraciones se cierran a mercado desde su botón.":"")
  }catch(e){if(tb._ok){$("posnote").textContent="⏳ Tradier tardó en contestar; se muestra lo último que llegó.";return}   // sin parpadeo
    tb.innerHTML='<tr><td colspan="11" style="color:var(--mut)">No pude leer las posiciones: '+esc(String(e.message||e).slice(0,120))+"</td></tr>"}}

/* ===== matematica de indicadores (funciones puras; cada una devuelve arreglos alineados a las velas, null donde aun no hay dato) ===== */
const IM={
sma(v,n){const o=new Array(v.length).fill(null);let s=0;for(let i=0;i<v.length;i++){s+=v[i];if(i>=n)s-=v[i-n];if(i>=n-1)o[i]=s/n}return o},
ema(v,n){const o=new Array(v.length).fill(null);if(v.length<n)return o;const k=2/(n+1);let e=0;for(let i=0;i<n;i++)e+=v[i];e/=n;o[n-1]=e;for(let i=n;i<v.length;i++){e=v[i]*k+e*(1-k);o[i]=e}return o},
rsi(c,n){const o=new Array(c.length).fill(null);if(c.length<=n)return o;let g=0,l=0;for(let i=1;i<=n;i++){const d=c[i]-c[i-1];if(d>=0)g+=d;else l-=d}g/=n;l/=n;
  o[n]=l===0?100:100-100/(1+g/l);for(let i=n+1;i<c.length;i++){const d=c[i]-c[i-1];g=(g*(n-1)+(d>0?d:0))/n;l=(l*(n-1)+(d<0?-d:0))/n;o[i]=l===0?100:100-100/(1+g/l)}return o},
macd(c,f,s,g){const ef=IM.ema(c,f),es=IM.ema(c,s),m=c.map((_,i)=>ef[i]!=null&&es[i]!=null?ef[i]-es[i]:null);
  const idx=m.findIndex(x=>x!=null),sig=new Array(c.length).fill(null);if(idx>=0){const e=IM.ema(m.slice(idx),g);e.forEach((x,j)=>{sig[idx+j]=x})}
  return{macd:m,signal:sig,hist:m.map((x,i)=>x!=null&&sig[i]!=null?x-sig[i]:null)}},
bb(c,n,k){const m=IM.sma(c,n),u=[],l=[];for(let i=0;i<c.length;i++){if(m[i]==null){u.push(null);l.push(null);continue}let s=0;for(let j=i-n+1;j<=i;j++)s+=(c[j]-m[i])**2;const sd=Math.sqrt(s/n);u.push(m[i]+k*sd);l.push(m[i]-k*sd)}return{mid:m,up:u,lo:l}},
atr(b,n){const o=new Array(b.length).fill(null);if(b.length<=n)return o;const tr=b.map((x,i)=>i===0?x.high-x.low:Math.max(x.high-x.low,Math.abs(x.high-b[i-1].close),Math.abs(x.low-b[i-1].close)));
  let a=0;for(let i=1;i<=n;i++)a+=tr[i];a/=n;o[n]=a;for(let i=n+1;i<b.length;i++){a=(a*(n-1)+tr[i])/n;o[i]=a}return o},
stoch(b,k,d){const K=new Array(b.length).fill(null);for(let i=k-1;i<b.length;i++){let hi=-1e18,lo=1e18;for(let j=i-k+1;j<=i;j++){hi=Math.max(hi,b[j].high);lo=Math.min(lo,b[j].low)}K[i]=hi===lo?50:(b[i].close-lo)/(hi-lo)*100}
  const idx=K.findIndex(x=>x!=null),D=new Array(b.length).fill(null);if(idx>=0)IM.sma(K.slice(idx),d).forEach((x,j)=>{D[idx+j]=x});return{k:K,d:D}},
vwap(b){const o=[];let pv=0,vv=0,day=null;for(const x of b){const dk=Math.floor(x.time/86400);if(dk!==day){day=dk;pv=0;vv=0}const tp=(x.high+x.low+x.close)/3;pv+=tp*x.volume;vv+=x.volume;o.push(vv>0?pv/vv:null)}return o},
supertrend(b,n,m){const a=IM.atr(b,n),line=new Array(b.length).fill(null),dir=new Array(b.length).fill(0);let fu=0,fl=0,d=1;
  for(let i=0;i<b.length;i++){if(a[i]==null)continue;const hl=(b[i].high+b[i].low)/2,bu=hl+m*a[i],bl=hl-m*a[i];
    if(line[i-1]==null){fu=bu;fl=bl;d=b[i].close>=hl?1:-1}else{fu=(bu<fu||b[i-1].close>fu)?bu:fu;fl=(bl>fl||b[i-1].close<fl)?bl:fl;
      if(d===1&&b[i].close<fl)d=-1;else if(d===-1&&b[i].close>fu)d=1}
    line[i]=d===1?fl:fu;dir[i]=d}return{line,dir}}
};

/* ===== indicadores estilo TradingView (por grafico): superpuestos en el precio u osciladores en franjas debajo ===== */
const IND={
 sma:{n:"SMA",p:[["n","Período",20,2,500]],c:"#f5c542"},
 ema:{n:"EMA",p:[["n","Período",50,2,500]],c:"#ff8a65"},
 bb:{n:"Bollinger",p:[["n","Período",20,2,200],["k","Desv.",2,.5,5]],c:"#7c9cff"},
 vwap:{n:"VWAP",p:[],c:"#e040fb"},
 st:{n:"Supertrend",p:[["n","ATR",10,2,100],["m","Mult.",3,.5,10]],c:"#26c6da"},
 rsi:{n:"RSI",osc:1,p:[["n","Período",14,2,100]],c:"#b388ff",lv:[30,70],rng:[0,100]},
 macd:{n:"MACD",osc:1,p:[["f","Rápida",12,2,100],["s","Lenta",26,3,200],["g","Señal",9,2,50]],c:"#4fc3f7"},
 stoch:{n:"Estocástico",osc:1,p:[["k","%K",14,2,100],["d","%D",3,1,50]],c:"#ffb74d",lv:[20,80],rng:[0,100]},
 atr:{n:"ATR",osc:1,p:[["n","Período",14,2,100]],c:"#90a4ae"}
};
const IND_MAXOSC=3;
function indLabel(x){const d=IND[x.t];return d.n+(d.p.length?" "+d.p.map(q=>x.p[q[0]]).join(","):"")}
Object.assign(Pane.prototype,{
 indLoad(){let a=[];try{a=JSON.parse(lsGet("ind_"+this.sym,null)??lsGet("ind"+this.i,"[]"))}catch(e){}
  this.ind=(Array.isArray(a)?a:[]).filter(x=>x&&IND[x.t]).map(x=>{const d=IND[x.t],p={};d.p.forEach(q=>{const v=+(x.p||{})[q[0]];p[q[0]]=isFinite(v)&&v>=q[3]&&v<=q[4]?v:q[2]});return{id:x.id||Math.random().toString(36).slice(2),t:x.t,p:p,c:/^#[0-9a-f]{6}$/i.test(x.c||"")?x.c:d.c,on:x.on!==false}})},
 indSave(){lsSet("ind_"+this.sym,JSON.stringify(this.ind.map(x=>({id:x.id,t:x.t,p:x.p,c:x.c,on:x.on}))));
  PANES.forEach(p=>{if(p!==this&&p.sym===this.sym&&p.indReload)p.indReload()})},   // el mismo simbolo en otras temporalidades: mismos indicadores
 indReload(){if(!this.chart)return;this.indLoad();this.indRefresh()},
 indInit(){this.indLoad();const lg=document.createElement("div");lg.className="pleg";this.el.pc.appendChild(lg);this.el.leg=lg;
  this.el.ind.onclick=()=>this.indMenu();this.indRefresh()},
 indKill(){(this.indS||[]).forEach(s=>{try{this.chart.removeSeries(s)}catch(e){}});this.indS=[];(this.ind||[]).forEach(x=>{x.ss=[]})},
 indRefresh(){if(!this.chart)return;this.indKill();let slot=0;
  this.ind.forEach(x=>{x.ss=[];x.slot=null;if(!x.on)return;const d=IND[x.t],ch=this.chart;
   const reg=s=>{x.ss.push(s);this.indS.push(s);return s};
   const L=(o)=>reg(ch.addLineSeries(Object.assign({color:x.c,lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false},o)));
   if(d.osc){if(slot>=IND_MAXOSC){x.on=false;return}x.slot=slot;const id="os"+slot++;const base={priceScaleId:id,title:indLabel(x),lastValueVisible:true};
    if(x.t==="macd"){reg(ch.addHistogramSeries({priceScaleId:id,priceLineVisible:false,lastValueVisible:false}));L(Object.assign({},base,{lineWidth:2}));L({priceScaleId:id,color:"#ffa726"})}
    else if(x.t==="stoch"){L(Object.assign({},base,{lineWidth:2,autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})}));L({priceScaleId:id,color:"#ef5350",autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})})}
    else{const o=Object.assign({},base,{lineWidth:2});if(d.rng)o.autoscaleInfoProvider=()=>({priceRange:{minValue:d.rng[0],maxValue:d.rng[1]}});L(o)}
    (d.lv||[]).forEach(v=>x.ss[x.ss.length-(x.t==="stoch"?2:1)].createPriceLine({price:v,color:"#3a4566",lineWidth:1,lineStyle:2,axisLabelVisible:false,title:""}))}
   else if(x.t==="bb"){L({lineWidth:1});L({lineWidth:1});L({lineWidth:1,lineStyle:2})}
   else if(x.t==="st"){L({lineWidth:2})}
   else L({lineWidth:2})});
  this.indLayout();this.indData();this.indLegend()},
 indLayout(){if(!this.chart)return;const k=this.ind.filter(x=>x.on&&IND[x.t].osc).length,H=0.17,V=k?0.07:0;
  this.cs.priceScale().applyOptions({scaleMargins:k?{top:0.06,bottom:V+k*H+0.02}:{top:0.2,bottom:0.1}});
  this.vs.priceScale().applyOptions({scaleMargins:{top:k?0.93:0.82,bottom:0}});
  this.ind.filter(x=>x.on&&x.slot!=null).forEach(x=>{const b=V+x.slot*H;try{this.chart.priceScale("os"+x.slot).applyOptions({scaleMargins:{top:1-b-H+0.01,bottom:b},visible:false,borderVisible:false})}catch(e){}})},
 indEmpty(){(this.ind||[]).forEach(x=>(x.ss||[]).forEach(s=>{try{s.setData([])}catch(e){}}));if(this.el.leg)this.el.leg.innerHTML=""},
 indData(){const B=this.bars||[];if(!this.chart||!B.length){this.indEmpty();return}
  const T=B.map(b=>b.time),C=B.map(b=>b.close),pts=(a,col)=>{const o=[];for(let i=0;i<a.length;i++)if(a[i]!=null&&isFinite(a[i]))o.push(col?{time:T[i],value:a[i],color:col(i)}:{time:T[i],value:a[i]});return o};
  this.ind.forEach(x=>{if(!x.on||!x.ss.length)return;const p=x.p;x.last=[];
   if(x.t==="sma"){const a=IM.sma(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="ema"){const a=IM.ema(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="vwap"){const a=(DLY(this.tf)||this.tf==="240")?C.map(()=>null):IM.vwap(B);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="bb"){const r=IM.bb(C,p.n,p.k);x.ss[0].setData(pts(r.up));x.ss[1].setData(pts(r.lo));x.ss[2].setData(pts(r.mid));x.last=[r.up[B.length-1],r.mid[B.length-1],r.lo[B.length-1]]}
   else if(x.t==="st"){const r=IM.supertrend(B,p.n,p.m);x.ss[0].setData(pts(r.line,i=>r.dir[i]===1?"#4ff0b7":"#ff5d6c"));x.last=[r.line[B.length-1]]}
   else if(x.t==="rsi"){const a=IM.rsi(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="atr"){const a=IM.atr(B,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="macd"){const r=IM.macd(C,p.f,p.s,p.g);x.ss[0].setData(r.hist.map((v,i)=>v==null?null:{time:T[i],value:v,color:v>=0?"rgba(79,240,183,.55)":"rgba(255,93,108,.55)"}).filter(Boolean));
    x.ss[1].setData(pts(r.macd));x.ss[2].setData(pts(r.signal));const n=B.length-1;x.last=[r.macd[n],r.signal[n],r.hist[n]]}
   else if(x.t==="stoch"){const r=IM.stoch(B,p.k,p.d);x.ss[0].setData(pts(r.k));x.ss[1].setData(pts(r.d));const n=B.length-1;x.last=[r.k[n],r.d[n]]}});
  this.indLegend()},
 indLegend(){const lg=this.el.leg;if(!lg)return;const f=v=>v==null||!isFinite(v)?"–":(Math.abs(v)>=100?v.toFixed(1):v.toFixed(2));
  lg.innerHTML=(this.ind||[]).map(x=>'<div class="pl'+(x.on?"":" off")+'" data-id="'+x.id+'"><i style="background:'+x.c+'"></i><span>'+esc(indLabel(x))+'</span><b>'+(x.on&&x.last?x.last.map(f).join(" "):"")+'</b><button type="button" data-a="eye" title="Mostrar / ocultar">'+(x.on?"👁":"✕")+'</button><button type="button" data-a="set" title="Ajustes">⚙</button><button type="button" data-a="del" title="Quitar">🗑</button></div>').join("");
  lg.onclick=e=>{const b=e.target.closest("button"),r=e.target.closest(".pl");if(!b||!r)return;const x=this.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(b.dataset.a==="eye"){x.on=!x.on;this.indRefresh();this.indSave()}else if(b.dataset.a==="del"){this.ind=this.ind.filter(y=>y!==x);this.indRefresh();this.indSave()}else this.indMenu()}},
 indMenu(){const root=this.el.root;let m=root.querySelector(".pmenu");if(m){m.remove();return}
  m=document.createElement("div");m.className="pmenu";root.appendChild(m);const me=this;
  const draw=()=>{m.innerHTML='<div class="pmh"><b>ƒx Indicadores</b><button type="button" data-a="x">✕</button></div><div class="pms">Sobre el precio</div><div class="pmg">'+
    Object.keys(IND).filter(k=>!IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">En franja debajo (máx. '+IND_MAXOSC+')</div><div class="pmg">'+
    Object.keys(IND).filter(k=>IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">Activos en este gráfico</div>'+
    (me.ind.length?me.ind.map(x=>'<div class="pmr" data-id="'+x.id+'"><b>'+IND[x.t].n+'</b>'+IND[x.t].p.map(q=>'<label>'+q[1]+' <input type="number" data-k="'+q[0]+'" value="'+x.p[q[0]]+'" min="'+q[3]+'" max="'+q[4]+'" step="'+(q[3]<1||q[0]==="k"&&x.t==="bb"||q[0]==="m"?0.5:1)+'"></label>').join("")+
     '<input type="color" data-k="c" value="'+x.c+'"><button type="button" data-a="del" title="Quitar">🗑</button></div>').join(""):'<div class="mut" style="font-size:12px">Ninguno todavía: elige uno arriba.</div>')+
    '<div class="pms" style="margin-top:8px"><button type="button" data-a="clr">Quitar todos</button></div>'};
  draw();
  m.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
   if(b.dataset.a==="x"){m.remove();return}
   if(b.dataset.add){const t=b.dataset.add,d=IND[t];if(d.osc&&me.ind.filter(y=>IND[y.t].osc&&y.on).length>=IND_MAXOSC){$("ch_hint")&&($("ch_hint").textContent="Máximo "+IND_MAXOSC+" indicadores en franja: quita uno");return}
    const p={};d.p.forEach(q=>p[q[0]]=q[2]);me.ind.push({id:Math.random().toString(36).slice(2),t:t,p:p,c:d.c,on:true})}
   else if(b.dataset.a==="del"){const id=b.closest(".pmr").dataset.id;me.ind=me.ind.filter(y=>y.id!==id)}
   else if(b.dataset.a==="clr")me.ind=[];else return;
   me.indRefresh();me.indSave();draw()});
  m.addEventListener("change",e=>{const i=e.target,r=i.closest(".pmr");if(!r||!i.dataset.k)return;const x=me.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(i.dataset.k==="c")x.c=i.value;else{const q=IND[x.t].p.find(q=>q[0]===i.dataset.k),v=+i.value;if(isFinite(v)&&v>=q[3]&&v<=q[4])x.p[i.dataset.k]=v;else i.value=x.p[i.dataset.k]}
   me.indRefresh();me.indSave();draw()})}
});

function toggleLink(){LINK=!LINK;lsSet("link",LINK?"1":"0");drawLayoutBtn()}
function dcolChange(){if(ACTIVE&&ACTIVE.sel)ACTIVE.setColor($("dcol").value)}
document.addEventListener("click",e=>{if(!e.target.closest("#layMenu,#layBtn"))$("layMenu").style.display="none"});
document.addEventListener("keydown",e=>{if(/INPUT|SELECT|TEXTAREA/.test((e.target.tagName||"")))return;const p=ACTIVE;if(!p)return;
  if(e.key==="Escape")p.escape();else if((e.key==="Delete"||e.key==="Backspace")&&p.sel){p.delSel();e.preventDefault()}});
const NYF=new Intl.DateTimeFormat("en-US",{timeZone:"America/New_York",hour12:false,weekday:"short",hour:"2-digit",minute:"2-digit",second:"2-digit"});
function nyClock(){const o={};for(const p of NYF.formatToParts(new Date()))o[p.type]=p.value;
  const sec=(+o.hour%24)*3600+(+o.minute)*60+(+o.second);
  const wd=o.weekday!=="Sat"&&o.weekday!=="Sun";
  return{sec:sec,open:wd&&sec>=34200&&sec<57600,pre:wd&&sec>=14400&&sec<34200,post:wd&&sec>=57600&&sec<72000}}
(function loop(){PANES.forEach(p=>{try{p.frame()}catch(e){}try{p.cd2()}catch(e){}});requestAnimationFrame(loop)})();
(function poll(){PANES.forEach(p=>p.load(false));setTimeout(poll,ESON?20000:(PANES.length>2?12000:8000))})();   // con streaming la vela viva se mueve sola: el historial se pide menos (cuida a Tradier)   // historial e indicadores
/* hora de Nueva York en el mismo formato que las velas (segundos "desplazados" a NY) */
function nyNow(){const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/New_York",hourCycle:"h23",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"}).formatToParts(new Date()),g=t=>+p.find(x=>x.type===t).value;
  return Date.UTC(g("year"),g("month")-1,g("day"),g("hour"),g("minute"),g("second"))/1000}
function nyMin(s){const d=new Date(s*1000);return d.getUTCHours()*60+d.getUTCMinutes()}
/* cada 2 s: ultimo precio de cada simbolo en pantalla -> mueve la vela (solo con el mercado abierto) */
(function ticker(){const now=nyNow(),m=nyMin(now),wd=new Date(now*1000).getUTCDay();
  if(wd>=1&&wd<=5&&(extOn()?(m>=240&&m<1200):(m>=570&&m<960))&&!document.hidden){   // con pre/post: de 4:00 a 20:00
    for(const s of [...new Set(PANES.map(p=>p.sym))]){
      if(ESON&&Date.now()-(ESTS[s]||0)<3000)continue;   // con streaming no hace falta preguntar
      fetch("/api/quote?sym="+encodeURIComponent(s),{cache:"no-store"}).then(r=>r.json()).then(q=>{if(q&&q.last>0)PANES.forEach(p=>{if(p.sym===s&&!p.inflight)p.live(q.last)})}).catch(()=>{})}}
  setTimeout(ticker,2000)})();
optLoad();try{maPaint()}catch(e){}
/* ===================== ROBOT DE LINEAS SPY (simulado, papel o REAL escribiendo REAL) ===================== */
var LN={ops:[],log:[],open:false,pick:null,drag:null};
function lnSymOk(s){return s==="SPY"}
function lnToggle(){LN.open=!LN.open;$("lnBox").style.display=LN.open?"":"none";$("lnBtn").classList.toggle("on",LN.open);lnPaint();lnLoad()}
async function lnLoad(){if(LN.drag)return;try{const j=await getj("/api/lineas");if(j&&j.ops){const sig=JSON.stringify(j.ops);const ch=sig!==LN.sig;LN.sig=sig;LN.ops=j.ops;LN.log=j.log||[];LN.cmp=j.comparacion||null;
  if(ch){if(LN.open)lnPaint();PANES.forEach(p=>{if(p.cd)p.lines(p.cd)})}}}catch(e){}}
setInterval(lnLoad,2000);setTimeout(lnLoad,800);
const LNST={esperando:["⏳ esperando entrada","#5cc8ff"],entrando:["📨 entrando","#ffd23f"],dentro:["✅ dentro","#4ff0b7"],saliendo:["📤 saliendo","#ffa726"],
  cerrada:["🏁 cerrada","#9fb0cc"],cancelada:["✖ cancelada","#7d8aa5"],error:["⚠ error","#ff5d6c"]};
function lnLines(){const out=[],act=["esperando","entrando","dentro","saliendo"];
  for(const o0 of LN.ops){if(!act.includes(o0.status))continue;const D=LN.drag,o=D&&D.id===o0.id?Object.assign({},o0,{[D.k]:D.v}):o0;
    const st=(LNST[o.status]||[o.status])[0],tag=(o.modo==="real"?"💵REAL ":o.sim?"🎮":"")+(o.dir==="alcista"?"▲":"▼")+o.qty+"ctr"+(D&&D.id===o0.id?" ↕":"");
    if(o.status==="esperando")out.push([o.entry,"#5cc8ff","🎯 ENTRADA "+tag+" · "+st,0]);
    else out.push([o.entry,"#5cc8ff","🎯 entró "+(o.short?o.short+"/"+o.long:"")+(o.credit?" @"+o.credit.toFixed(2):"")+" · "+st,2]);
    out.push([o.stop,"#ff5d6c","🛑 STOP "+tag,0]);out.push([o.tp,"#4ff0b7","💰 GANANCIA "+tag,0])}
  if(LN.pick){const n=["🎯 ENTRADA","🛑 STOP","💰 GANANCIA"],c=["#5cc8ff","#ff5d6c","#4ff0b7"];LN.pick.pts.forEach((v,i)=>out.push([v,c[i],n[i]+" (nueva)",2]))}
  return out}
function lnPickStart(){if(!PANES.some(p=>lnSymOk(p.sym))){notify("Abre una gráfica del SPY para poner las líneas");return}
  LN.pick={pts:[],entrada:($("ln_entrada")&&$("ln_entrada").value)||"rapida",modo:$("ln_modo").value||"sim",qty:+$("ln_qty").value||3,strike:$("ln_strike").value,until:$("ln_until").value||"15:00",exit:$("ln_exit").value||"15:45"};lnPaint()}
function lnPickCancel(){LN.pick=null;lnPaint();PANES.forEach(p=>{if(p.cd)p.lines(p.cd)})}
async function lnPickAt(pr){const P=LN.pick;if(!P)return;P.pts.push(pr);PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});lnPaint();
  if(P.pts.length<3)return;
  const [e,s,t]=P.pts,dir=t>e&&e>s?"alcista":t<e&&e<s?"bajista":null;
  if(!dir){notify("Las líneas no cuadran: ALCISTA = ganancia arriba de la entrada y stop abajo; BAJISTA = al revés. Vuelve a ponerlas.");P.pts=[];lnPaint();PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}
  const txt=(dir==="alcista"?"ALCISTA → PUT credit spread":"BAJISTA → CALL credit spread")+" 0DTE de 3 puntos, "+P.qty+" contrato(s)\n"
    +"Venta: "+(P.strike==="atm"?"el strike más cercano al precio":"el primer strike "+(dir==="alcista"?"abajo":"arriba")+" del precio")+" cuando toque la entrada\n\n"
    +"ENTRADA "+e+"   ·   STOP "+s+"   ·   GANANCIA "+t+"\nEntra hasta las "+P.until+" · sale a más tardar a las "+P.exit+"\n\n"+(P.modo==="real"?"💵 DINERO REAL: la orden va a tu CUENTA REAL de Tradier":P.modo==="papel"?"📄 La orden va a tu cuenta de PAPEL":"🎮 SIMULADO: no se manda ninguna orden; se llena con los precios reales del momento");
  if(!(await askOk(txt))){P.pts=[];lnPaint();PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}
  let confirm="";
  if(P.modo==="real"){confirm=await askWord("💵 DINERO REAL\n\nEl robot va a mandar órdenes a tu CUENTA REAL cuando el SPY toque "+e+".\nPara confirmar escribe: REAL");
    if(confirm.trim().toUpperCase()!=="REAL"){notify("No se activó: no escribiste REAL");P.pts=[];lnPaint();PANES.forEach(p=>{if(p.cd)p.lines(p.cd)});return}}
  const j=await post("/api/lineas",{action:"create",confirm,entrada:P.entrada||"rapida",modo:P.modo,entry:e,stop:s,tp:t,qty:P.qty,strike:P.strike,until:P.until,exit:P.exit});
  if(j.error){notify("✖ "+j.error);P.pts=[];lnPaint();return}
  LN.pick=null;notify("🎯 Robot activado: espera que el SPY toque "+e);LN.sig=null;lnLoad()}
document.addEventListener("keydown",e=>{const t=e.target;if(e.key==="Enter"&&t&&t.id&&/^ln_[est]_/.test(t.id)){e.preventDefault();lnSave(t.id.slice(5));t.blur()}});   // Enter en un numero = Guardar
async function lnAct(id,action,extra){const j=await post("/api/lineas",Object.assign({id,action},extra||{}));if(j.error)notify("✖ "+j.error);else{LN.sig=null;lnLoad()}}
function lnSave(id){const g=k=>{const v=$("ln_"+k+"_"+id);return v&&v.value!==""?+v.value:undefined};lnAct(id,"set",{entry:g("e"),stop:g("s"),tp:g("t")})}
function lnPaint(){const B=$("lnBox");if(!B||!LN.open)return;const P=LN.pick;
  const keep=k=>{const x=$(k);return x?x.value:null};const q=keep("ln_qty")||"3",md=keep("ln_modo")||"sim",st=keep("ln_strike")||"otm1",en=keep("ln_entrada")||"rapida",un=keep("ln_until")||"15:00",ex=keep("ln_exit")||"15:45";
  let h='<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:8px"><b style="color:#b48cff">🎯 ROBOT DE LÍNEAS SPY</b><span class="mono" style="font-size:11px;color:var(--mut)">SPY 0DTE · credit spread de 3 pts · simulado, papel o 💵 REAL · trabaja desde las 7:30 (premarket, menos liquidez) y de 9:30 al cierre</span>'
   +'<label class="mono" style="font-size:12px">Modo <select id="ln_modo"><option value="sim"'+(md==="sim"?" selected":"")+'>🎮 Simulado (precios reales, sin órdenes)</option><option value="papel"'+(md==="papel"?" selected":"")+'>📄 Papel de Tradier</option><option value="real"'+(md==="real"?" selected":"")+'>💵 REAL (dinero real)</option></select></label>'
   +'<label class="mono" style="font-size:12px" title="Rápida: empieza en el precio natural y lo persigue cada 2 s (casi siempre entra). Normal: empieza en el precio medio y baja poco a poco (cobra más, puede no entrar si el precio corre). Inmediata: un poco abajo del natural (entra al instante). Nunca entra cobrando menos del 20% del ancho.">Entrada <select id="ln_entrada"><option value="rapida"'+(en==="rapida"?" selected":"")+'>⚡ Rápida</option><option value="normal"'+(en==="normal"?" selected":"")+'>Normal (precio medio)</option><option value="inmediata"'+(en==="inmediata"?" selected":"")+'>🚀 Inmediata</option></select></label>'
   +'<label class="mono" style="font-size:12px">Contratos <input id="ln_qty" type="number" min="1" max="10" value="'+q+'" style="width:52px"></label>'
   +'<label class="mono" style="font-size:12px">Venta <select id="ln_strike"><option value="otm1"'+(st==="otm1"?" selected":"")+'>primer strike fuera del dinero</option><option value="atm"'+(st==="atm"?" selected":"")+'>en el dinero (más cercano)</option></select></label>'
   +'<label class="mono" style="font-size:12px">Entra hasta <input id="ln_until" type="time" value="'+un+'"></label>'
   +'<label class="mono" style="font-size:12px">Sale a más tardar <input id="ln_exit" type="time" value="'+ex+'"></label>';
  if(!P)h+='<button class="tf go" onclick="lnPickStart()">＋ Poner líneas en la gráfica</button>';
  else h+='<span style="color:#ffd23f;font-weight:700">Clic en la gráfica del SPY: '+["1) ENTRADA","2) STOP","3) GANANCIA"][Math.min(2,P.pts.length)]+'</span> <button class="tf" onclick="lnPickCancel()">Cancelar</button>';
  h+='</div>';
  if(LN.cmp&&LN.cmp.n){const C=LN.cmp,f=v=>(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(0),c=v=>v>0?"var(--ok)":v<0?"var(--bad)":"var(--mut)";
    h+='<div class="mono" style="font-size:12px;margin:4px 0 8px;padding:6px 8px;border:1px dashed #7a3cff;border-radius:8px">📊 COMPARACIÓN (modo sombra, '+C.n+' operaciones cerradas): spread del robot <b style="color:'+c(C.spread)+'">'+f(C.spread)+'</b> · si hubieras comprado call/put de 100+ días delta 0.20 <b style="color:'+c(C.alt_nat)+'">'+f(C.alt_nat)+'</b> <span style="color:var(--mut)">(a precio medio '+f(C.alt_mid)+') · ganó el de 100 días '+C.gana_alt+' de '+C.n+' veces</span></div>'}
  const today=LN.ops.slice().reverse();
  if(!today.length)h+='<div class="mono" style="font-size:12px;color:var(--mut)">Sin operaciones hoy. Pon tus tres líneas: el robot decide la dirección por dónde quedan la ganancia y el stop.</div>';
  else{const HEAD='<tr style="color:var(--mut)"><td>Estado</td><td>Dirección</td><td>Entrada</td><td>Stop</td><td>Ganancia</td><td>Spread</td><td>Crédito</td><td>P&L</td><td>Último movimiento</td><td></td></tr>';
    const VIVA=new Set(["esperando","entrando","dentro","saliendo"]),act=today.filter(o=>VIVA.has(o.status)),fin=today.filter(o=>!VIVA.has(o.status));
    let rows="";
    for(const o of act.concat(fin)){if(o===fin[0])h+=(act.length?'<table style="width:100%;font-size:12px">'+HEAD+rows+'</table>':'<div class="mono" style="font-size:12px;color:var(--mut);margin:2px 0 6px">Ninguna operación activa ahora. Pon nuevas líneas cuando quieras.</div>'),rows="";const S_=LNST[o.status]||[o.status,"#fff"],ed=o.status==="esperando"||o.status==="dentro";
      const inp=(k,v,dis)=>ed&&!dis?'<input id="ln_'+k+'_'+o.id+'" type="number" step="0.25" value="'+v+'" style="width:78px">':'<span class="mono">'+v+'</span>';
      const last=(o.ev||[]).slice(-1)[0]||["",""];
      rows+='<tr style="border-top:1px solid var(--line)"><td style="color:'+S_[1]+';font-weight:700;white-space:nowrap">'+S_[0]+'</td><td>'+(o.modo==="real"?'<b style="color:#ff9f43">💵 REAL</b> ':o.sim?'<b style="color:#ffd23f">🎮 SIM</b> ':'📄 ')+(o.dir==="alcista"?"▲ alcista (put)":"▼ bajista (call)")+' · '+o.qty+'</td>'
        +'<td>'+inp("e",o.entry,o.status!=="esperando")+'</td><td>'+inp("s",o.stop)+'</td><td>'+inp("t",o.tp)+'</td>'
        +'<td class="mono">'+(o.short?o.short+"/"+o.long:"–")+'</td><td class="mono">'+(o.credit!=null?o.credit.toFixed(2):(o.limit?"lím "+o.limit.toFixed(2):"–"))+'</td>'
        +(()=>{const v=o.pnl!=null?o.pnl:(o.status==="dentro"?o.pnl_now:null);return '<td class="mono '+(v>0?"ok":v<0?"bad":"")+'" title="'+(o.pnl==null&&v!=null?"P&L si cerraras ahora (al precio natural)":"")+'">'+(v!=null?(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(2)+(o.pnl==null?" ahora":""):"–")+((o.alt&&o.alt.done)?'<br><span class="tag" title="Si en vez del spread hubieras comprado '+(o.alt.type==="C"?"un call":"un put")+' '+o.alt.strike+' que vence '+o.alt.exp+' (delta '+o.alt.delta+'), comprando al ask y vendiendo al bid">100 días: <b class="'+(o.alt.pnl_nat>0?"ok":o.alt.pnl_nat<0?"bad":"")+'">'+(o.alt.pnl_nat>=0?"+":"−")+"$"+Math.abs(o.alt.pnl_nat).toFixed(0)+'</b></span>':(o.alt?'<br><span class="tag">100 días: '+(o.alt.type==="C"?"call ":"put ")+o.alt.strike+' '+o.alt.exp.slice(5)+'</span>':""))+'</td>'})()
        +'<td class="mono" style="color:var(--mut);max-width:360px">'+esc(last[0]+" "+last[1])+'</td><td style="white-space:nowrap">'
        +(ed?'<button class="tf" onclick="lnSave(\''+o.id+'\')">Guardar</button> ':'')
        +(o.status==="esperando"?'<button class="tf" onclick="lnAct(\''+o.id+'\',\'cancel\')">Cancelar</button>':'')
        +(o.status==="dentro"||o.status==="entrando"?'<button class="tf" style="border-color:#ff5d6c;color:#ff5d6c" onclick="lnAct(\''+o.id+'\',\'close\')">⏹ Cerrar ya</button>':'')+'</td></tr>'}
    if(!fin.length){h+='<table style="width:100%;font-size:12px">'+HEAD+rows+'</table>'}
    else{const tot=fin.reduce((a,o)=>a+(o.pnl||0),0),nc=fin.filter(o=>o.pnl!=null).length,open=lsGet("ln_done","0")==="1";
      h+='<div class="mono" onclick="lsSet(\'ln_done\',lsGet(\'ln_done\',\'0\')===\'1\'?\'0\':\'1\');lnPaint()" style="cursor:pointer;font-size:12px;margin:8px 0 4px;padding:6px 8px;border:1px solid var(--line);border-radius:8px;color:var(--mut)">'+(open?"▾":"▸")+' Terminadas hoy ('+fin.length+')'
        +(nc?' · P&L <b style="color:'+(tot>0?"var(--ok)":tot<0?"var(--bad)":"var(--mut)")+'">'+(tot>=0?"+":"−")+"$"+Math.abs(tot).toFixed(2)+'</b> en '+nc+' cerrada'+(nc>1?"s":""):'')+' <span style="font-size:11px">(clic para '+(open?"ocultar":"ver")+')</span></div>';
      if(open)h+='<div style="max-height:240px;overflow:auto;border:1px solid var(--line);border-radius:8px"><table style="width:100%;font-size:12px">'+HEAD+rows+'</table></div>'}}
  B.innerHTML=h}
/* algo cambio en tu otra computadora (dibujos, indicadores, colores, opciones): se aplica aqui sin recargar */
/* algo cambio en tu otra computadora (dibujos, indicadores, colores, opciones): se aplica aqui sin recargar */
window.onPrefsChanged=ch=>{ch.filter(k=>k.startsWith("dr_")).forEach(k=>{delete DR[k.slice(3)]});
  PANES.forEach(p=>{if(ch.includes("ind_"+p.sym))p.indReload()});
  if(ch.some(k=>/^(c_|w_)/.test(k)))maPaint();if(ch.some(k=>k.startsWith("o_"))){OPTK.forEach(k=>{$("o_"+k).checked=lsGet("o_"+k,"1")==="1"});const was=extOn();$("o_ext").checked=lsGet("o_ext","0")==="1";if(was!==extOn())PANES.forEach(p=>p.load(true))}
  applyOpts();if(ch.includes("gexh")||ch.includes("o_gex"))gexAll();PANES.forEach(p=>{p.dirty=true;p.stK=null;if(p.cd)p.lines(p.cd)})};
/* ===== ORDEN RAPIDA (scalping, sandbox) ===== */
const T={side:"C",exp:null,rows:[],spot:null,k:null,ref:"mid",open:false,timer:null,busy:false};
const post=async(p,b)=>{const r=await fetch(p,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});return r.json()};
const getj=async p=>{const r=await fetch(p,{cache:"no-store"});return r.json()};
const esc=x=>String(x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const nm=o=>{const m=/^SPY(\d{2})(\d{2})(\d{2})([CP])(\d{8})$/.exec(o);return m?(+m[5]/1000)+" "+(m[4]==="C"?"Call":"Put")+" "+m[2]+"/"+m[3]:o};
let TKTAB="o";
function tkTab(t){TKTAB=t;const s=t==="s";$("tk_opt").style.display=s?"none":"";$("tk_str").style.display=s?"":"none";$("tk").classList.toggle("wide",s);
  $("tkt_o").className="tf"+(s?"":" on");$("tkt_s").className="tf"+(s?" on":"");const f=$("tk_if");
  if(s){$("tk_strmsg").textContent=LIVE?"🔴 CUENTA REAL: las órdenes de este constructor usan dinero real (te pide confirmación Sí/No en cada una).":"";f.style.display="";if(!f.getAttribute("src"))f.src="/trade?embed=1"}
  else f.removeAttribute("src")}

/* ventana para escribir una palabra (dentro de la pagina, tambien en pantalla completa; sin la ventana del navegador) */
function askWord(msg){return new Promise(res=>{const d=document.createElement("div");
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:100001;display:flex;align-items:center;justify-content:center;padding:16px";
  const bx=document.createElement("div");bx.style.cssText="background:#0c0c0f;color:#e6ecf5;border:2px solid #ff9f43;border-radius:12px;padding:18px;max-width:380px;width:100%;font:14px -apple-system,sans-serif";
  const t=document.createElement("div");t.style.cssText="margin-bottom:12px;white-space:pre-wrap;line-height:1.45";t.textContent=msg;
  const inp=document.createElement("input");inp.placeholder="escribe REAL";inp.autocomplete="off";
  inp.style.cssText="width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #3c3c46;background:#000;color:#e6ecf5;font:700 16px ui-monospace,Menlo,monospace;margin-bottom:12px;text-transform:uppercase";
  const r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
  const no=document.createElement("button"),ok=document.createElement("button");no.textContent="Cancelar";ok.textContent="Confirmar";
  [no,ok].forEach(b=>{b.type="button";b.style.cssText="padding:8px 16px;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer"});
  ok.style.borderColor="#ff9f43";ok.style.color="#ff9f43";
  const done=v=>{document.removeEventListener("keydown",key,true);d.remove();res(v)};
  const key=ev=>{if(ev.key==="Escape"){ev.preventDefault();ev.stopPropagation();done("")}else if(ev.key==="Enter"&&document.activeElement===inp){ev.preventDefault();ev.stopPropagation();done(inp.value)}};
  no.onclick=()=>done("");ok.onclick=()=>done(inp.value);document.addEventListener("keydown",key,true);
  r.append(no,ok);bx.append(t,inp,r);d.appendChild(bx);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);setTimeout(()=>inp.focus(),30)})}
function askOk(msg){return new Promise(res=>{const d=document.createElement("div");
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99998;display:flex;align-items:center;justify-content:center";
  const bx=document.createElement("div");bx.style.cssText="background:#0c0c0f;color:#e6ecf5;border:1px solid #202027;border-radius:12px;padding:18px;max-width:340px;font:14px -apple-system,sans-serif";
  const t=document.createElement("div");t.style.cssText="margin-bottom:14px;white-space:pre-wrap";t.textContent=msg;
  const r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
  const no=document.createElement("button"),ok=document.createElement("button");no.textContent="No";ok.textContent="Sí";
  [no,ok].forEach(b=>{b.type="button";b.style.cssText="padding:7px 16px;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer"});
  ok.style.borderColor="#ff5d6c";ok.style.color="#ff5d6c";
  const done=v=>{d.remove();res(v)};no.onclick=()=>done(false);ok.onclick=()=>done(true);d.onclick=e=>{if(e.target===d)done(false)};
  r.append(no,ok);bx.append(t,r);d.append(bx);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);no.focus()})}
function askPrice(title,hint,val){return new Promise(res=>{const d=document.createElement("div");
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99998;display:flex;align-items:center;justify-content:center";
  const bx=document.createElement("div");bx.style.cssText="background:#0c0c0f;color:#e6ecf5;border:1px solid #202027;border-radius:12px;padding:18px;width:340px;max-width:92vw;font:14px -apple-system,sans-serif";
  const t=document.createElement("div");t.style.cssText="font-weight:800;margin-bottom:6px";t.textContent=title;
  const h=document.createElement("div");h.style.cssText="color:#7d8aa5;font-size:12px;margin-bottom:10px;white-space:pre-wrap";h.textContent=hint||"";
  const inp=document.createElement("input");inp.type="number";inp.step="0.01";inp.min="0.01";inp.value=val==null?"":(+val).toFixed(2);
  inp.style.cssText="width:100%;box-sizing:border-box;background:#08080a;color:#e6ecf5;border:1px solid #202027;border-radius:8px;padding:10px;font:700 18px ui-monospace,Menlo,monospace;text-align:center;margin-bottom:8px";
  const st=document.createElement("div");st.style.cssText="display:flex;gap:6px;margin-bottom:12px";
  const bump=dx=>{const v=Math.max(0.01,Math.round(((+inp.value||0)+dx)*100)/100);inp.value=v.toFixed(2)};
  [[-0.05,"−0.05"],[-0.01,"−0.01"],[0.01,"+0.01"],[0.05,"+0.05"]].forEach(a=>{const b=document.createElement("button");b.type="button";b.textContent=a[1];
    b.style.cssText="flex:1;padding:8px 0;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer";b.onclick=()=>bump(a[0]);st.appendChild(b)});
  const r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
  const no=document.createElement("button"),ok=document.createElement("button");no.textContent="Cancelar";ok.textContent="Modificar";
  [no,ok].forEach(b=>{b.type="button";b.style.cssText="padding:8px 16px;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer"});
  ok.style.borderColor="#4ff0b7";ok.style.color="#4ff0b7";
  const done=v=>{d.remove();res(v)};no.onclick=()=>done(null);ok.onclick=()=>{const v=+inp.value;done(v>0?Math.round(v*100)/100:null)};
  d.onclick=e=>{if(e.target===d)done(null)};inp.onkeydown=e=>{if(e.key==="Enter")ok.click();if(e.key==="Escape")no.click()};
  r.append(no,ok);bx.append(t,h,inp,st,r);d.append(bx);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);inp.focus();inp.select()})}
async function modOrder(id,type,price){
  const hint=type==="credit"?"Crédito: BAJAR el precio lo hace más fácil de ejecutar.":type==="debit"?"Débito: SUBIR el precio lo hace más fácil de ejecutar.":"Límite: compra → subir ayuda; venta → bajar ayuda.";
  const p=await askPrice("Modificar orden #"+id,hint+"\nPrecio actual: "+(price==null?"–":"$"+(+price).toFixed(2))+". Es la misma orden: no se cancela.",price);
  if(p==null)return;
  if(price!=null&&Math.abs(p-price)<0.004){notify("Ese ya es el precio de la orden");return}
  const g=await guard("MODIFICAR la orden #"+id+"\nPrecio: "+(price==null?"–":"$"+(+price).toFixed(2))+" → $"+p.toFixed(2));
  if(!g)return;
  let j;try{j=await post("/api/modify",Object.assign({id:String(id),price:p,type:type},g))}catch(e){j={error:String(e)}}
  notify(j.error?"No se pudo modificar: "+j.error:"✓ Orden #"+id+" modificada a $"+p.toFixed(2));return j}
function notify(msg){const n=document.createElement("div");n.textContent=msg;
  n.style.cssText="position:fixed;left:50%;bottom:20px;transform:translateX(-50%);max-width:90vw;background:#0c0c0f;color:#ffc04d;border:1px solid #ffc04d;border-radius:10px;padding:10px 16px;font:13px ui-monospace,Menlo,monospace;z-index:99999;white-space:pre-wrap";
  (document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(n);setTimeout(()=>n.remove(),7000)}
/* atajos de teclado de la orden rápida (nunca envían solos: siempre sale el cuadro Sí / No) */
document.addEventListener("keydown",e=>{
  if(e.ctrlKey||e.metaKey||e.altKey)return;
  const el=document.activeElement,tag=el&&el.tagName;
  if(tag==="INPUT"||tag==="TEXTAREA"||tag==="SELECT"||(el&&el.isContentEditable))return;
  if(document.querySelector('div[style*="z-index:100000"]'))return;
  const k=e.key.toLowerCase();
  if(k==="t"){e.preventDefault();toggleT();return}
  if(!T.open)return;
  if(k==="c"){tkSide("C")}else if(k==="p"){tkSide("P")}
  else if(k==="b"){tkRef("bid")}else if(k==="m"){tkRef("mid")}else if(k==="a"){tkRef("ask")}
  else if(k==="arrowup"||k==="+"||k==="="){e.preventDefault();tkStep(1)}else if(k==="arrowdown"||k==="-"){e.preventDefault();tkStep(-1)}
  else if(k==="enter"){if(tag==="BUTTON")return;e.preventDefault();if(!$("tk_buy").disabled)tkBuy()}
  else if(k==="escape"){toggleT()}
});
function toggleT(){T.open=!T.open;$("tk").style.display=T.open?"block":"none";$("tfT").className="tf go"+(T.open?" on":"");
  if(T.open){tkInit().then(tkRefresh);T.timer=setInterval(tkRefresh,4000)}else{clearInterval(T.timer);$("tk_if").removeAttribute("src")}
  if(T.open&&TKTAB==="s")tkTab("s")}
async function tkInit(){
  if($("tk_exp").options.length)return;
  const j=await getj("/api/expirations");if(j.error){$("tk_msg").textContent=j.error;return}
  $("tk_exp").innerHTML=j.dates.slice(0,8).map(d=>"<option>"+d+"</option>").join("");T.exp=$("tk_exp").value;
  try{const c=JSON.parse(localStorage.getItem("tk_last")||"null");if(c){if(c.q>=1)$("tk_qty").value=c.q;if(c.side==="C"||c.side==="P"){T.side=c.side;$("tk_c").className="tf"+(c.side==="C"?" on":"");$("tk_p").className="tf"+(c.side==="P"?" on":"")}if(c.ref==="bid"||c.ref==="mid"||c.ref==="ask")T.ref=c.ref}}catch(e){}}
function tkSide(s){T.side=s;T.k=null;$("tk_c").className="tf"+(s==="C"?" on":"");$("tk_p").className="tf"+(s==="P"?" on":"");tkFill()}
function tkExp(){T.exp=$("tk_exp").value;T.k=null;tkRefresh()}
function tkPick(){T.k=+$("tk_k").value;tkFill(true)}
function tkStep(d){const ks=tkKs();const i=ks.indexOf(T.k);const n=ks[Math.max(0,Math.min(ks.length-1,i+d))];if(n!=null){T.k=n;tkFill()}}
function tkKs(){return T.rows.filter(r=>r.type===T.side).map(r=>r.strike).sort((a,b)=>a-b)}
function tkRow(){return T.rows.find(r=>r.type===T.side&&r.strike===T.k)}
function tkRef(r){T.ref=r;tkFill(true)}
function tkManual(){T.ref=null;["bid","mid","ask"].forEach(x=>0);tkCost()}
function tkFill(force){
  const ks=tkKs(),sp=T.spot;if(!ks.length)return;
  if(T.k==null||!ks.includes(T.k))T.k=ks.reduce((a,b)=>Math.abs(b-sp)<Math.abs(a-sp)?b:a);
  const near=ks.filter(k=>Math.abs(k-T.k)<=12||Math.abs(k-sp)<=6);
  $("tk_k").innerHTML=near.map(k=>{const r=T.rows.find(x=>x.type===T.side&&x.strike===k);return '<option value="'+k+'"'+(k===T.k?" selected":"")+">"+k+(r&&r.delta!=null?"  Δ"+Math.abs(r.delta).toFixed(2):"")+"</option>"}).join("");
  const r=tkRow();if(!r)return;
  const mid=r.bid!=null&&r.ask!=null?(r.bid+r.ask)/2:null;
  $("tk_q").innerHTML="Bid <b>"+(r.bid??"–")+"</b> · Ask <b>"+(r.ask??"–")+"</b> · spread "+(r.bid!=null&&r.ask!=null?(r.ask-r.bid).toFixed(2):"–")+(r.delta!=null?" · Δ "+r.delta.toFixed(2):"");
  ["bid","mid","ask"].forEach(x=>0);
  if(T.ref){const v=T.ref==="bid"?r.bid:T.ref==="ask"?r.ask:(mid==null?null:Math.round(mid*100)/100);if(v!=null)$("tk_px").value=(+v).toFixed(2)}
  tkCost()}
function tkCost(){
  const r=tkRow(),q=+$("tk_qty").value||0,p=+$("tk_px").value||0,b=$("tk_buy");
  b.className="tkbuy"+(T.side==="P"?" put":"");
  b.textContent=r?"COMPRAR "+q+" × "+r.strike+" "+(T.side==="C"?"CALL":"PUT")+" a $"+p.toFixed(2)+"  (≈ $"+(q*p*100).toFixed(0)+")":"COMPRAR";
  b.disabled=!r||q<1||p<=0}
async function tkBuy(){
  const r=tkRow();if(!r)return;const q=+$("tk_qty").value,p=+$("tk_px").value;
  try{localStorage.setItem("tk_last",JSON.stringify({q:q,side:T.side,ref:T.ref}))}catch(e){}
  const g=await guard("COMPRAR "+q+" × SPY "+T.exp+" "+r.strike+" "+(T.side==="C"?"Call":"Put")+" a límite $"+p.toFixed(2)+" (≈ $"+(q*p*100).toFixed(0)+")");
  if(!g)return;
  $("tk_buy").disabled=true;$("tk_msg").textContent="Enviando…";
  const j=await post("/api/scalp",Object.assign({occ:r.occ,side:"buy_to_open",qty:q,type:"limit",price:p},g));
  $("tk_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden enviada (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+")"+(j.managed?" · 🤖 el gestor la vigilará al ejecutarse":"")+"</span>";
  tkCost();tkRefresh()}
async function tkSell(occ,qty,typ,px){
  const g=await guard("VENDER para cerrar "+qty+" × "+nm(occ)+(typ==="market"?" A MERCADO":" a límite $"+px.toFixed(2)));if(!g)return;
  const j=await post("/api/scalp",Object.assign({occ:occ,side:"sell_to_close",qty:qty,type:typ,price:px},g));
  $("tk_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden de cierre enviada ('+esc((j.order||{}).status)+")</span>";
  notify(j.error?"No se pudo cerrar: "+j.error:"Orden de cierre enviada ("+((j.order||{}).status||"ok")+")");tkRefresh();apRefresh()}
async function tkCancel(id){const j=await post("/api/cancel",{id:id});$("tk_msg").textContent=j.error||"Orden cancelada";tkRefresh()}
async function tkRefresh(){
  if(!T.open||T.busy)return;T.busy=true;
  try{
    if(T.exp){const c=await getj("/api/chain?exp="+T.exp);if(c.error){$("tk_msg").textContent=c.error}else{T.rows=c.options;T.spot=c.spot;$("tk_spot").textContent="SPY "+(c.spot??"–")+(LIVE?" · cuenta REAL":" · papel ~15 min de retraso");tkFill()}}
    const [p,o]=await Promise.all([getj("/api/positions"),getj("/api/orders")]);
    const legs=(p.legs||[]),shorts=new Set(legs.filter(l=>l.qty<0).map(l=>l.exp+l.type));
    const lone=legs.filter(l=>l.qty>0&&!shorts.has(l.exp+l.type));
    $("tk_pos").innerHTML=lone.length?lone.map(l=>{const pl=l.mark!=null&&l.cost!=null?l.mark*l.qty*100-l.cost:null;
      return '<div class="tkr"><span>'+l.qty+"× "+nm(l.occ)+(pl==null?"":' <b class="'+(pl>=0?"ok":"bad")+'">'+(pl>=0?"+":"-")+"$"+Math.abs(pl).toFixed(0)+"</b>")+'</span><span>'+
        (l.bid?'<button class="tf" onclick="tkSell(\''+l.occ+"',"+l.qty+",'limit',"+l.bid+')">Bid '+l.bid.toFixed(2)+"</button> ":"")+'<button class="tf" onclick="tkSell(\''+l.occ+"',"+l.qty+",'market',0)\">Mercado</button></span></div>"}).join(""):'<div style="color:var(--mut)">Ninguna. (Las patas de spreads se cierran en Trading manual.)</div>';
    const op=(o.orders||[]).filter(x=>x.open);
    $("tk_ord").innerHTML=op.length?op.map(x=>'<div class="tkr"><span>#'+esc(x.id)+" "+esc(x.status)+" "+x.legs.map(l=>esc((l.side||"").replace(/_/g," "))+" "+nm(l.occ||"")).join(" / ")+(x.price?" @"+x.price:"")+'</span><span>'+((x.price!=null&&["credit","debit","limit"].includes(x.type))?'<button class="tf" onclick="modOrder('+Number(x.id)+',\''+x.type+'\','+x.price+').then(()=>tkRefresh())">✎ Precio</button> ':"")+'<button class="tf" onclick="tkCancel('+Number(x.id)+')">✕</button></span></div>').join(""):'<div style="color:var(--mut)">Ninguna</div>';
  }catch(e){$("tk_msg").textContent="Error: "+e}finally{T.busy=false}}
/* ===== GESTOR AUTOMATICO ===== */
const G={d:null,filled:false};
const gm=v=>v==null?"–":"$"+(+v).toFixed(2);
async function gRefresh(){try{G.d=await getj("/api/gestor");gPaint()}catch(e){}}
function gPaint(){
  if(!G.d||G.d.error)return;
  const d=Object.assign({},G.d,{items:(G.d.items||[]).filter(i=>acctOf(i.live)===(window.ACCT||"paper"))});   // solo las posiciones de la cuenta que estás viendo (papel o real)
  const act=d.items.filter(i=>["entrada","activa","cerrando"].includes(i.status));
  $("gBadge").textContent="🤖 Gestor: "+(d.paused?"EN PAUSA":act.length?act.length+" vigilando":"listo");
  $("gBadge").className="tf"+(d.paused?" warn":act.length?" on":"");
  $("g_state").textContent=d.paused?"· EN PAUSA":"· activo";$("g_state").style.color=d.paused?"var(--warn)":"var(--ok)";
  $("g_pause").textContent=d.paused?"Reanudar":"Pausar todo";
  if(!G.filled||(!G.dirty&&(!document.activeElement||!document.activeElement.closest("#gb")))){
    const c=d.cfg;$("g_stop").value=c.stop_usd;$("g_tp").value=c.tp_usd;$("g_at").value=c.at_target;$("g_trl").value=c.trail_usd;
    $("g_hon").checked=c.time_on;$("g_hex").value=c.time_exit;$("g_auto").checked=c.auto;G.filled=true;G.dirty=false;gAtSync()}
  if(d.save_err)$("g_msg").innerHTML='<span class="bad">⚠ '+esc(d.save_err)+" — las reglas valen ahora pero se perderán al reiniciar.</span>";
  const ST={entrada:"esperando ejecución",activa:"vigilando",cerrando:"cerrando…",cerrada:"cerrada",cancelada:"no ejecutada",liberada:"liberada"};
  $("g_list").innerHTML=d.items.length?d.items.slice(0,8).map(i=>{
    const on=["entrada","activa","cerrando"].includes(i.status),pc=i.pct;
    return '<div class="gi"><div style="display:flex;justify-content:space-between;gap:6px"><b>'+(i.live?"🔴 ":"")+(i.qty||i.qty_ordered)+"× "+esc(i.name)+"</b><span style='color:"+(i.hold?"var(--bad)":on?"var(--ok)":"var(--mut)")+"'>"+(i.hold?"⚠ DETENIDA":ST[i.status]||i.status)+"</span></div>"+
      (i.entry?'<div>Entrada '+gm(i.entry)+" → ahora "+(on||!i.exit_px?gm(i.mark):gm(i.exit_px))+(pc==null||!on?"":' <b class="'+(pc>=0?"ok":"bad")+'">'+(pc>=0?"+":"")+pc.toFixed(1)+"%</b>")+(on?" · P&amp;L ":" · P&amp;L FINAL ")+"<b class='"+((i.pnl||0)>=0?"ok":"bad")+"'>"+((i.pnl||0)>=0?"+":"-")+"$"+Math.abs(i.pnl||0).toFixed(on?0:2)+"</b>"+(i.estimated?" (estimado)":"")+"</div>"+
        (on?(i.unit==="usd"?'<div style="color:var(--mut)">Stop −$'+i.cfg.stop_usd+"/ctr ×"+i.qty+"="+(i.cfg.stop_usd*i.qty)+" ("+gm(i.stop)+") · Objetivo +$"+i.cfg.tp_usd+" ("+gm(i.tp)+")"+(i.cfg.at_target==="trail"?" → trailing −$"+i.cfg.trail_usd:"")+"</div>"+(i.armed?'<div style="color:var(--ok)">🎯 Trailing activo · máx +$'+(i.peak_usd==null?"–":i.peak_usd.toFixed(0))+" · sale si baja a "+gm(i.trail)+"</div>":""):'<div style="color:var(--mut)">Stop '+gm(i.stop)+" · Objetivo "+gm(i.tp)+(i.partial_done?" · parcial hecho (stop en entrada)":"")+"</div>"):(i.reason?'<div style="color:var(--mut)">Salió por: '+esc(i.reason)+"</div>":"")):"")+
      (i.ev.length?'<div style="color:var(--mut)">'+esc(i.ev[i.ev.length-1][0]+" "+i.ev[i.ev.length-1][1])+"</div>":"")+
      (i.status==="activa"?'<div style="margin-top:4px;display:flex;gap:4px"><button class="tf" onclick="gAct(\''+i.id+"','close')\">Cerrar ya</button><button class=\"tf\" onclick=\"gEdit('"+i.id+"')\">✏️ Reglas</button><button class=\"tf\" onclick=\"gAct('"+i.id+"','release')\">Soltar</button>"+(i.hold?'<button class="tf" onclick="gAct(\''+i.id+"','resume')\">Reanudar</button>":"")+"</div>":"")+"</div>"}).join(""):'<div style="color:var(--mut)">Sin posiciones vigiladas. Tu próxima compra desde este ticket quedará a cargo del gestor.</div>';
  if($("acct_g")){const kids=[...$("g_list").children],A=[],H=[];
    d.items.slice(0,8).forEach((i,ix)=>{(["entrada","activa","cerrando"].includes(i.status)?A:H).push(kids[ix]?kids[ix].outerHTML:"")});
    const old=$("acct_g").querySelector("details"),wasOpen=old?old.open:false;
    $("acct_g").innerHTML=(A.join("")||'<div style="color:var(--mut)">Ninguna posición vigilada ahora.</div>')+(H.length?'<details style="margin-top:8px"><summary style="cursor:pointer;color:var(--mut)">Historial ('+H.length+')</summary>'+H.join("")+"</details>":"");
    const nd=$("acct_g").querySelector("details");if(nd&&wasOpen)nd.open=true;
    $("gdet_s").textContent="🤖 GESTOR · "+(d.paused?"EN PAUSA":act.length?act.length+" vigilando":"ninguna vigilada")+" — reglas, cerrar ya, soltar"}
  $("g_log").innerHTML=d.log.slice(-4).reverse().map(l=>esc(l[0]+" "+l[1])).join("<br>")}
function gEdit(id){
  const i=((G.d||{}).items||[]).find(x=>x.id===id);if(!i)return;
  if(i.unit!=="usd"){notify("Esta posición usa reglas en % (versión anterior); no se puede editar. Ciérrala o suéltala.");return}
  const old=document.getElementById("gedit");if(old)old.remove();const c=i.cfg;
  const d=document.createElement("div");d.id="gedit";
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center";
  const f=(k,l,v,st)=>'<label style="display:block;font-size:12px;margin-top:8px">'+l+'</label><input id="ge_'+k+'" value="'+v+'" '+(st||'type="number" step="1" min="1"')+' style="width:100%;box-sizing:border-box">';
  d.innerHTML='<div style="background:var(--card,#141418);color:var(--tx,#e6edf3);border:1px solid var(--line,#30363d);border-radius:12px;padding:16px;width:min(340px,92vw)"><b>Editar reglas · '+(i.qty||i.qty_ordered)+'× '+esc(i.name)+'</b><div style="font-size:12px;color:var(--mut,#8b949e);margin-top:4px">Montos en $ POR CONTRATO (× '+(i.qty||i.qty_ordered)+' contratos)</div>'
   +f("stop","Stop: pérdida máx. ($/contrato)",c.stop_usd)+f("tp","Objetivo: ganancia ($/contrato)",c.tp_usd)
   +'<label style="display:block;font-size:12px;margin-top:8px">Al llegar al objetivo…</label><select id="ge_at" style="width:100%"><option value="trail"'+(c.at_target==="trail"?" selected":"")+'>Seguir con trailing</option><option value="close"'+(c.at_target==="close"?" selected":"")+'>Cerrar y cobrar</option></select>'
   +f("trl","Trailing: devolver máx. ($/contrato)",c.trail_usd)+f("hex","Cerrar a las (NY, si vence hoy)",c.time_exit,'type="text"')
   +'<div id="ge_msg" style="color:#f85149;font-size:12px;min-height:16px;margin-top:6px"></div><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:6px"><button type="button" id="ge_no">Cancelar</button><button type="button" id="ge_ok">Guardar</button></div></div>';
  (document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);
  document.getElementById("ge_no").onclick=()=>d.remove();
  document.getElementById("ge_ok").onclick=async()=>{
    const cfg={unit:"usd",stop_usd:+document.getElementById("ge_stop").value,tp_usd:+document.getElementById("ge_tp").value,at_target:document.getElementById("ge_at").value,trail_usd:+document.getElementById("ge_trl").value,time_exit:document.getElementById("ge_hex").value.trim()};
    const j=await post("/api/gestor_item",{id:id,action:"set",cfg:cfg});
    if(j.error){document.getElementById("ge_msg").textContent=j.error;return}
    d.remove();gRefresh();}}
async function gAct(id,action){
  let g={};
  if(action==="close"){g=await guard("CERRAR YA (a mercado) la posición vigilada #"+id);if(!g)return}
  else if(action==="release"&&!(await askOk("¿Soltar esta posición? Seguirá abierta en tu cuenta pero el gestor ya no la vigila.")))return;
  const j=await post("/api/gestor_item",Object.assign({id:id,action:action},g));
  $("tk_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Gestor: '+(action==="close"?"cierre pedido":action==="release"?"posición liberada":"reanudada")+"</span>";
  notify(j.error?"Gestor: "+j.error:"Gestor: "+(action==="close"?"cierre pedido":action==="release"?"posición liberada":"reanudada"));gRefresh()}
function gAtSync(){const t=$("g_at").value==="trail";$("g_trw").style.display=t?"":"none";
  const s=+$("g_stop").value,p=+$("g_tp").value,r=+$("g_trl").value;
  $("g_ex").textContent=t?"Ej.: pierdes como máximo $"+s+". Al llegar a +$"+p+" NO vende: sigue dentro; si luego sube y devuelve $"+r+" desde su máximo, cierra (mínimo asegurado ≈ +$"+Math.max(0,p-r)+")."
    :"Ej.: pierdes como máximo $"+s+" o cierras con +$"+p+"."}
async function gSave(){
  const c={unit:"usd",stop_usd:+$("g_stop").value,tp_usd:+$("g_tp").value,at_target:$("g_at").value,trail_usd:+$("g_trl").value,time_on:$("g_hon").checked,time_exit:$("g_hex").value.trim(),auto:$("g_auto").checked};
  let j;try{j=await post("/api/gestor_cfg",{cfg:c})}catch(e){j={error:"No pude hablar con el panel: "+e}}
  if(j.error){$("g_msg").innerHTML='<span class="bad">✖ NO guardado: '+esc(j.error)+"</span>";notify("Reglas NO guardadas: "+j.error);return}
  G.d=j;G.filled=false;G.dirty=false;gPaint();const s=j.cfg;
  if(j.save_err){$("g_msg").innerHTML='<span class="bad">⚠ '+esc(j.save_err)+"</span>";notify("Guardadas solo hasta reiniciar: "+j.save_err);return}
  $("g_msg").innerHTML='<span class="ok">✓ Guardado en el disco: stop $'+s.stop_usd+" · objetivo $"+s.tp_usd+(s.at_target==="trail"?" → trailing $"+s.trail_usd:" (cerrar)")+" · salida "+s.time_exit+" (por contrato; valen para compras nuevas)</span>";notify("✓ Reglas guardadas")}
async function gPause(){const j=await post("/api/gestor_pause",{paused:!(G.d&&G.d.paused)});if(!j.error){G.d=j;gPaint()}}
["g_stop","g_tp","g_at","g_trl","g_hon","g_hex","g_auto"].forEach(k=>{const e=$(k);if(e){e.addEventListener("input",()=>{G.dirty=true});e.addEventListener("change",()=>{G.dirty=true})}});
gRefresh();setInterval(gRefresh,3000);
function pollLast(s){LAST=s;PANES.forEach(p=>p.marks())}
const money=v=>(v>=0?"+$":"-$")+Math.abs(v).toFixed(2);
const cls=v=>v>0?"ok":v<0?"bad":"";
function chart(c){
  const svg=$("chart");svg.innerHTML="";
  if(!c.length){svg.innerHTML='<text x="300" y="100" fill="#7d8aa5" text-anchor="middle" font-size="14">Sin operaciones cerradas hoy</text>';return}
  const pts=[0].concat(c),mn=Math.min(0,...pts),mx=Math.max(0,...pts),rg=(mx-mn)||1;
  const X=i=>10+580*i/Math.max(1,pts.length-1),Y=v=>180-170*(v-mn)/rg;
  const z=Y(0);let h='<line x1="10" x2="590" y1="'+z+'" y2="'+z+'" stroke="#202027" stroke-dasharray="4"/>';
  h+='<polyline fill="none" stroke="#4ff0b7" stroke-width="3" points="'+pts.map((v,i)=>X(i)+","+Y(v)).join(" ")+'"/>';
  svg.innerHTML=h;
}
function paint(s){
  const p=$("pill");
  const RA=s.robot&&s.robot.account==="live"?"REAL":"PAPEL";if(s.running===true){p.textContent="● BOT CORRIENDO · "+RA;p.className="pill";p.title="El robot opera la cuenta de "+RA+", sin importar si estás VIENDO papel o real arriba. Cámbialo en ⚙ Cuentas → Robot de SPY."}
  else if(s.running===false){p.textContent="● BOT DETENIDO · "+RA;p.className="pill bad"}
  else{p.textContent="● ESTADO DESCONOCIDO";p.className="pill warn"}
  $("c1").className="card"+((s.limit_hit||s.bot_pnl<=-s.limit)?" bad":"");
  const e=$("pnl");e.textContent=money(s.pnl);e.className="big mono "+cls(s.pnl);
  $("trades").textContent=s.trades;
  $("wr").textContent=s.trades?Math.round(100*s.wins/s.trades)+"%":"–";
  $("pf").textContent=s.pf==null?"–":s.pf.toFixed(2);
  $("limitmsg").textContent=(s.limit_hit||s.bot_pnl<=-s.limit)?"LÍMITE DE PÉRDIDA ALCANZADO":"";
  for(const [k,v] of [["r_day",s.pnl],["r_wk",s.week],["r_mo",s.month]]){const x=$(k);x.textContent=money(v);x.className=cls(v)}
  $("lim").textContent="-$"+s.limit.toFixed(0);
  for(const k of ["signals","near","chosen","dry_buys"])$(k).textContent=s[k];
  $("position").textContent=s.position||"Ninguna";
  window.__rob=s.robot;const RL=s.robot&&s.robot.account==="live";$("mode").textContent=(RL?"🔴 ROBOT EN REAL · "+s.robot.qty+" contrato(s) · ":"")+(s.dry===null?"Modo: sin datos hoy":s.dry?"Modo: DRY RUN (no envía órdenes)":"Modo: ÓRDENES ACTIVAS ("+(s.sandbox?"sandbox":"REAL")+")");$("mode").style.color=RL?"var(--bad)":"";
  $("bstart").style.display=s.running===true?"none":"";$("bstop").style.display=s.running===true?"":"none";
  if(s.msg)$("msg").textContent=s.msg;else if(!s.env_ok)$("msg").textContent="Falta configurar el token: ejecuta instalar.sh una vez.";
  else if($("msg").dataset.k!=="x"&&s.running===true)$("msg").textContent="";
  $("now").textContent=s.now.slice(11);$("ny").textContent=s.ny;
  const L=$("log");L.textContent="";
  if(!s.log.length)L.textContent="Esperando bot.log…";
  for(const x of s.log){const d=document.createElement("div");d.textContent=x.t;
    d.className=x.c==="err"?"err":x.c==="warn"?"wl":x.c==="bold"?"bl":"";L.appendChild(d)}
  L.scrollTop=L.scrollHeight;chart(s.curve);
  pollLast(s);paintMetrics(s);
  $("c1l").textContent="P&L "+SRCN[s.src]+" (HOY)";$("replbl").textContent="REPORTE · "+SRCN[s.src];
  const E=$("entries");
  if(!s.entries.length)E.innerHTML='<tr><td colspan="6" style="color:var(--mut)">Sin señales hoy</td></tr>';
  else E.innerHTML=s.entries.map(e=>'<tr style="border-top:1px solid var(--line)"><td class="mono">'+e.t+'</td><td class="'+(e.side==="BUY"?"ok":"bad")+'"><b>'+e.side+'</b></td><td class="mono">'+e.px.toFixed(2)+'</td><td class="'+(e.near?"ok":"")+'">'+(e.near?"Sí":"No")+'</td><td>'+e.res.replace(/&/g,"&amp;").replace(/</g,"&lt;")+'</td><td class="mono '+(e.pnl>0?"ok":e.pnl<0?"bad":"")+'" style="text-align:right">'+(e.pnl===null?"–":money(e.pnl))+'</td></tr>').join("");
  const A=s.acct,set=(id,v)=>{const x=$(id);if(v===null||v===undefined){x.textContent="–";x.className=""}else{x.textContent=money(v);x.className=cls(v)}};
  if(A&&A.error&&ACCT_OK){$("a_note").textContent="⏳ Tradier tardó en contestar; se muestran las últimas cifras"}   // sin parpadeo a "–"
  else if(!A||A.error){["a_real","a_open","a_tot","a_man"].forEach(i=>set(i,null));$("a_bot").textContent=money(s.bot_pnl);$("a_note").textContent=A&&A.error?A.error:"Consultando a Tradier…"}
  else{ACCT_OK=true;const tot=(A.realized===null?0:A.realized)+A.open;set("a_real",A.realized);set("a_open",A.open);set("a_tot",A.realized===null?null:tot);
    set("a_bot",s.bot_pnl);set("a_man",A.realized===null?null:tot-s.bot_pnl);
    $("a_note").textContent=(A.note?A.note+". ":"")+""+(LIVE?"Estás viendo tu cuenta REAL. El robot aparece aquí solo si lo configuraste en REAL (⚙ Cuentas → Robot de SPY).":"El robot y tus órdenes manuales comparten la misma cuenta de papel. Manual (estimado) = total de la cuenta − P&L del robot. Con DRY RUN el robot no opera, así que todo lo de la cuenta es manual.")}
  $("a_lbl").textContent=LIVE?"CUENTA REAL · P&L":"CUENTA DE PAPEL · ROBOT + MANUAL";$("tk_mode").textContent=LIVE?"· REAL":"· PAPEL"
}
async function act(what){
  if(what==="start"&&window.__rob&&window.__rob.account==="live"&&!(await askOk("🔴 Vas a iniciar el robot en tu cuenta REAL.\n\n"+window.__rob.qty+" contrato(s) por operación · pérdida máxima diaria $"+window.__rob.max_loss+"\n"+(window.__rob.send?"ENVÍA ÓRDENES REALES con dinero real.":"Modo simulación: solo registra lo que haría, no envía órdenes.")+"\n\n¿Iniciar?")))return;
  if(what==="stop"&&!confirm("¿Detener el bot? Si hay una posición abierta, el stop que ya está en el broker sigue activo, pero el bot dejará de manejarla (trailing y cierre de las 14:45)."))return;
  try{const r=await fetch("/"+what,{method:"POST"});const j=await r.json();$("msg").textContent=j.msg||""}
  catch(e){$("msg").textContent="No se pudo enviar la orden al panel."}
  tick();
}
async function tick(){
  try{const r=await fetch("/data?src="+SRC+"&rng="+RNG,{cache:"no-store"});paint(await r.json());$("foot").textContent="Datos reales de bot.log y trades.csv. Se actualiza cada 2 segundos."}
  catch(e){$("foot").textContent="Sin conexión con monitor_web.py (¿sigue corriendo en la Terminal?)"}
}
tick();setInterval(tick,2000);
try{const gd=$("gdet");gd.open=localStorage.getItem("gdet_open")!=="0";gd.addEventListener("toggle",()=>{try{localStorage.setItem("gdet_open",gd.open?"1":"0")}catch(e){}})}catch(e){}
apRefresh();setInterval(apRefresh,4000);
buildPanes();
</script>
<style>.card{position:relative}.cbtn{position:absolute;top:6px;right:8px;width:26px;height:22px;line-height:18px;padding:0;text-align:center;border:1px solid var(--line,#202027);border-radius:6px;background:transparent;color:var(--mut,#7d8aa5);font:700 15px ui-monospace,Menlo,monospace;cursor:pointer;z-index:3}.cbtn:hover{color:var(--tx,#e6ecf5);border-color:var(--cy,#5cc8ff)}
.card.mini>*:not(.kp):not(.cbtn){display:none!important}.card.mini{padding-bottom:10px}.card.mini .kp{margin-bottom:0!important}
.cbar{display:flex;gap:8px;justify-content:flex-end;margin:0 0 8px}.cbar button{background:transparent;border:1px solid var(--line,#202027);color:var(--mut,#7d8aa5);border-radius:7px;padding:3px 9px;font:600 12px ui-monospace,Menlo,monospace;cursor:pointer}.cbar button:hover{color:var(--tx,#e6ecf5)}</style>
<script>
(function(){
  const PG=location.pathname+(location.search.indexOf("embed")>=0?"?e":"");
  const get=k=>{try{return localStorage.getItem(k)}catch(e){return null}},set=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
  const cards=[...document.querySelectorAll(".card")].filter(c=>c.id!=="gcard"&&c.querySelector(":scope>h2,:scope>.lbl"));
  const apply=(c,mini,save)=>{c.classList.toggle("mini",mini);const b=c.querySelector(":scope>.cbtn");if(b){b.textContent=mini?"+":"_";b.title=mini?"Expandir":"Contraer"}if(save)set(c._k,mini?"1":"0")};
  cards.forEach(c=>{const h=c.querySelector(":scope>h2,:scope>.lbl");h.classList.add("kp");
    c._k="mini:"+PG+":"+h.textContent.trim().slice(0,28);
    const b=document.createElement("button");b.type="button";b.className="cbtn";b.onclick=()=>apply(c,!c.classList.contains("mini"),true);c.appendChild(b);
    apply(c,get(c._k)==="1",false)});
  const host=document.querySelector("main");
  if(host&&cards.length>2){const bar=document.createElement("div");bar.className="cbar";
    bar.innerHTML='<button type="button" id="cb_min">_ Contraer todo</button><button type="button" id="cb_max">+ Expandir todo</button>';
    host.insertBefore(bar,host.firstChild);
    bar.querySelector("#cb_min").onclick=()=>cards.forEach(c=>apply(c,true,true));bar.querySelector("#cb_max").onclick=()=>cards.forEach(c=>apply(c,false,true))}
})();
</script>
<script>
let UPD=null;
async function updCheck(quiet){const m=document.getElementById("updmsg"),b=document.getElementById("bupd");
  try{UPD=await (await fetch("/api/update_check",{cache:"no-store"})).json()}catch(e){UPD=null}
  if(!UPD||!UPD.ok){if(!quiet)m.textContent=(UPD&&UPD.error)||"No pude revisar.";return}
  if(UPD.available){b.textContent="🔄 Actualizar a "+UPD.latest;b.style.background="rgba(92,200,255,.15)";m.textContent="● versión nueva";m.style.color="var(--cy)"}
  else{b.textContent="🔄 Actualizar";b.style.background="";m.style.color="var(--mut)";m.textContent=quiet?"":"Ya tienes la última ("+UPD.current+")"}}
async function updClick(){const m=document.getElementById("updmsg");m.textContent="Revisando…";await updCheck(false);
  if(!UPD||!UPD.ok||!UPD.available)return;
  if(!confirm("Versión nueva: "+UPD.latest+" (tienes "+UPD.current+")\n\n"+(UPD.notes||"")+"\n\nLa terminal se reinicia (unos 15 segundos) y vuelve en PAPEL. Tus claves, licencia y datos no se tocan.\n\n¿Actualizar ahora?"))return;
  m.textContent="Instalando…";let r;
  try{r=await (await fetch("/api/update_apply",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json()}catch(e){r={ok:false,error:"Sin respuesta"}}
  if(!r.ok){m.textContent=r.error||"No se pudo";m.style.color="var(--bad)";return}
  m.textContent="Instalada "+r.version+". Reiniciando…";
  const t0=Date.now();await new Promise(z=>setTimeout(z,5000));
  (async function wait(){try{const x=await fetch("/api/update_check",{cache:"no-store"});if(x.ok){location.reload(true);return}}catch(e){}
    if(Date.now()-t0<90000)setTimeout(wait,2000);else m.textContent="Tarda en volver: recarga la página en un momento."})()}
setTimeout(()=>updCheck(true),4000);setInterval(()=>{if(!document.hidden)updCheck(true)},3600000);
</script>
</body></html>"""


# /trade?embed=1 : el constructor dentro del panel del grafico de inicio (papel y real)
EMBED_CSS = """<style>header,#modenote,#modeBtn,#liveBar{display:none!important}main{padding:6px!important;max-width:none!important}
.two{grid-template-columns:1fr!important}body{overflow-x:hidden}</style>"""
EMBED_BLOCK = """<!doctype html><meta charset="utf-8"><body style="background:#000000;color:#ffc04d;font:14px ui-monospace,Menlo,monospace;padding:20px">
Este constructor integrado solo funciona en la cuenta de PAPEL (en prueba). Para la cuenta real usa Trading manual.</body>"""


PREFS_JS = r"""
/* ===== dibujos, indicadores y colores iguales en todas tus computadoras (se guardan en tu Mac mini) ===== */
(function(){const RE=/^(dr_|ind_|o_)[A-Za-z0-9_.\/^\-]{1,40}$|^(dstyle|c_ema|c_sma|w_ema|w_sma|gexh|gexon|dsc_links)$/;
  let st;try{st=window.localStorage;st.getItem("x")}catch(e){return}
  const set0=Storage.prototype.setItem,rem0=Storage.prototype.removeItem;let VER=null,Q={},T=null,MUTE=false;
  function apply(d,changed){MUTE=true;try{for(const k in d){if(st.getItem(k)!==d[k]){set0.call(st,k,d[k]);changed.push(k)}}}finally{MUTE=false}}
  function push(){T=null;const b=Q;Q={};if(!Object.keys(b).length)return;
    fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({set:b})}).then(r=>r.json()).then(j=>{if(j&&j.ver!=null)VER=j.ver}).catch(()=>{Object.assign(Q,b);T=setTimeout(push,5000)})}
  function q(k,v){if(MUTE||!RE.test(k))return;Q[k]=v;clearTimeout(T);T=setTimeout(push,700)}
  Storage.prototype.setItem=function(k,v){set0.call(this,k,v);if(this===st)q(String(k),String(v))};
  Storage.prototype.removeItem=function(k){rem0.call(this,k);if(this===st)q(String(k),null)};
  /* al abrir la pagina: trae lo guardado ANTES de que se dibujen las graficas */
  try{const x=new XMLHttpRequest();x.open("GET","/api/prefs",false);x.send();const j=JSON.parse(x.responseText);VER=j.ver;
    const ch=[];apply(j.data||{},ch);
    const mine={};for(let i=0;i<st.length;i++){const k=st.key(i);if(RE.test(k)&&!(k in (j.data||{})))mine[k]=st.getItem(k)}   // lo que solo tenia este navegador, se sube
    if(Object.keys(mine).length){Object.assign(Q,mine);T=setTimeout(push,1500)}}catch(e){}
  /* cada 8 s revisa si cambiaste algo en la otra computadora */
  setInterval(async()=>{if(document.hidden||T)return;try{const j=await (await fetch("/api/prefs?since="+VER,{cache:"no-store"})).json();
    if(!j||j.same||j.ver==null)return;VER=j.ver;const d=j.data||{},ch=[];apply(d,ch);
    for(let i=st.length-1;i>=0;i--){const k=st.key(i);if(RE.test(k)&&!(k in d)){MUTE=true;rem0.call(st,k);MUTE=false;ch.push(k)}}
    if(ch.length&&window.onPrefsChanged)try{window.onPrefsChanged(ch)}catch(e){}}catch(e){}},8000)})();
"""


SOLO_HEAD = r"""<script>(function(){
  // Graficos de Portafolio: simbolo, temporalidad y distribucion propios (no cambian los de Inicio); dibujos e indicadores si se comparten.
  const M=k=>/^(psym\d+|ptf\d+|layout|link|tf)$/.test(k)?"pfg_"+k:k;
  const g=Storage.prototype.getItem,s=Storage.prototype.setItem;
  Storage.prototype.getItem=function(k){return g.call(this,M(k))};Storage.prototype.setItem=function(k,v){return s.call(this,M(k),v)};
  window.SOLO=1;
  window.addEventListener("message",e=>{if(e.origin!==location.origin)return;const d=e.data||{};
    if(!d.sym)return;try{if(PANES.length)setSymbol(ACTIVE||PANES[0],String(d.sym).toUpperCase())}catch(x){}});   // PANES es "let": no vive en window
})();</script>
<style>body>main>*:not(#gcard){display:none!important}main{padding:0!important;max-width:none!important}#gcard{margin:0!important;border-radius:0!important;border-left:0!important}
#liveBar{display:none!important}body{padding-top:0!important}</style>"""


def solo_chart():
    html = with_mode(PAGE)
    return html.replace('<meta charset="utf-8">', '<meta charset="utf-8">' + SOLO_HEAD, 1)


# ───────────── tema claro / oscuro (un boton ☀️/🌙 abajo a la izquierda en todas las paginas) ─────────────
THEME_HEAD = r"""<script>(function(){var t=null;try{t=localStorage.getItem("lv_theme")}catch(e){}if(t==="light")document.documentElement.setAttribute("data-theme","light");
document.addEventListener("DOMContentLoaded",function(){if(window.top!==window.self)return;var b=document.createElement("button");b.id="themeBtn";
 b.style.cssText="position:fixed;left:12px;bottom:12px;z-index:9999;border:1px solid #2a2a33;background:#111116;color:#e6ecf5;border-radius:99px;padding:6px 11px;font:600 12px -apple-system,Segoe UI,sans-serif;cursor:pointer;opacity:.75";
 var paint=function(){var l=document.documentElement.getAttribute("data-theme")==="light";b.textContent=l?"🌙 Oscuro":"☀️ Claro";b.title=l?"Cambiar a tema oscuro":"Cambiar a tema claro"};
 b.onmouseenter=function(){b.style.opacity=1};b.onmouseleave=function(){b.style.opacity=.75};
 b.onclick=function(){var l=document.documentElement.getAttribute("data-theme")==="light";if(l)document.documentElement.removeAttribute("data-theme");else document.documentElement.setAttribute("data-theme","light");
  try{localStorage.setItem("lv_theme",l?"dark":"light")}catch(e){}paint();document.querySelectorAll("iframe").forEach(function(f){try{f.contentWindow.location.reload()}catch(e){}})};
 paint();document.body.appendChild(b)});})();</script>
<style>html[data-theme=light]{filter:invert(.93) hue-rotate(180deg);background:#000}
html[data-theme=light] img,html[data-theme=light] video,html[data-theme=light] iframe{filter:invert(1) hue-rotate(180deg)}</style>"""


def themed(html):
    """Agrega el tema claro/oscuro a una pagina."""
    m = re.search(r"<head[^>]*>", html, re.I)
    return html[:m.end()] + THEME_HEAD + html[m.end():] if m else THEME_HEAD + html


def with_mode(html):
    """Agrega a la pagina el boton PAPEL/REAL y la confirmacion escrita de ordenes."""
    html = html.replace('<meta charset="utf-8">', '<meta charset="utf-8"><script>' + PREFS_JS + "</script>", 1)
    html = html.replace("</head>", "<script>" + trading.GRUPOS_JS + "</script></head>", 1)   # juntar / desarmar posiciones
    html = html.replace("<body>", "<body>" + trading.PAUSA_JS, 1) if "<body>" in html else html.replace("<main>", trading.PAUSA_JS + "<main>", 1)
    return html.replace("</body>", trading.MODE_WIDGET + "</body>", 1)


def _no_nan(x):
    if isinstance(x, float):
        return x if x == x and x not in (float("inf"), float("-inf")) else None
    if isinstance(x, dict):
        return {k: _no_nan(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_no_nan(v) for v in x]
    return x


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        try:
            body = json.dumps(obj, allow_nan=False).encode()
        except ValueError:   # algun NaN/infinito de Tradier: el navegador no lo entiende -> null
            body = json.dumps(_no_nan(obj)).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _origin_ok(self):
        host = self.headers.get("Host", "")
        origin = self.headers.get("Origin", "")
        ok_hosts = (f"localhost:{PORT}", f"127.0.0.1:{PORT}")
        return host in ok_hosts and (not origin or origin in tuple("http://" + h for h in ok_hosts))

    def _sse(self, q):
        """Empuja precios en tiempo real a las graficas (Server-Sent Events). Solo lee precios."""
        req = [s for s in (q.get("syms") or [""])[0].split(",") if s][:20]
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        sent, t0, tst = {}, time.time(), 0
        try:
            while time.time() - t0 < 600:   # el navegador se reconecta solo cada 10 min
                rth = trading._rth()
                m = {s: ("SPX" if s == "/SPX" and rth else s) for s in req}
                stream.want(set(m.values()))
                out = {}
                for s, real in m.items():
                    px = stream.price(real)
                    if px and sent.get(s) != px:
                        out[s] = sent[s] = px
                st = stream.status()
                if out or time.time() - tst > 5:
                    tst = time.time()
                    self.wfile.write(("data: " + json.dumps({"p": out, "on": st["on"], "msg": st["msg"]}) + "\n\n").encode())
                    self.wfile.flush()
                time.sleep(0.25)
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def do_GET(self):
        u = urlparse(self.path)
        if self.headers.get("Host", "") not in (f"localhost:{PORT}", f"127.0.0.1:{PORT}"):
            self.send_error(403)   # proteccion contra "DNS rebinding": solo se contesta a localhost
            return
        if u.path == "/api/stream":
            self._sse(parse_qs(u.query))
            return
        if u.path == "/api/uso":
            self._json(200, uso.resumen())
            return
        if u.path == "/api/prefs":
            self._json(200, prefs.get((parse_qs(u.query).get("since") or [None])[0]))
            return
        if u.path == "/api/lineas":
            self._json(200, lineas.state())
            return
        if u.path == "/api/update_check":
            self._json(200, updater.check())
            return
        if u.path.startswith("/api/fund/"):
            if not self._origin_ok():
                self.send_error(403)
                return
            code, obj = fundamentales.handle(u.path, parse_qs(u.query), load_env())
            self._json(code, obj)
            return
        if u.path.startswith("/api/"):
            if not self._origin_ok():
                self.send_error(403)
                return
            if u.path == "/api/tasty":
                e = load_env()
                out = {"configured": tasty.ready(e), "terms": bool(e.get("ACCEPTED_TERMS"))}
                if out["configured"]:
                    try:
                        out["data"] = tasty.resumen(e)
                    except tasty.TastyError as ex:
                        out["error"] = str(ex)
                self._json(200, out)
                return
            if u.path == "/api/setup_status":
                st = setup_wizard.status(ENV_FILE)
                st["license"] = dict(lic.current(), required=lic.required())
                self._json(200, st)
                return
            if u.path == "/api/swing":
                code, obj = swing.handle("GET", u.path, None, load_env())
                self._json(code, obj)
                return
            if u.path == "/api/escaner":
                code, obj = escaner.handle("GET", u.path, parse_qs(u.query), None, load_env())
                self._json(code, obj)
                return
            if u.path == "/api/sombra_op":
                code, obj = sombra_op.handle()
                self._json(code, obj)
                return
            if u.path == "/api/condor_real":
                h = (parse_qs(u.query).get("acct") or [""])[0] == "H"
                r = (condor_real_h if h else condor_real).handle("GET", {})
                if h:
                    r = dict(r, nombre=trading.acct_name(load_env(), "H"), configurada=trading.h_ready(load_env()))
                self._json(200, r)
                return
            if u.path == "/api/filtros":
                self._json(200, filtros.summary())
                return
            if u.path == "/api/sombra":
                code, obj = sombra.handle(parse_qs(u.query), load_env())
                self._json(code, obj)
                return
            if u.path == "/api/senales":
                code, obj = senales.handle(u.path, parse_qs(u.query))
                self._json(code, obj)
                return
            if u.path == "/api/market":
                code, obj = market.handle(parse_qs(u.query), load_env())
                self._json(code, obj)
                return
            code, obj = trading.handle("GET", u.path, parse_qs(u.query), None, load_env())
            self._json(code, obj)
            return
        if u.path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        if u.path in ("/senales", "/sombra"):
            body = themed(senales.PAGE if u.path == "/senales" else sombra.PAGE).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path == "/tasty":
            body = themed(tasty.PAGE).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path == "/setup":
            body = themed(setup_wizard.PAGE).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if lic_blocked() and u.path in ("/", "/index.html", "/trade", "/portafolio", "/fundamentales", "/market", "/escaner", "/swing"):
            self.send_response(302)   # sin licencia valida: al asistente (ahi se activa)
            self.send_header("Location", "/setup")
            self.end_headers()
            return
        if u.path in ("/", "/index.html") and not setup_wizard.status(ENV_FILE)["configured"] and not tasty.ready(load_env()):
            self.send_response(302)   # primera vez: sin cuentas guardadas, lleva al asistente
            self.send_header("Location", "/setup")
            self.end_headers()
            return
        if u.path == "/swing":
            body = themed(with_mode(swing.PAGE)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path == "/escaner":
            body = themed(with_mode(escaner.PAGE)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path in ("/trade", "/portafolio", "/fundamentales", "/market"):
            page = {"/trade": trading.PAGE, "/portafolio": portafolio.PAGE, "/fundamentales": fundamentales.PAGE, "/market": market.PAGE}[u.path]
            html = page if u.path in ("/fundamentales", "/market") else with_mode(page)
            if u.path == "/trade" and "embed" in parse_qs(u.query):
                html = html.replace("</head>", EMBED_CSS + "</head>", 1)
            body, ctype = themed(html).encode(), "text/html; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path in ("/report.xlsx", "/report", "/report.pdf"):
            q = parse_qs(u.query)
            src = (q.get("src") or ["all"])[0]
            rng = (q.get("rng") or ["hoy"])[0]
            if src not in ("robot", "manual", "all") or rng not in ("hoy", "semana", "mes", "todo"):
                self.send_error(400)
                return
            today = datetime.now().strftime("%Y-%m-%d")
            live = trading.MODE["live"]
            rows = reportes.in_range(reportes.load_rows(BASE, src, live), rng, today)
            m = reportes.metrics(rows)
            title = f"Reporte {dict(robot='Robot', manual='Manual', all='Combinado')[src]} · {dict(hoy='hoy', semana='semana', mes='mes', todo='histórico')[rng]} ({today})" + ((" · CUENTA " + trading.acct_name(load_env(), "H").upper()) if live == "H" else " · CUENTA REAL" if live else "")
            if u.path == "/report.xlsx":
                body, ctype = reportes.xlsx_bytes(rows, m, title), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", f'attachment; filename="reporte_{src}_{rng}_{today}.xlsx"')
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == "/report.pdf":
                body = reportes.pdf_bytes(rows, m, title)
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", f'attachment; filename="reporte_{src}_{rng}_{today}.pdf"')
                self.end_headers()
                self.wfile.write(body)
                return
            body, ctype = reportes.print_html(rows, m, title).encode(), "text/html; charset=utf-8"
        elif u.path == "/data":
            q = parse_qs(u.query)
            body, ctype = json.dumps(snapshot((q.get("src") or ["robot"])[0], (q.get("rng") or ["hoy"])[0])).encode(), "application/json"
        elif self.path in ("/", "/index.html"):
            body, ctype = themed(with_mode(PAGE)).encode(), "text/html; charset=utf-8"
        elif u.path == "/grafico":   # solo el grafico de Inicio (lo usa Portafolio dentro de un marco): mismas herramientas
            body, ctype = themed(solo_chart()).encode(), "text/html; charset=utf-8"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self._origin_ok():
            self.send_error(403)  # evita que otra pagina web mande ordenes a tu bot
            return
        if self.path == "/api/prefs":
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 2_000_000)) or b"{}")
                obj = prefs.put(body.get("set"))
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except OSError:
                obj = {"error": "No pude guardar las preferencias"}
            self._json(200, obj)
            return
        if self.path == "/api/lineas":   # robot de lineas SPY (real solo escribiendo REAL)
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 5000)) or b"{}")
                obj = lineas.create(body, load_env()) if body.get("action") == "create" else lineas.update(body)
                obj = {"ok": True, "op": obj}
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except lineas.LineasError as e:
                obj = {"error": str(e)}
            self._json(200, obj)
            return
        if self.path == "/api/update_apply":
            self._json(200, updater.apply())
            return
        if self.path == "/api/license_save":
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 5000)) or b"{}")
                r = lic.save(str(body.get("key", "")))
                obj = dict(r, required=lic.required()) if r["ok"] else {"error": r["error"]}
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except OSError:
                obj = {"error": "No pude guardar la licencia en tu Mac."}
            self._json(200, obj)
            return
        if self.path == "/api/filtros_run":
            if not filtros.STATE["busy"]:
                threading.Thread(target=filtros.run, args=(load_env(),), daemon=True).start()
            self._json(200, {"ok": True})
            return
        if urlparse(self.path).path == "/api/condor_real":
            hmod = (parse_qs(urlparse(self.path).query).get("acct") or [""])[0] == "H"
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 2000)) or b"{}")
            except ValueError:
                body = {}
            if hmod and not trading.h_ready(load_env()):
                self._json(200, {"error": "La cuenta 2 no está configurada (su token va en ⚙ Cuentas)."})
                return
            self._json(200, (condor_real_h if hmod else condor_real).handle("POST", body if isinstance(body, dict) else {}))
            return
        if self.path == "/api/robot_save":
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 5000)) or b"{}")
                obj = setup_wizard.robot_save(ENV_FILE, body, bool(bot_running()))
                sync_robot_paths()
            except setup_wizard.SetupError as e:
                obj = {"error": str(e)}
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except OSError:
                obj = {"error": "No pude guardar el archivo de claves en tu Mac."}
            self._json(200, obj)
            return
        if self.path in ("/api/tasty_save", "/api/tasty_remove"):
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 100_000)) or b"{}")
                obj = tasty.save(ENV_FILE, body) if self.path == "/api/tasty_save" else tasty.remove(ENV_FILE)
            except tasty.TastyError as e:
                obj = {"error": str(e)}
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except OSError:
                obj = {"error": "No pude guardar los datos"}
            self._json(200, obj)
            return
        if self.path in ("/api/setup_check", "/api/setup_save", "/api/setup_remove", "/api/setup_limits", "/api/setup_discord"):
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 5000)) or b"{}")
                if self.path == "/api/setup_check":
                    obj = setup_wizard.check(body)
                elif self.path == "/api/setup_save":
                    obj = setup_wizard.save(ENV_FILE, body)
                elif self.path == "/api/setup_limits":
                    obj = setup_wizard.limits(ENV_FILE, body)
                elif self.path == "/api/setup_discord":
                    obj = setup_wizard.discord_save(ENV_FILE, body)
                else:
                    obj = setup_wizard.remove(ENV_FILE, body.get("kind"))
            except setup_wizard.SetupError as e:
                obj = {"error": str(e)}
            except (ValueError, TypeError):
                obj = {"error": "Datos no válidos"}
            except OSError:
                obj = {"error": "No pude guardar el archivo de claves en tu Mac (revisa permisos de tu carpeta personal)."}
            self._json(200, obj)
            return
        if self.path.startswith("/api/"):
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(min(n, 20000)) or b"{}")
            except (ValueError, TypeError):
                self._json(200, {"error": "Datos no válidos"})
                return
            blk = lic_order_block(urlparse(self.path).path, body if isinstance(body, dict) else {})
            if blk:
                self._json(200, {"error": blk})
                return
            if urlparse(self.path).path == "/api/swing_scan":
                code, obj = swing.handle("POST", "/api/swing_scan", body, load_env())
                self._json(code, obj)
                return
            if urlparse(self.path).path in ("/api/escaner_scan", "/api/escaner_lista", "/api/escaner_manual", "/api/escaner_pend"):
                code, obj = escaner.handle("POST", urlparse(self.path).path, {}, body if isinstance(body, dict) else {}, load_env())
                self._json(code, obj)
                return
            code, obj = trading.handle("POST", urlparse(self.path).path, {}, body, load_env())
            self._json(code, obj)
            return
        if self.path == "/fund_install":
            res = fundamentales.install()
            self._json(200, res)
            if res.get("ok") and res.get("launchd"):
                threading.Timer(2.0, lambda: os._exit(0)).start()   # launchd (KeepAlive) lo vuelve a levantar con la libreria nueva
            return
        if self.path == "/notify_test":
            self._json(200, {"res": avisos.send(load_env(), "LV Options Terminal · prueba", "Si ves esto, los avisos funcionan ✅")})
            return
        if self.path == "/start":
            ok, msg = start_bot()
        elif self.path == "/stop":
            ok, msg = stop_bot()
        else:
            self.send_error(404)
            return
        body = json.dumps({"ok": ok, "msg": msg}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


def main():
    sync_robot_paths()
    # 127.0.0.1: solo tu Mac puede verlo, nadie más en tu red
    threading.Thread(target=scheduler, daemon=True).start()
    if "robot_spy" not in sombra.APAGADO:   # estudio apagado en el modo sombra (ver sombra.APAGADO)
        threading.Thread(target=senales.loop, args=(load_env,), daemon=True).start()
    if "robot_spy" not in sombra.APAGADO:   # estudio apagado en el modo sombra (ver sombra.APAGADO)
        threading.Thread(target=sombra_op.loop, args=(load_env,), daemon=True).start()
    threading.Thread(target=condor.loop, args=(load_env,), daemon=True).start()
    threading.Thread(target=condor_mensual.loop, args=(load_env,), daemon=True).start()
    threading.Thread(target=condor_noche.loop, args=(load_env,), daemon=True).start()
    threading.Thread(target=sombra2.loop, args=(load_env,), daemon=True).start()   # sombra: QQQ condor, SPY put spread, condors 0DTE
    threading.Thread(target=stream.loop, args=(load_env,), daemon=True).start()
    uso.install()   # contador de consultas a Tradier (tradier_uso.json y /api/uso)
    if "escaner_spreads" not in sombra.APAGADO:   # revision diaria automatica del escaner de spreads (apagada: se puede escanear a mano en /escaner)
        threading.Thread(target=escaner.loop, args=(load_env, lambda t, x: avisos.send(load_env(), t, x)), daemon=True).start()
    threading.Thread(target=acct_refresher, daemon=True).start()
    threading.Thread(target=lineas.loop, args=(load_env, lambda t, x: avisos.send(load_env(), t, x)), daemon=True).start()   # robot de lineas SPY
    threading.Thread(target=pausa.loop, args=(lambda t, x: avisos.send(load_env(), t, x),), daemon=True).start()   # avisos de la pausa tras 2 perdidas
    threading.Thread(target=swing.loop, args=(load_env,), daemon=True).start()   # escaner de swing en acciones (16:55 ET)
    threading.Thread(target=pf.alert_loop, args=(load_env, avisos.send), daemon=True).start()   # alertas de precio + valor diario de la cuenta
    threading.Thread(target=notify_watcher, daemon=True).start()
    threading.Thread(target=manual_sync_loop, daemon=True).start()
    threading.Thread(target=gestor.loop, args=(load_env, lambda t, x: avisos.send(load_env(), t, x)), daemon=True).start()
    threading.Thread(target=condor_real.loop, args=(load_env, lambda t, x: avisos.send(load_env(), t, x)), daemon=True).start()
    threading.Thread(target=pnl_rec.loop, args=(load_env,), daemon=True).start()   # graba el precio medio de tus posiciones cada minuto
    threading.Thread(target=condor_real_h.loop, args=(load_env, lambda t, x: avisos.send(load_env(), t, x)), daemon=True).start()   # cuenta 2 (no hace nada si no esta activado)
    threading.Thread(target=filtros.loop, args=(load_env,), daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Panel listo. Abre en tu navegador:  http://localhost:{PORT}   (Ctrl+C para parar)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
