"""Auto-actualizacion de LV Options Terminal desde GitHub (solo libreria estandar + requests).
Seguridad: cada version publicada viene FIRMADA con la llave privada de Luis (RSA 3072, PKCS#1 v1.5 SHA-256).
Aqui solo vive la llave PUBLICA; si la firma o el sha256 del ZIP no cuadran, no se instala nada.
Solo se reemplazan archivos de programa (*.py, instalar.sh, version.txt); nunca claves, licencia ni datos."""
import hashlib
import io
import json
import os
import re
import shutil
import threading
import time
import zipfile

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
REPO = "luisverdhdez/lv-terminal"
RAW = f"https://raw.githubusercontent.com/{REPO}/main/"
MANIFEST_URL = RAW + "manifest.json"
VERSION_FILE = os.path.join(BASE, "version.txt")
PUB_N = int("0xd2e6e0a73b7ed9ad3e3517b354cff0551ad3bc08162660624acb1b400127c558f5601f6ff5c6a5bb384e07567ff81e7cd1e90e52d5402e79a9f8bc5340fd62a1b4ad57d32d87a70fb4a4ac4024cc8d6cce023f313dd835a18bf897c2a0de21f931a7634a515aaa1bedd540f601e2f789125dd6594810d2ee6a4b2a4926781a7d8f13c9a35a4fc12f1e240df52d774fba7e5649c8d0dad8424143bc707758986c5584dd7c199aeb7a04d0e2abb0e6d10e3b8f56051cf8fcb108650d34baf1a3032e5e8e57c056284a90ba54e6e579031d95069da916e3d18908d43753a56c886e2456b158fbed43f9a2e96e88f40b2372735c73e067ace5eb34bb11dcc216d2aa5aeda056cdacdea2ddd62ac46a3570031d9abc693f5f182497342c685d77ec3691c63c5e1cd9e784fa3c51ffa7178891ff313ccc8792bfbd056715ba4337dcb5485f6ff9f0af97947a12bc767017ad31531b9bab262ed69ca11c0da2ee76da95ff29e0ad24c9ea28ee7fdd136e14fbc3c178a576d832048e41adac77e4ad316f", 16)
PUB_E = 65537
MAX_ZIP = 20_000_000
SAFE = re.compile(r"^[A-Za-z0-9_]+\.py$|^instalar\.sh$|^version\.txt$|^[A-Za-z0-9_]+_windows\.(ps1|bat)$|^INSTALAR_WINDOWS\.bat$")
_DI = bytes.fromhex("3031300d060960864801650304020105000420")
_lock = threading.Lock()


def current():
    try:
        with open(VERSION_FILE, encoding="utf-8") as f:
            return f.read().strip() or "0"
    except OSError:
        return "0"


def payload(m):
    """Texto exacto que se firma."""
    return f"LV1\n{m['version']}\n{m['sha256']}\n{int(m['size'])}\n{m['file']}".encode()


def _em(data, k):
    t = _DI + hashlib.sha256(data).digest()
    return int.from_bytes(b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t, "big")


def sign(m, n, e, d):
    k = (n.bit_length() + 7) // 8
    return pow(_em(payload(m), k), d, n).to_bytes(k, "big").hex()


def verify(m, n=None, e=None):
    n, e = n or PUB_N, e or PUB_E
    try:
        k = (n.bit_length() + 7) // 8
        s = int(m["sig"], 16)
        if not re.fullmatch(r"[0-9A-Za-z._-]{1,40}", str(m["version"])) or not SAFE_FILE.fullmatch(str(m["file"])):
            return False
        return 0 < s < n and pow(s, e, n) == _em(payload(m), k)
    except (KeyError, ValueError, TypeError):
        return False


SAFE_FILE = re.compile(r"[A-Za-z0-9_.-]{1,80}\.zip")


def newer(a, b):
    """True si la version a es mas nueva que b (formato AAAA-MM-DD + letra opcional)."""
    return str(a) > str(b)


def _get(url, timeout=15):
    r = requests.get(url, timeout=timeout, headers={"Cache-Control": "no-cache"}, params={"t": int(time.time())})
    r.raise_for_status()
    return r


def check():
    cur = current()
    try:
        m = _get(MANIFEST_URL).json()
    except Exception as ex:  # sin internet, GitHub caido, etc.
        return {"ok": False, "current": cur, "error": f"No pude revisar GitHub ({type(ex).__name__})."}
    if not verify(m):
        return {"ok": False, "current": cur, "error": "La version publicada no trae una firma valida; no se instala."}
    return {"ok": True, "current": cur, "latest": m["version"], "available": newer(m["version"], cur),
            "notes": str(m.get("notes", ""))[:2000]}


def install_zip(data, m, base=BASE):
    """Verifica el ZIP contra el manifiesto firmado y copia los archivos de programa. -> lista de archivos."""
    if len(data) != int(m["size"]) or hashlib.sha256(data).hexdigest() != m["sha256"]:
        raise ValueError("El archivo descargado no coincide con la version firmada.")
    files = {}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename.rsplit("/", 1)[-1]
            if info.filename.count("/") > 1 or ".." in info.filename or not SAFE.match(name):
                continue
            files[name] = z.read(info)
    if "monitor_web.py" not in files or "updater.py" not in files:
        raise ValueError("El paquete esta incompleto.")
    for name, body in files.items():
        if name.endswith(".py"):
            compile(body, name, "exec")  # nunca instalar algo con error de sintaxis
    bk = os.path.join(base, "_respaldo_auto", time.strftime("%Y%m%d_%H%M%S"))
    os.makedirs(bk, exist_ok=True)
    for name in files:
        p = os.path.join(base, name)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(bk, name))
    for name, body in files.items():
        p = os.path.join(base, name)
        tmp = p + ".nuevo"
        with open(tmp, "wb") as f:
            f.write(body)
        if name.endswith(".sh"):
            os.chmod(tmp, 0o755)
        os.replace(tmp, p)
    with open(VERSION_FILE if base == BASE else os.path.join(base, "version.txt"), "w", encoding="utf-8") as f:
        f.write(m["version"] + "\n")
    _prune(os.path.join(base, "_respaldo_auto"))
    return sorted(files), bk


def _prune(d, keep=5):
    try:
        old = sorted(os.listdir(d))[:-keep]
        for x in old:
            shutil.rmtree(os.path.join(d, x), ignore_errors=True)
    except OSError:
        pass


def apply(restart=True):
    if not _lock.acquire(blocking=False):
        return {"ok": False, "error": "Ya se esta actualizando."}
    try:
        m = _get(MANIFEST_URL).json()
        if not verify(m):
            return {"ok": False, "error": "Firma no valida; no se instalo nada."}
        if not newer(m["version"], current()):
            return {"ok": False, "error": "Ya tienes la ultima version."}
        r = _get(RAW + m["file"], timeout=60)
        if len(r.content) > MAX_ZIP:
            return {"ok": False, "error": "Archivo demasiado grande."}
        files, bk = install_zip(r.content, m)
    except Exception as ex:
        return {"ok": False, "error": f"No se pudo actualizar: {ex}"}
    finally:
        _lock.release()
    if restart:
        # launchd (KeepAlive) vuelve a abrir el panel en unos segundos; siempre arranca en PAPEL.
        threading.Timer(1.5, lambda: os._exit(0)).start()
    return {"ok": True, "version": m["version"], "files": len(files), "backup": bk}
