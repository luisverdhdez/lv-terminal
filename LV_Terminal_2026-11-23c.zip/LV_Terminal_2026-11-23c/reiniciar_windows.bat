@echo off
rem Reinicia LV Options Terminal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0reiniciar_windows.ps1"
