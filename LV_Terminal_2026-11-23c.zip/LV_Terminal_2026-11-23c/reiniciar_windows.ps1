# Reinicia LV Options Terminal en Windows: cierra el panel y el lanzador lo vuelve a abrir solo.
$DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$c = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
if ($c) {
  $c | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
  Write-Host "Reiniciando... en unos segundos recarga el navegador."
} else {
  $pyw = "pythonw"
  $f = Join-Path $DIR "python_path.txt"
  if (Test-Path $f) { $pyw = (Get-Content $f -Raw).Trim() }
  Start-Process -FilePath $pyw -ArgumentList "`"$DIR\lanzador.py`"" -WorkingDirectory $DIR -WindowStyle Hidden
  Write-Host "La terminal estaba cerrada: abriendola..."
}
Start-Sleep -Seconds 3
