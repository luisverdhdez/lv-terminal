@echo off
rem Doble clic aqui para instalar LV Options Terminal en Windows
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_windows.ps1"
echo.
pause
