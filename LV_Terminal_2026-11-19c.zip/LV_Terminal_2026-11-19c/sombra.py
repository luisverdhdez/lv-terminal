"""
Pestaña "Modo sombra" (/sombra): junta en un solo lugar los tres modos sombra del panel y responde las preguntas pendientes.
  1) Señales del robot (senales.py)      -> ¿conviene exigir la Corona 1·3·5? ¿conviene cerrar por señal contraria?
  2) Contratos (sombra_op.py)            -> opcion del robot vs debit spread 0DTE
  3) Escaner swing (escaner.py)          -> ¿los put credit spreads llegan al 50 % del credito?
Solo LEE los archivos que ya escriben esos procesos. No envia ordenes, no cambia ninguna configuracion.
"""
import os
import time
from datetime import datetime, time as dtime

import tradier_bot as tb
import senales
import sombra_op
import escaner
import condor
import condor_mensual
import condor_noche

ET = tb.ET
DIAS_META = 5        # dias de mercado minimos antes de decidir
N_META = 30          # señales minimas para que deje de ser "solo indicios"
N_META_ESC = 10      # spreads del escaner minimos


def _n(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _avg(v):
    v = [x for x in v if x is not None]
    return round(sum(v) / len(v), 2) if v else None


def _pct(v):
    v = [x for x in v if x is not None]
    return round(100.0 * sum(1 for x in v if x > 0) / len(v)) if v else None


def _mtime(p):
    try:
        return os.path.getmtime(p)
    except OSError:
        return None


def _mins(a, b):
    try:
        ha, ma = map(int, a.split(":"))
        hb, mb = map(int, b.split(":"))
        return (hb * 60 + mb) - (ha * 60 + ma)
    except (ValueError, AttributeError):
        return None


# ───────────── salida por señal contraria (calculada con las señales ya guardadas) ─────────────
def contraria(rows):
    """A cada señal le agrega la salida en la siguiente señal del lado contrario del MISMO dia.
    Devuelve una lista de dicts: fila original + 'mov_contra' (dolares de SPY a favor) y 'min_contra'."""
    by_day = {}
    for r in rows:
        by_day.setdefault(r.get("fecha"), []).append(r)
    out = []
    for day, lst in by_day.items():
        lst = sorted(lst, key=lambda r: r.get("hora_vela") or "")
        for i, r in enumerate(lst):
            p0, sg = _n(r.get("precio")), (1 if r.get("lado") == "buy" else -1)
            nxt = next((x for x in lst[i + 1:] if x.get("lado") != r.get("lado")), None)
            mv = mn = None
            if nxt is not None and p0 is not None and _n(nxt.get("precio")) is not None:
                mv = round((_n(nxt["precio"]) - p0) * sg, 2)
                mn = _mins(r.get("hora_vela"), nxt.get("hora_vela"))
            out.append(dict(r, mov_contra=mv, min_contra=mn))
    return out


def _grp_sen(rows):
    m15 = [_n(r.get("mov15")) for r in rows]
    return {"n": len(rows), "fav15": _pct(m15), "avg15": _avg(m15), "med15": sum(1 for x in m15 if x is not None)}


def _estado(dias, n, meta_n=N_META):
    if dias < DIAS_META:
        return {"nivel": "espera", "txt": f"Faltan {DIAS_META - dias} día(s) de mercado (lleva {dias} de {DIAS_META})"}
    if n < meta_n:
        return {"nivel": "indicio", "txt": f"Ya pasaron {DIAS_META} días, pero solo hay {n} señales (meta {meta_n}): son indicios"}
    return {"nivel": "listo", "txt": "Ya hay datos suficientes para mirar y decidir"}


def _lectura(a, b, nom_a, nom_b, unidad="$", umbral=0.0):
    """Frase corta: cual va mejor POR AHORA. a/b = promedio de cada opcion."""
    if a is None or b is None:
        return "Todavía no hay mediciones para comparar."
    d = b - a
    if abs(d) <= umbral:
        return f"Por ahora van prácticamente igual ({nom_a} vs {nom_b})."
    mejor, peor = (nom_b, nom_a) if d > 0 else (nom_a, nom_b)
    txt = f"${abs(d):.2f}" if unidad == "$" else f"{abs(d):.0f} {unidad}"
    return f"Por ahora va mejor {mejor} (+{txt} de diferencia promedio frente a {peor})."



# ───────────── objetivo y stop (simulado con los precios reales guardados por sombra_op) ─────────────
TPS = (8, 12, 15, 20)          # objetivo en dolares por contrato
SLS = (10, 15)                 # stop en dolares por contrato
LIMITE_MIN = 30.5              # sombra_op sigue ~35 min; se mide hasta 30


def _serie(e):
    """[(minuto, ganancia en $ por contrato)] de la opcion del robot: entra al ask, vale el bid."""
    if not e.get("single"):
        return []
    cost = e["single"]["ask"]
    return [(s["m"], (s["s"] - cost) * 100) for s in e.get("samples", []) if s.get("s") is not None and s["m"] <= LIMITE_MIN]


def sim_fijo(ser, tp, sl):
    """Sale todo al tocar +tp o -sl (al precio de esa muestra); si no toca nada, sale a los 30 min."""
    if not ser:
        return None
    for m, v in ser:
        if v >= tp or v <= -sl:
            return v
    return ser[-1][1]


def sim_robot(ser, dist=5.0, qty=3, stop=15.0, tp1=8.0, act=5.0, step=1.0):
    """Imita las salidas del robot (promedio por contrato): stop inicial, vende 1 en +tp1, trailing que se
    activa en +act y va `dist` detras del maximo. Si a los 30 min sigue abierta, sale ahi."""
    if not ser:
        return None
    st, hwm, rem, tot, tp_done = -stop, 0.0, qty, 0.0, False
    for m, v in ser:
        if v <= st:
            return (tot + v * rem) / qty
        hwm = max(hwm, v)
        if not tp_done and rem > 1 and v >= tp1:
            tot += v
            rem -= 1
            tp_done = True
        if v >= act:
            ns = hwm - dist
            if v <= ns:
                return (tot + v * rem) / qty
            if ns >= st + step:
                st = ns
    return (tot + ser[-1][1] * rem) / qty


def salidas(ents):
    ser = [s for s in (_serie(e) for e in ents) if s]
    def res(vals):
        v = [x for x in vals if x is not None]
        return {"n": len(v), "avg": round(sum(v) / len(v), 1) if v else None,
                "win": round(100 * sum(1 for x in v if x > 0) / len(v)) if v else None,
                "peor": round(min(v), 1) if v else None, "total": round(sum(v), 0) if v else None}
    filas = [{"nombre": "Robot hoy (stop −$15, vende 1 en +$8, trailing $5)", "r": res([sim_robot(s) for s in ser]), "actual": True},
             {"nombre": "Robot con trailing más amplio ($10)", "r": res([sim_robot(s, dist=10.0) for s in ser])},
             {"nombre": "Robot con stop más corto (−$10)", "r": res([sim_robot(s, stop=10.0) for s in ser])}]
    for sl in SLS:
        for tp in TPS:
            filas.append({"nombre": f"Objetivo +${tp} · stop −${sl} (todo de una vez)", "r": res([sim_fijo(s, tp, sl) for s in ser]), "tp": tp, "sl": sl})
    best = max((f for f in filas if f["r"]["avg"] is not None), key=lambda f: f["r"]["avg"], default=None)
    return {"n": len(ser), "filas": filas, "mejor": best["nombre"] if best else None}

# ───────────── resumen ─────────────
def summary(src, env):
    rows = senales.read_rows(src)
    dias_sen = sorted({r["fecha"] for r in rows if r.get("fecha")})
    rc = contraria(rows)
    cerca = [r for r in rc if r.get("cerca_hhll") == "1"]
    cerca_cor = [r for r in cerca if r.get("corona") == "1"]
    # robot real: solo en su horario
    cerca_h = [r for r in cerca if r.get("en_horario") == "1"]

    # P1 Corona
    g_a, g_b = _grp_sen(cerca_h), _grp_sen([r for r in cerca_h if r.get("corona") == "1"])
    p1 = {"a": g_a, "b": g_b, "dias": len(dias_sen), "estado": _estado(len(dias_sen), g_b["n"]),
          "lectura": _lectura(g_a["avg15"], g_b["avg15"], "sin exigir Corona", "con Corona", umbral=0.02)}

    # P3 señal contraria (mismo grupo de señales, solo las que tienen salida contraria ese dia)
    both = [r for r in cerca_h if r.get("mov_contra") is not None and _n(r.get("mov15")) is not None]
    fijo = [_n(r["mov15"]) for r in both]
    contra = [r["mov_contra"] for r in both]
    p3 = {"n": len(both), "fijo": {"avg": _avg(fijo), "fav": _pct(fijo)},
          "contra": {"avg": _avg(contra), "fav": _pct(contra), "min": _avg([_n(r["min_contra"]) for r in both])},
          "dias": len(dias_sen), "estado": _estado(len(dias_sen), len(both)),
          "lectura": _lectura(_avg(fijo), _avg(contra), "salir a los 15 min", "salir por señal contraria", umbral=0.02)}

    # P2 contratos
    d = sombra_op._load()
    ents = d.get("ent", [])
    dias_op = sorted({e["fecha"] for e in ents})
    ce = [e for e in ents if e.get("cerca")]
    a = [p for p in (sombra_op._pnls(e, "s") for e in ce) if p]
    b = [p for p in (sombra_op._pnls(e, "p") for e in ce) if p]
    c3 = [p for p in (sombra_op._pnls(e, "s3") for e in ce) if p]
    ra, rb, r3 = sombra_op._agg(a), sombra_op._agg(b), sombra_op._agg(c3)
    # comparacion justa A vs C: solo las señales que tienen las dos opciones
    ac_both = [e for e in ce if e.get("single") and e.get("single3")]
    pa2 = [p for p in (sombra_op._pnls(e, "s") for e in ac_both) if p]
    pc2 = [p for p in (sombra_op._pnls(e, "s3") for e in ac_both) if p]

    def roc(items):  # rendimiento sobre lo invertido a 15 min: ganancia total / costo total
        v = [x for x in items if x.get(15) is not None and x.get("cost")]
        tc = sum(x["cost"] for x in v)
        return round(sum(x[15] for x in v) / tc * 100, 1) if tc else None
    ra["roc15"], rb["roc15"], r3["roc15"] = roc(a), roc(b), roc(c3)
    pareja = {"n": len(ac_both), "a15": sombra_op._agg(pa2).get("avg15"), "c15": sombra_op._agg(pc2).get("avg15"),
              "a30": sombra_op._agg(pa2).get("avg30"), "c30": sombra_op._agg(pc2).get("avg30")}
    p2 = {"a": ra, "b": rb, "c": r3, "par": pareja, "n_total": len(ents), "dias": len(dias_op), "estado": _estado(len(dias_op), min(ra["n"], rb["n"])),
          "lectura": _lectura(ra["roc15"], rb["roc15"], "la opción del robot", "el debit spread", unidad="% sobre lo invertido", umbral=1)}

    # P5 objetivo y stop (solo las señales que toma el robot: cerca de HH/LL)
    sx = salidas(ce)
    act = next((f["r"]["avg"] for f in sx["filas"] if f.get("actual")), None)
    bv = next((f for f in sx["filas"] if f["nombre"] == sx["mejor"]), None)
    if act is None or bv is None:
        lec = "Todavía no hay mediciones para comparar."
    elif bv.get("actual") or abs(bv["r"]["avg"] - act) < 1:
        lec = "Por ahora las salidas actuales del robot están entre las mejores."
    else:
        lec = f"Por ahora la mejor es «{bv['nombre']}»: ${bv['r']['avg'] - act:+.1f} por contrato frente a las salidas actuales."
    p5 = dict(sx, dias=len(dias_op), estado=_estado(len(dias_op), sx["n"]), lectura=lec)

    # P6 iron condor SPX
    cs = condor.summary()
    p6 = dict(cs, estado=({"nivel": "listo", "txt": f"{cs['terminados']} condors terminados: ya se puede mirar"} if cs["terminados"] >= 45
              else {"nivel": "espera" if cs["terminados"] < 15 else "indicio",
                    "txt": (f"{cs['terminados']} de 45 condors terminados (15 por delta, unas 5 semanas)" if cs["n"]
                            else "Empieza solo el próximo lunes, martes o miércoles a las 10:00 ET")}))

    # P7 iron condor mensual SPX (A2)
    cm = condor_mensual.summary()
    p7 = dict(cm, estado=({"nivel": "listo", "txt": f"{cm['terminados']} meses terminados"} if cm["terminados"] >= 6
              else {"nivel": "espera" if cm["terminados"] < 3 else "indicio",
                    "txt": (f"{cm['terminados']} de 6 meses terminados (uno por mes)" if cm["n"]
                            else (cm["msg"] or "Entra cuando falten 30 días para el próximo vencimiento mensual"))}))

    # P8 iron condor de una noche
    cn = condor_noche.summary()
    p8 = dict(cn, estado=({"nivel": "listo", "txt": f"{cn['terminados']} noches terminadas"} if cn["terminados"] >= 20
              else {"nivel": "espera" if cn["terminados"] < 10 else "indicio",
                    "txt": (f"{cn['terminados']} de 20 noches terminadas (unas 4 semanas)" if cn["n"]
                            else (cn["msg"] or "Empieza solo el próximo día hábil a las 15:30 ET"))}))

    # P4 escaner
    hs = escaner.hist_summary()
    hist = escaner._load(escaner.F_HIST, [])
    dias_esc = sorted({h["fecha"] for h in hist})
    cerradas = [h for h in hist if h.get("closed")]
    p4 = {"s": hs, "dias": len(dias_esc), "cerradas": len(cerradas),
          "estado": ({"nivel": "listo", "txt": f"Ya hay {len(cerradas)} spreads terminados: se puede mirar y decidir"} if len(cerradas) >= N_META_ESC
                     else {"nivel": "espera" if hist else "espera",
                           "txt": (f"Lleva {hs['n']} señal(es) verde(s), {len(cerradas)} terminada(s); meta: {N_META_ESC} terminadas (un spread dura semanas)"
                                   if hist else "Aún no hay señales verdes del escáner")}),
          "lista": [{k: h.get(k) for k in ("fecha", "sym", "short", "long", "credit", "exp", "max_pct", "last_pct", "d25", "d50", "touched", "closed", "stop_hit")} for h in hist[-15:][::-1]]}

    # dia por dia
    by = {}
    for r in rc:
        by.setdefault(r["fecha"], []).append(r)
    ops = {}
    for e in ents:
        ops.setdefault(e["fecha"], []).append(e)
    dias = []
    for f in sorted(set(by) | set(ops), reverse=True):
        lst = by.get(f, [])
        ch = [r for r in lst if r.get("cerca_hhll") == "1" and r.get("en_horario") == "1"]
        cc = [r for r in ch if r.get("corona") == "1"]
        oe = [e for e in ops.get(f, []) if e.get("cerca")]
        pa = [p[15] for p in (sombra_op._pnls(e, "s") for e in oe) if p and p.get(15) is not None]
        pb = [p[15] for p in (sombra_op._pnls(e, "p") for e in oe) if p and p.get(15) is not None]
        dias.append({"fecha": f, "n": len(lst), "cerca": len(ch), "tomadas": sum(1 for r in lst if r.get("tomada") == "1"),
                     "fav15": _pct([_n(r.get("mov15")) for r in ch]), "avg15": _avg([_n(r.get("mov15")) for r in ch]),
                     "cor_n": len(cc), "cor_avg15": _avg([_n(r.get("mov15")) for r in cc]),
                     "contra": _avg([r["mov_contra"] for r in ch]),
                     "op_n": len(oe), "op_a": _avg(pa), "op_b": _avg(pb)})

    # procesos
    now = datetime.now(ET)
    t = now.time()
    habil = now.weekday() < 5
    env = env or {}
    procs = [
        {"nombre": "Señales del robot", "horario": "9:31 a 16:35 ET, cada minuto",
         "activo": habil and dtime(9, 31) <= t <= dtime(16, 35),
         "ultima": _mtime(senales.FILES[src]), "hoy": senales.STATE["last"].get(src), "error": senales.STATE["err"].get(src),
         "token": bool(env.get("TRADIER_LIVE_TOKEN" if src == "live" else "TRADIER_TOKEN")), "link": "/senales"},
        {"nombre": "Comparar contratos", "horario": "9:40 a 16:10 ET, cada 20 s (necesita token real)",
         "activo": habil and dtime(9, 40) <= t <= dtime(16, 10),
         "ultima": sombra_op.STATE.get("last") or _mtime(sombra_op.FILE), "hoy": sum(1 for e in ents if e["fecha"] == now.strftime("%Y-%m-%d")),
         "error": sombra_op.STATE.get("err"), "token": bool(env.get("TRADIER_LIVE_TOKEN")), "link": "/senales"},
        {"nombre": "Escáner swing", "horario": "Revisión diaria 16:40 ET · precios cada 5 min en horario",
         "activo": bool(escaner.STATE.get("busy")) or (habil and dtime(9, 30) <= t <= dtime(16, 5)),
         "ultima": _mtime(escaner.F_HIST) or _mtime(escaner.F_RES), "hoy": escaner.STATE.get("prog") or None,
         "error": escaner.STATE.get("err"), "token": bool(env.get("TRADIER_LIVE_TOKEN") or env.get("TRADIER_TOKEN")), "link": "/escaner"},
        {"nombre": "Iron condor SPX", "horario": "Entra lun–mié 10:00 ET · revisa cada 5 min · liquida el viernes 16:10 (token real)",
         "activo": habil and dtime(9, 30) <= t <= dtime(16, 15),
         "ultima": cs["last"], "hoy": sum(1 for x in cs["lista"] if x["fecha"] == now.strftime("%Y-%m-%d")) or None,
         "error": cs["err"], "token": bool(env.get("TRADIER_LIVE_TOKEN")), "link": "#condor"},
        {"nombre": "Iron condor mensual SPX (A2)", "horario": "Entra a 30 días del vencimiento, 10:00 ET · revisa cada 5 min (token real)",
         "activo": habil and dtime(9, 30) <= t <= dtime(16, 15),
         "ultima": cm["last"], "hoy": sum(1 for x in cm["lista"] if x["fecha"] == now.strftime("%Y-%m-%d")) or None,
         "error": cm["err"], "token": bool(env.get("TRADIER_LIVE_TOKEN")), "link": "#condorm"},
        {"nombre": "Iron condor de una noche SPX", "horario": "Entra 15:30 ET · precios 15:30–17:00 y 8:00–10:35 cada 5 min (token real)",
         "activo": habil and (dtime(15, 30) <= t <= dtime(17, 2) or dtime(8, 0) <= t <= dtime(10, 37)),
         "ultima": cn["last"], "hoy": sum(1 for x in cn["lista"] if x["fecha"] == now.strftime("%Y-%m-%d")) or None,
         "error": cn["err"], "token": bool(env.get("TRADIER_LIVE_TOKEN")), "link": "#condorn"},
    ]
    return {"src": src, "ahora": now.strftime("%Y-%m-%d %H:%M"), "mercado": habil and dtime(9, 30) <= t < dtime(16, 0),
            "meta": {"dias": DIAS_META, "n": N_META}, "procesos": procs,
            "p1": p1, "p2": p2, "p3": p3, "p4": p4, "p5": p5, "p6": p6, "p7": p7, "p8": p8, "dias": dias}


def handle(q, env):
    src = (q.get("src") or [""])[0]
    if src not in senales.FILES:
        src = "live" if senales.read_rows("live") else "sandbox"
    return 200, summary(src, env)


PAGE = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Modo sombra · LV Options Terminal</title><style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif;padding:16px 24px;max-width:2000px;margin:0 auto}
a{color:var(--cy);text-decoration:none;font-weight:700}h1{font:700 18px ui-monospace,Menlo,monospace;margin:6px 0 12px}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:10px}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 6px;white-space:nowrap}
td{padding:6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
.mono{font-family:ui-monospace,Menlo,monospace}.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}.warn{color:var(--warn)}
button{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:6px 12px;cursor:pointer;font-weight:700}
button.on{color:var(--tx);border-color:var(--cy)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,460px),1fr));gap:14px}.qt th,.qt td{padding:5px 5px;font-size:12.5px}
.q{background:#0a0a0d;border:1px solid var(--line);border-radius:12px;padding:14px}
.q h3{margin:0 0 4px;font-size:15px}.q .p{color:var(--mut);font-size:13px;margin-bottom:10px;line-height:1.4}
.badge{display:inline-block;font-size:12px;font-weight:700;padding:3px 9px;border-radius:999px;margin-bottom:10px}
.b-espera{background:#2a2410;color:var(--warn)}.b-indicio{background:#10243a;color:var(--cy)}.b-listo{background:#0f2a22;color:var(--ok)}
.bar{height:8px;background:var(--line);border-radius:6px;overflow:hidden;margin:6px 0 10px}.bar>i{display:block;height:100%;background:var(--warn)}
.lect{font-size:13px;margin-top:10px;line-height:1.4}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;vertical-align:middle}
</style></head><body>
<div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;align-items:center"><h1>🧪 MODO SOMBRA · PROCESOS Y RESULTADOS</h1><a href="/">← Inicio</a></div>
<div class="card"><div class="mut" style="font-size:13px;line-height:1.5">Aquí ves en un solo lugar los tres modos sombra: <b>qué están haciendo</b> y <b>qué van diciendo</b>. Ninguno envía órdenes ni cambia la configuración del robot: solo miran y anotan.
La regla es esperar <b>al menos 5 días de mercado</b> (y unas 30 señales) antes de decidir algo. Antes de eso, cualquier diferencia puede ser suerte.</div>
<div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span class="mut" style="font-size:12px">Señales medidas con:</span><button id="s_live" onclick="load('live')">Datos en vivo (cuenta real)</button><button id="s_sandbox" onclick="load('sandbox')">Datos de papel (con atraso)</button><span class="mut" style="font-size:12px" id="hora"></span></div></div>

<div class="card"><div class="lbl">PROCESOS · ¿ESTÁN TRABAJANDO?</div><div style="overflow-x:auto"><table><thead><tr><th>Proceso</th><th>Ahora</th><th>Horario</th><th>Última anotación</th><th>Hoy</th><th>Token</th><th>Detalle</th></tr></thead><tbody id="procs"></tbody></table></div>
<div class="mut" style="font-size:12px;margin-top:8px">“En pausa” fuera de horario es normal. Si en horario de mercado la última anotación tiene más de 5 minutos o aparece un error, avísame.</div></div>

<div class="card" style="border-left-color:var(--warn)"><div class="lbl">PREGUNTAS POR DECIDIR</div><div class="grid" id="qs"></div></div>

<div class="card"><div class="lbl">DÍA POR DÍA · señales que pasan el filtro del robot (cerca de HH/LL, en su horario)</div><div style="overflow-x:auto"><table><thead><tr><th>Fecha</th><th>Señales del día</th><th>Pasan el filtro</th><th>El robot tomó</th><th>A favor a 15 min</th><th>SPY a 15 min</th><th>Con Corona</th><th>SPY a 15 min (Corona)</th><th>Salir en contraria</th><th>Opción robot 15 min</th><th>Debit spread 15 min</th></tr></thead><tbody id="dias"></tbody></table></div>
<div class="mut" style="font-size:12px;margin-top:8px">“SPY a 15 min” = dólares que se movió SPY a favor de la señal (promedio). Las dos últimas columnas son dólares por contrato (promedio), sin comisiones.</div></div>

<div class="card"><div class="lbl">ESCÁNER SWING · PUT CREDIT SPREADS SEGUIDOS</div><div style="overflow-x:auto"><table><thead><tr><th>Fecha</th><th>Acción</th><th>Spread</th><th>Crédito</th><th>Vence</th><th>Capturado hoy</th><th>Máximo capturado</th><th>Llegó al 50%</th><th>Tocó strike</th><th>Estado</th></tr></thead><tbody id="esc"></tbody></table></div></div>

<script>
const $=id=>document.getElementById(id);let SRC=null;try{SRC=localStorage.getItem("sombra_src")}catch(e){}
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const cl=v=>v==null?"":v>0?"ok":v<0?"bad":"";
const usd=(v,d)=>v==null?"–":(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(d==null?2:d);
const pc=v=>v==null?"–":v+"%";
function hace(ts){if(!ts)return"nunca";const m=Math.round((Date.now()/1000-ts)/60);if(m<1)return"hace menos de 1 min";if(m<60)return"hace "+m+" min";const h=Math.round(m/60);if(h<48)return"hace "+h+" h";return"hace "+Math.round(h/24)+" días"}
function badge(e){return '<span class="badge b-'+e.nivel+'">'+(e.nivel==="listo"?"✓ ":e.nivel==="indicio"?"◐ ":"⏳ ")+esc(e.txt)+'</span>'}
function bar(d,m){const p=Math.min(100,Math.round(100*d/m));return '<div class="mut" style="font-size:12px">Días de mercado: <b style="color:var(--tx)">'+d+' de '+m+'</b></div><div class="bar"><i style="width:'+p+'%;background:'+(p>=100?"var(--ok)":"var(--warn)")+'"></i></div>'}
function tbl(head,rows){return '<div style="overflow-x:auto"><table class="qt"><thead><tr>'+head.map(h=>'<th>'+h+'</th>').join("")+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map((c,i)=>'<td'+(i?' class="mono"':'')+'>'+c+'</td>').join("")+'</tr>').join("")+'</tbody></table></div>'}
async function load(s){if(s)SRC=s;
  let j;try{j=await (await fetch("/api/sombra"+(SRC?"?src="+SRC:""),{cache:"no-store"})).json()}catch(e){$("hora").textContent="No pude hablar con el panel";return}
  SRC=j.src;try{localStorage.setItem("sombra_src",SRC)}catch(e){}
  $("s_live").className=SRC==="live"?"on":"";$("s_sandbox").className=SRC==="sandbox"?"on":"";
  $("hora").textContent="Nueva York: "+j.ahora+" · mercado "+(j.mercado?"abierto":"cerrado")+" · se actualiza sola cada 30 s";
  $("procs").innerHTML=j.procesos.map(p=>{const st=p.error?'<span class="bad"><span class="dot" style="background:var(--bad)"></span>Error: '+esc(p.error)+'</span>':p.activo?'<span class="ok"><span class="dot" style="background:var(--ok)"></span>Trabajando</span>':'<span class="mut"><span class="dot" style="background:var(--mut)"></span>En pausa (fuera de horario)</span>';
    return '<tr><td><b>'+esc(p.nombre)+'</b></td><td>'+st+'</td><td class="mut">'+esc(p.horario)+'</td><td>'+hace(p.ultima)+'</td><td class="mono">'+(p.hoy==null?"–":esc(p.hoy))+'</td><td>'+(p.token?'<span class="ok">✓</span>':'<span class="warn">falta</span>')+'</td><td><a href="'+p.link+'">ver →</a></td></tr>'}).join("");
  const p1=j.p1,p2=j.p2,p3=j.p3,p4=j.p4;let h="";
  h+='<div class="q"><h3>👑 ¿Exigir la Corona 1·3·5?</h3><div class="p">Si el robot solo entrara cuando 1, 3 y 5 min coinciden, ¿le iría mejor? Hoy el filtro está <b>apagado</b>.</div>'+badge(p1.estado)+bar(p1.dias,j.meta.dias)+
     tbl(["","Señales","A favor 15 min","SPY 15 min"],[["Sin Corona (como hoy)",p1.a.n,pc(p1.a.fav15),'<span class="'+cl(p1.a.avg15)+'">'+usd(p1.a.avg15)+'</span>'],["Con Corona",p1.b.n,pc(p1.b.fav15),'<span class="'+cl(p1.b.avg15)+'">'+usd(p1.b.avg15)+'</span>']])+
     '<div class="lect">'+esc(p1.lectura)+(p1.a.n?' <span class="mut">La Corona deja pasar '+p1.b.n+' de '+p1.a.n+' señales.</span>':'')+'</div></div>';
  const A=p2.a,B=p2.b,C=p2.c||{n:0},PR=p2.par||{n:0};
  h+='<div class="q"><h3>🎯 ¿Qué contrato? Opción del robot, debit spread u opción a 3 días</h3><div class="p">A) la opción que compra hoy el robot (vence el día hábil siguiente) · B) debit spread 0DTE de ancho 3 · C) la misma opción (mismo delta) pero vence en ~3 días hábiles. Mismas señales, dólares por contrato. C empezó a registrarse el 9 de noviembre.</div>'+badge(p2.estado)+bar(p2.dias,j.meta.dias)+
     tbl(["","Señales","Costo medio","Prom. 15 min","% sobre costo","Positivas 15 min","Tocó +$8"],[["A) Opción robot",A.n,A.cost==null?"–":"$"+A.cost,'<span class="'+cl(A.avg15)+'">'+usd(A.avg15,1)+'</span>','<span class="'+cl(A.roc15)+'">'+(A.roc15==null?"–":A.roc15+"%")+'</span>',pc(A.win15),pc(A.hit)],["B) Debit spread",B.n,B.cost==null?"–":"$"+B.cost,'<span class="'+cl(B.avg15)+'">'+usd(B.avg15,1)+'</span>','<span class="'+cl(B.roc15)+'">'+(B.roc15==null?"–":B.roc15+"%")+'</span>',pc(B.win15),pc(B.hit)],["C) Opción a 3 días",C.n,C.cost==null?"–":"$"+C.cost,'<span class="'+cl(C.avg15)+'">'+usd(C.avg15,1)+'</span>','<span class="'+cl(C.roc15)+'">'+(C.roc15==null?"–":C.roc15+"%")+'</span>',pc(C.win15),pc(C.hit)]])+
     (PR.n?'<div class="lect">A vs C en las mismas '+PR.n+' señales: a 15 min A '+usd(PR.a15,1)+' · C '+usd(PR.c15,1)+' · a 30 min A '+usd(PR.a30,1)+' · C '+usd(PR.c30,1)+' por contrato.</div>':'<div class="lect mut">La opción a 3 días todavía no tiene señales registradas.</div>')+
     '<div class="lect">'+esc(p2.lectura)+' <span class="mut">Se compara en % sobre lo invertido porque el spread cuesta menos.</span></div></div>';
  h+='<div class="q"><h3>↩️ ¿Cerrar por señal contraria?</h3><div class="p">Salir cuando aparece la señal del lado contrario vs salir fijo a los 15 min. Mismas señales (las que pasan el filtro y tienen señal contraria ese día). Movimiento de SPY a favor.</div>'+badge(p3.estado)+bar(p3.dias,j.meta.dias)+
     tbl(["","Señales","A favor","SPY prom."],[["Salir a los 15 min",p3.n,pc(p3.fijo.fav),'<span class="'+cl(p3.fijo.avg)+'">'+usd(p3.fijo.avg)+'</span>'],["Salir en señal contraria",p3.n,pc(p3.contra.fav),'<span class="'+cl(p3.contra.avg)+'">'+usd(p3.contra.avg)+'</span>']])+
     '<div class="lect">'+esc(p3.lectura)+(p3.contra.min!=null?' <span class="mut">La señal contraria llega en promedio a los '+Math.round(p3.contra.min)+' min.</span>':'')+'</div></div>';
  const p5=j.p5;const mx=Math.max(...p5.filas.map(f=>f.r.avg==null?-1e9:f.r.avg));
  h+='<div class="q" style="grid-column:1/-1"><h3>🎚️ ¿Qué objetivo y qué stop?</h3><div class="p">Con los precios reales de la opción del robot (guardados cada ~20 s durante 30 min), ¿cuánto habría dado cada forma de salir? Entra al ask, sale al bid, dólares <b>por contrato</b>, sin comisiones. Si a los 30 min no salió, se cierra ahí.</div>'+badge(p5.estado)+bar(p5.dias,j.meta.dias)+
     tbl(["Forma de salir","Señales","Prom. por contrato","Ganadoras","Peor resultado","Suma"],p5.filas.map(f=>[(f.actual?"<b>"+esc(f.nombre)+"</b> <span class=\"mut\">(lo que usa hoy)</span>":esc(f.nombre))+(f.r.avg!=null&&f.r.avg===mx?' <span class="ok">★ mejor por ahora</span>':''),f.r.n,'<span class="'+cl(f.r.avg)+'">'+usd(f.r.avg,1)+'</span>',pc(f.r.win),'<span class="bad">'+usd(f.r.peor,0)+'</span>','<span class="'+cl(f.r.total)+'">'+usd(f.r.total,0)+'</span>']))+
     '<div class="lect">'+esc(p5.lectura)+' <span class="mut">Es aproximado: el robot revisa cada 3 s y su stop está en el broker; aquí se mira cada ~20 s.</span></div></div>';
  const p6=j.p6;const D={0.1:"Delta 10",0.15:"Delta 15",0.2:"Delta 20"};
  h+='<div class="q" id="condor" style="grid-column:1/-1"><h3>🦅 Iron condor semanal en SPX</h3><div class="p">Lunes a miércoles a las 10:00 ET se registra un condor por cada delta de venta (10, 15 y 20), alas de 10 puntos, vence el viernes. Precios reales a <b>precio medio</b>; dólares <b>por condor</b> (1 contrato por pata), sin comisiones. Se mide el costo de cerrar cada 5 min y al final qué habría dado cada regla.</div>'+badge(p6.estado)+
     tbl(["Delta · regla","Terminados","Crédito medio","Prom. por condor","Ganadores","Peor","Suma"],p6.tabla.map(r=>[(r.regla==="vence"?"<b>"+D[r.delta]+"</b> · ":"<span class=\"mut\">"+D[r.delta]+" ·</span> ")+esc(r.nombre),r.n+(r.abiertos?' <span class="mut">(+'+r.abiertos+' abiertos)</span>':''),r.credito==null?"–":"$"+r.credito,'<span class="'+cl(r.avg)+'">'+usd(r.avg,0)+'</span>',pc(r.win),'<span class="bad">'+usd(r.peor,0)+'</span>','<span class="'+cl(r.total)+'">'+usd(r.total,0)+'</span>']))+
     (p6.lista.length?'<div class="lbl" style="margin-top:14px">CONDORS REGISTRADOS</div>'+tbl(["Entrada","Delta","Vence","Put vendido/comprado","Call vendido/comprado","Crédito (medio · natural)","Riesgo máx.","VIX · IV put / call","SPX entrada → ahora","Resultado"],p6.lista.map(x=>[esc(x.fecha+" "+x.hora),D[x.delta],esc(x.exp),esc(x.put),esc(x.call),"$"+x.credito+' <span class="mut">· $'+x.credito_nat+'</span>',"$"+x.riesgo,(x.vix==null?"–":x.vix.toFixed(1))+' <span class="mut">· '+(x.ivp==null?"–":x.ivp+"%")+" / "+(x.ivc==null?"–":x.ivc+"%")+'</span>',x.spx0+" → "+(x.settle?x.settle.spx.toFixed(2)+" (cierre)":(x.spx==null?"–":x.spx.toFixed(2))),'<span class="'+cl(x.pnl)+'">'+usd(x.pnl,0)+'</span>'+(x.done?' <span class="mut">final</span>':' <span class="mut">ahora</span>')])):'')+
     '<div class="lect mut">La semana del 2 al 6 de noviembre tiene elecciones (martes 3) y normalmente el reporte de empleo (viernes): sirve para ver el peor caso, no es una semana típica. El crédito “natural” (vender al bid, comprar al ask) muestra cuánto se pierde por el spread de precios.</div></div>';
  h+='<div class="q" id="filtros" style="grid-column:1/-1"><h3>🧪 Filtros de entrada para el robot de SPY</h3><div class="p">¿Con qué contexto las señales del robot funcionan mejor? Para cada señal se mira el momento (horario, VWAP, tendencia de 5 min, apertura, rango de apertura, VIX, tamaño de velas, Corona, cerca de HH/LL) y cuánto se movió SPY a favor a los 15 y 30 min. Se recalcula solo cada día a las 16:45. <b>Consistente</b> = mejora en las dos mitades de los días. Como referencia, $0.10 de SPY ≈ $5 por contrato con delta 0.5.</div><div id="fbox">Cargando…</div></div>';
  h+='<div class="q" id="creal" style="grid-column:1/-1;border:2px solid #ff9f43"><h3>🔴 Iron condor AUTOMÁTICO en cuenta REAL</h3><div id="crbox" class="p">Cargando…</div></div>';
  h+='<div class="q" id="crealh" style="grid-column:1/-1;border:2px solid #b48cff;display:none"><h3 id="crhh">🟣 Iron condor AUTOMÁTICO · cuenta 2</h3><div id="crboxH" class="p">Cargando…</div></div>';
  const p7=j.p7;
  h+='<div class="q" id="condorm" style="grid-column:1/-1"><h3>📅 Iron condor mensual en SPX · variante A2</h3><div class="p">La mejor combinación de la simulación hacia atrás: opciones <b>mensuales</b> de SPX (vencen el tercer viernes y se liquidan a la apertura), entra cuando faltan <b>30 días</b>, ventas en <b>delta 0.10</b>, alas de <b>25 puntos</b>. Sale con <b>stop</b> si cerrarlo cuesta 2× el crédito o, si no, <b>el jueves</b> antes del vencimiento (nunca llega a la liquidación AM). Precios reales a precio medio cada 5 min; dólares por condor, sin comisiones.</div>'+badge(p7.estado)+
     tbl(["Regla","Terminados","Prom. por condor","Ganadores","Peor","Suma"],p7.tabla.map(r=>[(r.regla==="a2"?"<b>"+esc(r.nombre)+"</b>":'<span class="mut">'+esc(r.nombre)+'</span>'),r.n+(r.abiertos?' <span class="mut">(+'+r.abiertos+' abierto)</span>':''),'<span class="'+cl(r.avg)+'">'+usd(r.avg,0)+'</span>',pc(r.win),'<span class="bad">'+usd(r.peor,0)+'</span>','<span class="'+cl(r.total)+'">'+usd(r.total,0)+'</span>']))+
     (p7.lista.length?'<div class="lbl" style="margin-top:14px">CONDORS MENSUALES</div>'+tbl(["Entrada","Vence (días)","Put vendido/comprado","Call vendido/comprado","Crédito (medio · natural)","Riesgo máx.","VIX · IV put / call","SPX entrada → ahora","A2"],p7.lista.map(x=>[esc(x.fecha+" "+x.hora),esc(x.exp)+' <span class="mut">('+x.dte+')</span>',esc(x.put),esc(x.call),"$"+x.credito+' <span class="mut">· $'+x.credito_nat+'</span>',"$"+x.riesgo,(x.vix==null?"–":x.vix.toFixed(1))+' <span class="mut">· '+(x.ivp==null?"–":x.ivp+"%")+" / "+(x.ivc==null?"–":x.ivc+"%")+'</span>',x.spx0+" → "+(x.settle?x.settle.spx.toFixed(2)+" (liquidación)":(x.spx==null?"–":x.spx.toFixed(2))),'<span class="'+cl(x.pnl)+'">'+usd(x.pnl,0)+'</span>'+(x.stop?' <span class="bad">stop '+esc(x.stop.slice(5))+'</span>':(x.done?' <span class="mut">final</span>':' <span class="mut">ahora</span>'))])):'')+
     '<div class="lect mut">Es una sola operación al mes: hacen falta varios meses para sacar conclusiones. La simulación (2010–2026) dio ~$117 por mes con riesgo de ~$2,100 y la peor racha en −$3,110, pero con precios estimados; aquí se miden los precios reales. La liquidación AM se aproxima con la apertura del SPX.</div></div>';
  const p8=j.p8;
  if(p8){const nt=x=>x.noticias==null?'<span class="mut">?</span>':(x.noticias.length?'<span class="bad">'+esc(x.noticias.join(", "))+'</span>':'<span class="mut">ninguna</span>');
  h+='<div class="q" id="condorn" style="grid-column:1/-1"><h3>🌙 Iron condor de una noche en SPX</h3><div class="p">Cada día hábil a las <b>15:30</b> registra un condor SPXW que vence en <b>2 días</b> (ventas en <b>delta 0.10</b>, alas de <b>10</b>) y lo sigue hasta las 17:00 y al día siguiente de <b>8:00 a 10:35</b> (Tradier deja operar SPX de 8:00 a 17:00). Compara salidas: objetivo 25% / stop 2× / cierre 10:30, o cerrar a hora fija. Dólares por condor sin comisiones (en SPX son ~$'+p8.comision.toFixed(2)+' ida y vuelta). <b>Medio</b> = a precio medio; <b>natural</b> = pagando toda la diferencia (lo real queda entre los dos).</div>'+badge(p8.estado)+
     tbl(["Regla","Noches","Prom. medio","Prom. natural","Ganadores","Peor","Suma medio"],p8.tabla.map(r=>[(r.regla==="tp25"?"<b>"+esc(r.nombre)+"</b>":'<span class="mut">'+esc(r.nombre)+'</span>'),r.n,'<span class="'+cl(r.avg)+'">'+usd(r.avg,0)+'</span>','<span class="'+cl(r.avg_nat)+'">'+usd(r.avg_nat,0)+'</span>',pc(r.win),'<span class="bad">'+usd(r.peor,0)+'</span>','<span class="'+cl(r.total)+'">'+usd(r.total,0)+'</span>']))+
     '<div class="lect mut">Objetivo 25%: noches tranquilas '+(p8.tranquilos.n?usd(p8.tranquilos.avg,0)+" prom. ("+p8.tranquilos.n+")":"–")+' · con noticias fuertes a la mañana '+(p8.con_noticias.n?usd(p8.con_noticias.avg,0)+" prom. ("+p8.con_noticias.n+")":"–")+'</div>'+
     (p8.lista.length?'<div class="lbl" style="margin-top:14px">NOCHES</div>'+tbl(["Entrada","Sale · vence","Put","Call","Crédito (medio · natural)","VIX","Noticias a la mañana","Brinco apertura","Precios 8:00–9:25","Resultado (25%)"],p8.lista.map(x=>[esc(x.fecha+" "+x.hora),esc(x.salida.slice(5))+" · "+esc(x.exp.slice(5)),esc(x.put),esc(x.call),"$"+x.credito+' <span class="mut">· $'+x.credito_nat+'</span>',x.vix==null?"–":x.vix.toFixed(1),nt(x),x.gap==null?"–":'<span class="'+cl(x.gap)+'">'+(x.gap>0?"+":"")+x.gap+'%</span>',x.pre?(x.pre.con_precio+"/"+x.pre.n+(x.pre.ancho!=null?' <span class="mut">· ancho $'+x.pre.ancho.toFixed(2)+'</span>':'')):"–",'<span class="'+cl(x.pnl)+'">'+usd(x.pnl,0)+'</span> <span class="mut">'+(x.done?"final":"ahora")+'</span>'])):'')+
     '<div class="lect mut">«Precios 8:00–9:25»: cuántas lecturas tuvieron precio en las 4 patas y qué tan ancha estaba la diferencia; sirve para saber si de verdad se puede salir antes de la apertura. Solo es sombra: no se manda ninguna orden.</div></div>'}
  const es=p4.s;
  h+='<div class="q"><h3>📈 ¿Funciona el escáner swing?</h3><div class="p">Cada señal verde se sigue sola (a precio medio): ¿llega el spread al 50% del crédito antes de tocar el stop?</div>'+badge(p4.estado)+
     tbl(["Señales","Abiertas","Llegaron 25%","Llegaron 50%","Tocaron strike","Perdieron crédito"],[[es.n,es.abiertas,es.n25+(es.med25!=null?' <span class="mut">('+es.med25+' d)</span>':''),es.n50+(es.med50!=null?' <span class="mut">('+es.med50+' d)</span>':''),es.tocaron,es.stops]])+
     '<div class="lect mut">Un spread de ~45 días tarda semanas en terminar; esta pregunta es la más lenta en responderse.</div></div>';
  $("qs").innerHTML=h;if(typeof crLoad==="function")crLoad();if(typeof fLoad==="function")fLoad();
  $("dias").innerHTML=j.dias.length?j.dias.map(d=>'<tr><td>'+esc(d.fecha)+'</td><td class="mono">'+d.n+'</td><td class="mono">'+d.cerca+'</td><td class="mono">'+d.tomadas+'</td><td class="mono">'+pc(d.fav15)+'</td><td class="mono '+cl(d.avg15)+'">'+usd(d.avg15)+'</td><td class="mono">'+d.cor_n+'</td><td class="mono '+cl(d.cor_avg15)+'">'+usd(d.cor_avg15)+'</td><td class="mono '+cl(d.contra)+'">'+usd(d.contra)+'</td><td class="mono '+cl(d.op_a)+'">'+(d.op_n?usd(d.op_a,1):'<span class="mut">sin datos</span>')+'</td><td class="mono '+cl(d.op_b)+'">'+(d.op_n?usd(d.op_b,1):'<span class="mut">sin datos</span>')+'</td></tr>').join(""):'<tr><td colspan="11" class="mut">Todavía no hay días registrados. Se llenan solos en horario de mercado.</td></tr>';
  $("esc").innerHTML=p4.lista.length?p4.lista.map(x=>'<tr><td>'+esc(x.fecha)+'</td><td><b>'+esc(x.sym)+'</b></td><td class="mono">'+esc(x.short)+'/'+esc(x.long)+'</td><td class="mono">$'+esc(x.credit)+'</td><td>'+esc(x.exp)+'</td><td class="mono '+cl(x.last_pct)+'">'+(x.last_pct==null?"–":x.last_pct+"%")+'</td><td class="mono">'+(x.max_pct==null?"–":x.max_pct+"%")+'</td><td>'+(x.d50!=null?'<span class="ok">sí, día '+x.d50+'</span>':"no")+'</td><td>'+(x.touched?'<span class="bad">sí</span>':"no")+'</td><td>'+(x.stop_hit?'<span class="bad">perdió crédito</span>':x.closed?"terminado":'<span class="ok">siguiendo</span>')+'</td></tr>').join(""):'<tr><td colspan="10" class="mut">Aún no hay señales verdes del escáner.</td></tr>'}
load(SRC);setInterval(()=>load(),30000);

/* ===== iron condor real automatico ===== */
async function crLoad(){await crLoadOne("");await crLoadOne("H")}
async function crLoadOne(A){const b=document.getElementById(A?"crboxH":"crbox");if(!b)return;const col=A?"#b48cff":"#ff9f43",fg=A?"#1a0b33":"#2e1600";
  try{const j=await fetch("/api/condor_real"+(A?"?acct=H":""),{cache:"no-store"}).then(r=>r.json());
    if(A){const card=document.getElementById("crealh");card.style.display=j.configurada?"":"none";if(!j.configurada)return;
      document.getElementById("crhh").textContent="🟣 Iron condor AUTOMÁTICO · cuenta de "+(j.nombre||"cuenta 2").toUpperCase()}
    const ST={abierta:"✅ abierta",enviada:"⏳ orden esperando",sin_llenar:"no se llenó",sin_entrada:"no entró",rechazada:"⚠️ rechazada",error:"⚠️ error",cancelada:"cancelada",armando:"armando…",cerrada:"🏁 cerrada",terminada:"🏁 terminada"};
    b.innerHTML='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px"><b style="font-size:15px;color:'+(j.activo?col:"#7d8aa5")+'">'+(j.activo?(A?"🟣 ACTIVO":"🔴 ACTIVO"):"⏸ APAGADO")+'</b>'
      +(j.activo?'<button onclick="crSet(false,\''+A+'\')" style="padding:6px 12px;border-radius:8px;border:1px solid #3c3c46;background:transparent;color:#e6ecf5;cursor:pointer">Apagar</button>'
               :'<button onclick="crSet(true,\''+A+'\')" style="padding:6px 12px;border-radius:8px;border:2px solid '+col+';background:'+col+';color:'+fg+';font-weight:800;cursor:pointer">'+(A?"Activar en SU cuenta REAL":"Activar en REAL")+'</button>')
      +'<span class="mut">'+esc(j.reglas)+(j.activado&&j.activo?" · activo desde "+esc(j.activado):"")+'</span></div>'
      +(j.msg?'<div class="mut">'+esc(j.msg)+'</div>':'')+(j.err?'<div class="bad">Último error: '+esc(j.err)+'</div>':'')
      +(j.dias.length?tbl(["Día","Estado","Strikes","Vence","Crédito límite","Orden"],j.dias.map(x=>[esc(x.fecha),esc(ST[x.status]||x.status||"–")+(x.pnl!=null?' <b class="'+(x.pnl>=0?"ok":"bad")+'">'+(x.pnl>=0?"+":"−")+"$"+Math.abs(x.pnl).toFixed(0)+'</b>':'')+(x.salida?' <span class="mut">'+esc(x.salida)+'</span>':'')+(x.motivo?' <span class="mut">'+esc(x.motivo)+'</span>':''),esc(x.strikes||"–"),esc(x.exp||"–"),x.price==null?"–":"$"+x.price.toFixed(2)+(x.tries>1?' <span class="mut">('+x.tries+' intentos)</span>':''),esc(x.order||"–")])):'<div class="mut">Todavía no ha abierto ninguno.</div>')
      +'<div class="mut" style="margin-top:6px">El resultado de cada condor lo ves en Trading manual → Posiciones y en el registro del gestor. El modo sombra de arriba sigue corriendo para comparar.</div>';
  }catch(e){b.textContent="No pude leer el estado: "+e}}
async function crSet(on,A){let body={activo:false};const who=A?"la cuenta REAL de "+((document.getElementById("crhh")||{}).textContent||"").replace(/^.*cuenta de /,""):"tu cuenta REAL";
  if(on){const t=prompt("Vas a ACTIVAR el iron condor AUTOMÁTICO en "+who+".\n\nLunes y martes a las 10:00 ET abre 1 iron condor de SPX (delta 0.10, alas de 10, 1 contrato) con dinero real. Pérdida máxima aprox. $850 por condor.\n\nEscribe ROBOT REAL para activarlo:");
    if((t||"").trim()!=="ROBOT REAL"){alert("No se activó.");return}body={activo:true,confirm:"ROBOT REAL"}}
  else if(!confirm("¿Apagar el iron condor automático? Los condors que ya estén abiertos los sigue vigilando el gestor."))return;
  const j=await fetch("/api/condor_real"+(A?"?acct=H":""),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}).then(r=>r.json());
  if(j.error)alert(j.error);crLoad()}
setInterval(crLoad,15000);setTimeout(crLoad,1500);

/* ===== filtros de entrada del robot ===== */
async function fLoad(){const b=document.getElementById("fbox");if(!b)return;
  try{const j=await fetch("/api/filtros",{cache:"no-store"}).then(r=>r.json());
    const btn='<button onclick="fRun()" style="padding:5px 10px;border-radius:8px;border:1px solid #5cc8ff;background:transparent;color:#5cc8ff;cursor:pointer;font-weight:700" '+(j.busy?"disabled":"")+'>'+(j.busy?"Calculando… "+esc(j.prog||""):"⟳ Recalcular ahora")+'</button>';
    if(!j.n){b.innerHTML=btn+' <span class="mut">'+(j.err?"Error: "+esc(j.err):"Todavía no se ha calculado.")+'</span>';return}
    const m=j.base.m15,s=v=>v==null?"–":(v>=0?"+":"")+v.toFixed(2);
    const row=x=>[(x.consistente?'<span class="ok">✔</span> ':'<span class="mut">·</span> ')+esc(x.filtro),x.n+' <span class="mut">('+x.pct+'%)</span>',pc(x.fav15),'<span class="'+cl(x.avg15)+'">'+s(x.avg15)+'</span>','<span class="'+cl(x.dif15)+'">'+s(x.dif15)+'</span>','<span class="'+cl(x.avg30)+'">'+s(x.avg30)+'</span>',x.mfe==null?"–":"+"+x.mfe.toFixed(2)+" / "+x.mae.toFixed(2)];
    const H=["Filtro","Señales","A favor 15 min","SPY prom. 15 min","vs todas","SPY prom. 30 min","Mejor / peor 30 min"];
    b.innerHTML='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px">'+btn+'<span class="mut">'+j.senales+' señales · '+j.base.dias+' días · sin filtro: a favor '+m.fav+'%, SPY '+s(m.avg)+' a 15 min'+(j.ts?" · calculado "+new Date(j.ts*1000).toLocaleString("es"):"")+'</span></div>'
      +(j.mejores&&j.mejores.length?'<div class="lbl">⭐ LOS QUE MEJORAN DE FORMA CONSISTENTE</div>'+tbl(H,j.mejores.map(row)):'<div class="lect">Por ahora ningún filtro mejora de forma consistente en las dos mitades de los días.</div>')
      +'<details style="margin-top:10px"><summary class="mut" style="cursor:pointer">Ver todos los filtros (uno por uno)</summary>'+tbl(H,j.simples.map(row))+'</details>'
      +'<details style="margin-top:6px"><summary class="mut" style="cursor:pointer">Ver combinaciones de dos filtros</summary>'+tbl(H,j.combos.map(row))+'</details>'
      +'<div class="lect mut">Con pocos días, una diferencia de unos centavos puede ser casualidad. Hay que buscar filtros con ✔ (consistentes), con suficientes señales y que se mantengan semana tras semana.'+(j.faltan&&j.faltan.length?' Días sin velas: '+esc(j.faltan.join(", ")):'')+'</div>';
  }catch(e){b.textContent="No pude leer los filtros: "+e}}
async function fRun(){await fetch("/api/filtros_run",{method:"POST"});setTimeout(fLoad,1500)}
setInterval(fLoad,20000);
</script></body></html>"""
