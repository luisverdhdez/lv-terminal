"""
Modo sombra: IRON CONDOR DE UNA NOCHE en SPX (opciones SPXW). NUNCA envia ordenes (dry=True, solo consultas GET).
- Cada dia habil a las 15:30 ET registra un condor que vence en 2 dias habiles: ventas en delta 0.10, alas de 10.
- Sigue el precio cada 5 min de 15:30 a 17:00 (Tradier deja operar SPX hasta las 17:00) y al dia siguiente
  de 8:00 a 10:35 (desde las 8:00 ya se puede operar SPX en Tradier). Anota si Tradier da precios antes de la apertura.
- Al final compara reglas de salida: objetivo 25% / stop 2x / cierre 10:30, y cerrar a las 8:25, 9:25, 9:45 o 10:30.
- Marca los dias con noticias fuertes a la mañana siguiente (inflacion, empleo, PIB, PCE... y la Fed).
Precios a precio MEDIO y tambien a precio "natural" (pagando la diferencia completa): lo real queda entre los dos.
"""
import json
import os
import threading
import time
from datetime import datetime, time as dtime

import condor as cw
import tradier_bot as tb

ET = cw.ET
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "condor_noche.json")
LOCK = threading.RLock()
STATE = {"err": None, "last": None, "msg": None}
SYM, DELTA, WIDTH = "SPX", 0.10, cw.WIDTH
ENTRY_FROM, ENTRY_TO = dtime(15, 30), dtime(15, 45)
TP, STOP_X = 0.25, 3.0               # objetivo 25% del credito; stop si cerrar cuesta 3x (pierde 2x)
POLL_SEC = 300
COMISION = 7.60                      # SPX ida y vuelta (4 patas x ~$0.95 por lado), solo informativo
WINDOWS = ((dtime(15, 30), dtime(17, 2)), (dtime(8, 0), dtime(10, 37)))
RULES = [("tp25", "Objetivo 25% o stop 2× (de noche) · si no, cerrar 10:30"),
         ("c0825", "Cerrar a las 8:25 (antes de noticias de 8:30)"),
         ("c0925", "Cerrar a las 9:25 (antes de la apertura)"),
         ("c0945", "Cerrar a las 9:45 (después del primer brinco)"),
         ("c1030", "Cerrar a las 10:30")]


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) and isinstance(d.get("ent"), list) else {"ent": []}
    except (OSError, ValueError):
        return {"ent": []}


def _save(d):
    d["ent"] = d["ent"][-400:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _exps(api, today):
    j = api._req("GET", "/markets/options/expirations", params={"symbol": SYM, "includeAllRoots": "true"})
    return sorted(d for d in tb.as_list((j.get("expirations") or {}).get("date")) if isinstance(d, str) and d > today.isoformat())


def _news(env, day):
    """Noticias fuertes (importancia >= 2) del dia de salida antes de las 10:30, o decision de la Fed ese dia."""
    try:
        import economia
        cal = economia.data(env).get("calendar") or []
    except Exception:
        return None
    out = [f'{e.get("time", "")} {e.get("name", "")}' for e in cal
           if e.get("date") == day and (e.get("fomc") or (e.get("imp", 0) >= 2 and e.get("time", "99") <= "10:30"))]
    return out


def enter(api, env, now):
    today = now.date().isoformat()
    with LOCK:
        if any(e["fecha"] == today for e in _load()["ent"]):
            return 0
    ds = _exps(api, now.date())
    if len(ds) < 2:
        STATE["msg"] = "No hay vencimiento SPXW a 2 días"
        return 0
    salida, exp = ds[0], ds[1]
    spot = cw._spot(api)
    if not spot:
        return 0
    p = cw.pick(cw._weekly(api.chain(SYM, exp)), spot, DELTA, cw.years_to(exp, now))
    if not p:
        STATE["msg"] = f"{today}: la cadena no tenía strikes válidos para delta 0.10 y alas de 10"
        return 0
    vix = None
    try:
        q = api._req("GET", "/markets/quotes", params={"symbols": "VIX"})
        vix = cw._f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))
    except Exception:
        pass
    e = dict(p, fecha=today, hora=now.strftime("%H:%M"), exp=exp, salida=salida, spot=round(spot, 2), vix=vix,
             noticias=_news(env, salida), samples=[], done=False)
    with LOCK:
        d = _load()
        if any(x["fecha"] == today for x in d["ent"]):
            return 0
        d["ent"].append(e)
        _save(d)
    STATE["msg"] = None
    return 1


def poll(api, now):
    with LOCK:
        act = [e for e in _load()["ent"] if not e.get("done")]
    if not act:
        return
    occs = sorted({o for e in act for o in e["occ"].values()})
    j = api._req("GET", "/markets/quotes", params={"symbols": ",".join(occs + [SYM])})
    qs = {x["symbol"]: x for x in tb.as_list((j.get("quotes") or {}).get("quote")) if isinstance(x, dict) and x.get("symbol")}
    spx = cw._f((qs.get(SYM) or {}).get("last"))
    t = now.strftime("%Y-%m-%d %H:%M")
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e.get("done"):
                continue
            q = {k: qs.get(o) or {} for k, o in e["occ"].items()}
            m = {k: cw._mid(v) for k, v in q.items()}
            mid = None if None in m.values() else round(m["sp"] + m["sc"] - m["lp"] - m["lc"], 2)
            try:
                nat = round(cw._f(q["sp"]["ask"]) + cw._f(q["sc"]["ask"]) - cw._f(q["lp"]["bid"]) - cw._f(q["lc"]["bid"]), 2)
            except TypeError:
                nat = None
            sin = sum(1 for v in q.values() if not (cw._f(v.get("bid")) or 0) > 0 or not (cw._f(v.get("ask")) or 0) > 0)
            e["samples"].append({"t": t, "spx": spx, "mid": None if mid is None else max(0.0, min(WIDTH, mid)),
                                 "nat": nat, "sin_precio": sin})
        _save(d)
    STATE["last"] = time.time()


def finish(now):
    """Termina los condors cuyo dia de salida ya paso las 10:35."""
    today, hm = now.date().isoformat(), now.strftime("%H:%M")
    with LOCK:
        d = _load()
        ch = False
        for e in d["ent"]:
            if not e.get("done") and (today > e["salida"] or (today == e["salida"] and hm >= "10:36")):
                e["done"] = True
                ch = True
        if ch:
            _save(d)


def loop(get_env):
    last_poll = 0.0
    while True:
        try:
            now = datetime.now(ET)
            env = get_env() or {}
            tok = env.get("TRADIER_LIVE_TOKEN")
            if tok and now.weekday() < 5:
                api = tb.Tradier(tok, "", "live", True)   # dry=True: nunca envia ordenes
                try:
                    if ENTRY_FROM <= now.time() <= ENTRY_TO:
                        enter(api, env, now)
                    if any(a <= now.time() <= b for a, b in WINDOWS) and time.time() - last_poll >= POLL_SEC - 5:
                        last_poll = time.time()
                        poll(api, now)
                    finish(now)
                    STATE["err"] = None
                except Exception as e:  # nunca tumbar el panel
                    STATE["err"] = e.__class__.__name__ + ": " + str(e)[:100]
        except Exception:
            pass
        time.sleep(30)


# ───────────── resultados ─────────────
def _night(e):
    """Muestras despues de la entrada: el resto del dia de entrada y la manana del dia de salida."""
    return [s for s in e["samples"] if s["t"] >= e["fecha"] + " " + e["hora"] and s["t"][:10] <= e["salida"]
            and not s.get("sin_precio") and (s.get("nat") is None or s["nat"] <= WIDTH)]   # sin lecturas rotas (9:25: patas sin precio)


def _at(e, hm, first_after=False):
    day = [s for s in _night(e) if s["t"][:10] == e["salida"] and s.get("mid") is not None]
    if first_after:
        c = [s for s in day if s["t"][11:] >= hm]
        return c[0] if c else None
    c = [s for s in day if s["t"][11:] <= hm]
    return c[-1] if c else None


def result(e, rule, natural=False):
    """Dolares por condor (1 contrato, sin comisiones). natural=True: entra al bid y sale al ask (lo peor)."""
    cr = e["credit_nat"] if natural else e["credit"]
    px = (lambda s: s.get("nat")) if natural else (lambda s: s.get("mid"))
    if not e.get("done"):
        return None
    if rule == "tp25":
        for s in _night(e):
            hm, v = s["t"][11:], px(s)
            if v is None or s["t"][:10] == e["fecha"] and hm < "15:31":
                continue
            if s["t"][:10] == e["salida"] and ("09:30" <= hm < "09:45" or hm > "10:30"):
                continue
            if s["mid"] is not None and s["mid"] <= e["credit"] * (1 - TP):
                return round((cr - v) * 100)
            if s["mid"] is not None and s["mid"] >= e["credit"] * STOP_X:
                return round((cr - v) * 100)
        s = _at(e, "10:30")
    else:
        hm = {"c0825": "08:25", "c0925": "09:25", "c0945": "09:45", "c1030": "10:30"}[rule]
        s = _at(e, hm, first_after=(rule == "c0945"))
    if not s or px(s) is None:
        return None
    return round((cr - px(s)) * 100)


def _gap(e):
    a = [s for s in e["samples"] if s["t"][:10] == e["fecha"] and s["t"][11:] <= "16:00" and s.get("spx")]
    b = [s for s in e["samples"] if s["t"][:10] == e["salida"] and s["t"][11:] >= "09:31" and s.get("spx")]
    if not a or not b:
        return None
    return round((b[0]["spx"] / a[-1]["spx"] - 1) * 100, 2)


def _pre(e):
    """Que tan operable estuvo de 8:00 a 9:25: muestras con precio de las 4 patas y ancho promedio (natural - medio)."""
    s = [x for x in e["samples"] if x["t"][:10] == e["salida"] and "08:00" <= x["t"][11:] <= "09:25"]
    if not s:
        return None
    ok = [x for x in s if x.get("sin_precio", 4) == 0 and x.get("mid") is not None and x.get("nat") is not None]
    ancho = round(sum(x["nat"] - x["mid"] for x in ok) / len(ok), 2) if ok else None
    return {"n": len(s), "con_precio": len(ok), "ancho": ancho}


def summary():
    d = _load()
    ents = d["ent"]
    tabla = []
    for k, nom in RULES:
        for nat in (False, True):
            v = [x for x in (result(e, k, nat) for e in ents) if x is not None]
            if nat:
                tabla[-1].update(avg_nat=round(sum(v) / len(v)) if v else None, total_nat=sum(v) if v else None)
                continue
            tabla.append({"regla": k, "nombre": nom, "n": len(v), "avg": round(sum(v) / len(v)) if v else None,
                          "win": round(100 * sum(1 for x in v if x > 0) / len(v)) if v else None,
                          "peor": min(v) if v else None, "total": sum(v) if v else None})
    tranq = [e for e in ents if e.get("done") and not e.get("noticias")]
    nots = [e for e in ents if e.get("done") and e.get("noticias")]
    def avg(L):
        v = [x for x in (result(e, "tp25") for e in L) if x is not None]
        return {"n": len(v), "avg": round(sum(v) / len(v)) if v else None}
    lista = []
    for e in ents[::-1][:15]:
        last = next((s for s in reversed(e["samples"]) if s.get("mid") is not None), None)
        lista.append({"fecha": e["fecha"], "hora": e["hora"], "exp": e["exp"], "salida": e["salida"],
                      "put": f'{e["kp"]:g}/{e["kpl"]:g}', "call": f'{e["kc"]:g}/{e["kcl"]:g}',
                      "credito": round(e["credit"] * 100), "credito_nat": round(e["credit_nat"] * 100),
                      "spx0": e["spot"], "vix": e.get("vix"), "noticias": e.get("noticias"),
                      "gap": _gap(e), "pre": _pre(e), "done": bool(e.get("done")),
                      "pnl": result(e, "tp25") if e.get("done") else (round((e["credit"] - last["mid"]) * 100) if last else None),
                      "r": {k: result(e, k) for k, _ in RULES} if e.get("done") else None})
    return {"n": len(ents), "terminados": sum(1 for e in ents if e.get("done")), "tabla": tabla, "lista": lista,
            "tranquilos": avg(tranq), "con_noticias": avg(nots), "comision": COMISION,
            "err": STATE["err"], "msg": STATE["msg"],
            "last": STATE["last"] or (os.path.getmtime(FILE) if os.path.exists(FILE) else None)}
