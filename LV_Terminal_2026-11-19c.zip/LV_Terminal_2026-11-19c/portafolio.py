"""Pagina /portafolio: watchlist en vivo, acciones propias (con Vender / Liquidar), grafico y cadena del simbolo elegido.
Solo SANDBOX (misma conexion que trading.py). Lo sirve monitor_web.py; los datos vienen de /api/* de trading.py."""

PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portafolio · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}
.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 20px;margin-bottom:14px}
h1{font-size:20px;margin:0;letter-spacing:.06em}a{color:var(--cy);text-decoration:none;font-weight:700}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.card.g{border-left-color:var(--ok)}.card.w{border-left-color:var(--warn)}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:8px}
.grid2{display:grid;grid-template-columns:1fr 1.25fr;gap:14px}@media(max-width:1000px){.grid2{grid-template-columns:1fr}}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 6px;white-space:nowrap}
td{padding:6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
tr.clk{cursor:pointer}tr.clk:hover{background:#141418}tr.sel{background:#1a1a20}
.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}
button,.btn{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:5px 11px;cursor:pointer;font-weight:700;font-size:12px}
button.on{color:var(--tx);border-color:var(--cy)}button.rollb{color:var(--cy);border-color:var(--cy)}
button.sell{color:var(--bad);border-color:var(--bad)}button.buy{color:var(--ok);border-color:var(--ok)}
input,select{background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 8px;font-size:13px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.atm{background:#1c1c24}
#lw{height:clamp(420px,60vh,640px);border:1px solid transparent;border-radius:8px}
.tag{font-size:11px;color:var(--mut)}
.card.w{position:relative}
.pane{position:relative}.pleg{position:absolute;left:6px;top:4px;z-index:11;display:flex;flex-direction:column;gap:2px;pointer-events:none;font:11px ui-monospace,Menlo,monospace;max-width:70%}
.pl{display:flex;gap:5px;align-items:center;background:rgba(12,12,15,.72);border-radius:5px;padding:1px 5px;color:#cfd8ea;pointer-events:auto;width:fit-content}.pl.off{opacity:.45}.pl i{width:8px;height:8px;border-radius:50%;display:inline-block}
.pl b{font-weight:600;color:#fff}.pl button{background:none;border:0;color:#7d8aa5;cursor:pointer;padding:0 2px;font-size:11px;display:none}.pl:hover button{display:inline}.pl button:hover{color:#fff}
.pmenu{position:absolute;top:34px;right:6px;width:min(360px,calc(100% - 12px));max-height:calc(100% - 44px);overflow:auto;z-index:40;background:#0c0c0f;border:1px solid #2b4a6b;border-radius:10px;padding:10px;box-shadow:0 8px 30px rgba(0,0,0,.6);font-size:12px}
.pmh{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.pms{color:#7d8aa5;font-size:11px;letter-spacing:.06em;margin:8px 0 4px;text-transform:uppercase}
.pmg{display:flex;flex-wrap:wrap;gap:5px}.pmenu button{background:#16161b;border:1px solid #202027;color:#e6ecf5;border-radius:7px;padding:4px 9px;cursor:pointer;font-size:12px}.pmenu button:hover{border-color:#5cc8ff}
.pmr{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:6px 0;border-top:1px solid #202027}.pmr label{display:flex;gap:4px;align-items:center;color:#9fb0cc}.pmr input[type=number]{width:56px;background:#000000;color:#e6ecf5;border:1px solid #202027;border-radius:6px;padding:3px 5px}.pmr input[type=color]{width:30px;height:24px;padding:0;border:1px solid #202027;background:none}

</style><script src="https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js"></script>
</head><body><main>
<header><h1 class="mono">PORTAFOLIO</h1>
 <div class="mono" style="font-size:13px"><span class="mut" id="acct"></span> &nbsp; <a href="/">← Inicio</a> &nbsp; <a href="/market">Market →</a> &nbsp; <a href="/fundamentales">Fundamentales →</a> &nbsp; <a href="/trade">Trading manual →</a></div></header>

<div class="grid2">
 <div class="card">
  <div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">WATCHLIST · EN VIVO <span class="tag">(papel: ~15 min de retraso)</span></div>
   <form class="row" onsubmit="addSym();return false"><input id="w_new" placeholder="Símbolo, ej. AMD" maxlength="6" style="width:130px;text-transform:uppercase"><button class="buy">+ Agregar</button></form></div>
  <div style="overflow-x:auto"><table><thead><tr><th>Símbolo</th><th>Último</th><th>% Día</th><th>Bid</th><th>Ask</th><th>Volumen</th><th></th></tr></thead><tbody id="w_body"><tr><td colspan="7" class="mut">Cargando…</td></tr></tbody></table></div>
  <div class="tag" id="w_msg" style="margin-top:6px">Haz clic en un símbolo para ver su gráfico.</div>
 </div>

 <div class="card g" id="o_card" style="display:none">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div class="lbl">MIS OPCIONES (covered calls, puts, spreads) · <span id="o_tot"></span></div><span class="grpbar"></span></div>
  <div id="o_strat"></div>
  <div id="o_loose" style="overflow-x:auto"><table><thead><tr><th>Contrato</th><th>Cant.</th><th>Costo prom.</th><th>Último</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th><th>Vence</th><th></th></tr></thead><tbody id="o_body"></tbody></table></div>
  <div id="roll_box"></div>
  <div class="mut" style="font-size:11px;margin-top:6px">Para cerrar o gestionar opciones usa Trading manual.</div>
 </div>

 <div class="card g">
  <div class="lbl">MIS ACCIONES (STOCKS) · <span id="s_tot"></span></div>
  <div style="overflow-x:auto"><table><thead><tr><th>Ticker</th><th>Cant.</th><th>Costo prom.</th><th>Último</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th><th></th></tr></thead><tbody id="s_body"><tr><td colspan="8" class="mut">Cargando…</td></tr></tbody></table></div>
  <div class="row" style="margin-top:10px;border-top:1px solid var(--line);padding-top:10px"><span class="tag">COMPRAR (límite)</span>
   <input id="b_sym" placeholder="Ticker" maxlength="6" style="width:90px;text-transform:uppercase"><input id="b_qty" type="number" min="1" value="10" style="width:80px"><input id="b_px" type="number" step="0.01" placeholder="Precio límite" style="width:120px">
   <button onclick="fillPx()">Precio actual</button><button class="buy" onclick="buyStock()">Comprar</button></div>
  <div class="mono" id="s_msg" style="margin-top:8px;font-size:12px;min-height:16px"></div>
 </div>
</div>

<div class="card w">
 <div class="row" style="justify-content:space-between;margin-bottom:8px">
  <div class="lbl" style="margin:0"><b id="c_sym" style="color:var(--tx);font-size:16px">SPY</b> <span id="c_px" class="mono" style="color:var(--tx)"></span> <span id="c_chg" class="mono"></span></div>
  <div class="row"><button type="button" class="btn" id="c_ind" title="Indicadores (RSI, MACD, Bollinger, VWAP, medias…)">ƒx Indicadores</button><a id="c_fund" href="/fundamentales" class="btn" style="color:var(--cy)">📊 Fundamentales</a><span id="c_tfs"></span></div></div>
 <div style="position:relative"><div id="lw"></div><div id="lk" class="mono" style="position:absolute;left:10px;top:8px;z-index:4;font-size:11px;color:var(--mut);background:rgba(0,0,0,.75);padding:3px 8px;border-radius:6px;pointer-events:none">🔒 Clic en el gráfico para mover / hacer zoom</div></div>
 <div class="tag" id="c_msg" style="margin-top:6px"></div>
</div>

</main>
<script>
const $=id=>document.getElementById(id);
const esc=x=>String(x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const money=v=>v==null?"–":(v>=0?"+$":"-$")+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const px=v=>v==null?"–":v.toFixed(2);
const cls=v=>v>0?"ok":v<0?"bad":"";
const vol=v=>v==null?"–":v>=1e6?(v/1e6).toFixed(1)+"M":v>=1e3?(v/1e3).toFixed(0)+"K":String(v);
const lsGet=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const getj=async p=>{const r=await fetch(p,{cache:"no-store"});return r.json()};
const post=async(p,b)=>{const r=await fetch(p,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});return r.json()};
let SYM=lsGet("p_sym","SPY"),TF=lsGet("p_tf","5"),WL=[],LAST={};
const TFS=[["1","1m"],["5","5m"],["15","15m"],["60","1h"],["D","1D"]];

/* ---------- watchlist ---------- */
async function loadWatch(){
  const j=await getj("/api/watch");if(j.error){$("w_msg").textContent=j.error;return}
  WL=j.rows.map(r=>r.sym);j.rows.forEach(r=>LAST[r.sym]=r.last);
  $("w_body").innerHTML=j.rows.map(r=>'<tr class="clk'+(r.sym===SYM?" sel":"")+'" onclick="pick(\''+r.sym+'\')"><td><b>'+esc(r.sym)+'</b> <span class="tag">'+esc((r.name||"").slice(0,18))+'</span></td><td class="mono"><b>'+px(r.last)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":(r.pct>0?"▲ +":r.pct<0?"▼ ":"")+r.pct.toFixed(2)+"%")+'</td><td class="mono">'+px(r.bid)+'</td><td class="mono">'+px(r.ask)+'</td><td class="mono">'+vol(r.vol)+'</td><td><button onclick="event.stopPropagation();rmSym(\''+r.sym+'\')" title="Quitar">✕</button></td></tr>').join("");
}
async function saveWatch(list){const j=await post("/api/watch_set",{symbols:list});if(j.error){$("w_msg").textContent=j.error;return false}loadWatch();return true}
async function addSym(){const s=$("w_new").value.trim().toUpperCase();if(!s)return;if(WL.includes(s)){$("w_msg").textContent=s+" ya está en la lista";return}
  if(await saveWatch(WL.concat([s]))){$("w_new").value="";$("w_msg").textContent=s+" agregado"}}
async function rmSym(s){if(WL.length<=1){$("w_msg").textContent="Deja al menos un símbolo";return}saveWatch(WL.filter(x=>x!==s))}
function pick(s){SYM=s;lsSet("p_sym",s);$("b_sym").value=s;firstFit=true;loadWatch();loadChart(true)}

/* ---------- agrupar patas en estrategias (igual que Inicio y Trading manual) ---------- */
function vname(v){return v.t==="P"?(v.s.strike>v.l.strike?"Put Credit Spread":"Put Debit Spread"):(v.s.strike<v.l.strike?"Call Credit Spread":"Call Debit Spread")}
function mkGroup(exp,vs,q){
  const legs=[];
  for(const v of vs)for(const l of [v.s,v.l])legs.push({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,q:v.q,frac:v.q/Math.abs(l.qty),l});
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0)*x.frac,0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark===null||x.l.mark===undefined)okv=false;else val+=x.sg*x.l.mark*x.q*100}
  const gr=k=>legs.reduce((a,x)=>a+((x.l[k]===null||x.l[k]===undefined)?0:x.sg*x.l[k]*x.q*100),0);
  let name;
  if(vs.length===2){const ps=vs.find(v=>v.t==="P").s.strike,cs=vs.find(v=>v.t==="C").s.strike;name=ps===cs?"Iron Fly":"Iron Condor"}
  else name=vname(vs[0]);
  return{name,exp,q,legs,entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,
    delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),strikes:legs.map(x=>x.strike).join(" / ")};
}
// Tradier no guarda que patas van juntas (solo cuantas unidades hay de cada opcion).
// Se empareja cada vendida con una comprada del mismo tipo minimizando la distancia total entre strikes.
function matchUnits(su,lu){
  const sw=su.length<=lu.length,A=sw?su:lu,B=sw?lu:su;
  if(!A.length)return[];
  const pair=(a,b)=>sw?[a,b]:[b,a];
  if(B.length<=6){
    let best=null,bc=1e18;const used=new Array(B.length).fill(false),cur=[];
    (function rec(i,c){
      if(c>=bc)return;
      if(i===A.length){bc=c;best=cur.slice();return}
      for(let j=0;j<B.length;j++){if(used[j])continue;used[j]=true;cur[i]=j;rec(i+1,c+Math.abs(A[i].strike-B[j].strike));used[j]=false}
    })(0,0);
    return A.map((a,i)=>pair(a,B[best[i]]));
  }
  const free=B.slice(),res=[];
  for(const a of A){let bi=0;for(let j=1;j<free.length;j++)if(Math.abs(free[j].strike-a.strike)<Math.abs(free[bi].strike-a.strike))bi=j;res.push(pair(a,free[bi]));free.splice(bi,1)}
  return res;
}
function groupPositions(legs){return grpApply(legs,groupAuto)}
function groupAuto(legs){
  const byExp={};for(const l of legs)(byExp[(l.root||"")+"|"+l.exp]=byExp[(l.root||"")+"|"+l.exp]||[]).push({...l,rem:Math.abs(l.qty)});
  const groups=[],loose=[];
  for(const key in byExp){
    const L=byExp[key],exp=L[0].exp,sym=L[0].root||"",verts=[];
    for(const t of ["P","C"]){
      const su=[],lu=[];
      for(const l of L.filter(x=>x.type===t)){const n=Math.floor(l.rem);for(let i=0;i<n;i++)(l.qty<0?su:lu).push(l)}
      const mp=new Map();
      for(const [s,c] of matchUnits(su,lu)){
        const key=s.occ+">"+c.occ;if(!mp.has(key))mp.set(key,{t,s,l:c,q:0});
        mp.get(key).q++;s.rem--;c.rem--;
      }
      for(const v of mp.values())verts.push(v);
    }
    const used=new Set(),pc=verts.filter(v=>v.t==="P"&&v.s.strike>v.l.strike),cc=verts.filter(v=>v.t==="C"&&v.s.strike<v.l.strike);
    for(const p of pc){const c=cc.find(x=>!used.has(x)&&x.q===p.q);if(c){used.add(p);used.add(c);groups.push(Object.assign(mkGroup(exp,[p,c],p.q),{sym}))}}
    for(const v of verts)if(!used.has(v))groups.push(Object.assign(mkGroup(exp,[v],v.q),{sym}));
    for(const l of L)if(l.rem>0)loose.push(l);
  }
  return{groups,loose};
}
const sgnc=v=>v===null||v===undefined?"":(v>0?"ok":v<0?"bad":"");
const usd=v=>v===null||v===undefined?"–":(v>=0?"+":"-")+"$"+Math.abs(v).toFixed(2);
function dte(exp){const et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  return Math.round((new Date(exp+"T00:00:00")-new Date(et.getFullYear(),et.getMonth(),et.getDate()))/86400000)}

/* ---------- acciones propias ---------- */
window.GRP_RENDER=()=>loadStocks();
async function loadStocks(){
  const j=await getj("/api/stocks");if(j.error){$("s_msg").textContent=j.error;return}
  $("s_tot").innerHTML='Valor <b class="mono">'+(j.value).toLocaleString("en-US",{style:"currency",currency:"USD"})+'</b> · P&L abierto <b class="mono '+cls(j.pnl)+'">'+money(j.pnl)+"</b>";
  const O=j.opts||[];$("o_card").style.display=O.length?"":"none";
  let loose=null,groups=[],sepd=new Set();
  if(O.length){try{const pj=await getj("/api/positions");if(!pj.error&&pj.legs){window.GRP_OSETS=pj.osets||[];const R=groupPositions(pj.legs.filter(l=>l.qty));groups=R.groups;loose=new Set(R.loose.map(l=>l.occ));sepd=new Set(R.loose.filter(l=>l.separada).map(l=>l.occ))}}catch(e){}}
  window.OPTS=O;
  if(O.length){$("o_tot").innerHTML='Valor <b class="mono">'+j.opt_value.toLocaleString("en-US",{style:"currency",currency:"USD"})+'</b> · P&L abierto <b class="mono '+cls(j.opt_pnl)+'">'+money(j.opt_pnl)+"</b>";
   $("o_strat").innerHTML=groups.length?'<div style="overflow-x:auto"><table><thead><tr><th>Estrategia</th><th>Vence</th><th>Cant.</th><th>Entrada</th><th>Cierre ahora</th><th>P&amp;L</th><th>Delta</th><th>Theta/día</th><th></th></tr></thead><tbody>'+groups.map(g=>{const cn=g.closeNow;return '<tr><td>'+grpChk(g.legs.map(x=>x.occ))+'<b>'+esc((g.sym?g.sym+" ":"")+g.name)+'</b><br><span class="mut">'+esc(g.strikes)+'</span></td><td class="mono">'+g.exp+" ("+dte(g.exp)+'d)</td><td class="mono">'+g.q+'</td><td class="mono">'+(g.entryNet>=0?"Crédito ":"Débito ")+Math.abs(g.entryNet).toFixed(2)+'</td><td class="mono">'+(cn===null?"–":(cn>=0?"Débito ":"Crédito ")+Math.abs(cn).toFixed(2))+'</td><td class="mono '+sgnc(g.pnl)+'"><b>'+usd(g.pnl)+'</b></td><td class="mono">'+g.delta.toFixed(1)+'</td><td class="mono '+sgnc(g.theta)+'">'+usd(g.theta)+'</td><td style="white-space:nowrap">'+grpSplitBtn(g.legs.map(x=>x.occ))+' <a class="btn" href="/trade#close='+encodeURIComponent(g.exp+"|"+g.strikes+"|"+g.q)+'">Cerrar</a></td></tr>'}).join("")+"</tbody></table></div>":"";
   const L=O.map((r,i)=>[r,i]).filter(([r])=>!loose||loose.has(r.sym));
   $("o_loose").style.display=L.length?"":"none";
   $("o_body").innerHTML=L.map(([r,i])=>'<tr><td>'+grpChk([r.sym])+'<b>'+esc(r.under)+'</b> '+r.strike+' '+(r.right=="CALL"?"Call":"Put")+(r.qty<0?' <span class="tag">corto</span>':"")+(sepd.has(r.sym)?grpLooseBtn({occ:r.sym,separada:true}):"")+'</td><td class="mono">'+r.qty+'</td><td class="mono">'+px(r.avg)+'</td><td class="mono">'+px(r.last)+'</td><td class="mono">'+(r.value==null?"–":r.value.toFixed(2))+'</td><td class="mono '+cls(r.pnl)+'"><b>'+money(r.pnl)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":r.pct.toFixed(2)+"%")+'</td><td class="mono">'+esc(r.exp||"–")+(r.dte==null?"":" ("+r.dte+"d)")+'</td><td><button class="rollb" onclick="openRoll('+i+')">⟳ Roll…</button></td></tr>').join("")}
  $("s_body").innerHTML=j.rows.length?j.rows.map(r=>{const short=r.qty<0;return '<tr class="clk" onclick="pick(\''+r.sym+'\')"><td><b>'+esc(r.sym)+'</b>'+(short?' <span class="tag">corto</span>':"")+'</td><td class="mono">'+r.qty+'</td><td class="mono">'+px(r.avg)+'</td><td class="mono">'+px(r.last)+'</td><td class="mono">'+(r.value==null?"–":r.value.toFixed(2))+'</td><td class="mono '+cls(r.pnl)+'"><b>'+money(r.pnl)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":r.pct.toFixed(2)+"%")+'</td><td><button class="sell" onclick="event.stopPropagation();sellStock(\''+r.sym+'\','+r.qty+',false)">Vender…</button> <button class="sell" onclick="event.stopPropagation();sellStock(\''+r.sym+'\','+r.qty+',true)">Liquidar</button></td></tr>'}).join(""):'<tr><td colspan="8" class="mut">No tienes acciones en esta cuenta. Puedes comprar abajo.</td></tr>';
}

/* ---------- roll de una opcion suelta (rueda) ---------- */
const RL={r:null,exps:[],chain:{},old:null};
function rlMid(o){return o&&o.bid!=null&&o.ask!=null&&o.ask>0?(o.bid+o.ask)/2:null}
async function rlChain(exp,under){const k=under+exp;if(!RL.chain[k]){const j=await getj("/api/chain?exp="+encodeURIComponent(exp)+"&sym="+encodeURIComponent(under));RL.chain[k]=j.error?{error:j.error}:j}return RL.chain[k]}
async function openRoll(i){
  const r=(window.OPTS||[])[i];if(!r)return;RL.r=r;RL.chain={};
  const box=$("roll_box");box.innerHTML='<div class="mut" style="margin-top:10px">Cargando vencimientos…</div>';
  const e=await getj("/api/expirations?sym="+encodeURIComponent(r.under));
  if(e.error){box.innerHTML='<div class="bad" style="margin-top:10px">'+esc(e.error)+"</div>";return}
  RL.exps=(e.dates||[]).filter(d=>d!==r.exp);
  if(!RL.exps.length){box.innerHTML='<div class="bad" style="margin-top:10px">No encontré otros vencimientos</div>';return}
  const later=RL.exps.find(d=>d>(r.exp||"")&&(new Date(d)-new Date(r.exp))/864e5>=5)||RL.exps.find(d=>d>(r.exp||""))||RL.exps[0];
  const short=r.qty<0,n=Math.abs(r.qty);
  box.innerHTML='<div style="border:1px solid var(--cy);border-radius:12px;padding:14px;margin-top:12px;background:#0a0a0d">'
   +'<div class="lbl" style="color:var(--cy)">ROLL · '+esc(r.under)+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+(short?" corto":" largo")+" ×"+n+" · vence "+esc(r.exp||"–")+"</div>"
   +'<div class="row" style="margin:8px 0"><span class="mut">Nuevo vencimiento</span><select id="rl_exp" onchange="rlLoad()">'+RL.exps.map(d=>'<option value="'+d+'"'+(d===later?" selected":"")+">"+d+"</option>").join("")+'</select>'
   +'<span class="mut">Nuevo strike</span><select id="rl_k" onchange="rlCalc(true)"></select>'
   +'<span class="mut">Cantidad</span><input id="rl_q" type="number" min="1" max="'+n+'" value="'+n+'" style="width:64px" oninput="rlCalc(true)"></div>'
   +'<div id="rl_legs" style="font-size:13px"></div>'
   +'<div class="row" style="margin:8px 0"><span id="rl_net"></span><select id="rl_t"><option value="credit">Crédito</option><option value="debit">Débito</option></select><span class="mut">Precio límite</span><input id="rl_p" type="number" step="0.01" min="0.01" style="width:90px"><button onclick="rlMidPx()">Usar mid</button></div>'
   +'<div class="row"><button class="buy" onclick="rlSend()">Enviar roll</button><button onclick="rlClose()">Cancelar</button><span class="tag">Una sola orden de 2 patas. Si no se llena, la modificas desde Órdenes.</span></div>'
   +'<div class="mono" id="rl_msg" style="font-size:12px;min-height:16px;margin-top:6px"></div></div>';
  rlLoad(true)}
function rlClose(){$("roll_box").innerHTML="";RL.r=null}
async function rlLoad(){
  const r=RL.r;if(!r)return;$("rl_msg").textContent="Cargando cadena…";
  const exp=$("rl_exp").value,[c,o]=await Promise.all([rlChain(exp,r.under),rlChain(r.exp,r.under)]);
  if(c.error){$("rl_msg").innerHTML='<span class="bad">'+esc(c.error)+"</span>";return}
  RL.old=((o.options||[]).find(x=>x.occ===r.sym))||null;
  const t=r.right=="CALL"?"C":"P",opts=(c.options||[]).filter(x=>x.type===t).sort((a,b)=>a.strike-b.strike);
  if(!opts.length){$("rl_msg").innerHTML='<span class="bad">Sin contratos para ese vencimiento</span>';return}
  let best=opts.reduce((a,b)=>Math.abs(b.strike-r.strike)<Math.abs(a.strike-r.strike)?b:a);
  $("rl_k").innerHTML=opts.map(x=>'<option value="'+x.occ+'"'+(x===best?" selected":"")+">"+x.strike+(x.delta!=null?" (Δ "+x.delta.toFixed(2)+")":"")+"</option>").join("");
  $("rl_msg").textContent="";rlCalc(true)}
function rlSel(){const c=RL.chain[RL.r.under+$("rl_exp").value];return c&&c.options?c.options.find(x=>x.occ===$("rl_k").value):null}
function rlCalc(setpx){
  const r=RL.r;if(!r)return;const nw=rlSel(),od=RL.old,short=r.qty<0;
  const oldB=od?od.bid:null,oldA=od?od.ask:null,oldM=od?rlMid(od):r.last;
  const nwM=rlMid(nw);let h="";
  const leg=(lbl,name,b,a)=>'<div style="display:grid;grid-template-columns:170px 1fr 1fr;gap:6px;padding:5px 0;border-top:1px solid var(--line)"><b class="mut">'+lbl+"</b><span>"+name+'</span><span class="mono mut">bid '+px(b)+" · ask "+px(a)+"</span></div>";
  h+=leg((short?"1. Comprar para cerrar":"1. Vender para cerrar"),esc(r.under)+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+" · "+esc(r.exp||""),oldB,oldA);
  h+=leg((short?"2. Vender para abrir":"2. Comprar para abrir"),nw?esc(r.under)+" "+nw.strike+" "+(r.right=="CALL"?"Call":"Put")+" · "+esc($("rl_exp").value):"–",nw?nw.bid:null,nw?nw.ask:null);
  $("rl_legs").innerHTML=h;
  let net=null;if(nwM!=null&&oldM!=null)net=short?(nwM-oldM):(oldM-nwM);
  RL.mid=net;
  $("rl_net").innerHTML=net==null?'<span class="mut">Sin precios para calcular el neto</span>':'Neto al mid: <b class="mono '+(net>=0?"ok":"bad")+'">'+(net>=0?"CRÉDITO $":"DÉBITO $")+Math.abs(net).toFixed(2)+'</b> <span class="mut">(≈ $'+Math.abs(net*100*(parseInt($("rl_q").value,10)||0)).toFixed(0)+" en total)</span>";
  if(setpx&&net!=null){$("rl_t").value=net>=0?"credit":"debit";$("rl_p").value=Math.max(0.01,Math.abs(net)).toFixed(2)}}
function rlMidPx(){if(RL.mid==null)return;$("rl_t").value=RL.mid>=0?"credit":"debit";$("rl_p").value=Math.max(0.01,Math.abs(RL.mid)).toFixed(2)}
async function rlSend(){
  const r=RL.r;if(!r)return;const q=parseInt($("rl_q").value,10),p=parseFloat($("rl_p").value),t=$("rl_t").value,nw=rlSel(),msg=$("rl_msg");
  if(!nw||!(q>=1)||!(p>0)){msg.innerHTML='<span class="bad">Revisa strike, cantidad y precio límite</span>';return}
  const body={old_occ:r.sym,new_occ:nw.occ,symbol:r.under,qty:q,price:p,type:t};
  msg.textContent="Revisando con el broker…";
  const pv=await post("/api/roll",Object.assign({preview:true},body));
  if(pv.error){msg.innerHTML='<span class="bad">'+esc(pv.error)+"</span>";return}
  const g=await guard("ROLL "+q+" × "+r.under+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+" "+r.exp+"  →  "+nw.strike+" "+nw.occ.slice(-9,-8).replace("C","Call").replace("P","Put")+" "+$("rl_exp").value+"\n"+(t=="credit"?"Crédito":"Débito")+" límite $"+p.toFixed(2));if(!g)return;
  msg.textContent="Enviando…";
  const j=await post("/api/roll",Object.assign({},body,g));
  if(j.error){msg.innerHTML='<span class="bad">'+esc(j.error)+"</span>";return}
  msg.innerHTML='<span class="ok">Roll enviado (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+"). Míralo en Órdenes de Trading manual; si no se llena, usa Modificar.</span>";
  setTimeout(loadStocks,2000)}
async function sellStock(sym,qty,all){
  const short=qty<0,held=Math.abs(qty);let n=held;
  if(!all){const a=prompt((short?"Cubrir":"Vender")+" cuántas acciones de "+sym+"? (tienes "+held+")",String(held));if(a===null)return;n=parseInt(a,10);if(!(n>=1&&n<=held)){$("s_msg").innerHTML='<span class="bad">Cantidad no válida</span>';return}}
  const g=await guard((short?"CUBRIR ":"VENDER A MERCADO ")+n+" × "+sym+(all?" (liquidar toda la posición)":""));if(!g)return;
  $("s_msg").textContent="Enviando…";
  const j=await post("/api/stock_order",Object.assign({symbol:sym,side:short?"buy_to_cover":"sell",qty:n,type:"market"},g));
  $("s_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden enviada (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+")</span>";
  setTimeout(loadStocks,1500);loadStocks()}
function fillPx(){const s=($("b_sym").value||SYM).toUpperCase();const v=LAST[s];if(v!=null)$("b_px").value=v.toFixed(2);else $("s_msg").textContent="Ese símbolo no está en tu watchlist: escribe el precio a mano"}
async function buyStock(){
  const s=($("b_sym").value||"").trim().toUpperCase(),q=parseInt($("b_qty").value,10),p=parseFloat($("b_px").value);
  if(!s||!(q>=1)||!(p>0)){$("s_msg").innerHTML='<span class="bad">Escribe ticker, cantidad y precio límite</span>';return}
  const g=await guard("COMPRAR "+q+" × "+s+" a límite $"+p.toFixed(2)+" (≈ $"+(q*p).toFixed(0)+")");if(!g)return;
  $("s_msg").textContent="Enviando…";
  const j=await post("/api/stock_order",Object.assign({symbol:s,side:"buy",qty:q,type:"limit",price:p},g));
  $("s_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden enviada (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+")</span>";
  setTimeout(loadStocks,1500)}

/* ===== matematica de indicadores (funciones puras; cada una devuelve arreglos alineados a las velas, null donde aun no hay dato) ===== */
const IM={
sma(v,n){const o=new Array(v.length).fill(null);let s=0;for(let i=0;i<v.length;i++){s+=v[i];if(i>=n)s-=v[i-n];if(i>=n-1)o[i]=s/n}return o},
ema(v,n){const o=new Array(v.length).fill(null);if(v.length<n)return o;const k=2/(n+1);let e=0;for(let i=0;i<n;i++)e+=v[i];e/=n;o[n-1]=e;for(let i=n;i<v.length;i++){e=v[i]*k+e*(1-k);o[i]=e}return o},
rsi(c,n){const o=new Array(c.length).fill(null);if(c.length<=n)return o;let g=0,l=0;for(let i=1;i<=n;i++){const d=c[i]-c[i-1];if(d>=0)g+=d;else l-=d}g/=n;l/=n;
  o[n]=l===0?100:100-100/(1+g/l);for(let i=n+1;i<c.length;i++){const d=c[i]-c[i-1];g=(g*(n-1)+(d>0?d:0))/n;l=(l*(n-1)+(d<0?-d:0))/n;o[i]=l===0?100:100-100/(1+g/l)}return o},
macd(c,f,s,g){const ef=IM.ema(c,f),es=IM.ema(c,s),m=c.map((_,i)=>ef[i]!=null&&es[i]!=null?ef[i]-es[i]:null);
  const idx=m.findIndex(x=>x!=null),sig=new Array(c.length).fill(null);if(idx>=0){const e=IM.ema(m.slice(idx),g);e.forEach((x,j)=>{sig[idx+j]=x})}
  return{macd:m,signal:sig,hist:m.map((x,i)=>x!=null&&sig[i]!=null?x-sig[i]:null)}},
bb(c,n,k){const m=IM.sma(c,n),u=[],l=[];for(let i=0;i<c.length;i++){if(m[i]==null){u.push(null);l.push(null);continue}let s=0;for(let j=i-n+1;j<=i;j++)s+=(c[j]-m[i])**2;const sd=Math.sqrt(s/n);u.push(m[i]+k*sd);l.push(m[i]-k*sd)}return{mid:m,up:u,lo:l}},
atr(b,n){const o=new Array(b.length).fill(null);if(b.length<=n)return o;const tr=b.map((x,i)=>i===0?x.high-x.low:Math.max(x.high-x.low,Math.abs(x.high-b[i-1].close),Math.abs(x.low-b[i-1].close)));
  let a=0;for(let i=1;i<=n;i++)a+=tr[i];a/=n;o[n]=a;for(let i=n+1;i<b.length;i++){a=(a*(n-1)+tr[i])/n;o[i]=a}return o},
stoch(b,k,d){const K=new Array(b.length).fill(null);for(let i=k-1;i<b.length;i++){let hi=-1e18,lo=1e18;for(let j=i-k+1;j<=i;j++){hi=Math.max(hi,b[j].high);lo=Math.min(lo,b[j].low)}K[i]=hi===lo?50:(b[i].close-lo)/(hi-lo)*100}
  const idx=K.findIndex(x=>x!=null),D=new Array(b.length).fill(null);if(idx>=0)IM.sma(K.slice(idx),d).forEach((x,j)=>{D[idx+j]=x});return{k:K,d:D}},
vwap(b){const o=[];let pv=0,vv=0,day=null;for(const x of b){const dk=Math.floor(x.time/86400);if(dk!==day){day=dk;pv=0;vv=0}const tp=(x.high+x.low+x.close)/3;pv+=tp*x.volume;vv+=x.volume;o.push(vv>0?pv/vv:null)}return o},
supertrend(b,n,m){const a=IM.atr(b,n),line=new Array(b.length).fill(null),dir=new Array(b.length).fill(0);let fu=0,fl=0,d=1;
  for(let i=0;i<b.length;i++){if(a[i]==null)continue;const hl=(b[i].high+b[i].low)/2,bu=hl+m*a[i],bl=hl-m*a[i];
    if(line[i-1]==null){fu=bu;fl=bl;d=b[i].close>=hl?1:-1}else{fu=(bu<fu||b[i-1].close>fu)?bu:fu;fl=(bl>fl||b[i-1].close<fl)?bl:fl;
      if(d===1&&b[i].close<fl)d=-1;else if(d===-1&&b[i].close>fu)d=1}
    line[i]=d===1?fl:fu;dir[i]=d}return{line,dir}}
};

/* ===== indicadores estilo TradingView (por grafico): superpuestos en el precio u osciladores en franjas debajo ===== */
const IND={
 sma:{n:"SMA",p:[["n","Período",20,2,500]],c:"#f5c542"},
 ema:{n:"EMA",p:[["n","Período",50,2,500]],c:"#ff8a65"},
 bb:{n:"Bollinger",p:[["n","Período",20,2,200],["k","Desv.",2,.5,5]],c:"#7c9cff"},
 vwap:{n:"VWAP",p:[],c:"#e040fb"},
 st:{n:"Supertrend",p:[["n","ATR",10,2,100],["m","Mult.",3,.5,10]],c:"#26c6da"},
 rsi:{n:"RSI",osc:1,p:[["n","Período",14,2,100]],c:"#b388ff",lv:[30,70],rng:[0,100]},
 macd:{n:"MACD",osc:1,p:[["f","Rápida",12,2,100],["s","Lenta",26,3,200],["g","Señal",9,2,50]],c:"#4fc3f7"},
 stoch:{n:"Estocástico",osc:1,p:[["k","%K",14,2,100],["d","%D",3,1,50]],c:"#ffb74d",lv:[20,80],rng:[0,100]},
 atr:{n:"ATR",osc:1,p:[["n","Período",14,2,100]],c:"#90a4ae"}
};
const IND_MAXOSC=3;
function indLabel(x){const d=IND[x.t];return d.n+(d.p.length?" "+d.p.map(q=>x.p[q[0]]).join(","):"")}
const IH={
 indLoad(){let a=[];try{a=JSON.parse(lsGet("ind"+this.i,"[]"))}catch(e){}
  this.ind=(Array.isArray(a)?a:[]).filter(x=>x&&IND[x.t]).map(x=>{const d=IND[x.t],p={};d.p.forEach(q=>{const v=+(x.p||{})[q[0]];p[q[0]]=isFinite(v)&&v>=q[3]&&v<=q[4]?v:q[2]});return{id:x.id||Math.random().toString(36).slice(2),t:x.t,p:p,c:/^#[0-9a-f]{6}$/i.test(x.c||"")?x.c:d.c,on:x.on!==false}})},
 indSave(){lsSet("ind"+this.i,JSON.stringify(this.ind.map(x=>({id:x.id,t:x.t,p:x.p,c:x.c,on:x.on}))))},
 indInit(){this.indLoad();const lg=document.createElement("div");lg.className="pleg";this.el.pc.appendChild(lg);this.el.leg=lg;
  this.el.ind.onclick=()=>this.indMenu();this.indRefresh()},
 indKill(){(this.indS||[]).forEach(s=>{try{this.chart.removeSeries(s)}catch(e){}});this.indS=[];(this.ind||[]).forEach(x=>{x.ss=[]})},
 indRefresh(){if(!this.chart)return;this.indKill();let slot=0;
  this.ind.forEach(x=>{x.ss=[];x.slot=null;if(!x.on)return;const d=IND[x.t],ch=this.chart;
   const reg=s=>{x.ss.push(s);this.indS.push(s);return s};
   const L=(o)=>reg(ch.addLineSeries(Object.assign({color:x.c,lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false},o)));
   if(d.osc){if(slot>=IND_MAXOSC){x.on=false;return}x.slot=slot;const id="os"+slot++;const base={priceScaleId:id,title:indLabel(x),lastValueVisible:true};
    if(x.t==="macd"){reg(ch.addHistogramSeries({priceScaleId:id,priceLineVisible:false,lastValueVisible:false}));L(Object.assign({},base,{lineWidth:2}));L({priceScaleId:id,color:"#ffa726"})}
    else if(x.t==="stoch"){L(Object.assign({},base,{lineWidth:2,autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})}));L({priceScaleId:id,color:"#ef5350",autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})})}
    else{const o=Object.assign({},base,{lineWidth:2});if(d.rng)o.autoscaleInfoProvider=()=>({priceRange:{minValue:d.rng[0],maxValue:d.rng[1]}});L(o)}
    (d.lv||[]).forEach(v=>x.ss[x.ss.length-(x.t==="stoch"?2:1)].createPriceLine({price:v,color:"#3a4566",lineWidth:1,lineStyle:2,axisLabelVisible:false,title:""}))}
   else if(x.t==="bb"){L({lineWidth:1});L({lineWidth:1});L({lineWidth:1,lineStyle:2})}
   else if(x.t==="st"){L({lineWidth:2})}
   else L({lineWidth:2})});
  this.indLayout();this.indData();this.indLegend()},
 indLayout(){if(!this.chart)return;const k=this.ind.filter(x=>x.on&&IND[x.t].osc).length,H=0.17,V=k?0.07:0;
  this.cs.priceScale().applyOptions({scaleMargins:k?{top:0.06,bottom:V+k*H+0.02}:{top:0.2,bottom:0.1}});
  this.vs.priceScale().applyOptions({scaleMargins:{top:k?0.93:0.82,bottom:0}});
  this.ind.filter(x=>x.on&&x.slot!=null).forEach(x=>{const b=V+x.slot*H;try{this.chart.priceScale("os"+x.slot).applyOptions({scaleMargins:{top:1-b-H+0.01,bottom:b},visible:false,borderVisible:false})}catch(e){}})},
 indEmpty(){(this.ind||[]).forEach(x=>(x.ss||[]).forEach(s=>{try{s.setData([])}catch(e){}}));if(this.el.leg)this.el.leg.innerHTML=""},
 indData(){const B=this.bars||[];if(!this.chart||!B.length){this.indEmpty();return}
  const T=B.map(b=>b.time),C=B.map(b=>b.close),pts=(a,col)=>{const o=[];for(let i=0;i<a.length;i++)if(a[i]!=null&&isFinite(a[i]))o.push(col?{time:T[i],value:a[i],color:col(i)}:{time:T[i],value:a[i]});return o};
  this.ind.forEach(x=>{if(!x.on||!x.ss.length)return;const p=x.p;x.last=[];
   if(x.t==="sma"){const a=IM.sma(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="ema"){const a=IM.ema(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="vwap"){const a=(this.tf==="D"||this.tf==="240")?C.map(()=>null):IM.vwap(B);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="bb"){const r=IM.bb(C,p.n,p.k);x.ss[0].setData(pts(r.up));x.ss[1].setData(pts(r.lo));x.ss[2].setData(pts(r.mid));x.last=[r.up[B.length-1],r.mid[B.length-1],r.lo[B.length-1]]}
   else if(x.t==="st"){const r=IM.supertrend(B,p.n,p.m);x.ss[0].setData(pts(r.line,i=>r.dir[i]===1?"#4ff0b7":"#ff5d6c"));x.last=[r.line[B.length-1]]}
   else if(x.t==="rsi"){const a=IM.rsi(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="atr"){const a=IM.atr(B,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="macd"){const r=IM.macd(C,p.f,p.s,p.g);x.ss[0].setData(r.hist.map((v,i)=>v==null?null:{time:T[i],value:v,color:v>=0?"rgba(79,240,183,.55)":"rgba(255,93,108,.55)"}).filter(Boolean));
    x.ss[1].setData(pts(r.macd));x.ss[2].setData(pts(r.signal));const n=B.length-1;x.last=[r.macd[n],r.signal[n],r.hist[n]]}
   else if(x.t==="stoch"){const r=IM.stoch(B,p.k,p.d);x.ss[0].setData(pts(r.k));x.ss[1].setData(pts(r.d));const n=B.length-1;x.last=[r.k[n],r.d[n]]}});
  this.indLegend()},
 indLegend(){const lg=this.el.leg;if(!lg)return;const f=v=>v==null||!isFinite(v)?"–":(Math.abs(v)>=100?v.toFixed(1):v.toFixed(2));
  lg.innerHTML=(this.ind||[]).map(x=>'<div class="pl'+(x.on?"":" off")+'" data-id="'+x.id+'"><i style="background:'+x.c+'"></i><span>'+esc(indLabel(x))+'</span><b>'+(x.on&&x.last?x.last.map(f).join(" "):"")+'</b><button type="button" data-a="eye" title="Mostrar / ocultar">'+(x.on?"👁":"✕")+'</button><button type="button" data-a="set" title="Ajustes">⚙</button><button type="button" data-a="del" title="Quitar">🗑</button></div>').join("");
  lg.onclick=e=>{const b=e.target.closest("button"),r=e.target.closest(".pl");if(!b||!r)return;const x=this.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(b.dataset.a==="eye"){x.on=!x.on;this.indRefresh();this.indSave()}else if(b.dataset.a==="del"){this.ind=this.ind.filter(y=>y!==x);this.indRefresh();this.indSave()}else this.indMenu()}},
 indMenu(){const root=this.el.root;let m=root.querySelector(".pmenu");if(m){m.remove();return}
  m=document.createElement("div");m.className="pmenu";root.appendChild(m);const me=this;
  const draw=()=>{m.innerHTML='<div class="pmh"><b>ƒx Indicadores</b><button type="button" data-a="x">✕</button></div><div class="pms">Sobre el precio</div><div class="pmg">'+
    Object.keys(IND).filter(k=>!IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">En franja debajo (máx. '+IND_MAXOSC+')</div><div class="pmg">'+
    Object.keys(IND).filter(k=>IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">Activos en este gráfico</div>'+
    (me.ind.length?me.ind.map(x=>'<div class="pmr" data-id="'+x.id+'"><b>'+IND[x.t].n+'</b>'+IND[x.t].p.map(q=>'<label>'+q[1]+' <input type="number" data-k="'+q[0]+'" value="'+x.p[q[0]]+'" min="'+q[3]+'" max="'+q[4]+'" step="'+(q[3]<1||q[0]==="k"&&x.t==="bb"||q[0]==="m"?0.5:1)+'"></label>').join("")+
     '<input type="color" data-k="c" value="'+x.c+'"><button type="button" data-a="del" title="Quitar">🗑</button></div>').join(""):'<div class="mut" style="font-size:12px">Ninguno todavía: elige uno arriba.</div>')+
    '<div class="pms" style="margin-top:8px"><button type="button" data-a="clr">Quitar todos</button></div>'};
  draw();
  m.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
   if(b.dataset.a==="x"){m.remove();return}
   if(b.dataset.add){const t=b.dataset.add,d=IND[t];if(d.osc&&me.ind.filter(y=>IND[y.t].osc&&y.on).length>=IND_MAXOSC){$("ch_hint")&&($("ch_hint").textContent="Máximo "+IND_MAXOSC+" indicadores en franja: quita uno");return}
    const p={};d.p.forEach(q=>p[q[0]]=q[2]);me.ind.push({id:Math.random().toString(36).slice(2),t:t,p:p,c:d.c,on:true})}
   else if(b.dataset.a==="del"){const id=b.closest(".pmr").dataset.id;me.ind=me.ind.filter(y=>y.id!==id)}
   else if(b.dataset.a==="clr")me.ind=[];else return;
   me.indRefresh();me.indSave();draw()});
  m.addEventListener("change",e=>{const i=e.target,r=i.closest(".pmr");if(!r||!i.dataset.k)return;const x=me.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(i.dataset.k==="c")x.c=i.value;else{const q=IND[x.t].p.find(q=>q[0]===i.dataset.k),v=+i.value;if(isFinite(v)&&v>=q[3]&&v<=q[4])x.p[i.dataset.k]=v;else i.value=x.p[i.dataset.k]}
   me.indRefresh();me.indSave();draw()})}
};
/* ---------- grafico del simbolo elegido ---------- */
let LW=null,CS=null,VS=null,ES=null,SS=null,firstFit=true,busyC=false,CREQ=0,ZT=null;
function drawTfs(){$("c_tfs").innerHTML=TFS.map(t=>'<button class="'+(t[0]===TF?"on":"")+'" onclick="setTf(\''+t[0]+'\')">'+t[1]+"</button>").join(" ")}
function setTf(t){TF=t;lsSet("p_tf",t);drawTfs();firstFit=true;loadChart(true)}
function initChart(){
  if(LW||!window.LightweightCharts)return !!LW;
  LW=LightweightCharts.createChart($("lw"),{layout:{background:{color:"#0c0c0f"},textColor:"#9fb0cc"},grid:{vertLines:{color:"#1c1c22"},horzLines:{color:"#1c1c22"}},
    rightPriceScale:{borderColor:"#202027"},timeScale:{borderColor:"#202027",timeVisible:true,rightOffset:6},autoSize:true,
    handleScroll:{mouseWheel:false,pressedMouseMove:false,horzTouchDrag:true,vertTouchDrag:false},handleScale:{mouseWheel:false,pinch:true,axisPressedMouseMove:false,axisDoubleClickReset:true}});
  const box=$("lw"),setAct=on=>{LW.applyOptions({handleScroll:{mouseWheel:on,pressedMouseMove:on,horzTouchDrag:true,vertTouchDrag:false},handleScale:{mouseWheel:on,pinch:true,axisPressedMouseMove:on,axisDoubleClickReset:true}});
    box.style.borderColor=on?"#5cc8ff":"transparent";$("lk").textContent=on?"🔓 Zoom y mover activos · saca el ratón del gráfico para bloquear":"🔒 Clic en el gráfico para mover / hacer zoom"};
  box.addEventListener("mousedown",()=>setAct(true),true);box.addEventListener("mouseleave",()=>setAct(false));setAct(false);
  CS=LW.addCandlestickSeries({upColor:"#4ff0b7",downColor:"#ff5d6c",borderVisible:false,wickUpColor:"#4ff0b7",wickDownColor:"#ff5d6c"});
  ES=LW.addLineSeries({color:"#f5a03a",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
  SS=LW.addLineSeries({color:"#5cc8ff",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
  VS=LW.addHistogramSeries({priceFormat:{type:"volume"},priceScaleId:""});VS.priceScale().applyOptions({scaleMargins:{top:0.82,bottom:0}});
  LW.timeScale().subscribeVisibleLogicalRangeChange(r=>{if(!r||firstFit||busyC)return;clearTimeout(ZT);
    ZT=setTimeout(()=>{const n=CS.data().length;if(n>1&&r.to>r.from)lsSet("pzoom_"+TF,JSON.stringify({w:+(r.to-r.from).toFixed(2),r:+(r.to-(n-1)).toFixed(2)}))},500)});
  IH.chart=LW;IH.cs=CS;IH.vs=VS;IH.i="pf";IH.bars=[];IH.tf=TF;IH.el={pc:$("lw").parentNode,root:document.querySelector(".card.w"),ind:$("c_ind")};
  IH.indInit();IH.el.leg.style.top="32px";
  return true}
async function loadChart(reset){
  /* la actualizacion de cada 10 s se salta si hay una carga en curso; un cambio de simbolo o temporalidad
     SIEMPRE carga, y las respuestas viejas (de un simbolo anterior) se descartan */
  if(busyC&&!reset)return;
  const my=++CREQ,sym=SYM,tf=TF;busyC=true;
  try{
    $("c_sym").textContent=sym;$("c_fund").href="/fundamentales?sym="+sym;
    if(reset)$("c_msg").textContent="Cargando "+sym+"…";
    if(!initChart()){$("c_msg").textContent="No cargó la librería del gráfico (¿sin internet?)";return}
    const c=await getj("/api/c?sym="+encodeURIComponent(sym)+"&i="+tf);
    if(my!==CREQ||sym!==SYM||tf!==TF)return;
    if(c.error){$("c_msg").textContent=c.error;return}
    $("c_msg").textContent=c.bars.length?"Línea naranja EMA 20 · azul SMA 50 · sandbox con ~15 min de retraso"+(c.vol_proxy?" · volumen de "+c.vol_proxy+" (el índice no tiene volumen)":""):"Sin velas (mercado cerrado o sin datos)";
    CS.setData(c.bars.map(b=>({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close})));
    VS.setData(c.bars.map(b=>({time:b.time,value:b.volume,color:b.close>=b.open?"rgba(79,240,183,.35)":"rgba(255,93,108,.35)"})));
    ES.setData(c.ema);SS.setData(c.sma);
    IH.bars=c.bars;IH.tf=TF;IH.indData();
    if(reset||firstFit){const N={"1":120,"5":100,"15":90,"60":90,"D":100}[TF]||100,n=c.bars.length;CS.priceScale().applyOptions({autoScale:true});
      let z=null;try{z=JSON.parse(lsGet("pzoom_"+TF,"null"))}catch(e){}
      if(z&&z.w>=5&&z.w<=5000&&Math.abs(z.r)<=500){const to=n-1+z.r;LW.timeScale().setVisibleLogicalRange({from:to-z.w,to})}   // como lo dejaste
      else LW.timeScale().setVisibleLogicalRange({from:Math.max(-1,n-N),to:n+6});firstFit=false}
    const l=c.bars[c.bars.length-1],p=c.bars[c.bars.length-2];
    if(l){$("c_px").textContent=l.close.toFixed(2);const d=p?l.close-p.close:0;$("c_chg").textContent=p?(d>=0?"▲ +":"▼ ")+d.toFixed(2):"";$("c_chg").className="mono "+cls(d)}
  }catch(e){if(my===CREQ)$("c_msg").textContent="Error del gráfico: "+e}finally{if(my===CREQ)busyC=false}}

async function acct(){try{const a=await getj("/api/account");if(a&&a.equity!=null)$("acct").textContent="Equity $"+a.equity.toLocaleString("en-US")+(a.option_bp!=null?" · BP opciones $"+a.option_bp.toLocaleString("en-US"):"")}catch(e){}}

drawTfs();$("b_sym").value=SYM;
loadWatch();loadStocks();loadChart(true);acct();
setInterval(loadWatch,5000);setInterval(loadStocks,5000);setInterval(()=>loadChart(false),10000);
</script></body></html>
"""
