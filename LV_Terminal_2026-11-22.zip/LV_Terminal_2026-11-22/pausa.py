"""PAUSA despues de perdidas seguidas (regla de Luis, 20-nov-2026): tras 2 operaciones MANUALES seguidas cerradas en
perdida (abiertas y cerradas el MISMO dia) en la cuenta REAL, 30 minutos sin poder ABRIR posiciones nuevas a mano. Cerrar, ajustar stops, el gestor y los
robots siguen igual. No hay boton para saltarla.
Se calcula siempre desde el registro de operaciones cerradas de HOY (manual_trades_real.csv), asi que sobrevive a reinicios."""
import json
import os
import threading
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import reportes

ET = ZoneInfo("America/New_York")
BASE = os.path.dirname(os.path.abspath(__file__))
LOSSES = 2          # perdidas seguidas
MINUTES = 30        # minutos de pausa
NOTIF_FILE = os.path.join(BASE, "pausa_avisos.json")


def _robot_occs():
    """Patas de los iron condors del robot automatico: esas operaciones no cuentan (la regla es solo para lo manual)."""
    out = set()
    for f in ("condor_real.json", "condor_real_h.json"):
        try:
            with open(os.path.join(BASE, f), encoding="utf-8") as fh:
                d = json.load(fh)
            for day in (d.get("dias") or {}).values():
                out.update(((day.get("plan") or {}).get("occ") or {}).values())
        except (OSError, ValueError, AttributeError):
            pass
    return out


def _old_occs(live, today):
    """Contratos que abriste ANTES de hoy (segun tus ordenes registradas): cerrarlos hoy no cuenta para la pausa
    (regla de Luis 22-nov: solo cuentan las operaciones que se abren y cierran el mismo dia)."""
    import csv
    f = reportes.FILLS_H_CSV if live == "H" else reportes.FILLS_LIVE_CSV
    last = {}
    try:
        with open(os.path.join(BASE, f), newline="", encoding="utf-8", errors="replace") as fh:
            for r in csv.DictReader(fh):
                if str(r.get("lado", "")).endswith("_to_open") and r.get("opcion"):
                    d = r.get("fecha", "")
                    if d <= today and d > last.get(r["opcion"], ""):
                        last[r["opcion"]] = d
    except OSError:
        pass
    return frozenset(o for o, d in last.items() if d < today)


def compute(rows, now, robot=frozenset(), old=frozenset()):
    """rows: operaciones cerradas (fecha, hora, pnl, opcion). -> {activa, hasta (datetime), racha, motivo}"""
    today = now.strftime("%Y-%m-%d")
    racha, hasta, cuando = 0, None, None
    for r in sorted((r for r in rows if r.get("fecha") == today), key=lambda r: r.get("hora", "")):
        legs = {x.strip() for x in str(r.get("opcion") or "").split("/") if x.strip()}
        if legs and (legs <= robot or legs <= old):
            continue
        pnl = r.get("pnl") or 0
        if pnl > 0:
            racha = 0
        elif pnl < 0:
            racha += 1
            if racha >= LOSSES:
                try:
                    t = datetime.strptime(today + " " + r["hora"][:8], "%Y-%m-%d %H:%M:%S").replace(tzinfo=now.tzinfo)
                except (KeyError, ValueError):
                    t = now
                hasta, cuando, racha = t + timedelta(minutes=MINUTES), t, 0
    activa = hasta is not None and now < hasta
    return {"activa": activa, "hasta": hasta, "desde": cuando, "racha": racha,
            "faltan": int((hasta - now).total_seconds()) if activa else 0}


def estado(live, now=None):
    """Estado de la pausa para la cuenta indicada (True = tu real, "H" = cuenta 2). Papel: nunca hay pausa."""
    now = now or datetime.now()   # las horas del registro son las de tu Mac (Nueva York)
    if not live:
        return {"activa": False, "faltan": 0, "racha": 0, "aplica": False}
    try:
        rows = reportes.load_rows(BASE, "manual", "H" if live == "H" else True)
    except Exception:  # noqa: BLE001
        rows = []
    st = compute(rows, now, _robot_occs(), _old_occs("H" if live == "H" else True, now.strftime("%Y-%m-%d")))
    return {"activa": st["activa"], "faltan": st["faltan"], "racha": st["racha"], "aplica": True,
            "hasta": st["hasta"].strftime("%H:%M") if st["hasta"] else None, "perdidas": LOSSES, "minutos": MINUTES}


def mensaje(st):
    m, s = divmod(max(0, st["faltan"]), 60)
    return (f"⏸ Pausa activa después de {LOSSES} pérdidas seguidas: faltan {m}:{s:02d} min (hasta las {st['hasta']}). "
            "Mientras tanto puedes cerrar posiciones y mover stops, pero no abrir nuevas.")


def loop(notify):
    """Avisa (Mac / Telegram) cuando empieza y cuando termina una pausa. Una sola vez por pausa, aunque reinicies."""
    try:
        with open(NOTIF_FILE, encoding="utf-8") as f:
            seen = json.load(f)
    except (OSError, ValueError):
        seen = {}
    while True:
        try:
            for live, name in ((True, "real"), ("H", "cuenta 2")):
                st = estado(live)
                if not st.get("hasta"):
                    continue
                k = f"{name}|{datetime.now().strftime('%Y-%m-%d')}|{st['hasta']}"
                if st["activa"] and seen.get(k) is None:
                    notify("⏸ Pausa de " + str(MINUTES) + " minutos", f"{LOSSES} pérdidas seguidas en tu cuenta {name}. "
                           f"Hasta las {st['hasta']} no se pueden abrir posiciones nuevas a mano (cerrar sí).")
                    seen[k] = "inicio"
                elif not st["activa"] and seen.get(k) == "inicio":
                    notify("✅ Ya puedes operar otra vez", f"Terminó la pausa en tu cuenta {name}. Respira y sigue tu plan.")
                    seen[k] = "fin"
                else:
                    continue
                seen = {kk: v for kk, v in seen.items() if kk.split("|")[1] >= (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d")}
                with open(NOTIF_FILE, "w", encoding="utf-8") as f:
                    json.dump(seen, f)
        except Exception:  # noqa: BLE001 - nunca tumbar el panel
            pass
        time.sleep(10)
