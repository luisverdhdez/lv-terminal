"""Precios en TIEMPO REAL por streaming de Tradier (como TradingView).

Solo LEE precios; nunca manda ordenes ni cambia nada de la cuenta.
Solo funciona con cuentas REALES (el sandbox de papel no tiene streaming y trae ~15 min de retraso).
Si el streaming falla o no hay permiso, el panel sigue como antes (consulta el precio cada 2 s).
"""
import json
import os
import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

import trading

NY = ZoneInfo("America/New_York")
_L = threading.Lock()
P = {}       # simbolo -> {"last", "bid", "ask", "ts"}
WANT = {}    # simbolo -> ultima vez que una grafica lo pidio
ST = {"on": False, "msg": "apagado", "syms": (), "err": 0, "since": 0}
_STARTED = [False]
MAX_SYMS = 150   # subyacentes + patas de opciones (posiciones, ordenes y constructor)
BARS = {}    # simbolo -> {minuto (hora de NY "desplazada", como las velas): [open, high, low, close, volumen]}


def _bar_tick(sym, px, t, size=0):
    """Arma velas de 1 minuto con los precios del streaming (rellenan lo que Tradier/Yahoo todavia no mandan)."""
    k = trading._shift(int(t)) // 60 * 60
    d = BARS.setdefault(sym, {})
    b = d.get(k)
    if b is None:
        d[k] = [px, px, px, px, size or 0]
        if len(d) > 500:
            for old in sorted(d)[:-400]:
                d.pop(old, None)
    else:
        b[1] = max(b[1], px)
        b[2] = min(b[2], px)
        b[3] = px
        b[4] += size or 0


def bars(sym, after=0):
    """Velas de 1 min del streaming con hora > after (solo de hoy)."""
    with _L:
        d = dict(BARS.get(sym) or {})
    day0 = trading._shift(int(time.time())) // 86400 * 86400
    return [{"time": k, "open": v[0], "high": v[1], "low": v[2], "close": v[3], "volume": v[4]}
            for k, v in sorted(d.items()) if k > after and k >= day0]


def _open_hours(now=None):
    """Lunes a viernes 9:25 a 16:05 NY (fuera de eso no hay operaciones que valga la pena seguir)."""
    n = now or datetime.now(NY)
    m = n.hour * 60 + n.minute
    return n.weekday() < 5 and 565 <= m < 965


def want(syms):
    """Las graficas avisan que simbolos estan viendo (se olvidan a los 30 s sin pedirlos)."""
    t = time.time()
    with _L:
        for s in syms:
            if s and not s.startswith("/"):
                WANT[s] = t


def price(sym, max_age=3.0):
    with _L:
        p = P.get(sym)
        return p["last"] if p and p.get("last") and time.time() - p["ts"] <= max_age else None


def quote(sym):
    """(bid, ask) del streaming si ese simbolo esta conectado y ya llego su cotizacion en esta conexion; si no, None.
    Tradier solo manda la cotizacion cuando CAMBIA: mientras siga conectado, la ultima sigue siendo la buena."""
    with _L:
        p = P.get(sym)
        if not p or not ST.get("on") or sym not in ST.get("syms", ()) or p.get("qts", 0) < ST.get("since", 0):
            return None
        b, a = p.get("bid"), p.get("ask")
        return (b, a) if b is not None and a is not None and a > 0 else None


def quotes(syms):
    want(syms)
    out = {}
    for s_ in syms:
        q = quote(s_)
        if q:
            out[s_] = q
    return out


def _need_reconnect(syms):
    act, cur = set(_active()), set(syms)
    if act - cur:                     # hay simbolos nuevos que seguir
        return True
    return bool(cur - act) and time.time() - ST.get("since", 0) > 60   # sobran: se limpian como maximo cada minuto


def status():
    with _L:
        return dict(ST, syms=list(ST["syms"]))


def _active():
    t = time.time()
    with _L:
        for s in [s for s, v in WANT.items() if t - v > 30]:
            del WANT[s]
        return tuple(sorted(sorted(WANT, key=lambda x: (len(x) > 8, x))[:MAX_SYMS]))   # primero los subyacentes, luego opciones


_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stream_estado.json")
_LAST_W = [0.0]


def _save(force=False):
    """Deja el estado en stream_estado.json para poder revisar si el streaming funciona (sin datos privados)."""
    if not force and time.time() - _LAST_W[0] < 10:
        return
    _LAST_W[0] = time.time()
    try:
        with _L:
            d = dict(ST, syms=list(ST["syms"]), hora=datetime.now(NY).strftime("%H:%M:%S"),
                     precios={k: {"last": v["last"], "hace_seg": round(time.time() - v["ts"], 1) if v["ts"] else None}
                              for k, v in P.items()})
        with open(_FILE, "w") as f:
            json.dump(d, f, indent=1)
    except OSError:
        pass


def _set(**kw):
    with _L:
        ch = any(ST.get(k) != v for k, v in kw.items())
        ST.update(kw)
    _save(force=ch)


def handle_line(line, now=None):
    """Procesa un mensaje de Tradier (una linea JSON). Devuelve el simbolo si cambio su precio."""
    try:
        m = json.loads(line)
    except (ValueError, TypeError):
        return None
    if not isinstance(m, dict):
        return None
    sym, typ = m.get("symbol"), m.get("type")
    if not sym:
        return None
    t = now or time.time()
    with _L:
        p = P.setdefault(sym, {"last": None, "bid": None, "ask": None, "ts": 0})
        if typ in ("trade", "timesale", "tradex"):
            px = trading._num(m.get("price")) or trading._num(m.get("last"))
            if px and px > 0 and not m.get("cancel"):
                p["last"], p["ts"] = px, t
                _bar_tick(sym, px, t, trading._num(m.get("size")) or 0)
                return sym
        elif typ == "quote":
            b, a = trading._num(m.get("bid")), trading._num(m.get("ask"))
            if b is not None:
                p["bid"] = b
            if a is not None:
                p["ask"] = a
            if b is not None or a is not None:
                p["qts"] = t
        elif typ == "summary":
            px = trading._num(m.get("last")) or trading._num(m.get("close"))
            if px and px > 0 and not p["last"]:
                p["last"], p["ts"] = px, t
                return sym
    return None


def _session(base, tok):
    r = requests.post(base + "/markets/events/session", timeout=10,
                      headers={"Authorization": f"Bearer {tok}", "Accept": "application/json"})
    if r.status_code == 401:
        raise RuntimeError("Tradier rechazó el token para streaming (401)")
    if r.status_code >= 400:
        raise RuntimeError(f"Tradier no dio permiso de streaming ({r.status_code})")
    s = (r.json() or {}).get("stream") or {}
    if not s.get("sessionid"):
        raise RuntimeError("Tradier no devolvió sesión de streaming")
    return s.get("url") or "https://stream.tradier.com/v1/markets/events", s["sessionid"]


def loop(env_fn):
    if _STARTED[0]:
        return
    _STARTED[0] = True
    while True:
        try:
            live = trading.MODE.get("live")
            syms = _active()
            if not live:
                _set(on=False, msg="papel: sin streaming (Tradier solo lo da en cuentas reales)", syms=())
                time.sleep(2)
                continue
            if not syms or not _open_hours():
                _set(on=False, msg="en espera (mercado cerrado o sin gráficas abiertas)", syms=())
                time.sleep(2)
                continue
            base, tok, acct = trading.creds(env_fn(), live)
            if not tok:
                _set(on=False, msg="sin token de la cuenta real", syms=())
                time.sleep(5)
                continue
            url, sid = _session(base, tok)
            r = requests.post(url, data={"sessionid": sid, "symbols": ",".join(syms), "linebreak": "true"},
                              headers={"Accept": "application/json"}, stream=True, timeout=(10, 20))
            if r.status_code >= 400:
                raise RuntimeError(f"streaming rechazado por Tradier ({r.status_code}): {(r.text or '')[:120]}")
            _set(on=True, msg="conectado", syms=syms, err=0, since=time.time())
            for line in r.iter_lines(chunk_size=1):
                if line:
                    handle_line(line)
                    ST["n"] = ST.get("n", 0) + 1
                _save()
                # se reconecta si cambian los simbolos, la cuenta o termina el horario
                if _need_reconnect(syms) or trading.MODE.get("live") != live or not _open_hours():
                    break
            r.close()
            _set(on=False, msg="reconectando")
        except Exception as e:   # noqa: BLE001 - nunca tumbar el panel; se reintenta con espera creciente
            with _L:
                ST["err"] = min(ST.get("err", 0) + 1, 6)
                ST.update(on=False, msg=str(e)[:160])
                w = 2 ** ST["err"]
            _save(force=True)
            time.sleep(w)
