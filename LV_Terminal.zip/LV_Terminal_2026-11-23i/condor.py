"""
Modo sombra: IRON CONDOR semanal en SPX (opciones SPXW, se liquidan en efectivo al cierre del viernes).
- De lunes a miercoles, a partir de las 10:00 ET, registra un condor nuevo con vencimiento el viernes de esa semana
  para cada delta de venta (0.10, 0.15 y 0.20), con alas de 10 puntos.
- Precios reales de Tradier (necesita el token REAL; con papel los precios de SPX llegan con atraso).
- Sigue el costo de cerrar cada 5 min hasta el vencimiento y al final calcula que habria dado cada regla de salida.
- NUNCA envia ordenes: la conexion se crea con dry=True y solo hace consultas GET.
Precios: entrada y salida a precio MEDIO (lo realista en SPX es algo peor; tambien se guarda el credito "natural").
"""
import json
import os
import threading
import time
from datetime import datetime, date, time as dtime, timedelta

import tradier_bot as tb

ET = tb.ET
BASE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(BASE, "condor.json")
LOCK = threading.RLock()
STATE = {"err": None, "last": None, "msg": None}
SYM = "SPX"
DELTAS = (0.10, 0.15, 0.20)
WIDTH = 10.0
ENTRY_FROM, ENTRY_TO = dtime(10, 0), dtime(10, 45)
ENTRY_DAYS = (0, 1, 2)          # lunes, martes, miercoles
POLL_SEC = 300
RULES = [("vence", "Dejarlo hasta el vencimiento"),
         ("tp50", "Cerrar al ganar 50% del crédito"),
         ("stop2", "Cerrar si pierde 2× el crédito"),
         ("tp50_stop2", "50% de ganancia o pérdida de 2× (lo que llegue antes)"),
         ("tp50_stop2_dia", "Lo anterior + cerrar el día antes del vencimiento")]


def _f(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {"ent": []}
    except (OSError, ValueError):
        return {"ent": []}


def _save(d):
    d["ent"] = d["ent"][-300:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


R_RATE = 0.04   # tasa libre de riesgo aproximada para la delta


def years_to(exp, now, am=False):
    """Años hasta el vencimiento: 16:00 ET del dia de vencimiento (9:30 si es mensual AM). Minimo 15 minutos."""
    e = datetime.combine(date.fromisoformat(exp), dtime(9, 30) if am else dtime(16, 0), tzinfo=ET)
    return max((e - now).total_seconds(), 900) / (365.0 * 86400)


def bs_delta(S, K, T, iv, call):
    """Delta de Black-Scholes con el precio de AHORA (la de Tradier puede venir de hace una hora)."""
    import math
    if not (S and K and T and iv) or S <= 0 or K <= 0 or iv <= 0:
        return None
    d1 = (math.log(S / K) + (R_RATE + iv * iv / 2) * T) / (iv * math.sqrt(T))
    n = 0.5 * (1 + math.erf(d1 / math.sqrt(2)))
    return n if call else n - 1


def _bs_price(S, K, T, v, call):
    import math
    if v <= 0 or T <= 0:
        return max(0.0, (S - K) if call else (K - S))
    sv = v * math.sqrt(T)
    d1 = (math.log(S / K) + (R_RATE + v * v / 2) * T) / sv
    d2 = d1 - sv
    N = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))
    df = math.exp(-R_RATE * T)
    return S * N(d1) - K * df * N(d2) if call else K * df * N(-d2) - S * N(-d1)


def implied_vol(o, spot, T):
    """Volatilidad implicita a partir del precio medio de AHORA (la de Tradier se actualiza cada hora)."""
    b, a, K = _f(o.get("bid")), _f(o.get("ask")), _f(o.get("strike"))
    if b is None or a is None or not K or not spot or not T or a <= 0 or b < 0 or a < b:
        return None
    call = o.get("option_type") == "call"
    mid = (a + b) / 2
    if mid <= max(0.0, (spot - K) if call else (K - spot)) + 0.02:
        return None
    lo, hi = 0.005, 5.0
    if _bs_price(spot, K, T, hi, call) < mid:
        return None
    for _ in range(50):
        m = (lo + hi) / 2
        if _bs_price(spot, K, T, m, call) > mid:
            hi = m
        else:
            lo = m
    return (lo + hi) / 2


def live_delta(o, spot, T):
    """Delta con el precio de AHORA y la IV sacada del precio de AHORA; si no se puede, con la IV de Tradier; si no, la de Tradier."""
    g = o.get("greeks") or {}
    iv = implied_vol(o, spot, T) or _f(g.get("mid_iv")) or _f(g.get("smv_vol"))
    if iv and iv > 0.01 and T:
        return bs_delta(spot, _f(o.get("strike")), T, iv, o.get("option_type") == "call")
    return _f(g.get("delta"))


def _mid(o):
    b, a = _f(o.get("bid")), _f(o.get("ask"))
    if b is None or a is None or a <= 0:
        return None
    return (b + a) / 2


def friday_exp(api, today):
    """Vencimiento SPXW del viernes de esta semana (si el viernes es feriado, el ultimo vencimiento antes)."""
    fri = today + timedelta(days=4 - today.weekday())
    j = api._req("GET", "/markets/options/expirations", params={"symbol": SYM, "includeAllRoots": "true"})
    ds = [d for d in tb.as_list((j.get("expirations") or {}).get("date")) if isinstance(d, str)]
    ok = [d for d in ds if today.isoformat() < d <= fri.isoformat()]
    return max(ok) if ok else None


def _weekly(chain):
    """Solo la raiz SPXW (las mensuales SPX vencen a la apertura y se liquidan distinto)."""
    w = [o for o in chain if (o.get("root_symbol") or str(o.get("symbol", ""))[:4]) == "SPXW"]
    return w or chain


def pick(chain, spot, delta, T=None, avoid=None, max_shift=6):
    """avoid = {"put": set(strikes), "call": set(strikes)} ya abiertos: ninguna pata nueva cae en esos strikes;
    si chocan, mueve ese lado hacia afuera (mas lejos del precio, mas seguro) hasta max_shift strikes."""
    by = {"put": {}, "call": {}}
    for o in chain:
        t, k = o.get("option_type"), _f(o.get("strike"))
        if t in by and k is not None:
            by[t][k] = o

    def dl(o):
        return live_delta(o, spot, T) if T else _f((o.get("greeks") or {}).get("delta"))
    sp = [o for k, o in by["put"].items() if k < spot and dl(o) is not None and _f(o.get("bid")) and _f(o.get("bid")) > 0]
    sc = [o for k, o in by["call"].items() if k > spot and dl(o) is not None and _f(o.get("bid")) and _f(o.get("bid")) > 0]
    if not sp or not sc:
        return None
    sp0 = min(sp, key=lambda o: abs(abs(dl(o)) - delta))
    sc0 = min(sc, key=lambda o: abs(abs(dl(o)) - delta))
    av = avoid or {}
    if avoid is None:
        max_shift = 0   # sin lista de strikes ocupados: igual que antes
    def side(t, s0, cands, sgn):
        """sgn=-1 puts (hacia abajo), +1 calls (hacia arriba)"""
        bad = av.get(t) or set()
        out = sorted([o for o in cands if (_f(o["strike"]) - _f(s0["strike"])) * sgn >= 0], key=lambda o: abs(_f(o["strike"]) - _f(s0["strike"])))
        for o in out[:max_shift + 1]:
            k = _f(o["strike"]); kl = k + sgn * WIDTH
            if k in bad or kl in bad:
                continue
            if by[t].get(kl):
                return o, by[t][kl], k != _f(s0["strike"])
        return None, None, False
    sp, lp, mp = side("put", sp0, sp, -1)
    sc, lc, mc = side("call", sc0, sc, 1)
    if not sp or not sc:
        return None
    kp, kc = _f(sp["strike"]), _f(sc["strike"])
    legs = {"sp": sp, "lp": lp, "sc": sc, "lc": lc}
    mids = {k: _mid(o) for k, o in legs.items()}
    if None in mids.values():
        return None
    cr_mid = mids["sp"] + mids["sc"] - mids["lp"] - mids["lc"]
    cr_nat = _f(sp["bid"]) + _f(sc["bid"]) - _f(lp["ask"]) - _f(lc["ask"])
    if cr_mid <= 0.05:
        return None
    def iv(o):   # volatilidad implicita de Tradier (precio medio); si falta, la de su modelo
        g = o.get("greeks") or {}
        v = _f(g.get("mid_iv")) or _f(g.get("smv_vol"))
        return round(v * 100, 1) if v else None
    return {"kp": kp, "kc": kc, "kpl": kp - WIDTH, "kcl": kc + WIDTH, "ivp": iv(sp), "ivc": iv(sc),
            "occ": {k: o["symbol"] for k, o in legs.items()},
            "dp": round(abs(dl(sp)), 3), "dc": round(abs(dl(sc)), 3),
            "credit": round(cr_mid, 2), "credit_nat": round(cr_nat, 2),
            "movido": [x for x, m in (("put", mp), ("call", mc)) if m]}


def _spot(api):
    q = api._req("GET", "/markets/quotes", params={"symbols": SYM})
    return _f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))


def enter(api, now):
    today = now.date()
    exp = friday_exp(api, today)
    if not exp:
        STATE["msg"] = "Sin vencimiento SPXW esta semana"
        return 0
    spot = _spot(api)
    if spot is None:
        return 0
    chain = _weekly(api.chain(SYM, exp))
    vix = None
    try:   # VIX al momento de entrar (si falla, se registra sin VIX)
        q = api._req("GET", "/markets/quotes", params={"symbols": "VIX"})
        vix = _f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))
    except Exception:
        pass
    n = 0
    with LOCK:
        d = _load()
        have = {(e["fecha"], e["delta"]) for e in d["ent"]}
        for dt in DELTAS:
            if (today.isoformat(), dt) in have:
                continue
            p = pick(chain, spot, dt, years_to(exp, now))
            if not p:
                continue
            d["ent"].append(dict(p, fecha=today.isoformat(), hora=now.strftime("%H:%M"), dia=today.weekday(), delta=dt,
                                 exp=exp, spot=round(spot, 2), vix=vix, samples=[], done=False, settle=None))
            n += 1
        _save(d)
    return n


def poll(api, now):
    with LOCK:
        d = _load()
    act = [e for e in d["ent"] if not e.get("done") and e["exp"] >= now.date().isoformat()]
    if not act:
        return
    occs = sorted({o for e in act for o in e["occ"].values()})
    j = api._req("GET", "/markets/quotes", params={"symbols": ",".join(occs + [SYM])})
    qs = {x["symbol"]: x for x in tb.as_list((j.get("quotes") or {}).get("quote")) if isinstance(x, dict) and x.get("symbol")}
    spx = _f((qs.get(SYM) or {}).get("last"))
    t = now.strftime("%Y-%m-%d %H:%M")
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e.get("done") or e["exp"] < now.date().isoformat():
                continue
            q = {k: qs.get(o) or {} for k, o in e["occ"].items()}
            m = {k: _mid(v) for k, v in q.items()}
            mid = None if None in m.values() else round(m["sp"] + m["sc"] - m["lp"] - m["lc"], 2)
            try:
                nat = round(_f(q["sp"]["ask"]) + _f(q["sc"]["ask"]) - _f(q["lp"]["bid"]) - _f(q["lc"]["bid"]), 2)
            except TypeError:
                nat = None
            if mid is not None:
                e["samples"].append({"t": t, "spx": spx, "mid": max(0.0, min(WIDTH, mid)), "nat": nat})
        _save(d)
    STATE["last"] = time.time()


def settle_value(e, s):
    """Valor del condor al vencimiento con SPX en `s` (lo que cuesta cerrarlo, de 0 a WIDTH)."""
    put = max(0.0, min(WIDTH, e["kp"] - s))
    call = max(0.0, min(WIDTH, s - e["kc"]))
    return put + call


def settle(api, now):
    """Despues del cierre del dia de vencimiento: precio de cierre de SPX de ese dia."""
    with LOCK:
        d = _load()
    pend = [e for e in d["ent"] if not e.get("done") and (e["exp"] < now.date().isoformat() or
            (e["exp"] == now.date().isoformat() and now.time() >= dtime(16, 10)))]
    if not pend:
        return
    closes = {}
    for ex in sorted({e["exp"] for e in pend}):
        j = api._req("GET", "/markets/history", params={"symbol": SYM, "interval": "daily", "start": ex, "end": ex})
        day = tb.as_list(((j.get("history") or {}) if isinstance(j.get("history"), dict) else {}).get("day"))
        c = _f(day[0].get("close")) if day else None
        if c is None and ex == now.date().isoformat():
            c = _spot(api)   # respaldo: ultimo precio despues del cierre
        if c is not None:
            closes[ex] = c
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if not e.get("done") and e["exp"] in closes and any(x["exp"] == e["exp"] for x in pend):
                e["settle"] = {"spx": closes[e["exp"]], "valor": round(settle_value(e, closes[e["exp"]]), 2)}
                e["done"] = True
        _save(d)


def loop(get_env):
    last_poll = 0.0
    while True:
        try:
            now = datetime.now(ET)
            tok = (get_env() or {}).get("TRADIER_LIVE_TOKEN")
            if tok and now.weekday() < 5:
                api = tb.Tradier(tok, "", "live", True)   # dry=True: nunca envia ordenes
                try:
                    if now.weekday() in ENTRY_DAYS and ENTRY_FROM <= now.time() <= ENTRY_TO:
                        enter(api, now)
                    if dtime(9, 30) <= now.time() <= dtime(16, 15) and time.time() - last_poll >= POLL_SEC:
                        last_poll = time.time()
                        poll(api, now)
                    if now.time() >= dtime(16, 10) or now.time() <= dtime(9, 0):
                        settle(api, now)
                    STATE["err"] = None
                except Exception as e:  # nunca tumbar el panel
                    STATE["err"] = e.__class__.__name__
        except Exception:
            pass
        time.sleep(60)


# ───────────── resultados ─────────────
def _prev_day_close(e):
    """Ultima muestra (>= 15:30) del ultimo dia de mercado antes del vencimiento."""
    days = sorted({s["t"][:10] for s in e["samples"] if s["t"][:10] < e["exp"]})
    if not days:
        return None
    last = days[-1]
    c = [s for s in e["samples"] if s["t"][:10] == last and s["t"][11:] >= "15:30"]
    return c[-1]["mid"] if c else None


def result(e, rule):
    """Ganancia en dolares por condor (1 contrato de cada pata) con esa regla. None si aun no se sabe."""
    cr = e["credit"]
    smp = e["samples"]
    if rule.endswith("_dia"):
        smp = [s for s in smp if s["t"][:10] < e["exp"]]
    tp = "tp50" in rule
    st = "stop2" in rule
    for s in smp:
        if tp and s["mid"] <= cr * 0.5:
            return round((cr - s["mid"]) * 100, 0)
        if st and s["mid"] >= cr * 3:
            return round((cr - s["mid"]) * 100, 0)
    if rule.endswith("_dia") and e.get("done"):
        v = _prev_day_close(e)
        if v is not None:
            return round((cr - v) * 100, 0)
    if not e.get("done") or not e.get("settle"):
        return None
    return round((cr - e["settle"]["valor"]) * 100, 0)


def _now_pnl(e):
    if not e["samples"]:
        return None
    return round((e["credit"] - e["samples"][-1]["mid"]) * 100, 0)


def summary():
    d = _load()
    ents = d["ent"]
    tabla = []
    for dt in DELTAS:
        es = [e for e in ents if e["delta"] == dt]
        cr = [e["credit"] for e in es]
        for k, nom in RULES:
            v = [x for x in (result(e, k) for e in es) if x is not None]
            tabla.append({"delta": dt, "regla": k, "nombre": nom, "n": len(v), "abiertos": sum(1 for e in es if not e.get("done")),
                          "credito": round(sum(cr) / len(cr) * 100) if cr else None,
                          "avg": round(sum(v) / len(v)) if v else None,
                          "win": round(100 * sum(1 for x in v if x > 0) / len(v)) if v else None,
                          "peor": min(v) if v else None, "total": sum(v) if v else None})
    terminados = sum(1 for e in ents if e.get("done"))
    abiertos = []
    for e in ents[::-1]:
        if e.get("done") and len(abiertos) >= 12:
            break
        abiertos.append({"fecha": e["fecha"], "hora": e["hora"], "delta": e["delta"], "exp": e["exp"],
                         "put": f'{e["kp"]:g}/{e["kpl"]:g}', "call": f'{e["kc"]:g}/{e["kcl"]:g}',
                         "credito": round(e["credit"] * 100), "credito_nat": round(e["credit_nat"] * 100),
                         "riesgo": round((WIDTH - e["credit"]) * 100), "spx0": e["spot"],
                         "vix": e.get("vix"), "ivp": e.get("ivp"), "ivc": e.get("ivc"),
                         "spx": (e["samples"][-1]["spx"] if e["samples"] else None),
                         "pnl": _now_pnl(e) if not e.get("done") else result(e, "vence"),
                         "done": bool(e.get("done")), "settle": e.get("settle")})
    dias_ent = sorted({e["fecha"] for e in ents})
    return {"n": len(ents), "terminados": terminados, "dias": len(dias_ent), "semanas": len({date.fromisoformat(x).isocalendar()[1] for x in dias_ent}),
            "tabla": tabla, "lista": abiertos[:15], "err": STATE["err"], "last": STATE["last"] or (os.path.getmtime(FILE) if os.path.exists(FILE) else None),
            "msg": STATE["msg"]}
