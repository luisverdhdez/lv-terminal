"""
Modo sombra: IRON CONDOR MENSUAL en SPX, variante A2 de la simulacion hacia atras (backtest_condor.py).
- Opciones MENSUALES de raiz SPX (tercer viernes, se liquidan a la APERTURA del viernes; se operan hasta el jueves).
- Entra UNA vez por vencimiento: el primer dia habil con 30 dias o menos al vencimiento, de 10:00 a 10:45 ET.
- Ventas en delta 0.10 (put y call), alas de 25 puntos.
- Regla A2: STOP si cerrarlo cuesta 2x el credito (perdida = credito); si no, CERRAR EL JUEVES (ultimo dia de operacion)
  a las 15:30 o despues. Nunca llega a la liquidacion AM.
- Para comparar tambien calcula: cerrar el jueves sin stop, stop y aguantar a la liquidacion AM, y aguantar a la liquidacion.
- Precios reales de Tradier (token REAL) a precio MEDIO cada 5 min. NUNCA envia ordenes (dry=True, solo consultas GET).
"""
import json
import os
import threading
import time
from datetime import datetime, date, time as dtime, timedelta

import tradier_bot as tb
import condor as cw   # reutiliza utilidades del condor semanal

ET = tb.ET
BASE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(BASE, "condor_mensual.json")
LOCK = threading.RLock()
STATE = {"err": None, "last": None, "msg": None}
SYM, ROOT = "SPX", "SPX"
DELTA, WIDTH, DTE_MAX, DTE_MIN = 0.10, 25.0, 30, 23   # entra a 30 dias (si el panel estuvo apagado, hasta 23)
ENTRY_FROM, ENTRY_TO = dtime(10, 0), dtime(10, 45)
POLL_SEC = 300
STOP_X = 2.0          # stop: costo de cerrar >= 2 x credito
RULES = [("a2", "A2 · stop 2× o cerrar el jueves"),
         ("jueves", "Cerrar el jueves (sin stop)"),
         ("stop_am", "Stop 2× o aguantar a la liquidación AM"),
         ("am", "Aguantar a la liquidación AM")]
_f, _mid = cw._f, cw._mid


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {"ent": []}
    except (OSError, ValueError):
        return {"ent": []}


def _save(d):
    d["ent"] = d["ent"][-120:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def third_friday(y, m):
    d = date(y, m, 15)
    while d.weekday() != 4:
        d += timedelta(days=1)
    return d


def monthlies(api, today):
    """Proximos vencimientos mensuales (tercer viernes; si es feriado, Tradier lo lista el jueves)."""
    j = api._req("GET", "/markets/options/expirations", params={"symbol": SYM, "includeAllRoots": "true"})
    ds = {d for d in tb.as_list((j.get("expirations") or {}).get("date")) if isinstance(d, str)}
    out = []
    for k in range(3):
        y, m = today.year + (today.month - 1 + k) // 12, (today.month - 1 + k) % 12 + 1
        f = third_friday(y, m)
        for cand in (f, f - timedelta(days=1)):
            if cand.isoformat() in ds and cand > today:
                out.append(cand.isoformat())
                break
    return out


def pick(chain, spot, T=None):
    """Cortas en delta 0.10 y largas 25 puntos mas lejos, solo raiz SPX (mensual AM)."""
    ch = [o for o in chain if (o.get("root_symbol") or "") == ROOT]
    by = {"put": {}, "call": {}}
    for o in ch:
        t, k = o.get("option_type"), _f(o.get("strike"))
        if t in by and k is not None:
            by[t][k] = o
    dl = lambda o: cw.live_delta(o, spot, T) if T else _f((o.get("greeks") or {}).get("delta"))
    sp = [o for k, o in by["put"].items() if k < spot and dl(o) is not None and (_f(o.get("bid")) or 0) > 0]
    sc = [o for k, o in by["call"].items() if k > spot and dl(o) is not None and (_f(o.get("bid")) or 0) > 0]
    if not sp or not sc:
        return None
    sp = min(sp, key=lambda o: abs(abs(dl(o)) - DELTA))
    sc = min(sc, key=lambda o: abs(abs(dl(o)) - DELTA))
    kp, kc = _f(sp["strike"]), _f(sc["strike"])
    lp, lc = by["put"].get(kp - WIDTH), by["call"].get(kc + WIDTH)
    if not lp or not lc:
        return None
    legs = {"sp": sp, "lp": lp, "sc": sc, "lc": lc}
    mids = {k: _mid(o) for k, o in legs.items()}
    if None in mids.values():
        return None
    cr = mids["sp"] + mids["sc"] - mids["lp"] - mids["lc"]
    nat = _f(sp["bid"]) + _f(sc["bid"]) - _f(lp["ask"]) - _f(lc["ask"])
    if cr <= 0.2:
        return None

    def iv(o):
        g = o.get("greeks") or {}
        v = _f(g.get("mid_iv")) or _f(g.get("smv_vol"))
        return round(v * 100, 1) if v else None
    return {"kp": kp, "kc": kc, "kpl": kp - WIDTH, "kcl": kc + WIDTH, "occ": {k: o["symbol"] for k, o in legs.items()},
            "dp": round(abs(dl(sp)), 3), "dc": round(abs(dl(sc)), 3), "ivp": iv(sp), "ivc": iv(sc),
            "credit": round(cr, 2), "credit_nat": round(nat, 2)}


def enter(api, now):
    today = now.date()
    exps = monthlies(api, today)
    if not exps:
        STATE["msg"] = "No encontré los próximos vencimientos mensuales"
        return 0
    ok = [x for x in exps if DTE_MIN <= (date.fromisoformat(x) - today).days <= DTE_MAX]
    if not ok:
        fut = [x for x in exps if (date.fromisoformat(x) - today).days > DTE_MAX]
        if fut:
            STATE["msg"] = f"Próxima entrada: {(date.fromisoformat(fut[0]) - timedelta(days=DTE_MAX)).isoformat()} (vencimiento {fut[0]})"
        return 0
    exp = ok[0]
    dte = (date.fromisoformat(exp) - today).days
    with LOCK:
        if any(e["exp"] == exp for e in _load()["ent"]):
            STATE["msg"] = f"Condor del {exp} ya registrado"
            return 0
    spot = cw._spot(api)
    if spot is None:
        return 0
    p = pick(api.chain(SYM, exp), spot, cw.years_to(exp, now, am=True))
    if not p:
        STATE["msg"] = "La cadena no tenía strikes válidos; reintento en un minuto"
        return 0
    vix = None
    try:
        q = api._req("GET", "/markets/quotes", params={"symbols": "VIX"})
        vix = _f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))
    except Exception:
        pass
    with LOCK:
        d = _load()
        if any(e["exp"] == exp for e in d["ent"]):
            return 0
        d["ent"].append(dict(p, fecha=today.isoformat(), hora=now.strftime("%H:%M"), exp=exp, dte=dte, spot=round(spot, 2),
                             vix=vix, samples=[], done=False, settle=None))
        _save(d)
    STATE["msg"] = f"Condor del {exp} registrado"
    return 1


def poll(api, now):
    with LOCK:
        d = _load()
    act = [e for e in d["ent"] if not e.get("done") and e["exp"] > now.date().isoformat()]
    if not act:
        return
    occs = sorted({o for e in act for o in e["occ"].values()})
    j = api._req("GET", "/markets/quotes", params={"symbols": ",".join(occs + [SYM])})
    qs = {x["symbol"]: x for x in tb.as_list((j.get("quotes") or {}).get("quote")) if isinstance(x, dict) and x.get("symbol")}
    spx = _f((qs.get(SYM) or {}).get("last"))
    t = now.strftime("%Y-%m-%d %H:%M")
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e.get("done") or e["exp"] <= now.date().isoformat():
                continue
            q = {k: qs.get(o) or {} for k, o in e["occ"].items()}
            m = {k: _mid(v) for k, v in q.items()}
            mid = None if None in m.values() else round(m["sp"] + m["sc"] - m["lp"] - m["lc"], 2)
            try:
                nat = round(_f(q["sp"]["ask"]) + _f(q["sc"]["ask"]) - _f(q["lp"]["bid"]) - _f(q["lc"]["bid"]), 2)
            except TypeError:
                nat = None
            if mid is not None:
                e["samples"].append({"t": t, "spx": spx, "mid": max(0.0, min(WIDTH, mid)), "nat": nat})
        _save(d)
    STATE["last"] = time.time()


def settle_value(e, s):
    return max(0.0, min(WIDTH, e["kp"] - s)) + max(0.0, min(WIDTH, s - e["kc"]))


def settle(api, now):
    """Liquidacion AM: se aproxima con la APERTURA del SPX el dia del vencimiento (el valor oficial SET puede diferir)."""
    with LOCK:
        d = _load()
    pend = [e for e in d["ent"] if not e.get("done") and (e["exp"] < now.date().isoformat() or
            (e["exp"] == now.date().isoformat() and now.time() >= dtime(10, 30)))]
    for ex in sorted({e["exp"] for e in pend}):
        j = api._req("GET", "/markets/history", params={"symbol": SYM, "interval": "daily", "start": ex, "end": ex})
        h = j.get("history") if isinstance(j.get("history"), dict) else {}
        day = tb.as_list(h.get("day"))
        o = _f(day[0].get("open")) if day else None
        if o is None:
            continue
        with LOCK:
            d = _load()
            for e in d["ent"]:
                if not e.get("done") and e["exp"] == ex:
                    e["settle"] = {"spx": o, "valor": round(settle_value(e, o), 2)}
                    e["done"] = True
            _save(d)


def loop(get_env):
    last_poll = 0.0
    while True:
        try:
            now = datetime.now(ET)
            tok = (get_env() or {}).get("TRADIER_LIVE_TOKEN")
            if tok and now.weekday() < 5:
                api = tb.Tradier(tok, "", "live", True)   # dry=True: nunca envia ordenes
                try:
                    if ENTRY_FROM <= now.time() <= ENTRY_TO:
                        enter(api, now)
                    if dtime(9, 30) <= now.time() <= dtime(16, 15) and time.time() - last_poll >= POLL_SEC:
                        last_poll = time.time()
                        poll(api, now)
                    if now.time() >= dtime(10, 30):
                        settle(api, now)
                    STATE["err"] = None
                except Exception as ex:
                    STATE["err"] = ex.__class__.__name__
        except Exception:
            pass
        time.sleep(60)


# ───────────── resultados ─────────────
def _thursday(e):
    """Ultima muestra (>= 15:30) del ultimo dia de operacion antes del vencimiento."""
    days = sorted({s["t"][:10] for s in e["samples"] if s["t"][:10] < e["exp"]})
    if not days:
        return None
    c = [s for s in e["samples"] if s["t"][:10] == days[-1] and s["t"][11:] >= "15:30"]
    return c[-1]["mid"] if c else None


def result(e, rule):
    """Dolares por condor (1 contrato por pata) a precio medio. None si aun no se sabe."""
    cr = e["credit"]
    if rule in ("a2", "stop_am"):
        for s in e["samples"]:
            if s["mid"] >= cr * STOP_X:
                return round((cr - s["mid"]) * 100)
    if rule in ("a2", "jueves"):
        if not e.get("done"):
            return None
        v = _thursday(e)
        return round((cr - v) * 100) if v is not None else None
    if e.get("done") and e.get("settle"):
        return round((cr - e["settle"]["valor"]) * 100)
    return None


def _now_pnl(e):
    return round((e["credit"] - e["samples"][-1]["mid"]) * 100) if e["samples"] else None


def summary():
    d = _load()
    ents = d["ent"]
    tabla = []
    for k, nom in RULES:
        v = [x for x in (result(e, k) for e in ents) if x is not None]
        tabla.append({"regla": k, "nombre": nom, "n": len(v), "abiertos": sum(1 for e in ents if not e.get("done")),
                      "avg": round(sum(v) / len(v)) if v else None, "win": round(100 * sum(1 for x in v if x > 0) / len(v)) if v else None,
                      "peor": min(v) if v else None, "total": sum(v) if v else None})
    lista = []
    for e in ents[::-1][:12]:
        stop = next((s for s in e["samples"] if s["mid"] >= e["credit"] * STOP_X), None)
        lista.append({"fecha": e["fecha"], "hora": e["hora"], "exp": e["exp"], "dte": e.get("dte"),
                      "put": f'{e["kp"]:g}/{e["kpl"]:g}', "call": f'{e["kc"]:g}/{e["kcl"]:g}',
                      "credito": round(e["credit"] * 100), "credito_nat": round(e["credit_nat"] * 100),
                      "riesgo": round((WIDTH - e["credit"]) * 100), "spx0": e["spot"], "vix": e.get("vix"),
                      "ivp": e.get("ivp"), "ivc": e.get("ivc"), "spx": e["samples"][-1]["spx"] if e["samples"] else None,
                      "stop": stop["t"] if stop else None,
                      "pnl": result(e, "a2") if (e.get("done") or stop) else _now_pnl(e), "done": bool(e.get("done")),
                      "settle": e.get("settle")})
    return {"n": len(ents), "terminados": sum(1 for e in ents if e.get("done")), "tabla": tabla, "lista": lista,
            "err": STATE["err"], "msg": STATE["msg"],
            "last": STATE["last"] or (os.path.getmtime(FILE) if os.path.exists(FILE) else None)}
