"""
Market → Economía: indicadores clave de EE. UU. y calendario de publicaciones, con datos oficiales de FRED
(Reserva Federal de St. Louis). Necesita FRED_API_KEY en ~/.tradier_env (gratis; cada usuario la suya).
Las reuniones de la Fed (FOMC) vienen de la pagina oficial de la Fed (2027 = tentativas hasta que se confirmen).
"""
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

import requests

API = "https://api.stlouisfed.org/fred"
_C, _L = {}, threading.RLock()

# (serie, nombre, como mostrarla, unidad, "sube es bueno"(True/False/None), nota)
#   como: "nivel" = valor tal cual · "yoy" = % contra hace 12 meses · "mom" = % contra el mes anterior · "dif" = cambio contra el anterior
IND = [
    ("CPIAUCSL", "Inflación (CPI)", "yoy", "%", False, "Precios al consumidor, contra hace 1 año"),
    ("CPILFESL", "Inflación subyacente (CPI)", "yoy", "%", False, "Sin alimentos ni energía"),
    ("PCEPILFE", "PCE subyacente", "yoy", "%", False, "La inflación que más mira la Fed"),
    ("UNRATE", "Desempleo", "nivel", "%", False, "Tasa de desempleo"),
    ("PAYEMS", "Nóminas no agrícolas", "dif", "k", True, "Empleos creados en el mes (miles)"),
    ("ICSA", "Solicitudes de desempleo", "nivel", "k", False, "Semanales, nuevas solicitudes"),
    ("A191RL1Q225SBEA", "PIB real", "nivel", "%", True, "Crecimiento trimestral anualizado"),
    ("RSAFS", "Ventas minoristas", "mom", "%", True, "Contra el mes anterior"),
    ("UMCSENT", "Confianza del consumidor", "nivel", "", True, "Universidad de Michigan"),
    ("DFEDTARU", "Tasa de la Fed", "nivel", "%", None, "Límite superior del rango objetivo"),
]
# palabra clave del nombre de la publicacion en FRED -> (nombre en español, hora ET habitual, importancia 1-3)
REL = [
    ("Consumer Price Index", "Inflación (CPI)", "8:30", 3),
    ("Employment Situation", "Empleo (nóminas y desempleo)", "8:30", 3),
    ("Gross Domestic Product", "PIB", "8:30", 3),
    ("Personal Income and Outlays", "Ingreso y gasto personal (PCE)", "8:30", 3),
    ("Producer Price Index", "Precios al productor (PPI)", "8:30", 2),
    ("Advance Monthly Sales for Retail", "Ventas minoristas", "8:30", 2),
    ("Job Openings and Labor Turnover", "Vacantes de empleo (JOLTS)", "10:00", 2),
    ("Unemployment Insurance Weekly Claims", "Solicitudes de desempleo", "8:30", 1),
    ("Industrial Production and Capacity", "Producción industrial", "9:15", 1),
    ("New Residential Construction", "Inicios de vivienda", "8:30", 1),
    ("Surveys of Consumers", "Confianza del consumidor (Michigan)", "10:00", 1),
    ("Durable Goods", "Bienes duraderos", "8:30", 1),
]
# publicacion -> filas del calendario (serie, nombre, como, unidad)   unidad M = millones (la serie viene en miles)
CAL_MAP = [
    ("Consumer Price Index", [("CPIAUCSL", "Inflación CPI (a/a)", "yoy", "%"), ("CPILFESL", "Inflación subyacente CPI (a/a)", "yoy", "%")]),
    ("Employment Situation", [("PAYEMS", "Nóminas no agrícolas", "dif", "k"), ("UNRATE", "Tasa de desempleo", "nivel", "%")]),
    ("Gross Domestic Product", [("A191RL1Q225SBEA", "PIB (trimestral anualizado)", "nivel", "%")]),
    ("Personal Income and Outlays", [("PCEPILFE", "PCE subyacente (a/a)", "yoy", "%")]),
    ("Producer Price Index", [("PPIFIS", "Precios al productor PPI (a/a)", "yoy", "%")]),
    ("Advance Monthly Sales for Retail", [("RSAFS", "Ventas minoristas (m/m)", "mom", "%")]),
    ("Job Openings and Labor Turnover", [("JTSJOL", "Vacantes de empleo JOLTS", "nivel", "M")]),
    ("Unemployment Insurance Weekly Claims", [("ICSA", "Solicitudes de desempleo", "nivel", "k")]),
    ("Industrial Production and Capacity", [("INDPRO", "Producción industrial (m/m)", "mom", "%")]),
    ("New Residential Construction", [("HOUST", "Inicios de vivienda (anualizado)", "nivel", "M")]),
    ("Surveys of Consumers", [("UMCSENT", "Confianza del consumidor (Michigan)", "nivel", "")]),
    ("Durable Goods", [("DGORDER", "Pedidos de bienes duraderos (m/m)", "mom", "%")]),
]
F_SEEN = None   # se fija abajo (archivo donde se anota cuando aparece cada dato nuevo)
FOMC = {2026: ["01-28", "03-18", "04-29", "06-17", "07-29", "09-16", "10-28", "12-09"],
        2027: ["01-27", "03-17", "04-28", "06-09", "07-28", "09-15", "10-27", "12-08"]}
FOMC_SEP = {"03", "06", "09", "12"}        # con proyecciones economicas (y "dot plot")


def _cached(key, ttl, fn):
    with _L:
        c = _C.get(key)
        if c and time.time() - c[0] < ttl:
            return c[1]
    v = fn()
    with _L:
        _C[key] = (time.time(), v)
    return v


def _get(path, key, **params):
    params.update(api_key=key, file_type="json")
    r = requests.get(f"{API}/{path}", params=params, timeout=20)
    if r.status_code in (400, 403) and "api_key" in r.text:
        raise RuntimeError("FRED rechazó la clave (FRED_API_KEY). Revisa que esté bien copiada en ~/.tradier_env.")
    r.raise_for_status()
    return r.json()


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _series(key, sid, how):
    start = (date.today() - timedelta(days=4 * 365)).isoformat()
    obs = _get("series/observations", key, series_id=sid, observation_start=start).get("observations", [])
    pts = [(o["date"], _num(o["value"])) for o in obs if _num(o.get("value")) is not None]
    if how == "yoy":
        d = dict(pts)
        out = []
        for dt, v in pts:
            prev = d.get(str(int(dt[:4]) - 1) + dt[4:])
            if prev:
                out.append((dt, (v / prev - 1) * 100))
        pts = out
    elif how == "mom":
        pts = [(pts[i][0], (pts[i][1] / pts[i - 1][1] - 1) * 100) for i in range(1, len(pts)) if pts[i - 1][1]]
    elif how == "dif":
        pts = [(pts[i][0], pts[i][1] - pts[i - 1][1]) for i in range(1, len(pts))]
    if sid in ("ICSA", "JTSJOL", "HOUST"):
        pts = [(d, v / 1000) for d, v in pts]
    if sid == "DFEDTARU":     # diaria: un punto por mes basta para la grafica
        m = {}
        for d, v in pts:
            m[d[:7]] = (d, v)
        pts = list(m.values())
    return pts


def _release_of(key, sid):
    def go():
        j = _get("series/release", key, series_id=sid)
        r = (j.get("releases") or [{}])[0]
        return r.get("id"), r.get("name")
    return _cached(("rel", sid), 7 * 86400, go)


def _calendar(key):
    today = date.today()
    j = _get("releases/dates", key, realtime_start=(today - timedelta(days=7)).isoformat(),
             realtime_end=(today + timedelta(days=45)).isoformat(), include_release_dates_with_no_data="true",
             sort_order="asc", limit=1000)
    out = []
    for r in j.get("release_dates", []):
        name = r.get("release_name", "")
        for kw, es, hora, imp in REL:
            if kw.lower() in name.lower():
                out.append({"date": r["date"], "name": es, "time": hora, "imp": imp, "rid": r.get("release_id"), "src": name})
                break
    seen, ded = set(), []
    for e in out:
        k = (e["date"], e["name"])
        if k not in seen:
            seen.add(k)
            ded.append(e)
    return ded


def _fomc(today):
    out = []
    for y, ds in FOMC.items():
        for md in ds:
            d = f"{y}-{md}"
            if (today - timedelta(days=7)).isoformat() <= d <= (today + timedelta(days=45)).isoformat():
                out.append({"date": d, "name": "Decisión de tasas de la Fed (FOMC)" + (" + proyecciones" if md[:2] in FOMC_SEP else ""),
                            "time": "14:00", "imp": 3, "fomc": True, "tentative": y >= 2027})
    return out


def data(env):
    key = (env or {}).get("FRED_API_KEY", "").strip()
    today = date.today()
    fomc = _fomc(today)
    nxt = next((f"{y}-{md}" for y in sorted(FOMC) for md in FOMC[y] if f"{y}-{md}" >= today.isoformat()), None)
    if not key:
        return {"need_key": True, "calendar": fomc, "next_fomc": nxt}

    def build():
        def one(ind):
            sid, name, how, unit, up_good, note = ind
            try:
                pts = _series(key, sid, how)
                rid, _ = _release_of(key, sid)
                return {"sid": sid, "name": name, "unit": unit, "how": how, "up_good": up_good, "note": note, "rid": rid,
                        "pts": [[d, round(v, 3)] for d, v in pts[-36:]]}
            except Exception as e:
                return {"sid": sid, "name": name, "note": note, "error": str(e)[:120]}
        with ThreadPoolExecutor(max_workers=4) as ex:
            inds = list(ex.map(one, IND))
        bad = [i for i in inds if i.get("error") and "clave" in i["error"]]
        if bad:
            raise RuntimeError(bad[0]["error"])
        try:
            cal = _calendar(key)
            cal_err = None
        except Exception as e:
            cal, cal_err = [], str(e)[:120]
        have = {i["sid"]: [(p[0], p[1]) for p in i.get("pts", [])] for i in inds if i.get("pts")}
        need = {sid: how for _, its in CAL_MAP for sid, _, how, _ in its if sid not in have}

        def ser(item):
            sid, how = item
            try:
                return sid, _series(key, sid, how)
            except Exception:
                return sid, []
        with ThreadPoolExecutor(max_workers=4) as ex:
            have.update(dict(ex.map(ser, need.items())))
        try:
            obs = _get("series/observations", key, series_id="DFEDTARU", observation_start=(date.today() - timedelta(days=90)).isoformat())["observations"]
            have["DFEDTARU_D"] = [(o["date"], _num(o["value"])) for o in obs if _num(o.get("value")) is not None]
        except Exception:
            pass
        return {"inds": inds, "cal": cal, "cal_err": cal_err, "series": have}
    try:
        d = _cached(("eco", key[:6]), 30 * 60, build)
    except Exception as e:
        return {"error": str(e)[:200], "calendar": fomc, "next_fomc": nxt}
    cal = sorted(d["cal"] + fomc, key=lambda e: (e["date"], e.get("time", "")))
    nxt_by_rid = {}
    for e in d["cal"]:
        if e["date"] >= today.isoformat() and e.get("rid") not in nxt_by_rid:
            nxt_by_rid[e["rid"]] = e["date"]
    inds = []
    for i in d["inds"]:
        i = dict(i)
        i["next"] = nxt_by_rid.get(i.get("rid"))
        if i["sid"] == "DFEDTARU":
            i["next"] = nxt
        inds.append(i)
    seen = _seen_update({k: v for k, v in d.get("series", {}).items() if not k.endswith("_D")})
    rows = calendar_rows(cal, d.get("series", {}), seen, today.isoformat())
    return {"inds": inds, "calendar": cal, "rows": rows, "cal_err": d.get("cal_err"), "next_fomc": nxt, "today": today.isoformat()}


# ───────────── calendario con dato actual y anterior ─────────────
import json as _json
import os as _os
F_SEEN = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "eco_vistos.json")


def _seen_update(series):
    """Anota la fecha en que aparece por primera vez cada periodo nuevo (para saber que dato salio en cada publicacion).
    La primera vez no se sabe cuando salieron los datos que ya existian: quedan como 'antes'."""
    try:
        with open(F_SEEN, encoding="utf-8") as f:
            seen = _json.load(f)
    except (OSError, ValueError):
        seen = {}
    today = date.today().isoformat()
    ch = False
    for sid, pts in series.items():
        if not pts:
            continue
        s = seen.get(sid)
        if s is None:
            seen[sid] = {p[0]: "antes" for p in pts}
            ch = True
            continue
        for d, _ in pts:
            if d not in s:
                s[d] = today
                ch = True
    if ch:
        tmp = F_SEEN + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            _json.dump(seen, f)
        _os.replace(tmp, F_SEEN)
    return seen


def _next_period(d, sid):
    y, m, dd = int(d[:4]), int(d[5:7]), int(d[8:10])
    if sid == "ICSA":
        return (date(y, m, dd) + timedelta(days=7)).isoformat()
    step = 3 if sid.startswith("A191") else 1
    m += step
    if m > 12:
        y, m = y + 1, m - 12
    return f"{y}-{m:02d}-01"


def _plabel(d, sid):
    if not d:
        return ""
    meses = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
    if sid == "ICSA":
        return "sem. " + str(int(d[8:10])) + " " + meses[int(d[5:7]) - 1]
    if sid.startswith("A191"):
        return f"T{(int(d[5:7]) - 1) // 3 + 1}"
    return meses[int(d[5:7]) - 1]


def calendar_rows(cal, series, seen, today):
    """Expande cada publicacion en filas con el dato actual (si ya salio) y el anterior."""
    rows = []
    past_by_sid = {}
    for e in cal:
        if e.get("fomc"):
            continue
        for kw, items in CAL_MAP:
            if kw.lower() in e.get("src", "").lower():
                for sid, *_ in items:
                    if e["date"] <= today:
                        past_by_sid.setdefault(sid, []).append(e["date"])
    for e in cal:
        if e.get("fomc"):
            fr = series.get("DFEDTARU_D") or []
            before = [v for d, v in fr if d < e["date"]]
            after = [v for d, v in fr if d > e["date"]]
            act = after[0] if after and e["date"] < today else None
            rows.append(dict(e, period="", actual=act, prev=before[-1] if before else None, unit="%r"))
            continue
        items = next((it for kw, it in CAL_MAP if kw.lower() in e.get("src", "").lower()), None)
        if not items:
            rows.append(dict(e, period="", actual=None, prev=None, unit=""))
            continue
        for sid, name, how, unit in items:
            pts = series.get(sid) or []
            r = dict(e, name=name, sid=sid, unit=unit, actual=None, prev=None, period="")
            if pts:
                s = seen.get(sid, {})
                if e["date"] <= today:
                    rel = [i for i, (d, _) in enumerate(pts) if s.get(d) not in (None, "antes") and s.get(d) >= e["date"]]
                    i = rel[0] if rel else None
                    if i is None and max(past_by_sid.get(sid, [""])) == e["date"] and e["date"] < today:
                        i = len(pts) - 1          # dato que ya existia antes de que el panel empezara a anotar
                    if i is not None:
                        r.update(actual=pts[i][1], prev=pts[i - 1][1] if i else None, period=_plabel(pts[i][0], sid))
                    else:
                        r.update(prev=pts[-1][1], period=_plabel(_next_period(pts[-1][0], sid), sid))
                else:
                    r.update(prev=pts[-1][1], period=_plabel(_next_period(pts[-1][0], sid), sid))
            rows.append(r)
    return rows
