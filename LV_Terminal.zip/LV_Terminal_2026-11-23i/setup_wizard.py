"""Asistente de primera configuracion (/setup): pide el token de Tradier de la cuenta de PAPEL y/o REAL, lo verifica
contra Tradier y lo guarda SOLO en tu computadora (~/.tradier_env, permisos 600). Los tokens nunca se muestran de vuelta ni se envian a otro sitio.
Lo sirve monitor_web.py (/setup, /api/setup_*)."""
import os
import re
from datetime import datetime

import requests

SANDBOX_BASE = "https://sandbox.tradier.com/v1"
LIVE_BASE = "https://api.tradier.com/v1"
TOKEN_RE = re.compile(r"^[A-Za-z0-9._\-]{8,200}$")
ACCT_RE = re.compile(r"^[A-Za-z0-9]{4,20}$")
KEYS = {"paper": ("TRADIER_TOKEN", "TRADIER_ACCOUNT_ID"), "live": ("TRADIER_LIVE_TOKEN", "TRADIER_LIVE_ACCOUNT_ID"),
        "h": ("TRADIER_H_TOKEN", "TRADIER_H_ACCOUNT_ID")}   # h = segunda cuenta REAL (familiar), con su propio token
NAME_RE = re.compile(r"^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9 .\-]{1,24}$")


class SetupError(Exception):
    pass


def _mask(s):
    s = s or ""
    return ("•" * max(0, len(s) - 4) + s[-4:]) if s else ""


def profile(kind, token):
    """Pregunta a Tradier quien es el dueño del token. Devuelve la lista de cuentas [{id, type, status}]."""
    if not TOKEN_RE.match(token or ""):
        raise SetupError("El token tiene caracteres que no son válidos. Cópialo de nuevo, sin espacios.")
    base = LIVE_BASE if kind in ("live", "h") else SANDBOX_BASE
    try:
        r = requests.get(base + "/user/profile", headers={"Authorization": f"Bearer {token}", "Accept": "application/json"}, timeout=12)
    except requests.RequestException:
        raise SetupError("No pude conectar con Tradier. Revisa tu internet e inténtalo de nuevo.")
    if r.status_code == 401:
        otro = "de PRODUCCIÓN (cuenta real)" if kind == "paper" else "de SANDBOX (papel)"
        raise SetupError("Tradier no aceptó ese token. Revisa que lo hayas copiado completo y que sea el de " +
                         ("SANDBOX (papel)" if kind == "paper" else "PRODUCCIÓN (cuenta real)") + f"; si pegaste uno {otro}, no sirve aquí.")
    if r.status_code >= 400:
        raise SetupError(f"Tradier respondió con un error ({r.status_code}). Inténtalo en unos minutos.")
    try:
        p = (r.json() or {}).get("profile") or {}
    except ValueError:
        raise SetupError("Tradier respondió algo inesperado. Inténtalo de nuevo.")
    acc = p.get("account")
    acc = acc if isinstance(acc, list) else ([acc] if isinstance(acc, dict) else [])
    out = [{"id": str(a.get("account_number")), "type": a.get("type") or "", "status": a.get("status") or ""} for a in acc if a.get("account_number")]
    if not out:
        raise SetupError("El token es válido pero Tradier no devolvió ninguna cuenta asociada.")
    return out


def read_env(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().splitlines()
    except OSError:
        return []


def _get(lines, key):
    for ln in lines:
        t = ln.strip()
        if t.startswith("export "):
            t = t[7:]
        if t.startswith(key + "="):
            return t.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def _set(lines, key, val):
    new = f'export {key}="{val}"'
    for i, ln in enumerate(lines):
        t = ln.strip()
        if t.startswith("export "):
            t = t[7:]
        if t.startswith(key + "="):
            lines[i] = new
            return
    lines.append(new)


def _del(lines, key):
    keep = []
    for ln in lines:
        t = ln.strip()
        if t.startswith("export "):
            t = t[7:]
        if not t.startswith(key + "="):
            keep.append(ln)
    lines[:] = keep


def status(path):
    L = read_env(path)
    out = {}
    for k, (tk, ac) in KEYS.items():
        out[k] = {"set": bool(_get(L, tk) and _get(L, ac)), "account": _mask(_get(L, ac)) if _get(L, ac) else "", "token": _mask(_get(L, tk))[-8:] if _get(L, tk) else ""}
    out["h_name"] = _get(L, "TRADIER_H_NAME") or "Cuenta 2"
    try:
        out["max_qty"] = max(1, int(float(_get(L, "TRADIER_LIVE_MAX_QTY") or 3)))
    except ValueError:
        out["max_qty"] = 3
    out["terms"] = bool(_get(L, "ACCEPTED_TERMS"))
    out["configured"] = out["paper"]["set"] or out["live"]["set"]
    out["robot"] = robot_settings(L)
    return out


def _write(path, lines):
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # permisos privados desde que se crea
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("\n".join(lines).rstrip("\n") + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def check(body):
    kind = body.get("kind")
    if kind not in KEYS:
        raise SetupError("Tipo de cuenta no válido")
    return {"accounts": profile(kind, str(body.get("token", "")).strip())}


def robot_settings(L):
    """Ajustes del robot de SPY leidos del archivo de claves (lista de lineas)."""
    live_ok = bool(_get(L, "TRADIER_LIVE_TOKEN") and _get(L, "TRADIER_LIVE_ACCOUNT_ID"))
    def num(k, d, cast=float):
        try:
            return cast(float(_get(L, k)))
        except (TypeError, ValueError):
            return d
    acct = "live" if (_get(L, "ROBOT_ACCOUNT") == "live" and live_ok and _get(L, "ACCEPTED_ROBOT_LIVE")) else "paper"
    return {"account": acct, "live_ok": live_ok, "send": _get(L, "ROBOT_LIVE_SEND") == "1",
            "qty": num("ROBOT_LIVE_QTY", 1, int), "max_loss": num("ROBOT_LIVE_MAX_LOSS", 45.0),
            "max_trades": max(1, min(10, num("ROBOT_LIVE_MAX_TRADES", 3, int))),
            "auto": _get(L, "ROBOT_LIVE_AUTO") == "1", "mtf": _get(L, "ROBOT_MTF") == "1"}


def robot_save(path, body, bot_running=False):
    """Guarda en que cuenta opera el robot. REAL exige: cuenta real configurada, aviso aceptado, robot detenido y escribir ROBOT REAL."""
    if bot_running:
        raise SetupError("Detén el robot (botón ■ en el panel) antes de cambiar su cuenta o sus límites.")
    lines = read_env(path)
    st = status(path)
    if not st["terms"]:
        raise SetupError("Primero acepta el aviso de riesgo (abajo).")
    acct = body.get("account")
    if acct not in ("paper", "live"):
        raise SetupError("Cuenta del robot no válida")
    cur = st["robot"]
    if acct == "live":
        if not st["live"]["set"]:
            raise SetupError("Para que el robot opere en REAL primero agrega tu cuenta real arriba.")
        try:
            qty = int(body.get("qty"))
            loss = round(float(body.get("max_loss")), 2)
        except (TypeError, ValueError):
            raise SetupError("Contratos y pérdida máxima deben ser números.")
        if not 1 <= qty <= 5:
            raise SetupError("En real el robot opera entre 1 y 5 contratos (empieza con 1).")
        if not 10 <= loss <= 1000:
            raise SetupError("La pérdida máxima diaria debe estar entre $10 y $1000.")
        try:
            mt = int(float(body.get("max_trades", 3)))
        except (TypeError, ValueError):
            raise SetupError("Las operaciones por día deben ser un número.")
        if not 1 <= mt <= 10:
            raise SetupError("En real el robot hace entre 1 y 10 operaciones por día (empieza con 3).")
        send = bool(body.get("send"))
        risky = cur["account"] != "live" or (send and not cur["send"])
        if risky and str(body.get("confirm", "")).strip().upper() != "ROBOT REAL":
            raise SetupError("Escribe ROBOT REAL para confirmar que el robot operará con tu dinero real.")
        _set(lines, "ROBOT_ACCOUNT", "live")
        _set(lines, "ACCEPTED_ROBOT_LIVE", datetime.now().strftime("%Y-%m-%d"))
        _set(lines, "ROBOT_LIVE_SEND", "1" if send else "0")
        _set(lines, "ROBOT_LIVE_QTY", str(qty))
        _set(lines, "ROBOT_LIVE_MAX_LOSS", f"{loss:g}")
        _set(lines, "ROBOT_LIVE_MAX_TRADES", str(mt))
        _set(lines, "ROBOT_LIVE_AUTO", "1" if body.get("auto") else "0")
    else:
        _set(lines, "ROBOT_ACCOUNT", "paper")
    _set(lines, "ROBOT_MTF", "1" if body.get("mtf") else "0")   # filtro Corona 1·3·5: vale para papel y real
    _write(path, lines)
    return status(path)


def save(path, body):
    """body: {paper:{token,account?}, live:{token,account?}, accept:bool}. Verifica cada token con Tradier antes de guardar nada."""
    lines = read_env(path)
    st = status(path)
    if not st["terms"] and not body.get("accept"):
        raise SetupError("Debes aceptar el aviso de riesgo para continuar.")
    todo = {}
    for kind in KEYS:
        b = body.get(kind) or {}
        tok = str(b.get("token", "")).strip()
        if not tok:
            continue
        accts = profile(kind, tok)
        want = str(b.get("account", "")).strip()
        if want:
            if not ACCT_RE.match(want):
                raise SetupError("El número de cuenta solo puede tener letras y números.")
            if want not in [a["id"] for a in accts]:
                raise SetupError(f"Ese número de cuenta ({want}) no pertenece a este token. Cuentas de este token: " + ", ".join(a["id"] for a in accts))
        else:
            want = accts[0]["id"]
        todo[kind] = (tok, want)
    hn = str((body.get("h") or {}).get("name", "")).strip()
    if "h" in todo or hn:
        if not hn and not _get(lines, "TRADIER_H_NAME"):
            raise SetupError("Escribe el nombre con el que verás la cuenta 2 (por ejemplo, el nombre de su dueña).")
        if hn and not NAME_RE.match(hn):
            raise SetupError("El nombre solo puede tener letras, números y espacios (máximo 24).")
        if hn:
            _set(lines, "TRADIER_H_NAME", hn)
    if "h" in todo and todo["h"][1] == _get(lines, "TRADIER_LIVE_ACCOUNT_ID"):
        raise SetupError("Ese número de cuenta es el mismo de tu cuenta REAL: la cuenta 2 debe ser otra cuenta.")
    if not todo and not st["configured"]:
        raise SetupError("Pega el token de al menos una cuenta (papel o real).")
    for kind, (tok, acc) in todo.items():
        _set(lines, KEYS[kind][0], tok)
        _set(lines, KEYS[kind][1], acc)
        if kind == "paper":
            _set(lines, "TRADIER_ENV", "sandbox")
            if not _get(lines, "DRY_RUN"):
                _set(lines, "DRY_RUN", "0")   # solo papel: las órdenes del robot son simuladas por Tradier
    if not st["terms"]:
        _set(lines, "ACCEPTED_TERMS", datetime.now().strftime("%Y-%m-%d"))
    _write(path, lines)
    return status(path)


def limits(path, body):
    """Tope de contratos por orden en las cuentas REALES (protege contra errores de dedo). Entre 1 y 10."""
    try:
        q = int(body.get("max_qty"))
    except (TypeError, ValueError):
        raise SetupError("Elige un número de contratos")
    if not 1 <= q <= 10:
        raise SetupError("El tope debe estar entre 1 y 10 contratos")
    lines = read_env(path)
    _set(lines, "TRADIER_LIVE_MAX_QTY", str(q))
    _write(path, lines)
    return status(path)


def remove(path, kind):
    if kind not in KEYS:
        raise SetupError("Tipo de cuenta no válido")
    lines = read_env(path)
    for k in KEYS[kind]:
        _del(lines, k)
    if kind == "h":
        _del(lines, "TRADIER_H_NAME")
    if kind == "live":
        _set(lines, "ROBOT_ACCOUNT", "paper")
    _write(path, lines)
    return status(path)


PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configuración · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:760px;margin:0 auto;padding:22px 16px 60px}h1{font-size:24px;margin:6px 0 4px}.sub{color:var(--mut);margin-bottom:18px;line-height:1.5}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}.card.live{border-left-color:var(--bad)}
h2{font-size:15px;margin:0 0 4px}.mut{color:var(--mut);font-size:13px;line-height:1.5}label{display:block;color:var(--mut);font-size:12px;margin:12px 0 4px}
input[type=password],input[type=text],select{width:100%;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:9px;padding:10px;font:14px ui-monospace,Menlo,monospace}
button{background:#16161b;border:1px solid var(--line);color:var(--tx);border-radius:9px;padding:9px 16px;cursor:pointer;font-weight:700;font-size:14px}button.go{border-color:var(--ok);color:var(--ok)}button.dng{border-color:var(--bad);color:var(--bad)}
.ok{color:var(--ok)}.bad{color:var(--bad)}.warn{color:var(--warn)}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px}
.box{background:rgba(255,192,77,.08);border:1px solid var(--warn);border-radius:10px;padding:12px;color:var(--warn);font-size:13px;line-height:1.55;margin-bottom:14px}
.tag{display:inline-block;font-size:11px;padding:2px 8px;border-radius:99px;border:1px solid var(--line);color:var(--mut);margin-left:6px}
a{color:var(--cy)}
</style></head><body><main>
<div style="font:800 12px ui-monospace,Menlo,monospace;letter-spacing:.12em;color:#e8b04a;margin-bottom:6px">LUIS VERDUZCO OPTIONS TERMINAL</div><h1>Configura tus cuentas de Tradier</h1>
<div class="sub">Pega el token de API de tu cuenta. Con él, el panel lee precios y envía órdenes <b>por ti</b>. Necesitas al menos una cuenta: la de <b>papel</b> (práctica, sin dinero) o la <b>real</b>. Lo ideal es empezar con papel.</div>
<div class="box" style="border-color:#5a2020;background:#140808">🔴 ¿Tu broker es <b>tastytrade</b>? <a href="/tasty" style="color:#ff8a8a;font-weight:700">Conéctalo aquí →</a> (por ahora solo para ver tu cuenta)</div>
<div class="box">🔒 Tu token se guarda <b>solo en tu computadora</b> (archivo privado <code>~/.tradier_env</code>) y solo se envía a Tradier. Nunca lo compartas con nadie, ni con quien te dé soporte. El panel no lo vuelve a mostrar completo.</div>
<div id="cur"></div>
<div class="card" id="liccard" style="display:none"><h2>🔑 Licencia</h2>
 <div class="mut" id="lic_st">Pega la clave que te enviaron (empieza con <code>TP1.</code>).</div>
 <label>Clave de licencia</label><input type="text" id="lic_key" autocomplete="off" spellcheck="false" placeholder="TP1.xxxxxxxx...">
 <div class="row"><button class="go" onclick="licSave()">Activar licencia</button><span id="lic_msg" class="mut"></span></div></div>


<div class="card"><h2>🧪 Cuenta de PAPEL (sandbox) <span class="tag">recomendada · necesaria para el robot de SPY</span></h2>
 <div class="mut">Dinero ficticio, precios con ~15 min de retraso. Aquí corre el robot y aquí practicas todo. En Tradier: tu cuenta de desarrollador → Sandbox → Access Token.</div>
 <label>Token de SANDBOX</label><input type="password" id="p_tok" autocomplete="off" spellcheck="false" placeholder="pega aquí el token de papel">
 <div class="row"><button onclick="chk('paper')">Verificar</button><span id="p_msg" class="mut"></span></div>
 <div id="p_acc" style="display:none"><label>Cuenta</label><select id="p_sel"></select></div></div>

<div class="card live"><h2>🔴 Cuenta REAL <span class="tag">opcional · trading manual, gestor y robot (beta)</span></h2>
 <div class="mut">Opera con dinero real. El panel siempre arranca en papel y cada orden real te pide confirmación (Sí/No). El robot de SPY puede operarla solo si tú lo activas abajo en «Robot de SPY». En Tradier: tu cuenta de brokerage → API → Access Token de producción.</div>
 <label>Token de PRODUCCIÓN</label><input type="password" id="l_tok" autocomplete="off" spellcheck="false" placeholder="pega aquí el token de la cuenta real (opcional)">
 <div class="row"><button onclick="chk('live')">Verificar</button><span id="l_msg" class="mut"></span></div>
 <div id="l_acc" style="display:none"><label>Cuenta</label><select id="l_sel"></select></div></div>

<div class="card" style="border-left-color:#b48cff"><h2>🟣 Cuenta REAL 2 (familiar) <span class="tag">opcional · con su propio token</span></h2>
 <div class="mut">Para operar la cuenta de otra persona (por ejemplo, de tu hermana) <b>con su permiso</b>. <b>Ella</b> genera su token de producción en su cuenta de Tradier (API → Access Token) y lo pega aquí. En el panel aparecerá en <b>morado</b>, con su nombre, para que nunca la confundas con la tuya. Sus órdenes, posiciones, reportes, gestor y robot van totalmente aparte.</div>
 <label>Nombre con el que la verás</label><input type="text" id="h_name" maxlength="24" autocomplete="off" placeholder="por ejemplo: su nombre">
 <label>Token de PRODUCCIÓN de la cuenta 2</label><input type="password" id="h_tok" autocomplete="off" spellcheck="false" placeholder="lo pega la dueña de la cuenta">
 <div class="row"><button onclick="chk('h')">Verificar</button><span id="h_msg" class="mut"></span></div>
 <div id="h_acc" style="display:none"><label>Cuenta</label><select id="h_sel"></select></div></div>

<div class="card live"><h2>🛡 Tope de contratos por orden (cuentas REALES)</h2>
 <div class="mut">Protección contra errores de dedo: ninguna orden de ABRIR en una cuenta real puede pasar de este número de contratos (para cerrar no hay tope). Vale para tu cuenta y para la cuenta 2. El robot de condors siempre usa 1.</div>
 <label>Máximo de contratos por orden</label><select id="mq"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select>
 <div class="row"><button class="go" onclick="mqSave()">Guardar tope</button><span id="mq_msg" class="mut"></span></div></div>

<div class="card live" id="robcard"><h2>🤖 Robot de SPY <span class="tag">beta</span></h2>
 <div class="mut">Elige en qué cuenta opera el robot. <b>Papel</b> es lo recomendado para empezar. En <b>REAL</b> el robot arranca con candados: 1 contrato, pérdida máxima diaria, y solo se inicia cuando <b>tú</b> pulses ▶ (no arranca solo, salvo que lo marques). Por defecto en real corre en <b>simulación</b>: ve las señales en vivo pero no manda órdenes hasta que lo actives.</div>
 <label style="display:flex;gap:8px;align-items:center;color:var(--tx)"><input type="checkbox" id="r_mtf"> Más selectivo: entrar solo si 1, 3 y 5 min coinciden en la dirección (Corona 👑 1·3·5)</label>
 <label>Cuenta del robot</label><select id="r_acc" onchange="robUi()"><option value="paper">🧪 Papel (recomendado)</option><option value="live">🔴 REAL (dinero real)</option></select>
 <div id="r_live" style="display:none">
  <label>Contratos por operación (1–5)</label><input type="text" id="r_qty" value="1">
  <label>Pérdida máxima diaria en $ (el robot se detiene al llegar)</label><input type="text" id="r_loss" value="45">
  <label>Operaciones máximas por día (1–10; el robot deja de entrar al llegar)</label><input type="text" id="r_mt" value="3">
  <label style="display:flex;gap:8px;align-items:center;color:var(--tx)"><input type="checkbox" id="r_send"> Enviar órdenes REALES (si no, solo simulación: registra qué haría)</label>
  <label style="display:flex;gap:8px;align-items:center;color:var(--tx)"><input type="checkbox" id="r_auto"> Arrancar solo cada día (lun–vie, antes de abrir)</label>
  <label>Para confirmar escribe: <b>ROBOT REAL</b></label><input type="text" id="r_conf" autocomplete="off" placeholder="ROBOT REAL">
 </div>
 <div class="row"><button class="go" onclick="robSave()">Guardar robot</button><span id="r_msg" class="mut"></span></div></div>

<div class="box" id="terms"><label style="display:flex;gap:10px;align-items:flex-start;margin:0;color:var(--warn);font-size:13px"><input type="checkbox" id="acc" style="margin-top:3px">
 <span>Entiendo que esto es una <b>herramienta de software</b>, no asesoría financiera. Operar acciones y opciones tiene riesgo de perder dinero, incluso más de lo que esperas. Yo decido y soy responsable de cada orden; los resultados pasados no garantizan nada, y el software puede tener errores.</span></label></div>
<div class="row"><button class="go" onclick="save()">Guardar y continuar</button><span id="msg"></span></div>
<script>
const $=id=>document.getElementById(id);const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;");
async function post(p,b){const r=await fetch(p,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});return r.json()}
let ST=null;
async function load(){ST=await (await fetch("/api/setup_status",{cache:"no-store"})).json();setTimeout(()=>{robLoad();licUi();$("mq").value=String(ST.max_qty||3)},0);
  $("terms").style.display=ST.terms?"none":"";
  if(ST.h_name&&ST.h&&ST.h.set)$("h_name").placeholder=ST.h_name;
  $("cur").innerHTML=[["paper","🧪 Papel"],["live","🔴 Real"],["h","🟣 "+(ST.h_name||"Cuenta 2")]].map(([k,n])=>'<div class="card" style="padding:10px 14px"><b>'+n+':</b> '+(ST[k].set?'<span class="ok">configurada</span> · cuenta <span class="mono">'+esc(ST[k].account)+'</span> <button class="dng" style="padding:3px 10px;font-size:12px" onclick="rm(\''+k+'\')">Quitar</button>':'<span class="mut">sin configurar</span>')+"</div>").join("")}
function pf(kind){return kind==="paper"?"p":kind==="h"?"h":"l"}
function fill(kind,accts){const p=pf(kind);$(p+"_acc").style.display="";$(p+"_sel").innerHTML=accts.map(a=>'<option value="'+esc(a.id)+'">'+esc(a.id)+(a.type?" · "+esc(a.type):"")+(a.status?" · "+esc(a.status):"")+"</option>").join("")}
async function chk(kind){const p=pf(kind),m=$(p+"_msg");const tok=$(p+"_tok").value.trim();if(!tok){m.innerHTML='<span class="bad">Pega el token primero</span>';return}
  m.textContent="Verificando con Tradier…";const j=await post("/api/setup_check",{kind:kind,token:tok});
  if(j.error){m.innerHTML='<span class="bad">✖ '+esc(j.error)+"</span>";$(p+"_acc").style.display="none";return}
  m.innerHTML='<span class="ok">✓ Token válido ('+j.accounts.length+" cuenta"+(j.accounts.length>1?"s":"")+")</span>";fill(kind,j.accounts)}
async function save(){const b={accept:$("acc").checked,paper:{},live:{}};
  if($("p_tok").value.trim()){b.paper={token:$("p_tok").value.trim(),account:$("p_sel").value||""}}
  if($("l_tok").value.trim()){b.live={token:$("l_tok").value.trim(),account:$("l_sel").value||""}}
  if($("h_tok").value.trim()||$("h_name").value.trim()){b.h={token:$("h_tok").value.trim(),account:$("h_sel").value||"",name:$("h_name").value.trim()}}
  $("msg").textContent="Guardando…";const j=await post("/api/setup_save",b);
  if(j.error){$("msg").innerHTML='<span class="bad">✖ '+esc(j.error)+"</span>";return}
  $("p_tok").value="";$("l_tok").value="";$("h_tok").value="";$("msg").innerHTML='<span class="ok">✓ Guardado. Abriendo el panel…</span>';setTimeout(()=>location.href="/",900)}
async function rm(k){if(!confirm("¿Quitar la cuenta "+(k==="paper"?"de papel":k==="h"?(ST.h_name||"2"):"REAL")+" de este panel?"))return;const j=await post("/api/setup_remove",{kind:k});if(j.error)alert(j.error);load()}
async function mqSave(){$("mq_msg").textContent="Guardando…";const j=await post("/api/setup_limits",{max_qty:$("mq").value});
  if(j.error){$("mq_msg").innerHTML='<span class="bad">✖ '+esc(j.error)+"</span>";return}ST=j;$("mq_msg").innerHTML='<span class="ok">✓ Tope guardado: '+j.max_qty+' contratos por orden (ya vale, sin reiniciar)</span>'}
function licUi(){const L=(ST&&ST.license)||{};$("liccard").style.display=L.required?"":"none";
  if(L.required)$("lic_st").innerHTML=L.ok?'<span class="ok">✓ Licencia activa</span> · '+esc(L.name||"")+' · vence '+esc(L.exp||"")+' ('+L.days_left+' días)':'<span class="bad">'+esc(L.error||"Falta activar tu licencia.")+'</span> Pega la clave que te enviaron (empieza con TP1.).'}
async function licSave(){$("lic_msg").textContent="Verificando…";const j=await post("/api/license_save",{key:$("lic_key").value});
  if(j.error){$("lic_msg").innerHTML='<span class="bad">✖ '+esc(j.error)+"</span>";return}
  $("lic_key").value="";$("lic_msg").innerHTML='<span class="ok">✓ Licencia activada</span>';await load()}
function robUi(){$("r_live").style.display=$("r_acc").value==="live"?"":"none"}
function robLoad(){const r=ST.robot||{};$("r_acc").value=r.account||"paper";$("r_qty").value=r.qty||1;$("r_loss").value=r.max_loss||45;$("r_mt").value=r.max_trades||3;$("r_send").checked=!!r.send;$("r_auto").checked=!!r.auto;$("r_mtf").checked=!!r.mtf;robUi();
  $("robcard").style.display=ST.paper.set||ST.live.set?"":"none"}
async function robSave(){const live=$("r_acc").value==="live";$("r_msg").textContent="Guardando…";
  const j=await post("/api/robot_save",{account:$("r_acc").value,qty:$("r_qty").value,max_loss:$("r_loss").value,max_trades:$("r_mt").value,send:$("r_send").checked,auto:$("r_auto").checked,mtf:$("r_mtf").checked,confirm:$("r_conf").value});
  if(j.error){$("r_msg").innerHTML='<span class="bad">✖ '+esc(j.error)+"</span>";return}
  $("r_conf").value="";$("r_msg").innerHTML='<span class="ok">✓ Guardado: el robot operará en '+(live?"REAL"+(j.robot.send?" con órdenes":" en simulación"):"PAPEL")+". Pulsa ▶ en el panel para iniciarlo.</span>";ST=await (await fetch("/api/setup_status",{cache:"no-store"})).json();robLoad()}
load();
</script></main></body></html>"""
