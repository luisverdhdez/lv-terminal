#!/usr/bin/env python3
"""
Bot de calls/puts de SPY para Tradier.

Por defecto corre en SANDBOX (paper trading) y en DRY_RUN (solo registra lo que haria,
no envia ordenes). Para enviar ordenes al sandbox: DRY_RUN=0.

Estrategia (hora de Nueva York):
  - Ventana de entradas: 9:45 a 14:30.
  - Señal: UT Bot (ATR trailing stop, key=1, ATR=10) sobre barras de 1 minuto de SPY.
  - Solo se opera si la señal sale cerca de un maximo (Sell) o de un minimo (Buy)
    de las ultimas 20 velas (a menos de 2 ATR; ver Config.prox_atr).
  - Buy cerca de minimo -> compra 1 call. Sell cerca de maximo -> compra 1 put.
  - Opcion: vencimiento del dia habil siguiente, fuera del dinero, delta 0,30 a 0,35.
  - 3 contratos. Stop inicial 15 dolares por contrato (0,15 de prima), puesto en el broker.
  - Trailing manejado por el bot: se activa a +0,05; sigue al maximo con distancia 0,05.
  - Parcial: vende 1 contrato en +0,075 (se redondea a 0,08) y deja el resto con trailing.
  - Cierre forzado a las 14:45. Limite de perdida diaria y maximo de operaciones.

Variables de entorno:
  TRADIER_TOKEN        token (sandbox o produccion, segun TRADIER_ENV)
  TRADIER_ACCOUNT_ID   numero de cuenta (el del sandbox es distinto al real)
  TRADIER_ENV          sandbox (defecto) | live
  DRY_RUN              1 (defecto) = no envia ordenes | 0 = envia ordenes
  CONFIRM_LIVE         debe ser YES para usar TRADIER_ENV=live
"""
from __future__ import annotations

import csv
import logging
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime, time as dtime, timedelta
from zoneinfo import ZoneInfo

import requests

ET = ZoneInfo("America/New_York")
log = logging.getLogger("bot")
# En REAL (TRADIER_ENV=live) el robot usa archivos propios: nunca se mezclan sus resultados con los de papel.
_SFX = "_live" if os.environ.get("TRADIER_ENV", "sandbox") == "live" else ""
TRADES_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"trades{_SFX}.csv")
DEAD = ("canceled", "rejected", "expired", "error")


@dataclass
class Config:
    symbol: str = "SPY"
    # señal
    ut_key: float = 1.0
    ut_atr: int = 10
    prox_lookback: int = 20
    # "cerca" de HH/LL = a menos de prox_atr x ATR del maximo/minimo de las ultimas prox_lookback velas.
    # Con key=1 el UT Bot solo da Sell cuando el precio ya retrocedio ~1 ATR desde el maximo (y Buy
    # igual desde el minimo), asi que 1.0 casi nunca se cumple. Por eso el defecto es 2.0.
    # Calibralo con los registros del bot en DRY_RUN (cuantas señales pasan el filtro).
    prox_atr: float = 2.0
    # Confirmacion multi-temporalidad (la "Corona 1·3·5" del grafico): solo entra si la tendencia UT Bot de 1, 3 y 5 min coincide.
    mtf: bool = False
    # horario (hora de Nueva York)
    start: dtime = dtime(9, 45)
    end: dtime = dtime(14, 30)
    force_close: dtime = dtime(14, 45)
    # contrato
    qty: int = 3
    delta_min: float = 0.30
    delta_max: float = 0.35
    max_spread: float = 0.02
    # salidas: dolares de prima por accion (x100 = dolares por contrato)
    stop: float = 0.15
    trail_activate: float = 0.05
    trail_dist: float = 0.05
    trail_step: float = 0.01
    tp1: float = 0.075
    tp1_qty: int = 1
    # riesgo
    daily_max_loss: float = 135.0
    max_trades: int = 6
    # tecnico
    poll_seconds: float = 3.0
    entry_timeout: float = 20.0
    max_bar_age: float = 90.0


def r2(x: float) -> float:
    return round(x + 1e-9, 2)


def as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


# ════════════════════════════════════════════════════════════
#  SEÑAL: UT Bot (misma logica que el indicador de TradingView)
# ════════════════════════════════════════════════════════════
def atr_rma(highs, lows, closes, n):
    tr = []
    for i in range(len(closes)):
        if i == 0:
            tr.append(highs[i] - lows[i])
        else:
            pc = closes[i - 1]
            tr.append(max(highs[i] - lows[i], abs(highs[i] - pc), abs(lows[i] - pc)))
    atr = [None] * len(closes)
    if len(closes) < n:
        return atr
    atr[n - 1] = sum(tr[:n]) / n
    for i in range(n, len(closes)):
        atr[i] = (atr[i - 1] * (n - 1) + tr[i]) / n
    return atr


def ut_bot_stop(closes, atr, key):
    n = len(closes)
    stop = [None] * n
    for i in range(n):
        if atr[i] is None:
            continue
        nl = key * atr[i]
        s = closes[i]
        prev = stop[i - 1] if i > 0 and stop[i - 1] is not None else s
        prev_s = closes[i - 1] if i > 0 else s
        if s > prev and prev_s > prev:
            stop[i] = max(prev, s - nl)
        elif s < prev and prev_s < prev:
            stop[i] = min(prev, s + nl)
        elif s > prev:
            stop[i] = s - nl
        else:
            stop[i] = s + nl
    return stop


def evaluate_signal(bars, cfg: Config):
    """Evalua la ultima barra cerrada. Devuelve None o dict con side, near, close, atr."""
    if len(bars) < cfg.ut_atr + 5:
        return None
    highs = [b["h"] for b in bars]
    lows = [b["l"] for b in bars]
    closes = [b["c"] for b in bars]
    atr = atr_rma(highs, lows, closes, cfg.ut_atr)
    stop = ut_bot_stop(closes, atr, cfg.ut_key)
    i = len(closes) - 1
    if stop[i] is None or stop[i - 1] is None:
        return None
    buy = closes[i] > stop[i] and closes[i - 1] <= stop[i - 1]
    sell = stop[i] > closes[i] and stop[i - 1] <= closes[i - 1]
    if not (buy or sell):
        return None
    side = "buy" if buy else "sell"
    lb = cfg.prox_lookback
    if side == "sell":
        ref = max(highs[-lb:])
        near = (ref - closes[i]) <= cfg.prox_atr * atr[i]
    else:
        ref = min(lows[-lb:])
        near = (closes[i] - ref) <= cfg.prox_atr * atr[i]
    return {"side": side, "near": near, "close": closes[i], "atr": atr[i], "ref": ref, "ts": bars[i]["ts"]}


def _agg_bars(bars, step):
    """Junta velas de 1 min en velas de `step` segundos ancladas a las 9:30 ET. Devuelve (velas, idx) donde idx[i] = vela agrupada de bars[i]."""
    out, idx, lastkey = [], [], None
    for b in bars:
        d = datetime.fromtimestamp(b["ts"], ET)
        k = (d.date(), (d.hour * 3600 + d.minute * 60 + d.second - 34200) // step)
        if k != lastkey:
            out.append({"ts": b["ts"], "h": b["h"], "l": b["l"], "c": b["c"]})
            lastkey = k
        else:
            a = out[-1]
            a["h"] = max(a["h"], b["h"])
            a["l"] = min(a["l"], b["l"])
            a["c"] = b["c"]
        idx.append(len(out) - 1)
    return out, idx


def _trend(bars, cfg):
    h, l, c = [b["h"] for b in bars], [b["l"] for b in bars], [b["c"] for b in bars]
    st = ut_bot_stop(c, atr_rma(h, l, c, cfg.ut_atr), cfg.ut_key)
    return [0 if st[i] is None else (1 if c[i] > st[i] else -1 if c[i] < st[i] else 0) for i in range(len(c))]


def mtf_states(bars, cfg):
    """Para cada vela de 1 min: +1 si la tendencia UT Bot de 1, 3 y 5 min es alcista en las tres, -1 si es bajista en las tres, 0 si no coinciden.
    Igual que la Corona 1·3·5 del grafico: en 3 y 5 min se usa la ultima vela YA CERRADA (no se repinta)."""
    n = len(bars)
    t1 = _trend(bars, cfg)
    tfs = []
    for step in (180, 300):
        ag, idx = _agg_bars(bars, step)
        tfs.append((_trend(ag, cfg), idx))
    out = [0] * n
    for i in range(n):
        st = [t1[i]]
        for tr, idx in tfs:
            j = idx[i]
            st.append(tr[j - 1] if j > 0 else 0)
        out[i] = st[0] if st[0] != 0 and all(x == st[0] for x in st) else 0
    return out


def mtf_ok(bars, side, cfg):
    """True si, en la ultima vela, 1, 3 y 5 min coinciden en la direccion de la señal."""
    return mtf_states(bars, cfg)[-1] == (1 if side == "buy" else -1)


def pick_contract(chain, side, cfg: Config):
    typ = "call" if side == "buy" else "put"
    target = (cfg.delta_min + cfg.delta_max) / 2
    best = None
    for o in chain:
        if o.get("option_type") != typ:
            continue
        d = (o.get("greeks") or {}).get("delta")
        bid, ask = o.get("bid"), o.get("ask")
        if d is None or bid is None or ask is None:
            continue
        d, bid, ask = abs(float(d)), float(bid), float(ask)
        if not (cfg.delta_min <= d <= cfg.delta_max):
            continue
        if bid <= 0 or ask < bid or r2(ask - bid) > cfg.max_spread:
            continue
        score = abs(d - target)
        if best is None or score < best["score"]:
            best = {"symbol": o["symbol"], "strike": o.get("strike"), "bid": bid, "ask": ask, "delta": d, "score": score}
    return best


# ════════════════════════════════════════════════════════════
#  BROKER (API de Tradier)
# ════════════════════════════════════════════════════════════
class Tradier:
    def __init__(self, token, account, env="sandbox", dry=True):
        self.base = "https://api.tradier.com/v1" if env == "live" else "https://sandbox.tradier.com/v1"
        self.acct = account
        self.dry = dry
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {token}", "Accept": "application/json"})

    def _req(self, method, path, params=None, data=None, tries=3):
        url = self.base + path
        for i in range(tries):
            try:
                r = self.s.request(method, url, params=params, data=data, timeout=10)
                if r.status_code == 429:
                    time.sleep(5)
                    continue
                r.raise_for_status()
                return r.json()
            except requests.RequestException:
                if method != "GET" or i == tries - 1:
                    raise
                time.sleep(1 + i)
        raise RuntimeError("limite de peticiones (429) persistente")

    def clock(self):
        return self._req("GET", "/markets/clock")["clock"]

    def bars(self, symbol, days=4):
        now = datetime.now(ET)
        p = {"symbol": symbol, "interval": "1min", "session_filter": "open",
             "start": (now - timedelta(days=days)).strftime("%Y-%m-%d 09:30"),
             "end": now.strftime("%Y-%m-%d %H:%M")}
        j = self._req("GET", "/markets/timesales", params=p)
        out = []
        for d in as_list((j.get("series") or {}).get("data")):
            out.append({"ts": int(d["timestamp"]), "o": float(d["open"]), "h": float(d["high"]),
                        "l": float(d["low"]), "c": float(d["close"])})
        return out

    def next_expiration(self, symbol, today):
        j = self._req("GET", "/markets/options/expirations", params={"symbol": symbol})
        dates = [d for d in as_list((j.get("expirations") or {}).get("date")) if d > today.strftime("%Y-%m-%d")]
        return min(dates) if dates else None

    def chain(self, symbol, expiration):
        j = self._req("GET", "/markets/options/chains",
                      params={"symbol": symbol, "expiration": expiration, "greeks": "true"})
        return as_list((j.get("options") or {}).get("option"))

    def quote(self, occ):
        j = self._req("GET", "/markets/quotes", params={"symbols": occ})
        return as_list((j.get("quotes") or {}).get("quote"))[0]

    def place_option(self, occ, side, qty, typ, price=None, stop=None):
        if self.dry:
            raise RuntimeError("DRY_RUN activo: no se envian ordenes")
        data = {"class": "option", "symbol": occ[:-15].strip(), "option_symbol": occ, "side": side,
                "quantity": int(qty), "type": typ, "duration": "day"}
        if price is not None:
            data["price"] = f"{price:.2f}"
        if stop is not None:
            data["stop"] = f"{stop:.2f}"
        j = self._req("POST", f"/accounts/{self.acct}/orders", data=data)
        return j["order"]["id"]

    def order(self, oid):
        return self._req("GET", f"/accounts/{self.acct}/orders/{oid}")["order"]

    def cancel(self, oid):
        return self._req("DELETE", f"/accounts/{self.acct}/orders/{oid}")

    def modify_stop(self, oid, stop):
        return self._req("PUT", f"/accounts/{self.acct}/orders/{oid}", data={"stop": f"{stop:.2f}"})


def wait_fill(b, oid, timeout, sleep=time.sleep):
    t0 = time.time()
    while True:
        o = b.order(oid)
        if o.get("status") in ("filled",) + DEAD:
            return o
        if time.time() - t0 >= timeout:
            return o
        sleep(1)


# ════════════════════════════════════════════════════════════
#  GESTION DE LA POSICION: stop en el broker + trailing + parcial
# ════════════════════════════════════════════════════════════
class Manager:
    def __init__(self, b, occ, entry, qty, cfg: Config, now_fn=None, sleep_fn=time.sleep):
        self.b, self.occ, self.entry, self.remaining, self.cfg = b, occ, entry, qty, cfg
        self.now_fn = now_fn or (lambda: datetime.now(ET))
        self.sleep = sleep_fn
        self.stop = r2(entry - cfg.stop)
        self.stop_id = None
        self.hwm = entry
        self.last_bid = entry
        self.tp1_done = False
        self.pnl = 0.0
        self.reason = None
        self.tick = 0

    def _place_stop(self):
        self.stop_id = self.b.place_option(self.occ, "sell_to_close", self.remaining, "stop", stop=self.stop)

    def _on_stop_filled(self, o):
        px = float(o.get("avg_fill_price") or self.stop)
        self.pnl += (px - self.entry) * 100 * self.remaining
        self.remaining = 0
        self.reason = "trailing stop" if self.stop >= self.entry else "stop inicial"
        log.info("Stop ejecutado a %.2f", px)

    def _cancel_stop(self):
        """True si se cancelo; False si ya estaba ejecutado."""
        try:
            self.b.cancel(self.stop_id)
        except Exception as e:  # puede fallar justo porque ya se ejecuto
            log.warning("No se pudo cancelar el stop: %s", e)
        o = self.b.order(self.stop_id)
        if o.get("status") == "filled":
            self._on_stop_filled(o)
            return False
        return True

    def _sell_market(self, qty):
        oid = self.b.place_option(self.occ, "sell_to_close", qty, "market")
        o = wait_fill(self.b, oid, 15, self.sleep)
        if o.get("status") == "filled":
            px = float(o.get("avg_fill_price") or self.last_bid)
        else:
            px = self.last_bid
            log.error("Venta a mercado no confirmada (estado %s). Revisa la posicion en Tradier.", o.get("status"))
        self.pnl += (px - self.entry) * 100 * qty
        self.remaining -= qty
        log.info("Vendidos %d a %.2f", qty, px)

    def _close_all(self, reason):
        if self.remaining <= 0:
            return
        if self._cancel_stop():
            self._sell_market(self.remaining)
            self.reason = reason

    def _move_stop(self, new_stop):
        try:
            self.b.modify_stop(self.stop_id, new_stop)
            self.stop = new_stop
            log.info("Stop sube a %.2f", new_stop)
        except Exception as e:
            log.warning("Modificar fallo (%s); cancelo y recreo el stop", e)
            if not self._cancel_stop():
                return
            self.stop = new_stop
            self._place_stop()
            log.info("Stop recreado en %.2f", new_stop)

    def run(self):
        cfg = self.cfg
        self._place_stop()
        log.info("Posicion: %d x %s entrada %.2f, stop %.2f", self.remaining, self.occ, self.entry, self.stop)
        fc = cfg.force_close
        while self.remaining > 0:
            self.sleep(cfg.poll_seconds)
            self.tick += 1
            now = self.now_fn()
            try:
                bid = float(self.b.quote(self.occ)["bid"])
            except Exception as e:
                log.warning("Sin cotizacion: %s", e)
                continue
            self.last_bid = bid
            if now.time() >= fc:
                self._close_all("cierre por hora")
                break
            if bid <= self.stop + 0.03 or self.tick % 5 == 0:
                o = self.b.order(self.stop_id)
                st = o.get("status")
                if st == "filled":
                    self._on_stop_filled(o)
                    break
                if st in DEAD:
                    log.error("El stop quedo en estado %s; cierro a mercado", st)
                    self._sell_market(self.remaining)
                    self.reason = "stop cancelado"
                    break
            self.hwm = max(self.hwm, bid)
            if (not self.tp1_done) and self.remaining > cfg.tp1_qty and bid >= r2(self.entry + cfg.tp1):
                if not self._cancel_stop():
                    break
                self._sell_market(cfg.tp1_qty)
                self.tp1_done = True
                self._place_stop()
                continue
            if bid >= r2(self.entry + cfg.trail_activate):
                new_stop = r2(self.hwm - cfg.trail_dist)
                if bid <= new_stop:
                    self._close_all("trailing")
                    break
                if new_stop >= r2(self.stop + cfg.trail_step):
                    self._move_stop(new_stop)
        return {"pnl": self.pnl, "reason": self.reason}


# ════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL
# ════════════════════════════════════════════════════════════
def log_trade(row):
    new = not os.path.exists(TRADES_CSV)
    with open(TRADES_CSV, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["fecha", "hora", "lado", "opcion", "cantidad", "entrada", "pnl_usd", "motivo"])
        w.writerow(row)


def load_today():
    today = datetime.now(ET).strftime("%Y-%m-%d")
    pnl, n = 0.0, 0
    if os.path.exists(TRADES_CSV):
        with open(TRADES_CSV) as f:
            for r in csv.DictReader(f):
                if r["fecha"] == today:
                    pnl += float(r["pnl_usd"])
                    n += 1
    return pnl, n


def open_and_manage(b, sig, cfg, dry):
    now = datetime.now(ET)
    exp = b.next_expiration(cfg.symbol, now.date())
    if not exp:
        log.warning("Sin vencimiento siguiente disponible")
        return None
    c = pick_contract(b.chain(cfg.symbol, exp), sig["side"], cfg)
    if not c:
        log.info("Ningun contrato cumple delta %.2f-%.2f con spread <= %.2f; no se opera",
                 cfg.delta_min, cfg.delta_max, cfg.max_spread)
        return None
    log.info("Contrato elegido: %s strike %s delta %.2f bid %.2f ask %.2f",
             c["symbol"], c["strike"], c["delta"], c["bid"], c["ask"])
    if dry:
        log.info("[DRY_RUN] Compraria %d x %s a %.2f limite. No se envia orden.", cfg.qty, c["symbol"], c["ask"])
        return {"pnl": 0.0, "reason": "dry_run", "dry": True}
    oid = b.place_option(c["symbol"], "buy_to_open", cfg.qty, "limit", price=c["ask"])
    o = wait_fill(b, oid, cfg.entry_timeout)
    if o.get("status") != "filled":
        try:
            b.cancel(oid)
        except Exception as e:
            log.warning("Cancelar entrada: %s", e)
        o = b.order(oid)
    filled = int(float(o.get("exec_quantity") or 0))
    if filled <= 0:
        log.info("Entrada no ejecutada; se cancela")
        return None
    entry = float(o.get("avg_fill_price") or c["ask"])
    res = Manager(b, c["symbol"], entry, filled, cfg).run()
    log_trade([now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S"), sig["side"], c["symbol"], filled,
               f"{entry:.2f}", f"{res['pnl']:.2f}", res["reason"]])
    log.info("Operacion cerrada: %.2f USD (%s)", res["pnl"], res["reason"])
    return res


def run(b, cfg, dry):
    pnl, trades = load_today()
    log.info("Inicio. P&L del dia %.2f, operaciones %d, dry_run=%s", pnl, trades, dry)
    last_bar = None
    while True:
        now = datetime.now(ET)
        if now.weekday() >= 5:
            log.info("Fin de semana; salgo")
            return
        t = now.time()
        if t < cfg.start:
            time.sleep(20)
            continue
        if t >= cfg.end:
            log.info("Fin del horario de entradas. P&L del dia %.2f", pnl)
            return
        if pnl <= -cfg.daily_max_loss:
            log.warning("Limite de perdida diaria alcanzado (%.2f). No se opera mas hoy.", pnl)
            return
        if trades >= cfg.max_trades:
            log.info("Maximo de operaciones del dia alcanzado")
            return
        try:
            bars = [x for x in b.bars(cfg.symbol) if x["ts"] + 60 <= time.time()]
        except Exception as e:
            log.warning("Error leyendo barras: %s", e)
            time.sleep(10)
            continue
        if not bars or bars[-1]["ts"] == last_bar:
            time.sleep(3)
            continue
        last_bar = bars[-1]["ts"]
        sig = evaluate_signal(bars, cfg)
        if sig:
            age = time.time() - (sig["ts"] + 60)
            log.info("Señal %s en %.2f (ATR %.2f, ref %.2f, cerca=%s, edad %.0fs, corona=%s)",
                     sig["side"].upper(), sig["close"], sig["atr"], sig["ref"], sig["near"], age,
                     mtf_ok(bars, sig["side"], cfg))
            if not sig["near"]:
                log.info("Ignorada: no esta cerca de HH/LL")
            elif cfg.mtf and not mtf_ok(bars, sig["side"], cfg):
                log.info("Ignorada: 1, 3 y 5 min no coinciden (Corona)")
            elif age > cfg.max_bar_age:
                log.info("Ignorada: señal vieja (%.0fs)", age)
            else:
                try:
                    res = open_and_manage(b, sig, cfg, dry)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    log.exception("Error en la operacion: %s. REVISA LA POSICION EN TRADIER.", e)
                    res = None
                if res and not res.get("dry"):
                    pnl += res["pnl"]
                    trades += 1
        time.sleep(max(1, 60 - time.time() % 60 + 3))


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout),
                                  logging.FileHandler(os.path.join(os.path.dirname(os.path.abspath(__file__)), f"bot{_SFX}.log"))])
    token, acct = os.environ.get("TRADIER_TOKEN"), os.environ.get("TRADIER_ACCOUNT_ID")
    env = os.environ.get("TRADIER_ENV", "sandbox")
    dry = os.environ.get("DRY_RUN", "1") != "0"
    if not token or not acct:
        sys.exit("Faltan TRADIER_TOKEN y/o TRADIER_ACCOUNT_ID")
    if env == "live" and os.environ.get("CONFIRM_LIVE") != "YES":
        sys.exit("Para operar en real pon CONFIRM_LIVE=YES (y revisa tamaño y limites)")
    cfg = Config()
    # Topes de la cuenta REAL: 1 contrato y perdida diaria = 3 stops completos, salvo que el panel diga otra cosa.
    if env == "live":
        cfg.qty = 1
        cfg.max_trades = 3
    try:
        if os.environ.get("BOT_QTY"):
            cfg.qty = max(1, min(10, int(os.environ["BOT_QTY"])))
        if env == "live" or os.environ.get("BOT_DAILY_MAX_LOSS"):
            cfg.daily_max_loss = float(os.environ.get("BOT_DAILY_MAX_LOSS") or round(cfg.stop * 100 * cfg.qty * 3, 2))
        if os.environ.get("BOT_MTF") == "1":
            cfg.mtf = True
        if os.environ.get("BOT_MAX_TRADES"):
            cfg.max_trades = max(1, min(20, int(os.environ["BOT_MAX_TRADES"])))
    except ValueError:
        sys.exit("BOT_QTY / BOT_DAILY_MAX_LOSS / BOT_MAX_TRADES no son numeros validos")
    if cfg.mtf:
        log.info("Filtro Corona 1·3·5 ACTIVO: solo entra si 1, 3 y 5 min coinciden")
    if env == "live":
        log.warning("MODO REAL: %d contrato(s), limite de perdida diaria $%.0f, maximo %d operaciones, %s",
                    cfg.qty, cfg.daily_max_loss, cfg.max_trades, "ORDENES ACTIVAS" if not dry else "solo simulacion (DRY_RUN)")
    if env != "live":
        cfg.max_bar_age = 20 * 60  # el sandbox trae datos con retraso
        log.info("Modo SANDBOX: datos con retraso, sirve para probar el flujo, no la sincronia")
    b = Tradier(token, acct, env, dry)
    try:
        c = b.clock()
        log.info("Reloj de mercado: %s", c.get("description"))
        run(b, cfg, dry)
    except KeyboardInterrupt:
        log.warning("Interrumpido. Si hay posicion abierta, su stop en el broker sigue activo: revisala en Tradier.")


if __name__ == "__main__":
    main()
