"""Covered calls: cuales contratos son calls cubiertos por acciones (inversion de largo plazo, NO trading del dia).
Se apuntan aqui cuando la terminal los ve abiertos con acciones suficientes (trading._positions).
Sirve para que NO cuenten en la pausa de 2 perdidas ni en las metricas del trading diario."""
import json
import os
import re
import threading

D = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(D, "cc_occs.json")
_lock = threading.Lock()
_cache = {"t": 0, "s": set()}
INDEX = {"SPY", "SPX", "SPXW", "QQQ", "XSP", "XSPW", "IWM", "NDX", "NDXP", "RUT", "RUTW", "DIA", "VIX"}


def occs():
    try:
        m = os.path.getmtime(FILE)
    except OSError:
        return set()
    if m != _cache["t"]:
        try:
            with open(FILE, encoding="utf-8") as f:
                _cache["s"] = set(json.load(f))
        except (OSError, ValueError):
            _cache["s"] = set()
        _cache["t"] = m
    return set(_cache["s"])


def mark(lst):
    lst = {str(x) for x in lst if x}
    if not lst or lst <= occs():
        return
    with _lock:
        s = occs() | lst
        tmp = FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(sorted(s)[-2000:], f)
        os.replace(tmp, FILE)


def is_cc_row(opcion):
    """Fila del registro manual (patas separadas por '/'): True si todas sus patas son covered calls apuntados."""
    legs = {x.strip() for x in str(opcion or "").split("/") if x.strip()}
    return bool(legs) and legs <= occs()


def looks_cc(sym, u, qty):
    """Historial de Tradier (antes de que se apuntaran): call VENDIDO de una ACCION (no indice/ETF de trading)."""
    return qty is not None and qty < 0 and u not in INDEX and bool(re.search(r"\d{6}C", str(sym)))
