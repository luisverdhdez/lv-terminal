#!/bin/zsh
# Actualiza tu LV Options Terminal con los archivos de esta carpeta.
# No toca tus claves, tu licencia ni tus datos (historial, reglas del gestor, dibujos). Antes hace un respaldo.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
pl_dir(){ /usr/libexec/PlistBuddy -c 'Print :WorkingDirectory' "$1" 2>/dev/null || true; }
OLD="$HOME/Library/LaunchAgents/com.tradierpanel.app.plist"
NEW="$HOME/Library/LaunchAgents/com.luis.tradierpanel.plist"
DEST=""
[ -f "$OLD" ] && DEST="$(pl_dir "$OLD")"
[ -z "$DEST" ] && [ -f "$NEW" ] && DEST="$(pl_dir "$NEW")"
[ -z "$DEST" ] && DEST="$HOME/bot"
if [ "$DEST" = "$SRC" ]; then
  echo "Corre este archivo desde la carpeta del paquete (en Descargas), no desde tu terminal."; exit 1
fi
if [ ! -f "$DEST/monitor_web.py" ]; then
  echo "No encontre tu terminal en $DEST."
  echo "Si nunca la instalaste, sigue la parte INSTALACION NUEVA del LEEME."; exit 1
fi
echo "Tu terminal esta en: $DEST"
launchctl bootout "gui/$(id -u)/com.luis.tradierpanel" 2>/dev/null || true
if [ -f "$OLD" ]; then
  launchctl bootout "gui/$(id -u)/com.tradierpanel.app" 2>/dev/null || true
  mkdir -p "$HOME/arranque_viejo"; mv "$OLD" "$HOME/arranque_viejo/"
  echo "Quite un arranque automatico viejo (quedo guardado en ~/arranque_viejo)."
fi
P="$(lsof -t -iTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"
if [ -n "$P" ]; then kill $P 2>/dev/null || true; sleep 2; echo "Cerre un panel viejo que seguia abierto."; fi
BK="${DEST}_respaldo_$(date +%Y%m%d_%H%M)"
cp -R "$DEST" "$BK"; echo "Respaldo de tu version anterior: $BK"
cp "$SRC"/*.py "$DEST"/
cp "$SRC"/instalar.sh "$SRC"/LEEME.txt "$DEST"/ 2>/dev/null || true
echo "Actualizando paquetes de Python (puede tardar un minuto)..."
python3 -m pip install --quiet --upgrade requests yfinance numpy 2>/dev/null || echo "(aviso: no pude actualizar los paquetes de Python; sigo)"
cd "$DEST" && zsh instalar.sh
sleep 6
if curl -s --max-time 10 http://localhost:8765/ | grep -q "LV Options Terminal"; then
  echo ""; echo "LISTO: ya corre la version nueva. En el navegador recarga con Cmd+Option+R (Safari) o Cmd+Shift+R (Chrome)."
else
  echo ""; echo "El panel arranco. Abre http://localhost:8765 y recarga con Cmd+Option+R."
  echo "Si sigues viendo la version vieja, manda una captura de esta ventana."
fi
