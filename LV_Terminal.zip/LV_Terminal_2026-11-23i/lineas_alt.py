"""Modo sombra del ROBOT DE LINEAS: en cada operacion, ¿que habria pasado con un CALL (alcista) o PUT (bajista)
de 100 dias o mas, delta 0.20, comprado en el mismo momento y vendido cuando el robot salio?
NUNCA manda ordenes. Solo consulta precios. Corre en segundo plano para no frenar al robot."""
import math
import threading
from datetime import date, datetime

MIN_DAYS, DELTA = 100, 0.20
R = 0.04


def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _bs(S, K, T, v, call):
    if T <= 0 or v <= 0:
        return max(0.0, (S - K) if call else (K - S))
    d1 = (math.log(S / K) + (R + v * v / 2) * T) / (v * math.sqrt(T))
    d2 = d1 - v * math.sqrt(T)
    return S * _ncdf(d1) - K * math.exp(-R * T) * _ncdf(d2) if call else K * math.exp(-R * T) * _ncdf(-d2) - S * _ncdf(-d1)


def _iv(mid, S, K, T, call):
    lo, hi = 0.01, 3.0
    if _bs(S, K, T, hi, call) < mid:
        return None
    for _ in range(60):
        m = (lo + hi) / 2
        if _bs(S, K, T, m, call) > mid:
            hi = m
        else:
            lo = m
    return (lo + hi) / 2


def delta(S, K, T, v, call):
    d1 = (math.log(S / K) + (R + v * v / 2) * T) / (v * math.sqrt(T))
    return _ncdf(d1) if call else _ncdf(d1) - 1


def _num(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def pick_exp(dates, today):
    ok = sorted(d for d in dates if (date.fromisoformat(d) - today).days >= MIN_DAYS)
    return ok[0] if ok else None


def pick(opts, spot, exp, call, today):
    """El contrato con delta mas cercana a 0.20 (calculada con el precio de ahora). opts: filas de la cadena de Tradier."""
    T = max((date.fromisoformat(exp) - today).days, 1) / 365
    best = None
    for o in opts:
        if (o.get("option_type") == "call") != call:
            continue
        K, b, a = _num(o.get("strike")), _num(o.get("bid")), _num(o.get("ask"))
        if not K or b is None or a is None or a <= 0 or (call and K <= spot) or (not call and K >= spot):
            continue
        v = _iv((b + a) / 2, spot, K, T, call)
        if not v:
            continue
        d = abs(delta(spot, K, T, v, call))
        if best is None or abs(d - DELTA) < abs(best[0] - DELTA):
            best = (d, o, K, b, a)
    if not best:
        return None
    d, o, K, b, a = best
    return {"occ": o.get("symbol"), "strike": K, "exp": exp, "type": "C" if call else "P", "delta": round(d, 3),
            "in_bid": b, "in_ask": a, "in_mid": round((b + a) / 2, 2)}


def open_alt(get, op, spot, lock, save, today=None):
    """Registra el contrato alternativo al ENTRAR el robot. get(path, params) -> json de Tradier (solo consultas)."""
    def run():
        try:
            td = today or datetime.now().date()
            call = op.get("dir") == "alcista"
            j = get("/markets/options/expirations", {"symbol": op.get("sym", "SPY")})
            dates = [d for d in _as_list((j.get("expirations") or {}).get("date")) if isinstance(d, str)]
            exp = pick_exp(dates, td)
            if not exp:
                return
            c = get("/markets/options/chains", {"symbol": op.get("sym", "SPY"), "expiration": exp, "greeks": "false"})
            opts = _as_list((c.get("options") or {}).get("option")) if isinstance(c.get("options"), dict) else []
            alt = pick(opts, spot, exp, call, td)
            if alt:
                with lock:
                    op["alt"] = dict(alt, spot_in=spot)
                    save()
        except Exception:  # noqa: BLE001 - la sombra nunca afecta al robot
            pass
    threading.Thread(target=run, daemon=True).start()


def close_alt(get, op, lock, save):
    """Al SALIR el robot: precio de venta del contrato alternativo y su resultado (natural = vendes al bid)."""
    a = op.get("alt")
    if not a or a.get("done"):
        return

    def run():
        try:
            j = get("/markets/quotes", {"symbols": a["occ"]})
            q = (_as_list((j.get("quotes") or {}).get("quote")) or [{}])[0]
            b, k = _num(q.get("bid")), _num(q.get("ask"))
            if b is None or k is None:
                return
            n = op.get("qty", 1)
            with lock:
                a.update(out_bid=b, out_mid=round((b + k) / 2, 2), done=True,
                         pnl_nat=round((b - a["in_ask"]) * 100 * n, 2),
                         pnl_mid=round(((b + k) / 2 - a["in_mid"]) * 100 * n, 2))
                save()
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=run, daemon=True).start()


def summary(ops):
    done = [o for o in ops if o.get("status") == "cerrada" and (o.get("alt") or {}).get("done") and o.get("pnl") is not None]
    return {"n": len(done), "spread": round(sum(o["pnl"] for o in done), 2),
            "alt_nat": round(sum(o["alt"]["pnl_nat"] for o in done), 2), "alt_mid": round(sum(o["alt"]["pnl_mid"] for o in done), 2),
            "gana_alt": sum(1 for o in done if o["alt"]["pnl_nat"] > o["pnl"])}
