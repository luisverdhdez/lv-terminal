@echo off
rem Reinicia LV Options Terminal
cd /d "%~dp0"
set PY=pythonw
if exist python_path.txt set /p PY=<python_path.txt
start "" "%PY%" reiniciar_windows.py
