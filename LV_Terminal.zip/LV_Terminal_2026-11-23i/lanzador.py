"""Arranque de la terminal en WINDOWS (en Mac lo hace launchd).
Corre monitor_web.py y, si se cierra (por ejemplo despues de "Actualizar" o de "Reiniciar"), lo vuelve a abrir solo.
Lo deja instalado instalar_windows.ps1 en el Inicio de Windows (arranca al prender la computadora)."""
import os
import socket
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = 8765


def ocupado(port=PORT):
    s = socket.socket()
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def main():
    if ocupado():
        return          # ya hay una terminal abierta: no abrir otra
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")   # acentos y emojis sin errores en Windows
    fallos = 0
    while True:
        t0 = time.time()
        with open(os.path.join(BASE, "panel.log"), "a", encoding="utf-8") as log:
            log.write(f"\n=== arranque {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            log.flush()
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            p = subprocess.Popen([sys.executable, os.path.join(BASE, "monitor_web.py")], cwd=BASE, env=env,
                                 stdout=log, stderr=log, creationflags=flags)
            p.wait()
        fallos = fallos + 1 if time.time() - t0 < 30 else 0
        time.sleep(min(60, 2 + 5 * fallos))   # si truena al arrancar, espera cada vez un poco mas


if __name__ == "__main__":
    main()
