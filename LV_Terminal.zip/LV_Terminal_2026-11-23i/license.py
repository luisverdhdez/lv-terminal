"""Licencias del panel: una clave firmada (RSA, solo libreria estandar) con nombre y fecha de vencimiento.
El programa trae la llave PUBLICA (license_pub.json) y solo puede VERIFICAR claves; las claves las genera el vendedor con su llave privada.
Si no existe license_pub.json (tu copia personal), no se exige licencia.
Nota honesta: una verificacion local frena el uso casual y las copias, no a alguien que edite el codigo."""
import base64
import hashlib
import json
import os
from datetime import date, datetime

BASE = os.path.dirname(os.path.abspath(__file__))
PUB_FILE = os.path.join(BASE, "license_pub.json")
KEY_FILE = os.path.join(BASE, "license.key")
PREFIX = "TP1."
# DigestInfo de SHA-256 (PKCS#1 v1.5)
_DI = bytes.fromhex("3031300d060960864801650304020105000420")


def _b64e(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def encode_em(payload, k):
    """Bloque PKCS#1 v1.5 (00 01 FF..FF 00 DigestInfo hash) como entero de k bytes."""
    t = _DI + hashlib.sha256(payload).digest()
    if k < len(t) + 11:
        raise ValueError("llave demasiado corta")
    return int.from_bytes(b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t, "big")


def _pub():
    try:
        with open(PUB_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return int(d["n"], 16), int(d["e"])
    except (OSError, ValueError, KeyError):
        return None


def required():
    return os.path.exists(PUB_FILE)


def verify(key):
    """-> {'ok': bool, 'name', 'exp', 'days_left', 'plan', 'error'}"""
    pub = _pub()
    if pub is None:
        return {"ok": True, "name": "", "exp": "", "days_left": None, "plan": "sin licencia (copia personal)", "error": ""}
    n, e = pub
    key = (key or "").strip()
    try:
        if not key.startswith(PREFIX):
            raise ValueError
        body, sig = key[len(PREFIX):].split(".")
        payload, s = _b64d(body), int.from_bytes(_b64d(sig), "big")
        k = (n.bit_length() + 7) // 8
        if pow(s, e, n) != encode_em(payload, k):
            raise ValueError
        d = json.loads(payload.decode("utf-8"))
        exp = datetime.strptime(d["exp"], "%Y-%m-%d").date()
    except Exception:
        return {"ok": False, "name": "", "exp": "", "days_left": None, "plan": "", "error": "La clave no es válida. Cópiala completa, sin espacios, tal como te la enviaron."}
    left = (exp - date.today()).days
    if left < 0:
        return {"ok": False, "name": d.get("name", ""), "exp": d["exp"], "days_left": left, "plan": d.get("plan", ""), "error": f"Tu licencia venció el {d['exp']}. Pide una nueva."}
    return {"ok": True, "name": d.get("name", ""), "exp": d["exp"], "days_left": left, "plan": d.get("plan", ""), "error": ""}


def current():
    try:
        with open(KEY_FILE, encoding="utf-8") as f:
            key = f.read().strip()
    except OSError:
        key = ""
    if not key and required():
        return {"ok": False, "name": "", "exp": "", "days_left": None, "plan": "", "error": "Falta activar tu licencia."}
    return verify(key)


def save(key):
    r = verify(key)
    if not r["ok"]:
        return r
    fd = os.open(KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key.strip() + "\n")
    return r
