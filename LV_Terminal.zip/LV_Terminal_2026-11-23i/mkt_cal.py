"""Calendario de la bolsa de EE.UU. (NYSE / Cboe): dias cerrados y dias de cierre temprano (1:00 pm ET).
Los robots y el gestor lo usan para no operar en festivos y para cerrar a tiempo los dias de medio dia.
OJO: hay que agregar los años nuevos cuando la bolsa publique su calendario."""
from datetime import date, datetime

CERRADO = {
    "2026-11-26", "2026-12-25",
    "2027-01-01", "2027-01-18", "2027-02-15", "2027-03-26", "2027-05-31", "2027-06-18",
    "2027-07-05", "2027-09-06", "2027-11-25", "2027-12-24",
}
TEMPRANO = {"2026-11-27", "2026-12-24", "2027-11-26"}   # la bolsa cierra a la 1:00 pm ET
CIERRE_TEMPRANO = "13:00"
SALIDA_TEMPRANO = "12:30"     # el gestor cierra lo que vence ese dia a esta hora (30 min de margen)
ENTRADA_TEMPRANO = "12:00"    # robots: ultima hora para entrar en un dia de medio dia


def _d(x=None):
    if x is None:
        return date.today().isoformat()
    if isinstance(x, (date, datetime)):
        return x.strftime("%Y-%m-%d")
    return str(x)[:10]


def cerrado(x=None):
    """True si la bolsa no abre ese dia (fin de semana o festivo)."""
    s = _d(x)
    return date.fromisoformat(s).weekday() >= 5 or s in CERRADO


def temprano(x=None):
    return _d(x) in TEMPRANO


def cierre(x=None):
    """Hora de cierre (HH:MM, ET) de la sesion normal de ese dia, o None si esta cerrado."""
    if cerrado(x):
        return None
    return CIERRE_TEMPRANO if temprano(x) else "16:00"


def tope(hm, x=None, limite=SALIDA_TEMPRANO):
    """Recorta una hora HH:MM para un dia de cierre temprano (sin cambio en dias normales)."""
    return min(hm, limite) if temprano(x) else hm
