"""Simulacion HACIA ATRAS de un iron condor MENSUAL de SPX (vencimientos AM del tercer viernes).
Uso:  python3 ~/bot/backtest_condor.py
- Baja de Tradier la historia diaria del SPX (apertura y cierre) y del VIX desde 2010. NO manda ordenes.
- Las opciones viejas no tienen historia de precios, asi que los precios se ESTIMAN con Black-Scholes usando
  el VIX del dia como volatilidad (con sesgo: los puts lejanos mas caros, los calls lejanos mas baratos).
- Solo revisa los precios de CIERRE de cada dia: un stop dentro del dia se veria al cierre.
- Guarda el resultado en ~/bot/backtest_condor.json (no imprime ni guarda tus claves).
"""
import json, math, os, sys, time
from datetime import date, timedelta
import requests

ENV_FILE = os.path.expanduser("~/.tradier_env")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backtest_condor.json")
DTE_IN, DELTA, R, Q = 45, 0.16, 0.02, 0.015
SLIP = 0.30            # costo de entrar o salir de las 4 patas (diferencia compra/venta), en puntos
WIDTHS = (10, 25)


def env():
    e = {}
    for ln in open(ENV_FILE, encoding="utf-8"):
        ln = ln.strip()
        if ln.startswith("export "):
            ln = ln[7:]
        if "=" in ln and not ln.startswith("#"):
            k, v = ln.split("=", 1)
            e[k.strip()] = v.strip().strip('"').strip("'")
    return e


def history(e, sym, start="2010-01-01"):
    for base, tok in (("https://api.tradier.com/v1", e.get("TRADIER_LIVE_TOKEN")), ("https://sandbox.tradier.com/v1", e.get("TRADIER_TOKEN"))):
        if not tok:
            continue
        try:
            r = requests.get(base + "/markets/history", params={"symbol": sym, "interval": "daily", "start": start},
                             headers={"Authorization": "Bearer " + tok, "Accept": "application/json"}, timeout=30)
            if r.status_code == 200:
                days = ((r.json().get("history") or {}).get("day")) or []
                days = days if isinstance(days, list) else [days]
                out = {}
                for d in days:
                    try:
                        o, c = float(d["open"]), float(d["close"])
                        if math.isfinite(o) and math.isfinite(c) and o > 0 and c > 0:
                            out[d["date"]] = (o, c)
                    except (KeyError, TypeError, ValueError):
                        pass
                if out:
                    return out
        except requests.RequestException:
            pass
    sys.exit(f"No pude bajar la historia de {sym} de Tradier.")


N = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))


def bs(S, K, T, iv, call):
    if T <= 1e-6:
        return max(S - K, 0) if call else max(K - S, 0)
    sd = iv * math.sqrt(T)
    d1 = (math.log(S / K) + (R - Q + iv * iv / 2) * T) / sd
    d2 = d1 - sd
    if call:
        return S * math.exp(-Q * T) * N(d1) - K * math.exp(-R * T) * N(d2)
    return K * math.exp(-R * T) * N(-d2) - S * math.exp(-Q * T) * N(-d1)


def iv_at(S, K, T, vix):
    """Volatilidad por strike: ATM = 0.88 x VIX; +10% por cada desviacion hacia abajo, -10% hacia arriba."""
    atm = 0.88 * vix / 100
    z = math.log(K / S) / (atm * math.sqrt(max(T, 1 / 365)))
    return max(0.05, atm * (1 - 0.10 * max(-3, min(3, z))))


def delta(S, K, T, vix, call):
    iv = iv_at(S, K, T, vix)
    sd = iv * math.sqrt(T)
    d1 = (math.log(S / K) + (R - Q + iv * iv / 2) * T) / sd
    return math.exp(-Q * T) * (N(d1) if call else N(d1) - 1)


def pick(S, T, vix, call):
    best, bd = None, 9
    for k in range(int(S * 0.6 / 5) * 5, int(S * 1.4 / 5) * 5, 5):
        d = abs(abs(delta(S, k, T, vix, call)) - DELTA)
        if d < bd:
            best, bd = k, d
    return best


def value(S, T, vix, legs):
    """Costo de cerrar el condor (puntos): + cortas - largas."""
    return sum(sg * bs(S, k, T, iv_at(S, k, T, vix), c) for k, c, sg in legs)


def third_fridays(y0, y1):
    for y in range(y0, y1 + 1):
        for m in range(1, 13):
            d = date(y, m, 15)
            while d.weekday() != 4:
                d += timedelta(days=1)
            yield d


def main():
    e = env()
    print("Bajando historia de SPX y VIX de Tradier…")
    spx, vix = history(e, "SPX"), history(e, "VIX")
    # copia de la historia (solo precios publicos del SPX y VIX) para probar variantes sin volver a bajarla
    json.dump({"spx": spx, "vix": vix}, open(os.path.join(os.path.dirname(OUT), "backtest_hist.json"), "w"))
    days = sorted(d for d in spx if d in vix)
    D = [date.fromisoformat(d) for d in days]
    last = D[-1]
    rules = ["vencimiento", "tp50", "stop2x", "21dte", "tp50_stop2x", "tp50_stop2x_21dte"]
    res = {w: {r: [] for r in rules} for w in WIDTHS}
    gaps = []
    for ex in third_fridays(D[0].year, last.year):
        if ex > last or (ex - D[0]).days < DTE_IN + 5:
            continue
        exd = max((d for d in D if d <= ex), default=None)          # feriado: vence el dia habil anterior
        ent = next((d for d in D if 0 < (ex - d).days <= DTE_IN), None)
        if not exd or not ent or ent >= exd:
            continue
        path = [d for d in D if ent <= d < exd]                     # cierres hasta el jueves (ultimo dia de operacion)
        S0, v0 = spx[ent.isoformat()][1], vix[ent.isoformat()][1]
        T0 = ((ex - ent).days - 0.7) / 365
        kp, kc = pick(S0, T0, v0, False), pick(S0, T0, v0, True)
        settle = spx[exd.isoformat()][0]                              # liquidacion AM ~ apertura del viernes
        thu = spx[path[-1].isoformat()][1]
        gaps.append(abs(settle / thu - 1) * 100)
        for w in WIDTHS:
            legs = [(kp, False, 1), (kp - w, False, -1), (kc, True, 1), (kc + w, True, -1)]
            credit = value(S0, T0, v0, legs) - SLIP / 2
            if credit <= 0.2:
                continue
            fin = credit - sum(sg * (max(settle - k, 0) if c else max(k - settle, 0)) for k, c, sg in legs)
            series = []
            for d in path[1:]:
                S, v = spx[d.isoformat()][1], vix[d.isoformat()][1]
                T = ((ex - d).days - 0.7) / 365
                series.append((d, (ex - d).days, credit - value(S, T, v, legs) - SLIP / 2))
            for r in rules:
                tp, st, t21 = "tp50" in r, "stop2x" in r, "21dte" in r
                out, why, when = fin, "vencimiento (AM)", exd
                for d, dte, pnl in series:
                    if tp and pnl >= 0.5 * credit:
                        out, why, when = pnl, "objetivo 50%", d; break
                    if st and pnl <= -credit:
                        out, why, when = pnl, "stop 2x", d; break
                    if t21 and dte <= 21:
                        out, why, when = pnl, "21 dias", d; break
                res[w][r].append({"exp": ex.isoformat(), "ent": ent.isoformat(), "sal": when.isoformat(), "kp": kp, "kc": kc,
                                  "credito": round(credit, 2), "pnl": round(out * 100, 2), "motivo": why,
                                  "riesgo": round((w - credit) * 100, 2)})
    resumen = {}
    for w in WIDTHS:
        for r in rules:
            t = res[w][r]
            if not t:
                continue
            p = [x["pnl"] for x in t]
            eq, pk, dd = 0, 0, 0
            for v in p:
                eq += v; pk = max(pk, eq); dd = min(dd, eq - pk)
            resumen[f"{w}|{r}"] = {"ancho": w, "regla": r, "operaciones": len(p), "ganadoras_pct": round(100 * sum(v > 0 for v in p) / len(p), 1),
                                   "total": round(sum(p), 2), "promedio": round(sum(p) / len(p), 2), "peor": round(min(p), 2),
                                   "mejor": round(max(p), 2), "max_caida": round(dd, 2),
                                   "credito_prom": round(100 * sum(x["credito"] for x in t) / len(t), 2),
                                   "riesgo_prom": round(sum(x["riesgo"] for x in t) / len(t), 2),
                                   "dias_prom": round(sum((date.fromisoformat(x["sal"]) - date.fromisoformat(x["ent"])).days for x in t) / len(t), 1)}
    gs = sorted(gaps)
    out = {"generado": time.strftime("%Y-%m-%d %H:%M"), "desde": days[0], "hasta": days[-1], "dte": DTE_IN, "delta": DELTA,
           "slip": SLIP, "resumen": resumen, "operaciones": {str(w): res[w] for w in WIDTHS},
           "brecha_am": {"n": len(gs), "mediana_pct": round(gs[len(gs) // 2], 2), "p90_pct": round(gs[int(len(gs) * 0.9)], 2), "max_pct": round(gs[-1], 2)}}
    json.dump(out, open(OUT, "w"), indent=1)
    print(f"Listo: {len(gs)} meses simulados ({days[0]} a {days[-1]}). Resultado guardado en {OUT}")


if __name__ == "__main__":
    main()
