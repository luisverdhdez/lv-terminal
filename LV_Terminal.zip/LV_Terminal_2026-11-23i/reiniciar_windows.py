"""Reinicia LV Options Terminal en Windows: cierra el panel y el lanzador lo vuelve a abrir solo.
Si estaba cerrado, lo abre."""
import os
import re
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = 8765


def pid_puerto():
    out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True).stdout
    for ln in out.splitlines():
        m = re.search(r"127\.0\.0\.1:%d\s+\S+\s+LISTENING\s+(\d+)" % PORT, ln)
        if m:
            return m.group(1)
    return None


p = pid_puerto()
if p:
    subprocess.run(["taskkill", "/PID", p, "/F"], capture_output=True)
    print("Reiniciando... en unos segundos recarga el navegador.")
else:
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    f = os.path.join(BASE, "python_path.txt")
    if os.path.exists(f):
        pyw = open(f, encoding="ascii").read().strip()
    subprocess.Popen([pyw if os.path.exists(pyw) else sys.executable, os.path.join(BASE, "lanzador.py")], cwd=BASE,
                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    print("La terminal estaba cerrada: abriendola...")
