"""
Pestaña Dividendos de Fundamentales: TTM, anual proyectado, frecuencia, proximo ex-dividendo, payout, crecimiento,
historia por año (con rendimiento y payout) y cada pago (con pagos futuros ESTIMADOS).
Datos: Yahoo Finance via yfinance (no oficial). Yahoo da la fecha ex-dividendo y el monto; NO da fecha de pago ni de anuncio.
"""
from datetime import date, datetime, timedelta

import fundamentales as F
from fund_ratios import _ser

FREQ_NAME = {12: "Mensual", 4: "Trimestral", 2: "Semestral", 1: "Anual"}


def _load(sym):
    yf = F._yf()

    def go():
        try:
            t = yf.Ticker(sym)
            dv = t.dividends
            hist = t.history(period="12y", interval="1d", auto_adjust=False)
            inc = t.income_stmt
        except Exception as e:
            raise F._wrap(e)
        pays = []
        if dv is not None and len(dv):
            for d, v in dv.items():
                v = F._n(v)
                if v and v > 0:
                    pays.append((str(d)[:10], v))
        px = []
        if hist is not None and not getattr(hist, "empty", True):
            for d, v in hist["Close"].items():
                v = F._n(v)
                if v:
                    px.append((str(d)[:10], v))
        eps = _ser(inc, ("Diluted EPS", "Basic EPS"))
        return {"pays": sorted(pays), "px": px, "eps": {k[:4]: v for k, v in eps.items()}}
    return F._cached(("div2", sym), F.TTL_LONG, go)


def _price_on(px, d):
    lo, hi = 0, len(px) - 1
    best = None
    while lo <= hi:
        m = (lo + hi) // 2
        if px[m][0] <= d:
            best, lo = px[m][1], m + 1
        else:
            hi = m - 1
    return best


def _freq(pays, today):
    last = [p for p in pays if p[0] > (today - timedelta(days=380)).isoformat()]
    n = len(last)
    if n >= 10:
        return 12
    if n >= 3:
        return 4
    if n == 2:
        return 2
    if n == 1:
        return 1
    return None


def _add_months(d, m):
    y, mo = d.year + (d.month - 1 + m) // 12, (d.month - 1 + m) % 12 + 1
    import calendar
    return date(y, mo, min(d.day, calendar.monthrange(y, mo)[1]))


def dividends(env, sym):
    D = _load(sym)
    info = F._info(sym)
    pays, px = D["pays"], D["px"]
    today = date.today()
    price = F._n(F._p(info, "currentPrice", "regularMarketPrice")) or (px[-1][1] if px else None)
    out = {"sym": sym, "has": bool(pays), "price": price}
    if not pays:
        out["warn"] = ["Esta empresa no registra dividendos en Yahoo."]
        return out
    fq = _freq(pays, today)
    ttm = sum(v for d, v in pays if d > (today - timedelta(days=365)).isoformat())
    last_d, last_v = pays[-1]
    fwd = F._n(info.get("dividendRate")) or (last_v * fq if fq else None)
    # proximo ex-dividendo: el de Yahoo si es futuro; si no, estimado con la frecuencia
    nx, nx_est = None, True
    ex = info.get("exDividendDate")
    try:
        exd = datetime.utcfromtimestamp(int(ex)).date() if ex else None
    except (TypeError, ValueError, OverflowError):
        exd = None
    if exd and exd > date.fromisoformat(last_d):
        nx, nx_est = exd, False          # fecha anunciada por Yahoo (posterior al ultimo pago registrado)
    future = []
    if fq:
        step = 12 // fq
        if nx and not nx_est:            # fecha anunciada: va primero y las demas se proyectan desde ella
            future.append({"date": nx.isoformat(), "amount": last_v, "est": False, "anunciada": True})
            base, k = nx, 1
        else:
            base, k = date.fromisoformat(last_d), 1
        while len(future) < 4:
            d = _add_months(base, step * k)
            k += 1
            if d > today - timedelta(days=5):
                future.append({"date": d.isoformat(), "amount": last_v, "est": True})
        if not nx or nx_est:
            nx, nx_est = date.fromisoformat(future[0]["date"]), True
    # historia por año
    years = {}
    for d, v in pays:
        y = d[:4]
        years.setdefault(y, {"dps": 0.0, "n": 0})
        years[y]["dps"] += v
        years[y]["n"] += 1
    rows = []
    for y in sorted(years):
        ps = [p for d, p in px if d[:4] == y]
        avgp = sum(ps) / len(ps) if ps else None
        yr = years[y]
        cur = y == str(today.year)
        dps, n, est = yr["dps"], yr["n"], False
        if cur and fq:   # año en curso: lo pagado + lo estimado que falta
            rest = [f for f in future if f["date"][:4] == y]
            dps += sum(f["amount"] for f in rest)
            n += len(rest)
            est = bool(rest)
        eps = D["eps"].get(y)
        rows.append({"year": y, "dps": round(dps, 4), "n": n, "est": est, "yield": (dps / avgp) if avgp else None,
                     "payout": (dps / eps) if eps and eps > 0 else None, "partial": cur})
    if fq:   # año siguiente estimado
        rows.append({"year": str(today.year + 1), "dps": round(last_v * fq, 4), "n": fq, "est": True,
                     "yield": (last_v * fq / price) if price else None, "payout": None, "partial": False})
    rows = rows[-11:]
    for i, r in enumerate(rows):
        p = rows[i - 1] if i else None
        r["yoy"] = (r["dps"] / p["dps"] - 1) if p and p["dps"] else None
    full = [r for r in rows if not r["partial"] and not r["est"]]
    growth = full[-1]["yoy"] if full and full[-1].get("yoy") is not None else None
    cagr5 = None
    if len(full) >= 6 and full[-6]["dps"] > 0:
        cagr5 = (full[-1]["dps"] / full[-6]["dps"]) ** (1 / 5) - 1
    # cada pago (mas nuevo primero), con rendimiento anualizado al precio de ese dia y cambio vs el pago anterior
    hist = []
    for i, (d, v) in enumerate(pays):
        p = _price_on(px, d)
        prev = pays[i - 1][1] if i else None
        hist.append({"date": d, "amount": v, "yield": (v * fq / p) if p and fq else None,
                     "chg": (v / prev - 1) if prev else None, "est": False})
    hist = [dict(f, yield_=None, chg=None) for f in future[::-1]] + hist[::-1]
    out.update({"ttm": ttm, "ttm_yield": ttm / price if price else None, "fwd": fwd, "fwd_yield": fwd / price if fwd and price else None,
                "freq": fq, "freq_name": FREQ_NAME.get(fq, "Irregular"), "next": nx.isoformat() if nx else None, "next_est": nx_est,
                "next_amount": last_v, "payout": F._n(info.get("payoutRatio")), "growth": growth, "growth_year": full[-1]["year"] if full else None,
                "cagr5": cagr5, "years": rows, "history": hist, "warn": []})
    return out
