"""
Indice de miedo y codicia del panel (calculo propio con datos de Tradier; NO es el indice de CNN).
Seis componentes. Cada uno se califica por cuantas desviaciones estandar se aleja de SU PROPIO promedio reciente
(1 ano para momento y volatilidad, 6 meses para los demas) y se convierte a 0-100 con la curva normal:
  0 sigmas = 50 · +1 = 84 · -1 = 16 · +2 = 98 · -2 = 2.  El indice es el promedio de los componentes disponibles.
La historia (cierre anterior, hace 1 semana / 1 mes / 1 ano y la grafica de 12 meses) se reconstruye con cierres diarios.
El put/call no tiene historia en Tradier: se guarda cada dia en fg_pc.json y entra a la historia desde que existe.
Pesado (≈100 historiales) se calcula una vez al dia en segundo plano; durante el dia solo se refresca con cotizaciones.
"""
import json
import math
import os
import threading
import time
from datetime import datetime, timedelta

import trading

BASE = os.path.dirname(os.path.abspath(__file__))
F_PC = os.path.join(BASE, "fg_pc.json")
IDX = ["SPY", "VIX", "IEF", "HYG"]
DAYS_BACK = 1150          # dias calendario de historia (~3 anos: 1 ano de grafica + ventanas de calculo)
LIVE_TTL = 300
_S = {"hist": None, "key": None, "running": False, "done": 0, "total": 0, "err": None, "live": None, "live_ts": 0}
_LOCK = threading.RLock()
COMPS = [
    ("mom", "Momento del mercado", "S&P 500 (SPY) frente a su media de 125 sesiones", 252, False),
    ("vol", "Volatilidad del mercado", "VIX frente a su media de 50 sesiones", 252, True),
    ("ref", "Demanda de refugio", "Acciones (SPY) frente a bonos del Tesoro de 7-10 años (IEF), 20 sesiones", 126, False),
    ("jnk", "Demanda de bonos basura", "Alto rendimiento (HYG) frente a Tesoro (IEF), 20 sesiones", 126, False),
    ("pc", "Ratio put/call", "Volumen de puts entre calls de SPY (3 vencimientos más cercanos), promedio de 5 días", 126, True),
    ("fza", "Fuerza de las acciones", "Cerca de máximos menos cerca de mínimos de 52 semanas, % de la lista, promedio de 20 días", 126, False),
]


def _num(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def zone(v):
    return ("Miedo extremo" if v < 25 else "Miedo" if v < 45 else "Neutral" if v < 55 else "Codicia" if v < 75 else "Codicia extrema")


def _phi(z):
    return 50.0 * (1.0 + math.erf(z / math.sqrt(2.0)))


def _closes(env, sym, days=DAYS_BACK):
    start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    j = trading._call(env, "GET", "/markets/history", params={"symbol": sym, "interval": "daily", "start": start})
    h = j.get("history") if isinstance(j, dict) else None
    ds = trading._as_list(h.get("day")) if isinstance(h, dict) else []
    return {d["date"]: _num(d.get("close")) for d in ds if d.get("date") and _num(d.get("close")) is not None}


def _quotes(env, syms):
    out = {}
    for i in range(0, len(syms), 60):
        j = trading._call(env, "GET", "/markets/quotes", params={"symbols": ",".join(syms[i:i + 60])})
        qs = trading._as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
        out.update({q.get("symbol"): q for q in qs if isinstance(q, dict)})
    return out


# ───────────── put/call (se guarda un dato por dia) ─────────────
def _pc_load():
    try:
        with open(F_PC, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _pc_today(env, today):
    ex = trading._call(env, "GET", "/markets/options/expirations", params={"symbol": "SPY"})
    dates = trading._as_list((ex.get("expirations") or {}).get("date")) if isinstance(ex.get("expirations"), dict) else []
    dates = [d for d in dates if d >= today][:3]
    pv = cv = 0.0
    for d in dates:
        ch = trading._call(env, "GET", "/markets/options/chains", params={"symbol": "SPY", "expiration": d})
        for o in trading._as_list((ch.get("options") or {}).get("option")) if isinstance(ch.get("options"), dict) else []:
            v = _num(o.get("volume")) or 0
            if o.get("option_type") == "put":
                pv += v
            elif o.get("option_type") == "call":
                cv += v
    if cv <= 0 or pv + cv < 5000:
        return None
    r = round(pv / cv, 3)
    with _LOCK:
        d = _pc_load()
        d[today] = r
        tmp = F_PC + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(dict(sorted(d.items())[-800:]), f)
        os.replace(tmp, F_PC)
    return r


# ───────────── calculo de la serie ─────────────
def _mean(v):
    return sum(v) / len(v)


def _z_scores(x, win):
    """x: lista (con None). z de cada punto frente a las `win` observaciones anteriores (incluida la actual)."""
    out = [None] * len(x)
    for i in range(len(x)):
        if x[i] is None:
            continue
        w = [v for v in x[max(0, i - win + 1):i + 1] if v is not None]
        if len(w) < max(20, win // 2):
            continue
        m = _mean(w)
        sd = math.sqrt(sum((v - m) ** 2 for v in w) / (len(w) - 1))
        out[i] = (x[i] - m) / sd if sd > 1e-12 else 0.0
    return out


def compute(series, stocks, pc, today=None, live=None, cache=None):
    """series: {sym: {fecha: cierre}} de IDX; stocks: {sym: {fecha: cierre}}; pc: {fecha: ratio}.
    live: {sym: ultimo} -> reemplaza/agrega el punto de HOY. Devuelve fechas, componentes y el indice por dia."""
    live = live or {}
    dates = sorted(series.get("SPY", {}))
    if today and live.get("SPY") and (not dates or dates[-1] < today):
        dates.append(today)

    def col(sym, src):
        s = src.get(sym, {})
        out, last = [], None
        for d in dates:
            v = live.get(sym) if (d == today and live.get(sym)) else s.get(d)
            last = v if v is not None else last
            out.append(last)
        return out
    spy, vix, ief, hyg = (col(s, series) for s in IDX)
    n = len(dates)

    def r20(a, i):
        return (a[i] / a[i - 20] - 1) * 100 if i >= 20 and a[i] and a[i - 20] else None
    raw = {k: [None] * n for k, *_ in COMPS}
    for i in range(n):
        if i >= 124 and spy[i]:
            raw["mom"][i] = (spy[i] / _mean(spy[i - 124:i + 1]) - 1) * 100
        if i >= 49 and vix[i] and all(vix[i - 49:i + 1]):
            raw["vol"][i] = (vix[i] / _mean(vix[i - 49:i + 1]) - 1) * 100
        a, b, c = r20(spy, i), r20(ief, i), r20(hyg, i)
        if a is not None and b is not None:
            raw["ref"][i] = a - b
        if c is not None and b is not None:
            raw["jnk"][i] = c - b
    # put/call: promedio de los ultimos 5 datos guardados hasta ese dia (si el ultimo dato no es viejo)
    pcs = sorted(pc.items())
    j = -1
    for i, d in enumerate(dates):
        while j + 1 < len(pcs) and pcs[j + 1][0] <= d:
            j += 1
        if j >= 0 and pcs[j][0] >= dates[max(0, i - 3)]:
            raw["pc"][i] = _mean([r for _, r in pcs[max(0, j - 4):j + 1]])
    # fuerza: % de la lista cerca de maximo de 52 semanas menos % cerca de minimo, promedio de 20 dias
    cache = cache if cache is not None else {}
    cols = [col(s, stocks) for s in stocks]
    daily = [None] * n
    for i in range(251, n):
        d = dates[i]
        if d != today and d in cache:
            daily[i] = cache[d]
            continue
        hi = lo = m = 0
        for cc in cols:
            if cc[i] is None:
                continue
            win = [v for v in cc[i - 251:i + 1] if v is not None]
            if len(win) < 200:
                continue
            m += 1
            hi += cc[i] >= max(win) * 0.95
            lo += cc[i] <= min(win) * 1.05
        daily[i] = (hi - lo) / m * 100 if m >= 20 else None
        if d != today:
            cache[d] = daily[i]
    for i in range(n):
        w = [v for v in daily[max(0, i - 19):i + 1] if v is not None]
        if len(w) >= 10:
            raw["fza"][i] = _mean(w)
    sc, prov = {}, {}
    for k, _, _, win, inv in COMPS:
        z = _z_scores(raw[k], win)
        sc[k] = [None if v is None else round(100 - _phi(v) if inv else _phi(v), 1) for v in z]
        prov[k] = [False] * n
    # put/call sin historia suficiente: rango fijo provisional (ratio 0.7 = codicia ... 1.5 = miedo)
    for i in range(n):
        if sc["pc"][i] is None and raw["pc"][i] is not None:
            sc["pc"][i] = round(100 - max(0.0, min(100.0, (raw["pc"][i] - 0.7) / 0.8 * 100)), 1)
            prov["pc"][i] = True
    idx = []
    for i in range(n):
        v = [sc[k][i] for k, *_ in COMPS if sc[k][i] is not None]
        idx.append(round(_mean(v), 1) if len(v) >= 3 else None)
    return {"dates": dates, "raw": raw, "score": sc, "index": idx, "prov": prov}


# ───────────── trabajo de fondo: historiales (una vez al dia) ─────────────
def _worker(env, key, syms):
    try:
        series, stocks = {}, {}
        _S.update(done=0, total=len(IDX) + len(syms))
        for s in IDX:
            series[s] = _closes(env, s)
            _S["done"] += 1
        for s in syms:
            try:
                stocks[s] = _closes(env, s)
            except trading.ApiError:
                pass
            _S["done"] += 1
            time.sleep(0.3)
        _S.update(hist={"series": series, "stocks": stocks, "ts": time.time(), "cache": {}}, key=key, live=None, err=None)
    except trading.ApiError as e:
        _S["err"] = str(e)
    finally:
        _S["running"] = False


def _fmt(k, x):
    if x is None:
        return "–"
    if k == "pc":
        return f"{x:.2f}"
    if k in ("ref", "jnk"):
        return f"{x:+.2f} pp"
    return f"{x:+.2f}%"


def fear_greed(env, syms):
    today = datetime.now().strftime("%Y-%m-%d")
    key = (today, trading.MODE["live"])
    with _LOCK:
        if _S["key"] != key and not _S["running"]:
            _S["running"] = True
            threading.Thread(target=_worker, args=(env, key, list(syms)), daemon=True).start()
    if _S["hist"] is None:   # la primera vez: hay que bajar ~100 historiales (≈1 min)
        return {"building": True, "done": _S["done"], "total": _S["total"], "err": _S["err"]}
    now = time.time()
    if _S["live"] and now - _S["live_ts"] < LIVE_TTL and _S["live"].get("key") == key:
        return _S["live"]
    h = _S["hist"]
    live = {}
    try:
        q = _quotes(env, IDX + list(h["stocks"]))
        live = {s: _num((q.get(s) or {}).get("last")) for s in q}
    except trading.ApiError:
        pass
    pc = _pc_load()
    nowl = datetime.now()
    if nowl.weekday() < 5 and nowl.hour >= 10:   # dato del dia: desde las 10 (antes hay poco volumen)
        try:
            if _pc_today(env, today) is not None:
                pc = _pc_load()
        except trading.ApiError:
            pass
    nl = datetime.now()
    sesion = nl.weekday() < 5 and (nl.hour, nl.minute) >= (9, 30)   # hoy cuenta solo si ya abrio el mercado
    r = compute(h["series"], h["stocks"], pc, today if sesion else None, live if sesion else {}, h["cache"])
    n = len(r["dates"])
    i = max((k for k in range(n) if r["index"][k] is not None), default=None)
    if i is None:
        return {"building": False, "error": "Sin datos suficientes para el índice"}
    comps = []
    for k, name, desc, win, inv in COMPS:
        s = r["score"][k][i]
        if s is None:
            continue
        last_d = max((r["dates"][j] for j in range(i + 1) if r["raw"][k][j] is not None), default=None)
        comps.append({"key": k, "name": name, "desc": desc, "score": s, "zone": zone(s), "detail": _fmt(k, r["raw"][k][i]),
                      "asof": last_d if last_d != r["dates"][i] else None, "prov": r["prov"][k][i]})
    val = r["index"][i]

    def back(nb):
        j = i - nb
        return {"value": round(r["index"][j]), "zone": zone(r["index"][j]), "date": r["dates"][j]} if j >= 0 and r["index"][j] is not None else None
    chart = [{"d": r["dates"][j], "v": r["index"][j]} for j in range(max(0, i - 251), i + 1) if r["index"][j] is not None]
    out = {"key": key, "value": round(val), "zone": zone(val), "date": r["dates"][i], "comps": comps, "n": len(comps),
           "prev": back(1), "week": back(5), "month": back(21), "year": back(252), "chart": chart,
           "n_stocks": len(h["stocks"]), "pc_days": len(pc), "hist_ts": h["ts"], "ts": now, "live": key[1]}
    _S.update(live=out, live_ts=now)
    return out
