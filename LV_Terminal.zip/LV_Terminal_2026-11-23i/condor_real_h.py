"""Copia del robot de iron condor REAL para la CUENTA 2 (familiar). Mismo codigo que condor_real.py, pero:
- opera SOLO la cuenta 2 (su token), con su propio archivo condor_real_h.json y su propia activacion (ROBOT REAL);
- nunca toca tu cuenta: todas las ordenes y consultas de cuenta van con ACCT = "H"."""
import importlib.util
import os

_here = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("condor_real_h_impl", os.path.join(_here, "condor_real.py"))
_m = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_m)
_m.ACCT = "H"
_m.FILE = os.path.join(_here, "condor_real_h.json")
_m.TAG = "🟣 CUENTA 2"
handle, loop, step, STATE = _m.handle, _m.loop, _m.step, _m.STATE
MOD = _m
