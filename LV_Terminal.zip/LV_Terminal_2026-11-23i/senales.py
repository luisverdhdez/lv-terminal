"""
Modo sombra del robot: registra TODAS las señales del indicador durante el dia (las que el robot toma, las que ignora por el
filtro HH/LL, y las que llegan cuando ya agoto sus operaciones) y mide que hizo SPY despues de cada una.

- NO envia ninguna orden y no toca al robot: solo lee velas de 1 minuto (timesales) y calcula con la MISMA funcion de señal
  que usa el robot (tradier_bot.atr_rma / ut_bot_stop). Como el indicador solo mira hacia atras, se puede recalcular
  todo el dia en cualquier momento: si reinicias el panel no se pierde nada.
- Dos fuentes de datos, cada una en su archivo: papel (sandbox, con atraso) -> senales.csv ; real (en vivo) -> senales_live.csv.
  La de real solo se usa para LEER velas con tu token real; no manda ordenes.
- El movimiento de SPY despues de la señal es un SUSTITUTO: el resultado de una opcion depende ademas de delta, spread y tiempo.
"""
import bisect
import csv
import os
import threading
import time
from datetime import datetime, time as dtime

import tradier_bot as tb

ET = tb.ET
BASE = os.path.dirname(os.path.abspath(__file__))
FILES = {"sandbox": os.path.join(BASE, "senales.csv"), "live": os.path.join(BASE, "senales_live.csv")}
TRADES = {"sandbox": os.path.join(BASE, "trades.csv"), "live": os.path.join(BASE, "trades_live.csv")}
HEAD = ["fecha", "hora_vela", "lado", "precio", "atr", "ref", "cerca_hhll", "corona", "en_horario", "tomada", "pnl_robot",
        "mov5", "mov10", "mov15", "mov30", "mfe30", "mae30"]
HORIZ = (5, 10, 15, 30)
LOCK = threading.Lock()
STATE = {"last": {}, "err": {}}


def _f(x, nd=2):
    return "" if x is None else f"{x:.{nd}f}"


def compute(bars, cfg, today, trades=None):
    """bars: velas de 1 min ordenadas (con historia de varios dias). Devuelve las filas (dict) de las señales de `today`."""
    n = len(bars)
    if n < cfg.ut_atr + 6:
        return []
    highs = [b["h"] for b in bars]
    lows = [b["l"] for b in bars]
    closes = [b["c"] for b in bars]
    ts = [b["ts"] for b in bars]
    atr = tb.atr_rma(highs, lows, closes, cfg.ut_atr)
    stop = tb.ut_bot_stop(closes, atr, cfg.ut_key)
    last_ts = ts[-1]
    corona = tb.mtf_states(bars, cfg)   # +1 / -1 si 1, 3 y 5 min coinciden (igual que la Corona del grafico)
    rows = []
    for i in range(1, n):
        d = datetime.fromtimestamp(ts[i], ET)
        if d.strftime("%Y-%m-%d") != today:
            continue
        if stop[i] is None or stop[i - 1] is None:
            continue
        buy = closes[i] > stop[i] and closes[i - 1] <= stop[i - 1]
        sell = stop[i] > closes[i] and stop[i - 1] <= closes[i - 1]
        if not (buy or sell):
            continue
        side = "buy" if buy else "sell"
        lo = max(0, i - cfg.prox_lookback + 1)
        if side == "sell":
            ref = max(highs[lo:i + 1])
            near = (ref - closes[i]) <= cfg.prox_atr * atr[i]
        else:
            ref = min(lows[lo:i + 1])
            near = (closes[i] - ref) <= cfg.prox_atr * atr[i]
        sg = 1 if buy else -1
        # la vela con ts = inicio de minuto; cierra 60 s despues
        close_dt = datetime.fromtimestamp(ts[i] + 60, ET)
        in_hours = cfg.start <= close_dt.time() < cfg.end
        row = {"fecha": today, "hora_vela": close_dt.strftime("%H:%M"), "lado": side, "precio": _f(closes[i]),
               "atr": _f(atr[i]), "ref": _f(ref), "cerca_hhll": 1 if near else 0, "corona": 1 if corona[i] == sg else 0, "en_horario": 1 if in_hours else 0,
               "tomada": 0, "pnl_robot": "", "_ts": ts[i] + 60}
        for h in HORIZ:
            target = ts[i] + h * 60
            if target > last_ts:
                row[f"mov{h}"] = ""
                continue
            j = bisect.bisect_right(ts, target) - 1
            row[f"mov{h}"] = _f((closes[j] - closes[i]) * sg)
        if ts[i] + 30 * 60 <= last_ts:
            jmax = bisect.bisect_right(ts, ts[i] + 30 * 60)
            hh = max(highs[i + 1:jmax]) if jmax > i + 1 else closes[i]
            ll = min(lows[i + 1:jmax]) if jmax > i + 1 else closes[i]
            if buy:
                row["mfe30"], row["mae30"] = _f(hh - closes[i]), _f(ll - closes[i])
            else:
                row["mfe30"], row["mae30"] = _f(closes[i] - ll), _f(closes[i] - hh)
        else:
            row["mfe30"] = row["mae30"] = ""
        rows.append(row)
    _mark_taken(rows, trades or [], today)
    return rows


def _mark_taken(rows, trades, today):
    """Una operacion del robot (trades.csv) corresponde a la señal 'cerca' del mismo lado cuya vela cerro justo antes."""
    for t in trades:
        if t.get("fecha") != today:
            continue
        try:
            tt = datetime.strptime(today + " " + t["hora"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=ET).timestamp()
        except (ValueError, KeyError):
            continue
        best, bd = None, None
        for r in rows:
            if r["lado"] != t.get("lado") or not r["cerca_hhll"] or r["tomada"]:
                continue
            dt = tt - r["_ts"]
            if -10 <= dt <= 25 * 60 and (bd is None or dt < bd):
                best, bd = r, dt
        if best is not None:
            best["tomada"] = 1
            best["pnl_robot"] = t.get("pnl_usd", "")


def _read_trades(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, newline="") as f:
            return list(csv.DictReader(f))
    except OSError:
        return []


def read_rows(src):
    p = FILES[src]
    if not os.path.exists(p):
        return []
    try:
        with open(p, newline="") as f:
            return list(csv.DictReader(f))
    except OSError:
        return []


def _write(src, today, today_rows):
    keep = [r for r in read_rows(src) if r.get("fecha") != today]
    tmp = FILES[src] + ".tmp"
    with open(tmp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEAD, extrasaction="ignore")
        w.writeheader()
        for r in keep + today_rows:
            w.writerow(r)
    os.replace(tmp, FILES[src])


def update(src, token):
    """Baja las velas y reescribe las filas de HOY de esa fuente. Devuelve cuantas señales hay hoy."""
    cfg = tb.Config()
    b = tb.Tradier(token, "", "live" if src == "live" else "sandbox", True)
    bars = [x for x in b.bars(cfg.symbol) if x["ts"] + 60 <= time.time()]
    today = datetime.now(ET).strftime("%Y-%m-%d")
    rows = compute(bars, cfg, today, _read_trades(TRADES[src]))
    with LOCK:
        _write(src, today, rows)
    return len(rows)


def loop(get_env):
    """Hilo del panel: cada minuto en horario de mercado (y una vez mas despues del cierre para completar las mediciones)."""
    while True:
        try:
            now = datetime.now(ET)
            if now.weekday() < 5 and dtime(9, 31) <= now.time() <= dtime(16, 35):
                env = get_env() or {}
                for src, key in (("sandbox", "TRADIER_TOKEN"), ("live", "TRADIER_LIVE_TOKEN")):
                    tok = env.get(key)
                    if not tok:
                        continue
                    try:
                        STATE["last"][src] = update(src, tok)
                        STATE["err"].pop(src, None)
                    except Exception as e:  # nunca tumbar el panel
                        STATE["err"][src] = e.__class__.__name__
        except Exception:
            pass
        time.sleep(60)


# ───────────── resumen para la pagina ─────────────
def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _stats(rows):
    out = {"n": len(rows)}
    for h in (5, 15, 30):
        v = [_num(r.get(f"mov{h}")) for r in rows]
        v = [x for x in v if x is not None]
        out[f"med{h}"] = len(v)
        out[f"fav{h}"] = (100.0 * sum(1 for x in v if x > 0) / len(v)) if v else None
        out[f"avg{h}"] = (sum(v) / len(v)) if v else None
    mf = [_num(r.get("mfe30")) for r in rows]
    ma = [_num(r.get("mae30")) for r in rows]
    mf, ma = [x for x in mf if x is not None], [x for x in ma if x is not None]
    out["mfe30"] = (sum(mf) / len(mf)) if mf else None
    out["mae30"] = (sum(ma) / len(ma)) if ma else None
    return out


def summary(src):
    rows = read_rows(src)
    groups = {
        "todas": rows,
        "cerca_si": [r for r in rows if r.get("cerca_hhll") == "1"],
        "cerca_no": [r for r in rows if r.get("cerca_hhll") == "0"],
        "corona_si": [r for r in rows if r.get("corona") == "1"],
        "corona_no": [r for r in rows if r.get("corona") == "0"],
        "cerca_y_corona": [r for r in rows if r.get("cerca_hhll") == "1" and r.get("corona") == "1"],
        "tomadas": [r for r in rows if r.get("tomada") == "1"],
        "cerca_no_tomadas": [r for r in rows if r.get("cerca_hhll") == "1" and r.get("tomada") != "1"],
    }
    days = sorted({r["fecha"] for r in rows})
    return {"src": src, "dias": len(days), "stats": {k: _stats(v) for k, v in groups.items()},
            "ultimas": rows[-40:][::-1], "estado": {"ultima": STATE["last"].get(src), "error": STATE["err"].get(src)}}


def handle(path, q):
    src = (q.get("src") or ["sandbox"])[0]
    if src not in FILES:
        src = "sandbox"
    return 200, summary(src)


PAGE = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Señales · LV Options Terminal</title><style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif;padding:16px 24px;max-width:2000px;margin:0 auto}
a{color:var(--cy);text-decoration:none;font-weight:700}h1{font:700 18px ui-monospace,Menlo,monospace;margin:6px 0 12px}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:8px}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 6px;white-space:nowrap}
td{padding:6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
.mono{font-family:ui-monospace,Menlo,monospace}.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}
button{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:6px 12px;cursor:pointer;font-weight:700}
button.on{color:var(--tx);border-color:var(--cy)}.tag{font-size:11px;color:var(--mut)}
</style></head><body>
<div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px"><h1>🔬 SEÑALES · MODO SOMBRA</h1><a href="/">← Inicio</a></div>
<div class="card"><div class="mut" style="font-size:13px;line-height:1.5">Registra <b>todas</b> las señales del indicador durante el día (las que el robot toma, las que ignora y las que llegan cuando ya no puede operar) y mide lo que hizo SPY después. <b>No manda órdenes.</b>
El movimiento es en dólares de SPY <b>a favor de la señal</b> (positivo = el precio fue en la dirección que marcó). Es un sustituto: lo que gana una opción depende además del delta, el spread y el tiempo. Con pocos días son solo indicios.</div>
<div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button id="s_sandbox" onclick="load('sandbox')">Datos de papel (con atraso)</button><button id="s_live" onclick="load('live')">Datos en vivo (cuenta real)</button><span class="tag" id="est"></span></div></div>
<div class="card"><div class="lbl">RESUMEN · <span id="dias"></span></div><div style="overflow-x:auto"><table><thead><tr><th>Grupo</th><th>Señales</th><th>A favor a 5 min</th><th>A favor a 15 min</th><th>Mov. medio 15 min</th><th>A favor a 30 min</th><th>Mejor punto (30 min)</th><th>Peor punto (30 min)</th></tr></thead><tbody id="res"></tbody></table></div></div>
<div class="card" style="border-left-color:var(--warn)"><div class="lbl">COMPARAR CONTRATOS · opción del robot vs debit spread 0DTE (sin órdenes)</div>
<div class="mut" style="font-size:13px;line-height:1.5;margin-bottom:8px">En cada señal en horario del robot se registran dos "operaciones de papel" con precios reales: <b>A)</b> la opción que compra hoy el robot (delta 0.30–0.35, vence el día hábil siguiente; entra al ask, sale al bid) y <b>B)</b> un debit spread 0DTE: compra al dinero y vende 3 puntos más lejos (entra pagando ask−bid, sale bid−ask). Se siguen 35 minutos. Cifras en <b>dólares por contrato</b>, sin comisiones, con salidas fijas a 5/10/15/30 min (el robot real usa stop y trailing, así que es una comparación aproximada). Necesita el token real; solo se registran señales dentro del horario del robot.</div>
<div style="overflow-x:auto"><table><thead><tr><th>Grupo</th><th>Estrategia</th><th>Señales</th><th>Costo medio</th><th>Prom. 5 min</th><th>Prom. 15 min</th><th>Prom. 30 min</th><th>% positivas 15 min</th><th>Mejor punto</th><th>Peor punto</th><th>Tocó +$8</th></tr></thead><tbody id="cmp"></tbody></table></div>
<div class="tag" id="cmpn" style="margin-top:6px"></div></div>
<div class="card"><div class="lbl">ÚLTIMAS SEÑALES</div><div style="overflow-x:auto"><table><thead><tr><th>Fecha</th><th>Hora vela</th><th>Lado</th><th>Precio</th><th>Cerca HH/LL</th><th>Corona 1·3·5</th><th>En horario</th><th>El robot la tomó</th><th>P&amp;L robot</th><th>5 min</th><th>15 min</th><th>30 min</th></tr></thead><tbody id="ult"></tbody></table></div></div>
<script>
const $=id=>document.getElementById(id);let SRC=localStorage.getItem("sen_src")||"sandbox";
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pc=v=>v==null?"–":v.toFixed(0)+"%",mv=v=>v==null?"–":(v>=0?"+":"")+v.toFixed(2);
const cl=v=>v==null?"":v>0?"ok":v<0?"bad":"";
const NAMES={todas:"Todas",cerca_si:"Cerca de HH/LL (pasan el filtro)",cerca_no:"No cerca (el robot las ignora)",corona_si:"Con Corona 1·3·5 (1, 3 y 5 min coinciden)",corona_no:"Sin Corona (no coinciden)",cerca_y_corona:"Cerca de HH/LL + Corona (el filtro más selectivo)",tomadas:"Las que el robot tomó","cerca_no_tomadas":"Pasaron el filtro pero no se tomaron (límite, otra operación abierta…)"};
async function load(s){SRC=s;try{localStorage.setItem("sen_src",s)}catch(e){}
  $("s_sandbox").className=s==="sandbox"?"on":"";$("s_live").className=s==="live"?"on":"";
  const j=await (await fetch("/api/senales?src="+s,{cache:"no-store"})).json();
  $("dias").textContent=j.dias+" día(s) con datos";
  $("est").textContent=j.estado.error?"Error al leer velas: "+j.estado.error:(j.estado.ultima!=null?"Hoy: "+j.estado.ultima+" señales (se actualiza cada minuto en horario de mercado)":"");
  $("res").innerHTML=Object.keys(NAMES).map(k=>{const x=j.stats[k]||{n:0};return '<tr><td>'+NAMES[k]+'</td><td class="mono">'+x.n+'</td><td class="mono">'+pc(x.fav5)+'</td><td class="mono '+cl(x.fav15==null?null:x.fav15-50)+'">'+pc(x.fav15)+'</td><td class="mono '+cl(x.avg15)+'">'+mv(x.avg15)+'</td><td class="mono">'+pc(x.fav30)+'</td><td class="mono ok">'+mv(x.mfe30)+'</td><td class="mono bad">'+mv(x.mae30)+'</td></tr>'}).join("");
  $("ult").innerHTML=j.ultimas.length?j.ultimas.map(r=>'<tr><td>'+esc(r.fecha)+'</td><td class="mono">'+esc(r.hora_vela)+'</td><td>'+(r.lado==="buy"?"▲ Buy":"▼ Sell")+'</td><td class="mono">'+esc(r.precio)+'</td><td>'+(r.cerca_hhll==="1"?"sí":"no")+'</td><td>'+(r.corona==="1"?"👑 sí":"no")+'</td><td>'+(r.en_horario==="1"?"sí":"no")+'</td><td>'+(r.tomada==="1"?"✓ sí":"–")+'</td><td class="mono '+cl(parseFloat(r.pnl_robot))+'">'+esc(r.pnl_robot||"")+'</td><td class="mono '+cl(parseFloat(r.mov5))+'">'+esc(r.mov5)+'</td><td class="mono '+cl(parseFloat(r.mov15))+'">'+esc(r.mov15)+'</td><td class="mono '+cl(parseFloat(r.mov30))+'">'+esc(r.mov30)+'</td></tr>').join(""):'<tr><td colspan="12" class="mut">Aún no hay señales registradas. Se llenan durante el horario de mercado (la primera revisión es a las 9:31).</td></tr>'}
load(SRC);setInterval(()=>load(SRC),30000);
const GN={todas:"Todas las señales",cerca:"Cerca de HH/LL (las que toma el robot)",cerca_corona:"Cerca + Corona 1·3·5"};
async function loadCmp(){try{const j=await (await fetch("/api/sombra_op",{cache:"no-store"})).json();
  const f=(v,p)=>v==null?"–":(p?"":(v>=0?"+":"-")+"$")+(p?v+"%":Math.abs(v).toFixed(0));
  const c=v=>v==null?"":v>0?"ok":v<0?"bad":"";
  let h="";for(const g of Object.keys(GN)){const x=(j.grupos||{})[g];if(!x)continue;
    for(const [k,nm] of [["robot","A) Opción del robot"],["spread","B) Debit spread 0DTE"]]){const y=x[k];
      h+='<tr><td>'+(k==="robot"?GN[g]:"")+'</td><td>'+nm+'</td><td class="mono">'+y.n+'</td><td class="mono">'+(y.cost==null?"–":"$"+y.cost)+'</td><td class="mono '+c(y.avg5)+'">'+f(y.avg5)+'</td><td class="mono '+c(y.avg15)+'">'+f(y.avg15)+'</td><td class="mono '+c(y.avg30)+'">'+f(y.avg30)+'</td><td class="mono">'+f(y.win15,1)+'</td><td class="mono ok">'+f(y.mfe)+'</td><td class="mono bad">'+f(y.mae)+'</td><td class="mono">'+f(y.hit,1)+'</td></tr>'}}
  $("cmp").innerHTML=h||'<tr><td colspan="11" class="mut">Todavía no hay señales registradas. Se llenan solas en horario del robot (9:45–14:30 ET), con el token real configurado.</td></tr>';
  $("cmpn").textContent=j.n+" señal(es) seguidas en total"+(j.err?" · error: "+j.err:"")+". Con menos de ~30 señales son solo indicios."}catch(e){}}
loadCmp();setInterval(loadCmp,30000);

</script></body></html>"""
