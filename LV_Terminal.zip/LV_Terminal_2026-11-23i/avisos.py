"""
Avisos en tiempo real: notificacion nativa de macOS y, si lo configuras en ~/.tradier_env, Telegram, Discord o Slack.
Lo usa monitor_web.py. Variables opcionales en ~/.tradier_env:
    NOTIFY_MAC=1                      (0 para apagar las notificaciones de macOS)
    TELEGRAM_BOT_TOKEN=...  TELEGRAM_CHAT_ID=...
    DISCORD_WEBHOOK_URL=...           SLACK_WEBHOOK_URL=...
"""
import json
import subprocess
import sys

import requests


def channels(env):
    ch = []
    if sys.platform == "darwin" and env.get("NOTIFY_MAC", "1") != "0":
        ch.append("macOS")
    if sys.platform == "win32" and env.get("NOTIFY_MAC", "1") != "0":
        ch.append("Windows")
    if env.get("TELEGRAM_BOT_TOKEN") and env.get("TELEGRAM_CHAT_ID"):
        ch.append("Telegram")
    if env.get("DISCORD_WEBHOOK_URL"):
        ch.append("Discord")
    if env.get("SLACK_WEBHOOK_URL"):
        ch.append("Slack")
    return ch


def _post(url, payload, timeout=8):
    r = requests.post(url, json=payload, timeout=timeout)
    r.raise_for_status()
    return r.status_code


def send(env, title, text):
    """Manda el aviso por todos los canales configurados. Devuelve una lista de textos con el resultado de cada uno."""
    res = []
    if "macOS" in channels(env):
        try:
            esc = lambda s: str(s).replace("\\", "\\\\").replace('"', '\\"')
            subprocess.run(["osascript", "-e", f'display notification "{esc(text)}" with title "{esc(title)}" sound name "Glass"'],
                           capture_output=True, timeout=8)
            res.append("macOS: enviado")
        except Exception as e:
            res.append(f"macOS: error {e.__class__.__name__}")
    if "Windows" in channels(env):
        try:   # globo de notificacion de Windows (sin instalar nada)
            q = lambda s: str(s).replace("'", "''")
            ps = ("Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing;"
                  "$n=New-Object System.Windows.Forms.NotifyIcon;$n.Icon=[System.Drawing.SystemIcons]::Information;$n.Visible=$true;"
                  f"$n.ShowBalloonTip(8000,'{q(title)}','{q(text)}',[System.Windows.Forms.ToolTipIcon]::Info);"
                  "[System.Media.SystemSounds]::Asterisk.Play();Start-Sleep -Seconds 9;$n.Dispose()")
            subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            res.append("Windows: enviado")
        except Exception as e:
            res.append(f"Windows: error {e.__class__.__name__}")
    msg = f"{title}\n{text}"
    for name, fn in (
        ("Telegram", lambda: _post(f"https://api.telegram.org/bot{env.get('TELEGRAM_BOT_TOKEN')}/sendMessage",
                                   {"chat_id": env.get("TELEGRAM_CHAT_ID"), "text": msg})),
        ("Discord", lambda: _post(env.get("DISCORD_WEBHOOK_URL", ""), {"content": msg})),
        ("Slack", lambda: _post(env.get("SLACK_WEBHOOK_URL", ""), {"text": msg})),
    ):
        if name in channels(env):
            try:
                fn()
                res.append(f"{name}: enviado")
            except Exception as e:
                res.append(f"{name}: error ({e.__class__.__name__}) revisa el token/URL y tu internet")
    if not res:
        res.append("No hay ningún canal configurado")
    return res
