"""Pagina /market: panorama del mercado con datos de Tradier (cuenta activa: papel ~15 min de retraso, real en vivo).
Pestanas: Resumen, Mapa de calor, Sectores, Movimientos.  Universo: ~100 de las mayores empresas de EE. UU. (no todo el mercado).
Lo sirve monitor_web.py (/market y /api/market)."""
import math
import threading
import time
from datetime import datetime, timedelta

import trading
import fg
import panorama

# (simbolo, nombre, sector, capitalizacion aprox. en miles de millones (SOLO para el tamano del mapa), indices: n=Nasdaq 100, d=Dow 30)
U = [
    ("NVDA", "NVIDIA", "Tecnología", 4500, "nd"), ("MSFT", "Microsoft", "Tecnología", 3900, "nd"), ("AAPL", "Apple", "Tecnología", 3800, "nd"),
    ("AVGO", "Broadcom", "Tecnología", 1500, "n"), ("ORCL", "Oracle", "Tecnología", 600, ""), ("PLTR", "Palantir", "Tecnología", 400, "n"),
    ("AMD", "AMD", "Tecnología", 450, "n"), ("CRM", "Salesforce", "Tecnología", 250, "d"), ("CSCO", "Cisco", "Tecnología", 280, "nd"),
    ("IBM", "IBM", "Tecnología", 270, "d"), ("ADBE", "Adobe", "Tecnología", 180, "n"), ("NOW", "ServiceNow", "Tecnología", 190, ""),
    ("INTC", "Intel", "Tecnología", 180, "n"), ("QCOM", "Qualcomm", "Tecnología", 170, "n"), ("TXN", "Texas Instruments", "Tecnología", 170, "n"),
    ("AMAT", "Applied Materials", "Tecnología", 160, "n"), ("MU", "Micron", "Tecnología", 200, "n"), ("PANW", "Palo Alto", "Tecnología", 130, "n"),
    ("LRCX", "Lam Research", "Tecnología", 150, "n"), ("KLAC", "KLA", "Tecnología", 130, "n"), ("ANET", "Arista", "Tecnología", 150, "n"),
    ("INTU", "Intuit", "Tecnología", 190, "n"),
    ("GOOGL", "Alphabet", "Comunicaciones", 3600, "n"), ("META", "Meta", "Comunicaciones", 1700, "n"), ("NFLX", "Netflix", "Comunicaciones", 480, "n"),
    ("DIS", "Disney", "Comunicaciones", 200, "d"), ("VZ", "Verizon", "Comunicaciones", 180, "d"), ("T", "AT&T", "Comunicaciones", 170, ""),
    ("TMUS", "T-Mobile", "Comunicaciones", 260, "n"), ("CMCSA", "Comcast", "Comunicaciones", 130, "n"),
    ("AMZN", "Amazon", "Consumo cíclico", 2400, "nd"), ("TSLA", "Tesla", "Consumo cíclico", 1300, "n"), ("HD", "Home Depot", "Consumo cíclico", 380, "d"),
    ("MCD", "McDonald's", "Consumo cíclico", 210, "d"), ("NKE", "Nike", "Consumo cíclico", 100, "d"), ("LOW", "Lowe's", "Consumo cíclico", 140, ""),
    ("SBUX", "Starbucks", "Consumo cíclico", 100, "n"), ("BKNG", "Booking", "Consumo cíclico", 170, "n"), ("TJX", "TJX", "Consumo cíclico", 150, ""),
    ("ABNB", "Airbnb", "Consumo cíclico", 80, "n"),
    ("WMT", "Walmart", "Consumo defensivo", 750, "d"), ("COST", "Costco", "Consumo defensivo", 420, "n"), ("PG", "Procter & Gamble", "Consumo defensivo", 380, "d"),
    ("KO", "Coca-Cola", "Consumo defensivo", 300, "d"), ("PEP", "PepsiCo", "Consumo defensivo", 200, "n"), ("PM", "Philip Morris", "Consumo defensivo", 250, ""),
    ("MDLZ", "Mondelez", "Consumo defensivo", 90, "n"), ("MO", "Altria", "Consumo defensivo", 100, ""), ("CL", "Colgate", "Consumo defensivo", 70, ""),
    ("LLY", "Eli Lilly", "Salud", 900, ""), ("JNJ", "Johnson & Johnson", "Salud", 450, "d"), ("UNH", "UnitedHealth", "Salud", 300, "d"),
    ("ABBV", "AbbVie", "Salud", 380, ""), ("MRK", "Merck", "Salud", 250, "d"), ("TMO", "Thermo Fisher", "Salud", 210, ""),
    ("ABT", "Abbott", "Salud", 220, ""), ("AMGN", "Amgen", "Salud", 170, "nd"), ("ISRG", "Intuitive Surgical", "Salud", 190, "n"),
    ("PFE", "Pfizer", "Salud", 150, ""), ("GILD", "Gilead", "Salud", 140, "n"), ("DHR", "Danaher", "Salud", 150, ""),
    ("JPM", "JPMorgan", "Financiero", 800, "d"), ("V", "Visa", "Financiero", 650, "d"), ("MA", "Mastercard", "Financiero", 500, ""),
    ("BAC", "Bank of America", "Financiero", 360, ""), ("WFC", "Wells Fargo", "Financiero", 280, ""), ("GS", "Goldman Sachs", "Financiero", 220, "d"),
    ("MS", "Morgan Stanley", "Financiero", 220, ""), ("AXP", "American Express", "Financiero", 230, "d"), ("C", "Citigroup", "Financiero", 180, ""),
    ("BLK", "BlackRock", "Financiero", 170, ""), ("SCHW", "Charles Schwab", "Financiero", 170, ""), ("TRV", "Travelers", "Financiero", 60, "d"),
    ("GE", "GE Aerospace", "Industrial", 300, ""), ("CAT", "Caterpillar", "Industrial", 260, "d"), ("RTX", "RTX", "Industrial", 210, ""),
    ("HON", "Honeywell", "Industrial", 140, "nd"), ("UNP", "Union Pacific", "Industrial", 140, ""), ("BA", "Boeing", "Industrial", 150, "d"),
    ("LMT", "Lockheed Martin", "Industrial", 110, ""), ("DE", "Deere", "Industrial", 120, ""), ("UPS", "UPS", "Industrial", 90, ""),
    ("MMM", "3M", "Industrial", 80, "d"),
    ("XOM", "Exxon Mobil", "Energía", 480, ""), ("CVX", "Chevron", "Energía", 280, "d"), ("COP", "ConocoPhillips", "Energía", 130, ""),
    ("SLB", "Schlumberger", "Energía", 60, ""), ("EOG", "EOG Resources", "Energía", 70, ""),
    ("LIN", "Linde", "Materiales", 200, "n"), ("SHW", "Sherwin-Williams", "Materiales", 90, "d"), ("FCX", "Freeport-McMoRan", "Materiales", 70, ""),
    ("NEM", "Newmont", "Materiales", 80, ""),
    ("PLD", "Prologis", "Inmobiliario", 100, ""), ("AMT", "American Tower", "Inmobiliario", 90, ""), ("EQIX", "Equinix", "Inmobiliario", 80, ""),
    ("NEE", "NextEra", "Servicios públicos", 150, ""), ("SO", "Southern Co", "Servicios públicos", 100, ""), ("DUK", "Duke Energy", "Servicios públicos", 90, ""),
]
# ETF sectoriales SPDR (nombre, ciclico?)
SECT = {"XLK": ("Tecnología", 1), "XLC": ("Comunicaciones", 1), "XLY": ("Consumo discrecional", 1), "XLF": ("Financiero", 1),
        "XLI": ("Industrial", 1), "XLE": ("Energía", 1), "XLB": ("Materiales", 1), "XLP": ("Consumo defensivo", 0),
        "XLV": ("Salud", 0), "XLU": ("Servicios públicos", 0), "XLRE": ("Inmobiliario", 0)}
INDEX = {"SPY": "S&P 500", "QQQ": "Nasdaq 100", "DIA": "Dow 30", "IWM": "Russell 2000"}

_LOCK = threading.RLock()
_C = {"q": (0, None), "h": (0, None, None)}      # (ts, datos[, modo])
_Q_TTL, _H_TTL = 20, 15 * 60


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _quotes(env, syms):
    out = {}
    for i in range(0, len(syms), 60):
        j = trading._call(env, "GET", "/markets/quotes", params={"symbols": ",".join(syms[i:i + 60])})
        qs = trading._as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
        out.update({q.get("symbol"): q for q in qs if isinstance(q, dict)})
    return out


def _closes(env, sym):
    start = (datetime.now() - timedelta(days=400)).strftime("%Y-%m-%d")
    j = trading._call(env, "GET", "/markets/history", params={"symbol": sym, "interval": "daily", "start": start})
    h = j.get("history") if isinstance(j, dict) else None
    days = trading._as_list(h.get("day")) if isinstance(h, dict) else []
    return [(d.get("date"), _num(d.get("close"))) for d in days if _num(d.get("close")) is not None]


def _periods(closes, last, today):
    """Rendimiento % de 1S / 1M / en el ano frente a los cierres anteriores a hoy."""
    cs = [c for d, c in closes if d and d < today]
    if not cs or not last:
        return {}
    out = {}
    for k, n in (("1S", 5), ("1M", 21)):
        if len(cs) >= n:
            out[k] = (last / cs[-n] - 1) * 100
    prev_year = [c for d, c in closes if d and d < f"{today[:4]}-01-01"]
    if prev_year:
        out["YTD"] = (last / prev_year[-1] - 1) * 100
    return out


def data(env):
    """Una sola foto del mercado (cacheada unos segundos): indices, sectores, universo de acciones."""
    now = time.time()
    mode = trading.MODE["live"]
    with _LOCK:
        ts, d = _C["q"]
        if d is not None and now - ts < _Q_TTL and d.get("live") == mode:
            return d
        syms = [u[0] for u in U] + list(SECT) + list(INDEX)
        by = _quotes(env, syms)
        today = datetime.now().strftime("%Y-%m-%d")
        if _C["h"][1] is None or now - _C["h"][0] > _H_TTL or _C["h"][2] != mode:
            hist = {}
            for s in list(SECT) + ["SPY"]:
                try:
                    hist[s] = _closes(env, s)
                except trading.ApiError:
                    hist[s] = []
            _C["h"] = (now, hist, mode)
        hist = _C["h"][1]

        def row(s, q):
            return {"sym": s, "last": _num(q.get("last")), "pct": _num(q.get("change_percentage")), "chg": _num(q.get("change")),
                    "vol": _num(q.get("volume")), "prev": _num(q.get("prevclose"))}
        stocks = []
        for sym, name, sec, cap, fl in U:
            q = by.get(sym)
            if q and _num(q.get("last")) is not None:
                r = row(sym, q); r.update(name=name, sector=sec, cap=cap, idx=fl)
                stocks.append(r)
        sectors = []
        for s, (nm, cyc) in SECT.items():
            q = by.get(s)
            if q and _num(q.get("last")) is not None:
                r = row(s, q); r.update(name=nm, cyc=cyc, per=_periods(hist.get(s, []), r["last"], today)); sectors.append(r)
        spy_q = by.get("SPY")
        spy = None
        if spy_q and _num(spy_q.get("last")) is not None:
            spy = row("SPY", spy_q); spy["per"] = _periods(hist.get("SPY", []), spy["last"], today)
        index = [dict(row(s, by[s]), name=n) for s, n in INDEX.items() if s in by and _num(by[s].get("last")) is not None]
        d = {"ts": now, "live": mode, "stocks": stocks, "sectors": sectors, "spy": spy, "index": index,
             "missing": len(U) - len(stocks)}
        _C["q"] = (now, d)
        return d


# ───────────── Miedo y codicia (calculado con datos de Tradier; NO es el indice de CNN) ─────────────
_FG = {"ts": 0, "d": None, "live": None}


def _lin(x, lo, hi):
    """Mapea x de [lo, hi] a 0..100 (recortado)."""
    return max(0.0, min(100.0, (x - lo) / (hi - lo) * 100.0))


def _ret(closes, n, last=None):
    cs = [c for _, c in closes]
    if last is not None:
        base = cs[-n] if len(cs) >= n else None
        return (last / base - 1) * 100 if base else None
    return (cs[-1] / cs[-n - 1] - 1) * 100 if len(cs) > n else None


def _zone(v):
    return ("Miedo extremo" if v < 25 else "Miedo" if v < 45 else "Neutral" if v < 55 else "Codicia" if v < 75 else "Codicia extrema")


def fear_greed(env):
    now = time.time()
    mode = trading.MODE["live"]
    if _FG["d"] and now - _FG["ts"] < 300 and _FG["live"] == mode:
        return _FG["d"]
    by = _quotes(env, ["SPY", "TLT", "HYG", "IEF", "VIX"])
    comps = []

    def add(name, desc, score, detail):
        if score is not None:
            comps.append({"name": name, "desc": desc, "score": round(score, 1), "zone": _zone(score), "detail": detail})

    def hist(sym):
        try:
            return _closes(env, sym)
        except trading.ApiError:
            return []
    spy_h = hist("SPY")
    spy_last = _num((by.get("SPY") or {}).get("last"))
    # 1 momento: SPY frente a su media de 125 sesiones
    if spy_last and len(spy_h) >= 125:
        sma = sum(c for _, c in spy_h[-125:]) / 125
        dv = (spy_last / sma - 1) * 100
        add("Momento del mercado", "S&P 500 (SPY) frente a su media de 125 sesiones", _lin(dv, -6, 6), f"{dv:+.2f}%")
    # 2 volatilidad: VIX frente a su media de 50 sesiones (mas alto = mas miedo)
    vix = _num((by.get("VIX") or {}).get("last"))
    vh = hist("VIX")
    if vix and len(vh) >= 50:
        av = sum(c for _, c in vh[-50:]) / 50
        dv = (vix / av - 1) * 100
        add("Volatilidad del mercado", "VIX frente a su media de 50 sesiones", 100 - _lin(dv, -25, 40), f"{dv:+.2f}%")
    # 3 fuerza: acciones cerca de maximos vs minimos de 52 semanas (lista de grandes empresas)
    near_hi = near_lo = n = 0
    try:
        uq = _quotes(env, [u[0] for u in U])
    except trading.ApiError:
        uq = {}
    for q in uq.values():
        l, hi, lo = _num(q.get("last")), _num(q.get("week_52_high")), _num(q.get("week_52_low"))
        if l and hi and lo:
            n += 1
            near_hi += l >= hi * 0.95
            near_lo += l <= lo * 1.05
    if n >= 20:
        d = (near_hi - near_lo) / n * 100
        add("Fuerza del mercado", "Cerca de máximos menos cerca de mínimos de 52 semanas (lista)", _lin(d, -30, 30), f"{near_hi} en máximos · {near_lo} en mínimos de {n}")
    # 4 refugio: acciones (SPY) vs bonos largos (TLT) en 20 sesiones
    tlt_h = hist("TLT")
    if spy_h and tlt_h and spy_last and _num((by.get("TLT") or {}).get("last")):
        d = _ret(spy_h, 20, spy_last) - _ret(tlt_h, 20, _num(by["TLT"]["last"]))
        add("Demanda de refugio", "Acciones frente a bonos del Tesoro largos (SPY vs TLT, 20 sesiones)", _lin(d, -6, 6), f"{d:+.2f} pp")
    # 5 bonos basura: HYG frente a IEF en 20 sesiones
    hyg_h, ief_h = hist("HYG"), hist("IEF")
    if hyg_h and ief_h and _num((by.get("HYG") or {}).get("last")) and _num((by.get("IEF") or {}).get("last")):
        d = _ret(hyg_h, 20, _num(by["HYG"]["last"])) - _ret(ief_h, 20, _num(by["IEF"]["last"]))
        add("Demanda de bonos basura", "Alto rendimiento frente a deuda pública (HYG vs IEF, 20 sesiones)", _lin(d, -3, 3), f"{d:+.2f} pp")
    # 6 put/call de SPY en el vencimiento mas cercano
    try:
        ex = trading._call(env, "GET", "/markets/options/expirations", params={"symbol": "SPY"})
        dates = trading._as_list((ex.get("expirations") or {}).get("date")) if isinstance(ex.get("expirations"), dict) else []
        if dates:
            ch = trading._call(env, "GET", "/markets/options/chains", params={"symbol": "SPY", "expiration": dates[0]})
            opts = trading._as_list((ch.get("options") or {}).get("option")) if isinstance(ch.get("options"), dict) else []
            pv = sum(_num(o.get("volume")) or 0 for o in opts if o.get("option_type") == "put")
            cv = sum(_num(o.get("volume")) or 0 for o in opts if o.get("option_type") == "call")
            if cv > 0 and pv + cv > 1000:
                r = pv / cv
                add("Ratio put/call", "Volumen de puts entre calls de SPY (vencimiento más cercano, hoy)", 100 - _lin(r, 0.6, 1.4), f"{r:.2f}")
    except trading.ApiError:
        pass
    if not comps:
        raise trading.ApiError("No pude calcular ningún componente del índice (sin datos de Tradier)")
    val = sum(c["score"] for c in comps) / len(comps)
    d = {"value": round(val), "zone": _zone(val), "comps": comps, "n": len(comps), "ts": now, "live": mode}
    _FG.update(ts=now, d=d, live=mode)
    return d


# ───────────── Volatilidad: IV 30d, HV 20d e IV/HV de la lista (se calcula en segundo plano, con pausas) ─────────────
_V = {"rows": {}, "running": False, "ts": 0, "done": 0, "total": 0, "live": None, "err": None}
_V_TTL = 30 * 60


def _hv20(closes):
    cs = [c for _, c in closes][-21:]
    if len(cs) < 15:
        return None
    r = [math.log(cs[i] / cs[i - 1]) for i in range(1, len(cs)) if cs[i] > 0 and cs[i - 1] > 0]
    if len(r) < 10:
        return None
    m = sum(r) / len(r)
    return math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1)) * math.sqrt(252) * 100


def _iv30(env, sym, last):
    ex = trading._call(env, "GET", "/markets/options/expirations", params={"symbol": sym})
    dates = trading._as_list((ex.get("expirations") or {}).get("date")) if isinstance(ex.get("expirations"), dict) else []
    today = datetime.now().date()
    best, bd = None, None
    for d in dates:
        try:
            dd = (datetime.strptime(d, "%Y-%m-%d").date() - today).days
        except ValueError:
            continue
        if dd >= 14 and (bd is None or abs(dd - 30) < abs(bd - 30)):
            best, bd = d, dd
    if not best:
        return None
    ch = trading._call(env, "GET", "/markets/options/chains", params={"symbol": sym, "expiration": best, "greeks": "true"})
    opts = trading._as_list((ch.get("options") or {}).get("option")) if isinstance(ch.get("options"), dict) else []
    ivs = []
    for t in ("call", "put"):
        side = [o for o in opts if o.get("option_type") == t and _num(o.get("strike")) is not None and _num((o.get("greeks") or {}).get("mid_iv"))]
        if side:
            o = min(side, key=lambda o: abs(_num(o["strike"]) - last))
            ivs.append(_num(o["greeks"]["mid_iv"]) * 100)
    return sum(ivs) / len(ivs) if ivs else None


def _vol_worker(env, mode, snap):
    try:
        for i, s in enumerate(snap):
            try:
                iv = _iv30(env, s["sym"], s["last"])
                hv = _hv20(_closes(env, s["sym"])) if iv is not None else None
                if iv is not None:
                    _V["rows"][s["sym"]] = {"sym": s["sym"], "name": s["name"], "last": s["last"], "pct": s["pct"], "iv": round(iv, 1),
                                            "hv": round(hv, 1) if hv else None, "ivhv": round(iv / hv, 2) if hv else None}
            except trading.ApiError as e:
                _V["err"] = str(e)
            _V["done"] = i + 1
            time.sleep(0.35)
        _V["ts"] = time.time()
    finally:
        _V["running"] = False


def volatility(env):
    now = time.time()
    mode = trading.MODE["live"]
    with _LOCK:
        stale = _V["live"] != mode or now - _V["ts"] > _V_TTL
        if stale and not _V["running"]:
            snap = [dict(s) for s in data(env)["stocks"] if s["last"]]
            _V.update(running=True, rows={}, done=0, total=len(snap), live=mode, err=None)
            threading.Thread(target=_vol_worker, args=(env, mode, snap), daemon=True).start()
    by = _quotes(env, ["VIX"])
    v = by.get("VIX") or {}
    return {"vix": {"last": _num(v.get("last")), "pct": _num(v.get("change_percentage"))} if _num(v.get("last")) is not None else None,
            "rows": list(_V["rows"].values()), "done": _V["done"], "total": _V["total"], "running": _V["running"], "err": _V["err"], "ts": _V["ts"]}


# ───────────── Tarjetas de indices (Resumen): indice real si Tradier lo da; si no, su ETF ─────────────
CARDS = [  # (clave, nombre, insignia, color, [(simbolo, multiplicador, nota)])
    ("spx", "S&P 500", "500", "#e5484d", [("SPX", 1, "SPX"), ("SPY", 1, "SPY (ETF)")]),
    ("ndx", "Nasdaq 100", "100", "#3b82f6", [("NDX", 1, "NDX"), ("QQQ", 1, "QQQ (ETF)")]),
    ("dji", "Dow Jones", "30", "#8b5cf6", [("DJI", 1, "DJI"), ("DJX", 100, "DJX × 100"), ("DIA", 1, "DIA (ETF)")]),
    ("rut", "Russell 2000", "2K", "#f59e0b", [("RUT", 1, "RUT"), ("IWM", 1, "IWM (ETF)")]),
    ("vix", "VIX", "VIX", "#f97316", [("VIX", 1, "VIX")]),
    ("gld", "Oro", "Au", "#eab308", [("GLD", 1, "vía ETF GLD")]),
    ("uso", "Petróleo (WTI)", "WTI", "#94a3b8", [("USO", 1, "vía ETF USO")]),
    ("btc", "Bitcoin", "₿", "#f7931a", [("IBIT", 1, "vía ETF IBIT")]),
]
_CARD = {"ts": 0, "sts": 0, "d": None, "live": None, "slive": None, "spark": {}}


def _spark(env, sym):
    """Velas de 5 min de la ultima sesion (hoy si ya abrio)."""
    start = (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d 09:30")
    j = trading._call(env, "GET", "/markets/timesales", params={"symbol": sym, "interval": "5min", "session_filter": "open", "start": start})
    s = j.get("series") if isinstance(j, dict) else None
    pts = trading._as_list(s.get("data")) if isinstance(s, dict) else []
    pts = [(p.get("time") or "", _num(p.get("close"))) for p in pts if _num(p.get("close")) is not None]
    if not pts:
        return []
    last_day = pts[-1][0][:10]
    return [round(c, 4) for tm, c in pts if tm[:10] == last_day]


YREAL = {"gld": ("GC=F", "Futuros COMEX · Yahoo"), "uso": ("CL=F", "Futuros NYMEX · Yahoo"), "btc": ("BTC-USD", "BTC-USD · Yahoo")}
_YR = {}


def _yahoo_day(sym):
    """Precio, cierre anterior y velas de 5 min del dia (Yahoo, no oficial). Cache 60 s."""
    c = _YR.get(sym)
    if c and time.time() - c[0] < 60:
        return c[1]
    import requests
    r = requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}", params={"range": "1d", "interval": "5m"},
                     headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
    r.raise_for_status()
    res = ((r.json().get("chart") or {}).get("result") or [None])[0]
    meta = res.get("meta") or {}
    cl = [x for x in (((res.get("indicators") or {}).get("quote") or [{}])[0].get("close") or []) if x is not None]
    last, prev = _num(meta.get("regularMarketPrice")), _num(meta.get("chartPreviousClose") or meta.get("previousClose"))
    if not last:
        raise ValueError("sin precio")
    v = {"last": last, "prev": prev, "spark": [round(x, 2) for x in cl]}
    _YR[sym] = (time.time(), v)
    return v


def cards(env):
    now = time.time()
    mode = trading.MODE["live"]
    with _LOCK:
        if _CARD["d"] and now - _CARD["ts"] < 30 and _CARD["live"] == mode:
            return _CARD["d"]
    allsyms = [s for c in CARDS for s, _, _ in c[4]]
    by = _quotes(env, allsyms)
    clock = {}
    try:
        clock = (trading._call(env, "GET", "/markets/clock") or {}).get("clock") or {}
    except trading.ApiError:
        pass
    refresh = now - _CARD["sts"] > 120 or _CARD["slive"] != mode   # graficas: cada 2 min
    out = []
    for key, name, badge, color, cands in CARDS:
        if key in YREAL:
            ys, note = YREAL[key]
            try:
                y = _yahoo_day(ys)
                pct = (y["last"] / y["prev"] - 1) * 100 if y["prev"] else None
                out.append({"key": key, "name": name, "badge": badge, "color": color, "sym": ys, "note": note,
                            "last": round(y["last"], 2), "pct": pct, "chg": (y["last"] - y["prev"]) if y["prev"] else None,
                            "prev": round(y["prev"], 2) if y["prev"] else None, "spark": y["spark"], "etf": False, "usd": True, "index": False})
                continue
            except Exception:
                pass                      # sin Yahoo: se usa el ETF de Tradier como antes
        for sym, mult, note in cands:
            q = by.get(sym) or {}
            last = _num(q.get("last"))
            if last is None or last <= 0:
                continue
            sp = _CARD["spark"].get(sym)
            if refresh or sp is None:
                try:
                    sp = [round(v * mult, 2) for v in _spark(env, sym)]
                except trading.ApiError:
                    sp = sp or []
                _CARD["spark"][sym] = sp
            prev = _num(q.get("prevclose"))
            out.append({"key": key, "name": name, "badge": badge, "color": color, "sym": sym, "note": note,
                        "last": round(last * mult, 2), "pct": _num(q.get("change_percentage")), "chg": (_num(q.get("change")) or 0) * mult,
                        "prev": round(prev * mult, 2) if prev else None, "spark": sp, "etf": "ETF" in note,
                        "index": sym in ("SPX", "NDX", "DJI", "DJX", "RUT", "VIX")})
            break
    d = {"cards": out, "live": mode, "ts": now,
         "clock": {"state": clock.get("state"), "next_change": clock.get("next_change"), "next_state": clock.get("next_state"),
                   "desc": clock.get("description")}}
    with _LOCK:
        _CARD.update(d=d, ts=now, live=mode)
        if refresh:
            _CARD.update(sts=now, slive=mode)
    return d


def handle(q, env):
    what = (q.get("what") or [""])[0] if isinstance(q, dict) else ""
    try:
        if what == "fg":
            return 200, fg.fear_greed(env, [u[0] for u in U])
        if what == "rep":
            import resultados
            return 200, resultados.data(env)
        if what == "eco":
            import economia
            return 200, economia.data(env)
        if what == "inv":
            import investors
            return 200, investors.handle(q if isinstance(q, dict) else {})
        if what == "rank":
            import ranking
            return 200, ranking.rank(env)
        if what in ("tsy", "tech", "comm", "fx"):
            return panorama.handle(what, env)
        if what == "cards":
            return 200, cards(env)
        if what == "vol":
            return 200, volatility(env)
        return 200, data(env)
    except trading.ApiError as e:
        return 502, {"error": str(e)}


PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Market · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff;--gold:#e8b04a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:12px}
h1{font-size:28px;margin:0;color:#7c6cff}a{color:var(--cy);text-decoration:none;font-weight:700}
.tabs{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 14px;border-bottom:1px solid var(--line);padding-bottom:12px}
.tab{background:none;border:1px solid transparent;color:var(--tx);padding:8px 14px;border-radius:9px;cursor:pointer;font-size:15px}
.tab.on{border-color:var(--line);background:#121216;color:var(--gold)}.tab.off{color:#4a5670;cursor:not-allowed}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:14px}
.lbl{font-weight:800;letter-spacing:.04em;font-size:13px;margin-bottom:4px}.sub{color:var(--mut);font-size:12px;margin-bottom:10px}
.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}
.pill{align-self:flex-start;white-space:nowrap;background:#121216;border:1px solid var(--line);color:var(--mut);padding:4px 10px;border-radius:99px;font-size:12px;cursor:pointer}.pill.on{color:var(--gold);border-color:var(--gold)}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.cgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,280px),1fr));gap:14px;margin-bottom:14px}
.icard{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px 14px 0;text-align:center;position:relative;overflow:hidden;min-height:150px;display:flex;flex-direction:column}
.icard .bdg{display:inline-block;min-width:40px;padding:3px 8px;border-radius:7px;font:800 13px ui-monospace,Menlo,monospace;margin:0 auto 6px}
.icard .nm{font-size:12px;font-weight:700;letter-spacing:.08em;color:var(--mut)}
.icard .px{font-size:25px;font-weight:800;margin:4px auto 0;padding:0 6px;border-radius:6px;font-variant-numeric:tabular-nums}
.icard .ch{font-weight:700;font-size:14px;margin-top:2px}.icard .nt{font-size:11px;color:var(--mut);margin:4px 0 6px}
.icard .lv{position:absolute;top:12px;right:12px;font-size:10px;font-weight:800;letter-spacing:.06em}
.icard svg{display:block;margin-top:auto}
.clk{display:inline-flex;gap:6px;align-items:center;border:1px solid var(--line);border-radius:999px;padding:4px 12px;font-size:13px;margin-right:12px;white-space:nowrap}
@media(max-width:640px){.cgrid{grid-template-columns:1fr 1fr;gap:10px}.icard{padding:12px 8px 0;min-height:130px}.icard .px{font-size:18px}.icard .ch{font-size:12px}.icard .lv{font-size:0;top:10px;right:10px}.icard .lv::first-letter{font-size:12px}.icard .nm{font-size:10.5px}}
.pgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,360px),1fr));gap:14px;margin-bottom:14px;align-items:start}
.yb{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,150px),1fr));gap:8px;margin:8px 0 14px}
.yb>div{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:9px 12px}.yb .t{font-size:12px;color:var(--mut);font-weight:700}
.yb .v{font-size:17px;font-weight:800;font-variant-numeric:tabular-nums}.yb .d{font-size:12.5px;font-weight:700}
.crow{display:grid;grid-template-columns:minmax(0,1.3fr) 64px minmax(50px,1fr) 66px;gap:10px;align-items:center;padding:7px 0;border-top:1px solid var(--line)}
.crow .n b{display:block;font-size:13.5px}.crow .n span{font-size:11.5px;color:var(--mut)}.crow .p{text-align:right;font-weight:700;font-size:13px;font-variant-numeric:tabular-nums}
.cbar{position:relative;height:8px;background:#202027;border-radius:4px}.cbar i{position:absolute;top:0;height:100%;border-radius:4px}.cbar u{position:absolute;left:50%;top:-2px;bottom:-2px;width:1px;background:#7d8aa5}
.trow{display:flex;align-items:center;gap:10px;padding:8px 0;border-top:1px solid var(--line)}.trow .av{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;font-weight:900;font-size:15px;flex:none}
.gh{font-size:11.5px;font-weight:800;letter-spacing:.08em;color:var(--mut);margin:12px 0 2px}
.chip{display:inline-block;font-size:12px;font-weight:800;padding:2px 9px;border-radius:999px;margin-right:8px}
.rk3{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:12px;margin-bottom:12px}
.rkt td,.rkt th{padding:8px 8px}.rkt tbody tr{border-top:1px solid var(--line)}.rkt tbody tr:hover{background:#121216}
.rkt th.s{cursor:pointer;user-select:none}.rkt th.s:hover{color:var(--tx)}.rkt th.on{color:#e8b04a}
.med{display:inline-grid;place-items:center;width:24px;height:24px;border-radius:50%;font-size:11.5px;font-weight:800;background:#202027;color:#9fb0cc}
.secc{display:inline-block;font-size:11.5px;font-weight:700;padding:2px 9px;border-radius:999px;white-space:nowrap}
.tchip{display:inline-flex;gap:5px;align-items:center;border:1px solid var(--line);border-radius:999px;padding:3px 9px 3px 4px;font-size:12px;font-weight:800;margin:0 4px 5px 0}
.tchip i{width:18px;height:18px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-size:10px}
.badge1t{font-size:10px;font-weight:800;color:#7cc4ff;background:#7cc4ff1f;border-radius:6px;padding:1px 5px;margin-left:5px}
.ivg{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.ivc{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px;cursor:pointer;text-align:center}.ivc:hover{border-color:#e8b04a}.ivc.sel{border-color:#e8b04a;box-shadow:0 0 0 1px #e8b04a}
.ivav{width:46px;height:46px;border-radius:50%;display:grid;place-items:center;font-weight:900;margin:0 auto 6px;font-size:15px}
.ivs{width:24px;height:24px;border-radius:50%;display:inline-grid;place-items:center;font-size:9.5px;font-weight:800;margin-left:-6px;border:2px solid var(--card)}
.ivr{display:grid;grid-template-columns:34px minmax(0,1fr) auto 72px;gap:10px;align-items:center;padding:8px 0;border-top:1px solid var(--line)}
.tile{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.g4{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}
.lrow{display:flex;justify-content:space-between;gap:8px;padding:7px 0;border-top:1px solid var(--line);font-size:13px}.lrow:first-child{border-top:0}
#heat{position:relative;width:100%;height:68vh;min-height:420px;background:#000000;border-radius:8px;overflow:hidden}
.hc{position:absolute;overflow:hidden;border:1px solid #000000;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.15;text-shadow:0 1px 2px rgba(0,0,0,.6)}
.hs{position:absolute;color:#cfd8ea;font-size:11px;font-weight:700;letter-spacing:.03em;padding:1px 4px;pointer-events:none;white-space:nowrap;overflow:hidden}
.srow{display:grid;grid-template-columns:34px 190px 56px 1fr 80px;gap:10px;align-items:center;padding:7px 8px;border:1px solid var(--line);border-radius:9px;margin-bottom:6px;background:#08080a;font-size:14px}
.bar{position:relative;height:14px;background:#16161b;border-radius:7px}.bar i{position:absolute;top:0;bottom:0;border-radius:7px}.bar u{position:absolute;left:50%;top:-2px;bottom:-2px;width:1px;background:#33405f}
th{font-weight:600;padding:6px}th:nth-child(n+3){text-align:right}td{padding:6px}
.seg{display:flex;gap:2px}.seg i{flex:1;height:10px;border-radius:2px}
@media(max-width:800px){.srow{grid-template-columns:28px 1fr 70px}.srow .bar,.srow .xs{display:none}}
</style></head><body><main>
<header><h1>Market</h1>
 <div class="mono" style="font-size:13px"><span id="clk"></span><span class="mut" id="st"></span> &nbsp; <a href="/">← Inicio</a> &nbsp; <a href="/trade">Trading →</a> &nbsp; <a href="/portafolio">Portafolio →</a></div></header>
<div class="tabs" id="tabs"></div>
<div id="msg" class="mut" style="margin-bottom:10px"></div>
<div id="view"></div>
<script>
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const TABS=[["res","Resumen"],["rank","Ranking"],["inv","Inversionistas"],["heat","Mapa de calor"],["sec","Sectores"],["mov","Movimientos"],["vol","Volatilidad"],["eco","Economía"],["rep","Resultados"],["fg","Miedo y codicia"]];
let D=null,TAB=localStorage.getItem("mk_tab")||"res",IDX=localStorage.getItem("mk_idx")||"S",PER=localStorage.getItem("mk_per")||"hoy";
if(!TABS.some(t=>t[0]===TAB&&!t[2]))TAB="res";
const fp=v=>v==null?"–":(v>=0?"+":"")+v.toFixed(2)+"%",cl=v=>v==null?"mut":v>=0?"ok":"bad";
const fm=v=>v==null?"–":v>=1e9?(v/1e9).toFixed(1)+" mil M":v>=1e6?(v/1e6).toFixed(1)+" M":(v/1e3).toFixed(0)+" mil";
function tabs(){$("tabs").innerHTML=TABS.map(t=>'<button class="tab'+(t[0]===TAB?" on":"")+(t[2]?" off":"")+'" '+(t[2]?'title="Necesita datos que Tradier no da; pendiente"':'onclick="setTab(\''+t[0]+'\')"')+'>'+t[1]+'</button>').join("")}
function setTab(t){TAB=t;if(t==="vol"){VO=null}if(t==="fg"){FG=null}localStorage.setItem("mk_tab",t);tabs();paint()}
function inIdx(s){return IDX==="S"||s.idx.includes(IDX==="N"?"n":"d")}
function idxPills(){return '<div style="display:flex;gap:6px">'+[["S","Mayores EE. UU."],["N","Nasdaq 100"],["D","Dow 30"]].map(x=>'<span class="pill'+(IDX===x[0]?" on":"")+'" onclick="setIdx(\''+x[0]+'\')">'+x[1]+'</span>').join("")+'</div>'}
function setIdx(i){IDX=i;localStorage.setItem("mk_idx",i);paint()}
function heatCol(p){if(p==null)return"#3a4152";const a=Math.min(Math.abs(p)/3,1);const g=p>=0;const base=g?[38,166,80]:[214,48,64],gray=[58,64,80];
  const m=base.map((b,i)=>Math.round(gray[i]+(b-gray[i])*(0.25+0.75*a)));return"rgb("+m.join(",")+")"}
function squarify(items,x,y,w,h){const out=[];items=items.filter(i=>i.v>0).sort((a,b)=>b.v-a.v);const tot=items.reduce((s,i)=>s+i.v,0);if(!tot)return out;
  const k=w*h/tot;let rest=items.map(i=>({i,a:i.v*k}));
  const worst=(row,side)=>{const s=row.reduce((t,r)=>t+r.a,0),mx=Math.max(...row.map(r=>r.a)),mn=Math.min(...row.map(r=>r.a));return Math.max(side*side*mx/(s*s),s*s/(side*side*mn))};
  while(rest.length){const side=Math.min(w,h);let row=[rest[0]],n=1;
    while(n<rest.length&&worst(row.concat(rest[n]),side)<=worst(row,side)){row.push(rest[n]);n++}
    rest=rest.slice(n);const s=row.reduce((t,r)=>t+r.a,0);
    if(w>=h){const rw=s/h;let yy=y;row.forEach(r=>{const rh=r.a/rw;out.push({it:r.i,x,y:yy,w:rw,h:rh});yy+=rh});x+=rw;w-=rw}
    else{const rh=s/w;let xx=x;row.forEach(r=>{const rw=r.a/rh;out.push({it:r.i,x:xx,y,w:rw,h:rh});xx+=rw});y+=rh;h-=rh}}
  return out}
let CD=null;
async function loadCards(){try{CD=await getw("cards");clk();if(TAB==="res"&&$("cards"))$("cards").innerHTML=cardsHTML()}catch(e){if($("cards")&&!CD)$("cards").innerHTML='<div class="mut">No pude cargar los índices: '+esc(e.message||e)+'</div>'}}
function nyNow(){const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/New_York",hour:"2-digit",minute:"2-digit",hour12:false}).formatToParts(new Date());const g=k=>+p.find(x=>x.type===k).value;return{h:g("hour")%24,m:g("minute")}}
function clk(){const c=(CD||{}).clock||{},n=nyNow(),hm=String(n.h).padStart(2,"0")+":"+String(n.m).padStart(2,"0");let left="";
  if(c.next_change&&/^\d\d:\d\d$/.test(c.next_change)){let d=(+c.next_change.slice(0,2)*60+ +c.next_change.slice(3))-(n.h*60+n.m);if(d<0)d+=1440;left=d>=60?Math.floor(d/60)+"h "+(d%60)+"m":d+"m"}
  const S={open:["#3fd38a","Abierto","cierra en"],premarket:["#ffc04d","Pre-mercado","abre en"],postmarket:["#ffc04d","Post-mercado","cierra en"],closed:["#ff5d6c","Cerrado",""]}[c.state]||["#7d8aa5","–",""];
  $("clk").innerHTML=c.state?'<span class="clk"><b style="color:'+S[0]+'">● '+S[1]+'</b>'+(left&&S[2]?'<span class="mut">· '+S[2]+' '+left+'</span>':'')+'<span class="mut">·</span><b>'+hm+' ET</b></span>':''}
function sparkSVG(pts,prev,up){if(!pts||pts.length<3)return'<div style="height:64px"></div>';const W=260,H=64,all=prev?pts.concat([prev]):pts,mn=Math.min(...all),mx=Math.max(...all),r=mx-mn||1;
  const x=i=>i*W/(pts.length-1),y=v=>4+(1-(v-mn)/r)*(H-8),col=up?"#3fd38a":"#ff5d6c",id="g"+Math.random().toString(36).slice(2,8);
  const line=pts.map((v,i)=>(i?"L":"M")+x(i).toFixed(1)+" "+y(v).toFixed(1)).join("");
  return '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%;height:64px" aria-hidden="true"><defs><linearGradient id="'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+col+'" stop-opacity=".35"/><stop offset="1" stop-color="'+col+'" stop-opacity="0"/></linearGradient></defs>'
   +(prev?'<line x1="0" x2="'+W+'" y1="'+y(prev).toFixed(1)+'" y2="'+y(prev).toFixed(1)+'" stroke="#7d8aa5" stroke-dasharray="3 4" stroke-width="1" opacity=".55" vector-effect="non-scaling-stroke"/>':'')
   +'<path d="'+line+' L'+W+' '+H+' L0 '+H+' Z" fill="url(#'+id+')"/><path d="'+line+'" fill="none" stroke="'+col+'" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>'}
function cardsHTML(){if(!CD)return'<div class="mut">Cargando índices…</div>';
  const fmt=(v,etf)=>(etf?"$":"")+v.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});const isU=c=>c.etf||c.usd;
  return CD.cards.map(c=>{const good=c.key==="vix"?(c.pct||0)<=0:(c.pct||0)>=0,col=good?"#3fd38a":"#ff5d6c",arrow=(c.pct||0)>=0?"▲":"▼";
    return '<div class="icard" title="'+esc(c.name)+' · '+esc(c.note)+(c.prev?' · cierre anterior '+fmt(c.prev,isU(c)):'')+'">'+(c.index?'<span class="lv" style="color:'+(CD.live?"#3fd38a":"#ffc04d")+'">● '+(CD.live?"EN VIVO":"~15 MIN")+'</span>':'')
     +'<span class="bdg" style="color:'+c.color+';background:'+c.color+'22;border:1px solid '+c.color+'66">'+esc(c.badge)+'</span><div class="nm">'+esc(c.name.toUpperCase())+'</div>'
     +'<div class="px" style="background:'+col+'14">'+fmt(c.last,isU(c))+'</div><div class="ch" style="color:'+col+'">'+(c.pct==null?"–":arrow+" "+(c.pct>=0?"+":"")+c.pct.toFixed(2)+"%")+'</div><div class="nt">'+esc(c.note)+'</div>'
     +sparkSVG(c.spark,c.prev,good)+'</div>'}).join("")}
let TS=null,TE=null,CM=null,FXD=null,PERC="1D",PERF="1D";try{PERC=localStorage.getItem("mk_pc")||"1D";PERF=localStorage.getItem("mk_pf")||"1D"}catch(e){}
const PERS=[["1D","1D"],["1W","1S"],["1M","1M"],["3M","3M"],["YTD","Año"],["1Y","1A"]];
async function loadPano(w,force){try{const j=await getw(w);if(w==="tsy")TS=j;if(w==="tech")TE=j;if(w==="comm")CM=j;if(w==="fx")FXD=j}catch(e){const m={error:String(e.message||e)};if(w==="tsy")TS=TS&&!TS.error?TS:m;if(w==="tech")TE=TE&&!TE.error?TE:m;if(w==="comm")CM=CM&&!CM.error?CM:m;if(w==="fx")FXD=FXD&&!FXD.error?FXD:m}
  const el=$("pn_"+w);if(el&&TAB==="res")el.innerHTML=({tsy:tsyHTML,tech:techHTML,comm:commHTML,fx:fxHTML})[w]()}
function loadAllPano(){["tsy","tech","comm","fx"].forEach(w=>loadPano(w))}
const errBox=j=>'<div class="mut" style="font-size:13px">No pude cargar estos datos: '+esc(j.error)+'</div>';
const bpsTxt=(v,rev)=>v==null?"–":(v>0?"▲ ":v<0?"▼ ":"")+Math.abs(v)+" pb";
function miniSpark(pts,up){if(!pts||pts.length<2)return'<span></span>';const W=64,H=24,mn=Math.min(...pts),mx=Math.max(...pts),r=mx-mn||1;
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:64px;height:24px" aria-hidden="true"><path d="'+pts.map((v,i)=>(i?"L":"M")+(i*W/(pts.length-1)).toFixed(1)+" "+(2+(1-(v-mn)/r)*(H-4)).toFixed(1)).join("")+'" fill="none" stroke="'+(up?"#3fd38a":"#ff5d6c")+'" stroke-width="1.6" stroke-linejoin="round"/></svg>'}
function cBar(p,mx){if(p==null)return'<div class="cbar"><u></u></div>';const w=Math.min(50,Math.abs(p)/(mx||1)*50);return '<div class="cbar"><u></u><i style="'+(p>=0?"left:50%":"right:50%")+';width:'+w.toFixed(1)+'%;background:'+(p>=0?"#3fd38a":"#ff5d6c")+'"></i></div>'}
function perPills(cur,fn){return '<div style="display:flex;gap:4px;flex-wrap:wrap">'+PERS.map(p=>'<span class="pill'+(cur===p[0]?" on":"")+'" onclick="'+fn+'(\''+p[0]+'\')">'+p[1]+'</span>').join("")+'</div>'}
function setPC(p){PERC=p;try{localStorage.setItem("mk_pc",p)}catch(e){}$("pn_comm").innerHTML=commHTML()}
function setPF(p){PERF=p;try{localStorage.setItem("mk_pf",p)}catch(e){}$("pn_fx").innerHTML=fxHTML()}
function curveSVG(c){const W=900,H=300,L=40,R=40,T=36,B=40,pts=c.filter(x=>x.v!=null);if(pts.length<3)return"";
  const all=[];c.forEach(x=>{[x.v,x.m,x.y].forEach(v=>{if(v!=null)all.push(v)})});const mn=Math.min(...all)-.15,mx=Math.max(...all)+.15;
  const x=i=>L+i*(W-L-R)/(c.length-1),y=v=>T+(1-(v-mn)/(mx-mn))*(H-T-B);
  const path=k=>{let d="";c.forEach((p,i)=>{if(p[k]!=null)d+=(d?"L":"M")+x(i).toFixed(1)+" "+y(p[k]).toFixed(1)});return d};
  const today=path("v");
  return '<svg viewBox="0 0 '+W+' '+(H+30)+'" style="width:100%;max-width:960px;height:auto;display:block;margin:0 auto" role="img" aria-label="Curva de rendimientos"><path d="'+today+' L'+x(c.length-1)+' '+(H-B)+' L'+x(0)+' '+(H-B)+' Z" fill="#c9a24a" opacity=".09"/>'
   +'<path d="'+path("y")+'" fill="none" stroke="#9aa6bd" stroke-width="2" stroke-dasharray="2 6" stroke-linecap="round"/><path d="'+path("m")+'" fill="none" stroke="#9aa6bd" stroke-width="2.2" stroke-dasharray="9 7"/>'
   +'<path d="'+today+'" fill="none" stroke="#c9a24a" stroke-width="3.5" stroke-linejoin="round"/>'
   +c.map((p,i)=>(p.v==null?"":'<circle cx="'+x(i)+'" cy="'+y(p.v)+'" r="7" fill="#c9a24a" stroke="#e6ecf5" stroke-width="2.5"/><text x="'+x(i)+'" y="'+(y(p.v)-15)+'" text-anchor="middle" font-size="15" font-weight="800" fill="#e6ecf5">'+p.v.toFixed(2)+'%</text>')+'<text x="'+x(i)+'" y="'+(H-B+28)+'" text-anchor="middle" font-size="15" fill="#8a96ad">'+p.t.replace("M"," M").replace("Y"," A")+'</text>').join("")
   +'</svg><div style="display:flex;gap:18px;justify-content:center;flex-wrap:wrap;font-size:12.5px;color:var(--mut)"><span><b style="color:#c9a24a">━━</b> Hoy</span><span>╌╌ Hace 1 mes</span><span>┈┈ Hace 1 año</span></div>'}
function s102SVG(s){if(!s||s.length<10)return"";const W=900,H=180,L=34,T=26,B=26,vs=s.map(p=>p.v),mn=Math.min(0,...vs),mx=Math.max(0,...vs)+5;
  const x=i=>L+i*(W-L-8)/(s.length-1),y=v=>T+(1-(v-mn)/(mx-mn))*(H-T-B);const hi=vs.indexOf(Math.max(...vs)),lo=vs.indexOf(Math.min(...vs));
  const line=s.map((p,i)=>(i?"L":"M")+x(i).toFixed(1)+" "+y(p.v).toFixed(1)).join("");const MES=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  let ml="",lm="";s.forEach((p,i)=>{const m=p.d.slice(5,7);if(m!==lm&&i>4&&i<s.length-10)ml+='<text x="'+x(i)+'" y="'+(H+12)+'" font-size="12" fill="#8a96ad" text-anchor="middle">'+MES[+m-1]+'</text>';lm=m});
  const lab=(i,dy)=>'<text x="'+x(i)+'" y="'+(y(vs[i])+dy)+'" text-anchor="middle" font-size="13" font-weight="800" fill="#c8d2e4">'+(vs[i]>0?"+":"")+vs[i]+'</text>';
  return '<svg viewBox="0 0 '+W+' '+(H+18)+'" style="width:100%;max-width:960px;height:auto;display:block;margin:0 auto" role="img" aria-label="10 años menos 2 años, último año"><path d="'+line+' L'+x(s.length-1)+' '+y(0)+' L'+x(0)+' '+y(0)+' Z" fill="#2fae72" opacity=".16"/>'
   +'<line x1="'+L+'" x2="'+W+'" y1="'+y(0)+'" y2="'+y(0)+'" stroke="#8a96ad" stroke-dasharray="4 5"/><text x="'+(L-8)+'" y="'+(y(0)+4)+'" text-anchor="end" font-size="12" fill="#8a96ad">0</text>'
   +'<path d="'+line+'" fill="none" stroke="#c9a24a" stroke-width="2.2"/>'+lab(hi,-10)+lab(lo,22)+'<circle cx="'+x(s.length-1)+'" cy="'+y(vs[vs.length-1])+'" r="5" fill="#c9a24a" stroke="#e6ecf5" stroke-width="2"/>'+ml+'</svg>'}
function tsyHTML(){const j=TS;if(!j)return'<div class="mut">Cargando bonos del Tesoro…</div>';if(j.error)return errBox(j);
  const fd=d=>d?d.slice(8,10)+"/"+d.slice(5,7)+"/"+d.slice(0,4):"",E=j.estado,ec={normal:"#2fae72",plana:"#c9b04a",invertida:"#ff5d6c"}[E[0]];
  const live=j.live.some(x=>x.v!=null)?'<div class="gh">ÚLTIMO · CBOE <span style="font-weight:600;letter-spacing:0">(vía Yahoo, puede tener retraso)</span></div><div class="yb">'+j.live.map(x=>'<div><div class="t">'+x.t.replace("Y"," años")+'</div><div class="v">'+(x.v==null?"–":x.v.toFixed(3)+"%")+'</div><div class="d mut">'+(x.bps==null?"":bpsTxt(x.bps)+" hoy")+'</div></div>').join("")+'</div>':'';
  const sp=Object.entries(j.spreads).map(([k,v])=>'<div><div class="t">'+k.replace(/Y/g," años").replace(/(\d)M/g,"$1 meses").replace("-"," − ")+'</div><div class="v" style="color:'+(v==null?"":v>=0?"#3fd38a":"#ff5d6c")+'">'+(v==null?"–":(v>0?"+":"")+v+" pb")+'</div></div>').join("");
  const s=j.s102||[],vs=s.map(p=>p.v);
  return '<div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800">🏛 BONOS DEL TESORO</div><div class="sub">Rendimientos de la deuda del gobierno de EE. UU. · pb = puntos básicos (100 pb = 1%)</div>'+live
   +'<div class="gh">CIERRE OFICIAL DEL TESORO · AL '+fd(j.fecha)+'</div><div style="margin:4px 0 2px;font-size:13px"><span class="chip" style="background:'+ec+'26;color:'+ec+'">'+E[1]+'</span><span class="mut">'+esc(E[2])+'</span></div>'
   +'<div class="yb" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,110px),1fr))">'+j.curve.map(c=>'<div style="text-align:center"><div class="t">'+c.t.replace("M"," mes"+(c.t==="1M"?"":"es")).replace("Y"," año"+(c.t==="1Y"?"":"s"))+'</div><div class="v">'+(c.v==null?"–":c.v.toFixed(2)+"%")+'</div><div class="d mut" title="frente a hace 1 mes">'+bpsTxt(c.dm)+'</div></div>').join("")+'</div>'
   +'<div class="mut" style="font-size:11.5px;margin:-8px 0 10px">El cambio de cada plazo es frente a hace 1 mes ('+fd(j.fecha_mes)+').</div>'
   +'<div class="yb">'+sp+'</div><div class="gh">CURVA DE RENDIMIENTOS</div><div style="overflow-x:auto"><div style="min-width:620px">'+curveSVG(j.curve)+'</div></div>'
   +'<div class="gh" style="margin-top:16px">10 AÑOS − 2 AÑOS · ÚLTIMO AÑO</div><div style="overflow-x:auto"><div style="min-width:620px">'+s102SVG(s)+'</div></div>'
   +(vs.length?'<div class="mut" style="font-size:12px;line-height:1.5;margin-top:4px">Se marcan el máximo y el mínimo del año. '+(j.inv_days?'La curva estuvo <b>invertida '+j.inv_days+' día(s)</b> en los últimos 12 meses (el bono de 2 años pagó más que el de 10).':'La curva <b>no se invirtió</b> en los últimos 12 meses: el de 10 años siempre pagó más que el de 2.')+' La inversión ha precedido recesiones en el pasado, con meses o años de retraso y no siempre.</div>':'')
   +'<div class="mut" style="font-size:11px;margin-top:6px">Fuente: Departamento del Tesoro de EE. UU. (curva oficial, se publica una vez al día por la tarde).</div>'}
function avCol(s,a){let h=0;for(const c of s)h=(h*31+c.charCodeAt(0))%360;return "hsla("+h+",60%,60%,"+(a==null?1:a)+")"}
function techHTML(){const j=TE;if(!j)return'<div class="mut">Cargando…</div>';if(j.error)return errBox(j);
  return '<div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800">⚡ TECNOLÓGICAS Y POPULARES</div>'+j.rows.map(r=>{const c=avCol(r.sym),up=(r.pct||0)>=0;
    return '<div class="trow"><span class="av" style="background:'+avCol(r.sym,.15)+';color:'+c+';border:1px solid '+avCol(r.sym,.4)+'">'+r.sym[0]+'</span><b style="flex:1;color:#e8b04a">'+r.sym+'</b><span style="font-variant-numeric:tabular-nums">$'+r.last.toFixed(2)+'</span><b style="min-width:84px;white-space:nowrap;text-align:right;color:'+(up?"#3fd38a":"#ff5d6c")+'">'+(r.pct==null?"–":(up?"▲ +":"▼ ")+r.pct.toFixed(2)+"%")+'</b></div>'}).join("")}
function perRow(name,sub,per,P,mx){const x=per[P]||{},p=x.pct,up=(p||0)>=0;return '<div class="crow"><div class="n"><b>'+esc(name)+'</b><span>'+sub+'</span></div>'+miniSpark(x.spark,up)+cBar(p,mx)+'<div class="p" style="color:'+(p==null?"":up?"#3fd38a":"#ff5d6c")+'">'+(p==null?"–":(p>0?"+":"")+p.toFixed(2)+"%")+'</div></div>'}
function commHTML(){const j=CM;if(!j)return'<div class="mut">Cargando…</div>';if(j.error)return errBox(j);
  const all=j.grupos.flatMap(g=>g.rows.map(r=>Math.abs((r.per[PERC]||{}).pct||0))),mx=Math.max(1,...all);
  return '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center"><div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800;margin:0">🏆 MATERIAS PRIMAS</div>'+perPills(PERC,"setPC")+'</div>'
   +j.grupos.map(g=>'<div class="gh">'+esc(g.grupo.toUpperCase())+'</div>'+g.rows.map(r=>perRow(r.name,r.sym+" · $"+r.last.toFixed(2),r.per,PERC,mx)).join("")).join("")
   +'<div class="mut" style="font-size:11.5px;margin-top:10px;line-height:1.45">Precio y % del <b>ETF</b> de cada materia prima (GLD, USO…), no del contrato. Los ETF de futuros pueden separarse del precio al contado por el cambio de contratos (roll). El precio real del oro, el petróleo y el bitcoin está en las tarjetas de arriba.</div>'}
function fxHTML(){const j=FXD;if(!j)return'<div class="mut">Cargando…</div>';if(j.error)return errBox(j);
  const all=j.majors.concat(j.crosses).map(r=>Math.abs((r.per[PERF]||{}).pct||0)),mx=Math.max(.2,...all),d=j.dollar[PERF];
  const fx=v=>v>=20?v.toFixed(2):v.toFixed(4);
  return '<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center"><div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800;margin:0">💱 DIVISAS</div>'+perPills(PERF,"setPF")+'</div>'
   +'<div class="yb" style="grid-template-columns:1fr;margin-top:10px"><div><div class="t">Dólar frente a 7 monedas principales</div><div class="v" style="color:'+(d==null?"":d>=0?"#3fd38a":"#ff5d6c")+'">'+(d==null?"–":(d>0?"+":"")+d.toFixed(2)+"%")+'</div><div class="d mut">'+(d==null?"":d>=0?"el dólar se fortalece":"el dólar se debilita")+'</div></div></div>'
   +'<div class="gh">PRINCIPALES CONTRA EL DÓLAR</div>'+j.majors.map(r=>perRow(r.name,fx(r.last),r.per,PERF,mx)).join("")
   +'<div class="gh">CRUZADAS</div>'+j.crosses.map(r=>perRow(r.name,fx(r.last),r.per,PERF,mx)).join("")
   +'<div class="mut" style="font-size:11.5px;margin-top:10px">Fuente: Yahoo Finance (no oficial; puede tener retraso).'+(j.errors.length?' Sin datos: '+esc(j.errors.join(", "))+'.':'')+'</div>'}
let RK=null,RKF="all",RKT="all",RKQ="",RKS="cap",RKD=-1,RKN=50,rkT=null;
async function loadRank(){try{RK=await getw("rank");if(TAB==="rank")paint();clearTimeout(rkT);if(TAB==="rank")rkT=setTimeout(loadRank,RK.building?6000:30000)}catch(e){if($("view")&&TAB==="rank")$("view").innerHTML='<div class="card bad">No pude cargar el ranking: '+esc(e.message||e)+'</div>'}}
const SECC={"Tecnología":"#7c8cff","Comunicaciones":"#3fc8e8","Consumo cíclico":"#c47cff","Consumo defensivo":"#c9a46a","Energía":"#ff9a4d","Financiero":"#5c9cff","Industrial":"#9aa6bd","Inmobiliario":"#e88a6a","Materiales":"#8bc34a","Salud":"#ff6fa3","Servicios públicos":"#4dd0a0","ETF":"#e8b04a"};
const capF=v=>v==null?"–":v>=1e12?"$"+(v/1e12).toFixed(2)+"T":v>=1e9?"$"+(v/1e9).toFixed(1)+"B":"$"+(v/1e6).toFixed(0)+"M";
const volF=v=>v==null||!v?"–":v>=1e9?(v/1e9).toFixed(1)+"B":v>=1e6?(v/1e6).toFixed(1)+"M":(v/1e3).toFixed(0)+"K";
function rkAv(s){const c=avCol(s);return '<span class="av" style="width:28px;height:28px;border-radius:8px;display:inline-grid;place-items:center;font-weight:900;font-size:13px;background:'+avCol(s,.15)+';color:'+c+';border:1px solid '+avCol(s,.4)+'">'+s[0]+'</span>'}
function rkRows(){if(!RK)return[];let r=RK.rows.slice();if(RKF!=="all")r=r.filter(x=>!x.etf&&x.idx.includes(RKF));if(RKT==="st")r=r.filter(x=>!x.etf);if(RKT==="etf")r=r.filter(x=>x.etf);
  const q=RKQ.trim().toUpperCase();if(q)r=r.filter(x=>x.sym.includes(q)||(x.name||"").toUpperCase().includes(q));
  const rank={};RK.rows.forEach((x,i)=>rank[x.sym]=i+1);r.forEach(x=>x.rk=rank[x.sym]);
  r.sort((a,b)=>((a[RKS]??-1e18)-(b[RKS]??-1e18))*RKD);return r}
function setRK(k,v){if(k==="f")RKF=v;if(k==="t")RKT=v;if(k==="s"){if(RKS===v)RKD=-RKD;else{RKS=v;RKD=-1}}if(k==="n")RKN=v;$("rk_tbl").innerHTML=rkTable();$("rk_ctl").innerHTML=rkCtl()}
function rkCtl(){const r=rkRows();return [["all","Todo"],["st","Acciones"],["etf","ETF"]].map(x=>'<span class="pill'+(RKT===x[0]?" on":"")+'" onclick="setRK(\'t\',\''+x[0]+'\')">'+x[1]+'</span>').join("")+'<span class="mut" style="font-size:12px;margin-left:6px">'+Math.min(RKN,r.length)+' de '+r.length+'</span>'}
function rkTable(){const r=rkRows(),mx=Math.max(...RK.rows.map(x=>x.cap||0))||1,sh=r.slice(0,RKN);
  const th=(k,l,al)=>'<th class="s'+(RKS===k?" on":"")+'" style="text-align:'+(al||"right")+'" onclick="setRK(\'s\',\''+k+'\')">'+l+(RKS===k?(RKD<0?" ▼":" ▲"):"")+'</th>';
  return '<div style="overflow-x:auto"><table class="rkt" style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr class="mut"><th style="text-align:left">#</th><th style="text-align:left">Símbolo y nombre</th>'+th("last","Precio")+th("pct","Último día")+th("cap","Valor de mercado")+th("vol","Volumen")+'<th style="text-align:left">Sector</th></tr></thead><tbody>'
   +sh.map(x=>{const m=x.rk<=3?['#e8b04a','#c0c8d8','#cd8a4a'][x.rk-1]:null,up=(x.pct||0)>=0,sc=SECC[x.sector]||"#9aa6bd";
     return '<tr><td><span class="med"'+(m?' style="background:'+m+';color:#0a0a0d"':'')+'>'+x.rk+'</span></td><td><div style="display:flex;gap:10px;align-items:center">'+rkAv(x.sym)+'<div><b>'+esc(x.sym)+'</b>'+(!x.etf&&x.cap>=1e12?'<span class="badge1t">💎 1T+</span>':'')+'<div class="mut" style="font-size:12px">'+esc(x.name||"")+'</div></div></div></td>'
      +'<td style="text-align:right" class="mono">$'+x.last.toFixed(2)+'</td><td style="text-align:right"><span class="chip" style="background:'+(up?"#3fd38a22":"#ff5d6c22")+';color:'+(up?"#3fd38a":"#ff5d6c")+';font-weight:800;font-size:12px;padding:2px 8px;border-radius:6px">'+(x.pct==null?"–":(up?"+":"")+x.pct.toFixed(2)+"%")+'</span></td>'
      +'<td style="text-align:right;white-space:nowrap"><span class="mono">'+capF(x.cap)+'</span>'+(x.etf?' <span class="mut" style="font-size:11px">patrim.</span>':'')+(x.approx?' <span class="mut" style="font-size:11px" title="Aún sin acciones en circulación de Yahoo: valor aproximado fijo">aprox.</span>':'')+'<span style="display:inline-block;vertical-align:middle;width:64px;height:5px;background:#202027;border-radius:3px;margin-left:8px"><i style="display:block;height:100%;width:'+Math.max(2,(x.cap||0)/mx*100).toFixed(1)+'%;background:#e8b04a;border-radius:3px"></i></span></td>'
      +'<td style="text-align:right" class="mono">'+volF(x.vol)+'</td><td><span class="secc" style="background:'+sc+'22;color:'+sc+'">● '+esc(x.sector)+'</span></td></tr>'}).join("")+'</tbody></table></div>'
   +(r.length>RKN?'<div style="text-align:center;margin-top:10px"><button class="pill" onclick="setRK(\'n\','+r.length+')">Ver los '+r.length+'</button></div>':RKN>50&&r.length>50?'<div style="text-align:center;margin-top:10px"><button class="pill" onclick="setRK(\'n\',50)">Ver menos</button></div>':'')}
function viewRank(){if(!RK){loadRank();return'<div class="card mut">Cargando ranking…</div>'}
  const B=RK.breadth,p=B.n?Math.round(100*B.up/B.n):0,tri=RK.trillion;
  const mv=(x,c)=>x?'<div style="display:flex;gap:10px;align-items:center;margin-top:8px">'+rkAv(x.sym)+'<div style="flex:1"><b>'+esc(x.sym)+'</b><div class="mut" style="font-size:12px">'+esc(x.name)+'</div></div><b style="color:'+c+'">'+(x.pct>=0?"+":"")+x.pct.toFixed(2)+'%</b></div>':'';
  return '<div class="card" id="rk_box"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px"><div><div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800;margin:0">RANKING</div><div class="sub">Las empresas y fondos más grandes, y los que más se movieron en la última sesión</div></div>'
   +'<div style="display:flex;gap:6px;flex-wrap:wrap">'+[["all","Destacadas"],["n","Nasdaq 100"],["d","Dow 30"]].map(x=>'<span class="pill'+(RKF===x[0]?" on":"")+'" onclick="RKF=\''+x[0]+'\';paint()">'+x[1]+'</span>').join("")+'</div></div>'
   +'<div class="rk3" style="margin-top:12px"><div class="tile"><div class="lbl" style="font-weight:800">AMPLITUD · ÚLTIMA SESIÓN</div><div><b style="font-size:28px">'+p+'%</b> <span class="mut">suben</span></div><div style="display:flex;height:8px;border-radius:5px;overflow:hidden;margin:8px 0;gap:2px"><i style="width:'+p+'%;background:#3fd38a"></i><i style="flex:1;background:#ff5d6c"></i></div><div class="mut" style="font-size:12.5px">'+B.up+' suben · '+B.down+' bajan · de '+B.n+'</div></div>'
   +'<div class="tile"><div class="lbl" style="font-weight:800">CLUB DEL BILLÓN</div><div><b style="font-size:28px">'+tri.length+'</b> <span class="mut">valen $1 billón (1T) o más</span></div><div style="margin-top:8px">'+tri.map(s=>'<span class="tchip"><i style="background:'+avCol(s,.2)+';color:'+avCol(s)+'">'+s[0]+'</i>'+esc(s)+'</span>').join("")+'</div></div>'
   +'<div class="tile"><div class="lbl" style="font-weight:800">MAYORES MOVIMIENTOS · ÚLTIMA SESIÓN</div>'+mv(RK.gain,"#3fd38a")+mv(RK.lose,"#ff5d6c")+'<div class="mut" style="font-size:12px;margin-top:8px">Entre empresas de más de $10B de valor.</div></div></div>'
   +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:6px"><input id="rk_q" placeholder="Buscar símbolo o nombre…" value="'+esc(RKQ)+'" oninput="RKQ=this.value;$(\'rk_tbl\').innerHTML=rkTable();$(\'rk_ctl\').innerHTML=rkCtl()" style="flex:1;min-width:200px;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px 12px"><span id="rk_ctl" style="display:flex;gap:6px;align-items:center">'+rkCtl()+'</span></div>'
   +'<div id="rk_tbl">'+rkTable()+'</div>'
   +'<div class="mut" style="font-size:11.5px;margin-top:10px;line-height:1.5">Valor de mercado = precio de Tradier ('+(RK.live?"cuenta real, en vivo":"papel, ~15 min de retraso")+') × acciones en circulación de Yahoo (se actualizan solas cada 3 días). En los ETF se muestra su patrimonio (AUM) según Yahoo. Son las ~100 empresas más grandes de la lista del programa más los ETF principales, no todo el mercado.'
   +(RK.building?' <b style="color:#ffc04d">Actualizando acciones en circulación: '+RK.done+' de '+RK.total+'…</b>':'')+(RK.approx?' '+RK.approx+' con valor aproximado (aprox.) mientras llegan los datos.':'')+(RK.err?' <span class="bad">'+esc(RK.err)+'</span>':'')+'</div></div>'}
let IV=null,IVD=null,IVSEL=null,IVS=lsGetM("mk_ivs","dest"),IVQ="",ivT=null;
function lsGetM(k,d){try{return localStorage.getItem(k)||d}catch(e){return d}}
async function loadInv(){try{IV=await getw("inv");if(TAB==="inv")paint();clearTimeout(ivT);if(TAB==="inv"&&IV.building)ivT=setTimeout(loadInv,8000)}catch(e){if(TAB==="inv")$("view").innerHTML='<div class="card bad">No pude cargar inversionistas: '+esc(e.message||e)+'</div>'}}
async function ivPick(cik){IVSEL=IVSEL===cik?null:cik;IVD=null;paint();if(IVSEL){try{IVD=await getw("inv&cik="+cik)}catch(e){IVD={error:String(e.message||e)}}if(TAB==="inv")paint();const el=$("iv_det");if(el)el.scrollIntoView({behavior:"smooth",block:"start"})}}
const ini=n=>(n||"").split(/\s+/).filter(Boolean).map(w=>w[0]).slice(0,2).join("").toUpperCase();
const bigU=v=>v==null?"–":v>=1e12?"$"+(v/1e12).toFixed(2)+"T":v>=1e9?"$"+(v/1e9).toFixed(2)+"B":v>=1e6?"$"+(v/1e6).toFixed(1)+"M":"$"+(v/1e3).toFixed(0)+"K";
function ivStack(names){const sh=names.slice(0,5);return '<span style="display:inline-flex;align-items:center;padding-left:6px">'+sh.map(n=>'<span class="ivs" title="'+esc(n)+'" style="background:'+avCol(n,.25)+';color:'+avCol(n)+'">'+ini(n)+'</span>').join("")+(names.length>5?'<span class="mut" style="font-size:11.5px;margin-left:4px">+'+(names.length-5)+'</span>':'')+'</span>'}
function ivRow(r,buy){const nm=r.ticker||"—",c=buy?"#3fd38a":"#ff5d6c",list=buy?r.buy:r.sell;
  const sub=buy?(r.new+" nueva"+(r.new===1?"":"s")+(r.sell.length?" · "+r.sell.length+" vendieron":"")):(r.exit+" salieron"+(r.buy.length?" · "+r.buy.length+" compraron":""));
  return '<div class="ivr"><span style="width:30px;height:30px;border-radius:8px;display:grid;place-items:center;font-weight:900;font-size:12px;background:'+avCol(nm,.15)+';color:'+avCol(nm)+'">'+esc(nm[0]||"?")+'</span><div style="min-width:0"><b>'+esc(nm)+'</b><div class="mut" style="font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(r.name)+'</div></div>'+ivStack(list)+'<div style="text-align:right"><b style="font-size:18px;color:'+c+'">'+list.length+'</b><div class="mut" style="font-size:10.5px">'+sub+'</div></div></div>'}
function ivBars(v){const ok=(v||[]).filter(x=>x!=null);if(ok.length<2)return"";const mx=Math.max(...ok),W=54,H=18,n=v.length;
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:54px;height:18px;vertical-align:middle">'+v.map((x,i)=>x==null?"":'<rect x="'+(i*W/n)+'" y="'+(H-Math.max(2,x/mx*H))+'" width="'+(W/n-2)+'" height="'+Math.max(2,x/mx*H)+'" fill="'+(i===n-1?"#e8b04a":"#5d6987")+'"/>').join("")+'</svg>'}
function ivDetail(){if(!IVSEL)return"";if(!IVD)return'<div class="card mut" id="iv_det">Cargando posiciones…</div>';if(IVD.error)return'<div class="card bad" id="iv_det">'+esc(IVD.error)+'</div>';
  const chg=r=>r.chg==="nueva"?'<span style="background:#3fd38a22;color:#3fd38a;font-size:11px;padding:2px 8px;border-radius:999px;font-weight:800">Nueva</span>':r.chg==="aumentó"?'<span class="ok">▲ '+(r.chg_pct!=null?"+"+(r.chg_pct*100).toFixed(0)+"%":"")+'</span>':r.chg==="redujo"?'<span class="bad">▼ '+(r.chg_pct!=null?(r.chg_pct*100).toFixed(0)+"%":"")+'</span>':'<span class="mut">sin cambio</span>';
  return '<div class="card" id="iv_det" style="border-color:#e8b04a"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px"><div><b style="font-size:16px">'+esc(IVD.firm)+'</b> <span style="color:#e8b04a">'+esc(IVD.mgr)+'</span><div class="mut" style="font-size:12px">Posiciones principales del 13F de '+esc(IVD.q)+' · cambio contra el trimestre anterior</div></div><span class="pill" onclick="ivPick('+IVSEL+')">Cerrar ✕</span></div>'
   +'<div style="overflow-x:auto;margin-top:8px"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr class="mut"><th style="text-align:left">#</th><th style="text-align:left">Empresa</th><th style="text-align:right">Valor</th><th style="text-align:left;padding-left:14px">% del portafolio</th><th style="text-align:right">Cambio</th></tr></thead><tbody>'
   +IVD.rows.map((r,i)=>'<tr style="border-top:1px solid var(--line)"><td class="mut" style="padding:6px 4px">'+(i+1)+'</td><td><b>'+esc(r.ticker||"—")+'</b>'+(r.opt?' <span style="background:#ffc04d22;color:#ffc04d;font-size:10.5px;padding:1px 6px;border-radius:6px">'+esc(r.opt.toLowerCase())+'</span>':'')+' <span class="mut" style="font-size:12px">'+esc(r.name)+'</span></td><td style="text-align:right" class="mono">'+bigU(r.value)+'</td><td style="padding-left:14px;white-space:nowrap"><span style="display:inline-block;width:110px;height:6px;background:#202027;border-radius:3px;vertical-align:middle"><i style="display:block;height:100%;width:'+Math.min(100,r.pct*100*2).toFixed(1)+'%;background:#e8b04a;border-radius:3px"></i></span> <span class="mono">'+(r.pct*100).toFixed(1)+'%</span></td><td style="text-align:right">'+chg(r)+'</td></tr>').join("")+'</tbody></table></div>'
   +(IVD.exited.length?'<div class="mut" style="font-size:12.5px;margin-top:10px"><b style="color:#ff5d6c">Vendió por completo:</b> '+IVD.exited.map(x=>esc(x.ticker||x.name)+(x.opt?" ("+x.opt.toLowerCase()+")":"")+' <span class="mono">'+bigU(x.value)+'</span>').join(" · ")+'</div>':'')+'</div>'}
function viewInv(){if(!IV){loadInv();return'<div class="card mut">Cargando inversionistas (la primera vez el panel baja los reportes 13F de la SEC: tarda unos minutos)…</div>'}
  if(IV.error)return'<div class="card bad">'+esc(IV.error)+'</div>';
  const q=IVQ.trim().toLowerCase();let C=IV.cards.filter(c=>!q||(c.firm+" "+c.mgr).toLowerCase().includes(q));
  if(IVS==="val")C=[...C].sort((a,b)=>(b.value||0)-(a.value||0));if(IVS==="chg")C=[...C].sort((a,b)=>(b.chg??-9)-(a.chg??-9));
  let h='<div class="card"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px"><div><div class="lbl" style="font-size:15px;color:var(--tx);font-weight:800;margin:0">🏛 INVERSIONISTAS INSTITUCIONALES</div><div class="sub">Portafolios 13F de grandes gestores · fuente oficial: SEC (EDGAR)</div></div><input id="iv_q" placeholder="Buscar fondo o gestor…" value="'+esc(IVQ)+'" oninput="IVQ=this.value;paint()" style="background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px 12px;min-width:220px"></div>'
   +(IV.building?'<div style="color:#ffc04d;font-size:12.5px;margin-top:8px">Bajando reportes 13F de la SEC: '+IV.done+' de '+IV.total+' gestores… (solo la primera vez del día tarda; la página se actualiza sola)</div>':'')+(IV.err?'<div class="bad" style="font-size:12.5px;margin-top:6px">'+esc(IV.err)+'</div>':'')+'</div>';
  if(IV.buy.length||IV.sell.length)h+='<div class="card"><div><b style="font-size:16px">🧠 Consenso de los gurús</b> '+(IV.curq?'<span style="background:#e8b04a22;color:#e8b04a;font-size:12px;padding:2px 9px;border-radius:999px;font-weight:800">'+esc(IV.curq)+'</span>':'')+'</div><div class="mut" style="font-size:12.5px;margin:4px 0 10px">Lo que más gestores compraron y vendieron al mismo tiempo, entre los '+IV.n_cons+' con 13F del trimestre actual y portafolio concentrado (≤ '+IV.max_pos+' posiciones).</div>'
   +'<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:24px"><div><div class="ok" style="font-weight:800;font-size:12.5px;letter-spacing:.06em">▲ MÁS COMPRADAS</div>'+IV.buy.map(r=>ivRow(r,true)).join("")+'</div><div><div class="bad" style="font-weight:800;font-size:12.5px;letter-spacing:.06em">▼ MÁS VENDIDAS</div>'+IV.sell.map(r=>ivRow(r,false)).join("")+'</div></div>'
   +'<div class="mut" style="font-size:11.5px;margin-top:10px;line-height:1.5">Ordenado por neto (compradores − vendedores): si unos compran y otros venden por igual, no hay consenso. Cuenta gestores, no dólares. Compra = abrir o aumentar ≥1% las acciones; venta = reducir o salir. Se dejan fuera los "quants" con miles de posiciones y los 13F atrasados. Las escisiones (spin-offs) aparecen como posición "nueva" aunque no las compraron. Un 13F llega hasta 45 días después del trimestre: es lo que hicieron, no lo que hacen hoy, y no muestra ventas en corto.</div></div>';
  h+='<div style="display:flex;gap:6px;align-items:center;margin:4px 0 10px"><span class="mut" style="font-size:12.5px">Ordenar:</span>'+[["dest","Destacados"],["val","Valor del 13F"],["chg","Cambio trimestral"]].map(x=>'<span class="pill'+(IVS===x[0]?" on":"")+'" onclick="IVS=\''+x[0]+'\';try{localStorage.setItem(\'mk_ivs\',IVS)}catch(e){};paint()">'+x[1]+'</span>').join("")+'</div>';
  h+='<div class="ivg">'+C.map(c=>{const has=c.value!=null;return '<div class="ivc'+(IVSEL===c.cik?" sel":"")+'" onclick="'+(has?'ivPick('+c.cik+')':'')+'"><div class="ivav" style="background:'+avCol(c.mgr,.18)+';color:'+avCol(c.mgr)+';border:2px solid '+avCol(c.mgr,.45)+'">'+ini(c.mgr)+'</div><b style="font-size:13px">'+esc(c.firm)+'</b><div style="color:#e8b04a;font-size:12.5px">'+esc(c.mgr)+'</div>'
    +(has?'<div style="border-top:1px solid var(--line);margin-top:8px;padding-top:8px;display:flex;justify-content:space-between;align-items:center"><b class="mono" style="font-size:15px">'+bigU(c.value)+'</b>'+ivBars(c.bars)+'<span class="'+(c.chg==null?"mut":c.chg>=0?"ok":"bad")+'" style="font-size:12px">'+(c.chg==null?"":(c.chg>=0?"+":"")+(c.chg*100).toFixed(1)+"%")+'</span></div>'
      +'<div style="display:flex;justify-content:space-between;font-size:12px;margin-top:4px"><span>'+(c.pos||"–")+' pos.'+(c.new!=null?' <b class="ok">+'+c.new+'</b> <b class="bad">−'+c.exited+'</b>':'')+'</span><span style="color:'+(c.stale?"#ffc04d":"var(--mut)")+'">'+(c.stale?"⚠ ":"")+esc(c.q)+'</span></div>'
     :'<div class="mut" style="font-size:12px;margin-top:10px">'+esc(c.err||(IV.building?"Bajando…":"Sin datos 13F"))+'</div>')+'</div>'}).join("")+'</div>';
  h+=ivDetail();
  h+='<div class="mut" style="font-size:11.5px;margin-top:10px">Valor del 13F = acciones y opciones de EE. UU. que el fondo reporta a la SEC (no incluye efectivo, bonos ni ventas en corto). El cambio trimestral del valor incluye lo que compró o vendió, no solo cuánto subieron sus acciones. ⚠ = su último 13F es de un trimestre anterior.</div>';
  return h}
let ECO=null;
async function loadEco(){try{ECO=await getw("eco");if(TAB==="eco")paint()}catch(e){if(TAB==="eco")$("view").innerHTML='<div class="card bad">No pude cargar Economía: '+esc(e.message||e)+'</div>'}}
const DIAS=["domingo","lunes","martes","miércoles","jueves","viernes","sábado"],MES3=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
const dlong=s=>{const d=new Date(s+"T12:00:00"),w=DIAS[d.getDay()];return w[0].toUpperCase()+w.slice(1)+" "+d.getDate()+" "+MES3[d.getMonth()]};
const dshort=s=>{const d=new Date(s+"T12:00:00");return d.getDate()+" "+MES3[d.getMonth()]};
function nyToday(){const p=new Intl.DateTimeFormat("en-CA",{timeZone:"America/New_York"}).format(new Date());return p}
function daysTo(s){return Math.round((new Date(s+"T12:00:00")-new Date(nyToday()+"T12:00:00"))/864e5)}
const DLONG=s=>{const d=new Date(s+"T12:00:00"),w=DIAS[d.getDay()],M=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];return w[0].toUpperCase()+w.slice(1)+", "+d.getDate()+" de "+M[d.getMonth()]+" de "+d.getFullYear()};
function ecoVal(u,v){if(v==null)return"";if(u==="k"){const r=Math.round(v);return (r>0&&u==="k"?"":"")+r.toLocaleString("en-US")+"K"}if(u==="M")return v.toFixed(3).replace(/0+$/,"").replace(/\.$/,"")+"M";if(u==="%"||u==="%r")return v.toFixed(u==="%r"?2:1)+"%";return v.toFixed(1)}
function ecoCal(cal){if(!cal||!cal.length)return'<div class="mut">Sin publicaciones en las próximas semanas.</div>';const t=nyToday(),g={};cal.forEach(e=>{(g[e.date]=g[e.date]||[]).push(e)});
  const stars=n=>'<span style="letter-spacing:1px;white-space:nowrap">'+[1,2,3].map(i=>'<span style="color:'+(i<=n?(n>=3?"#ff5d6c":n===2?"#e8b04a":"#9aa6bd"):"#2a3654")+'">★</span>').join("")+'</span>';
  let h='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13.5px;min-width:620px"><thead><tr class="mut" style="text-align:left"><th style="padding:8px 6px;width:64px;text-align:left">Hora</th><th style="width:78px;text-align:left">País</th><th style="text-align:left">Evento</th><th style="width:70px;text-align:left">Imp.</th><th style="text-align:right;width:100px">Actual</th><th style="text-align:right;width:100px;padding-right:8px">Anterior</th></tr></thead><tbody>';
  Object.keys(g).sort().forEach(d=>{const n=daysTo(d),past=d<t;
    h+='<tr><td colspan="6" style="text-align:center;padding:12px 6px 10px;border-top:2px solid '+(n===0?"#e8b04a88":"#2a3654")+';border-bottom:1px solid #202027;background:'+(n===0?"#e8b04a12":"#08080a")+'"><b style="font-size:14.5px">'+DLONG(d)+'</b>'+(n===0?' <span style="background:#e8b04a;color:#0a0a0d;font-size:11px;font-weight:800;padding:2px 8px;border-radius:999px;margin-left:6px">HOY</span>':n===1?' <span class="mut" style="font-size:12px;margin-left:6px">mañana</span>':past?' <span class="mut" style="font-size:12px;margin-left:6px">publicado</span>':'')+'</td></tr>';
    g[d].forEach(e=>{h+='<tr style="border-top:1px solid #202027;'+(past?"opacity:.6":"")+'"><td class="mono" style="padding:9px 6px">'+esc(e.time||"")+'</td><td style="white-space:nowrap">🇺🇸 EE. UU.</td><td style="'+(e.fomc?"color:#e8b04a;font-weight:800":e.imp>=3?"font-weight:700":"")+'">'+(e.fomc?"🏛 ":"")+esc(e.name)+(e.period?' <span class="mut">('+esc(e.period)+')</span>':'')+(e.tentative?' <span class="mut" style="font-size:11px">(tentativa)</span>':'')+'</td><td>'+stars(e.imp)+'</td>'
      +'<td class="mono" style="text-align:right;font-weight:800">'+ecoVal(e.unit,e.actual)+'</td><td class="mono" style="text-align:right;padding-right:8px">'+ecoVal(e.unit,e.prev)+'</td></tr>'})});
  return h+'</tbody></table></div>'}
function ecoSpark(pts,up){const v=(pts||[]).map(p=>p[1]);if(v.length<3)return"";const W=160,H=38,mn=Math.min(...v),mx=Math.max(...v),r=mx-mn||1;
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:38px" aria-hidden="true"><path d="'+v.map((x,i)=>(i?"L":"M")+(i*W/(v.length-1)).toFixed(1)+" "+(3+(1-(x-mn)/r)*(H-6)).toFixed(1)).join("")+'" fill="none" stroke="#5cc8ff" stroke-width="1.8"/><circle cx="'+W+'" cy="'+(3+(1-(v[v.length-1]-mn)/r)*(H-6)).toFixed(1)+'" r="3" fill="#e8b04a"/></svg>'}
function ecoFmt(i,v,diff){if(v==null)return"–";if(i.unit==="k"){const s=Math.round(v);return (diff&&s>0?"+":"")+s.toLocaleString("en-US")+"k"}
  if(i.unit==="%")return (diff?(v>=0?"+":"")+v.toFixed(2)+" pp":(i.how!=="nivel"&&v>0&&i.how!=="yoy"?"+":"")+v.toFixed(i.sid==="DFEDTARU"?2:1)+"%");return (diff&&v>=0?"+":"")+v.toFixed(1)}
function ecoPer(i,d){if(!d)return"";if(i.sid==="ICSA")return"semana del "+dshort(d);if(i.sid.startsWith("A191"))return"T"+(Math.floor((+d.slice(5,7)-1)/3)+1)+" "+d.slice(0,4);if(i.sid==="DFEDTARU")return"vigente";return MES3[+d.slice(5,7)-1]+" "+d.slice(0,4)}
function ecoCard(i){if(i.error)return'<div class="tile"><b>'+esc(i.name)+'</b><div class="bad" style="font-size:12px;margin-top:6px">'+esc(i.error)+'</div></div>';
  const p=i.pts,L=p[p.length-1],P=p[p.length-2],d=L&&P?L[1]-P[1]:null,good=i.up_good==null||d==null||Math.abs(d)<1e-9?null:(d>0)===i.up_good;
  return '<div class="tile"><div style="display:flex;justify-content:space-between;gap:6px"><b style="font-size:13.5px">'+esc(i.name)+'</b><span class="mut" style="font-size:11.5px">'+ecoPer(i,L&&L[0])+'</span></div><div class="mut" style="font-size:11.5px">'+esc(i.note)+'</div>'
   +'<div style="display:flex;align-items:baseline;gap:10px;margin-top:6px"><b style="font-size:24px">'+ecoFmt(i,L&&L[1])+'</b><span style="font-size:12.5px;font-weight:700;color:'+(good==null?"var(--mut)":good?"#3fd38a":"#ff5d6c")+'">'+(d==null||Math.abs(d)<1e-9?"sin cambio":(d>0?"▲ ":"▼ ")+ecoFmt(i,Math.abs(d)*Math.sign(d),true))+'</span></div>'
   +'<div class="mut" style="font-size:11.5px">Anterior: '+ecoFmt(i,P&&P[1])+'</div>'+ecoSpark(p)+'<div style="font-size:11.5px;color:'+(i.next&&daysTo(i.next)<=7?"#e8b04a":"var(--mut)")+'">'+(i.next?"Próximo dato: "+dlong(i.next)+(daysTo(i.next)===0?" (hoy)":""):"")+'</div></div>'}
function viewEco(){if(!ECO){loadEco();return'<div class="card mut">Cargando datos económicos…</div>'}
  const nf=ECO.next_fomc,head='<div class="card"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px"><div><div class="lbl" style="font-size:15px;color:var(--tx);font-weight:800;margin:0">📊 ECONOMÍA DE EE. UU.</div><div class="sub">Indicadores clave y calendario de publicaciones · fuente oficial: FRED (Reserva Federal de St. Louis)</div></div>'
   +(nf?'<div class="tile" style="padding:8px 14px"><div class="mut" style="font-size:11.5px">PRÓXIMA DECISIÓN DE LA FED</div><b style="color:#e8b04a">'+dlong(nf)+'</b> <span class="mut" style="font-size:12px">· '+(daysTo(nf)===0?"hoy":"en "+daysTo(nf)+" días")+' · 2:00 pm ET</span></div>':'')+'</div></div>';
  if(ECO.need_key)return head+'<div class="card" style="border-left-color:#ffc04d"><b>Falta la clave de FRED</b><div style="font-size:13.5px;line-height:1.7;margin-top:6px">1. Entra a <b>fredaccount.stlouisfed.org/apikeys</b>, crea tu cuenta gratis y pulsa <b>Request API Key</b>.<br>2. En Terminal: <span class="mono">open -e ~/.tradier_env</span> y agrega una línea <span class="mono">FRED_API_KEY=tu_clave</span>. Guarda.<br>3. Reinicia el panel. Aquí aparecerán los indicadores y el calendario completo.</div></div><div class="card"><div class="lbl">REUNIONES DE LA FED (PRÓXIMAS SEMANAS)</div>'+ecoCal(ECO.calendar)+'</div>';
  if(ECO.error)return head+'<div class="card bad">'+esc(ECO.error)+'</div><div class="card"><div class="lbl">REUNIONES DE LA FED</div>'+ecoCal(ECO.calendar)+'</div>';
  return head+'<div class="lbl" style="font-weight:800;margin:4px 0 8px">INDICADORES CLAVE</div><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,250px),1fr));gap:12px;margin-bottom:14px">'+ECO.inds.map(ecoCard).join("")+'</div>'
   +'<div class="card"><div class="lbl" style="font-weight:800">CALENDARIO · ÚLTIMOS 7 DÍAS Y PRÓXIMAS SEMANAS</div><div class="mut" style="font-size:11.5px;margin-bottom:6px">Hora de Nueva York (la habitual de cada publicación). ★★★ = suele mover mucho al mercado. Entre paréntesis, el periodo que se publica. "Actual" aparece en cuanto FRED tiene el dato (se revisa cada 30 min). No hay columna de pronóstico ni eventos privados (ISM, PMI de S&amp;P, ADP): FRED no los da.</div>'+ecoCal(ECO.rows||ECO.calendar)+(ECO.cal_err?'<div class="bad" style="font-size:12px">'+esc(ECO.cal_err)+'</div>':'')+'</div>'
   +'<div class="mut" style="font-size:11.5px;line-height:1.5">Último dato publicado y el anterior. Verde/rojo según si el cambio suele ser bueno o malo para la economía (no necesariamente para la bolsa: un empleo muy fuerte puede bajar la bolsa si aleja los recortes de tasas). Los datos se revisan después de publicarse. Fechas de la Fed: federalreserve.gov (las de 2027 son tentativas).</div>'}
let REP=null,repT=null;
async function loadRep(){try{REP=await getw("rep");if(TAB==="rep")paint();clearTimeout(repT);if(TAB==="rep")repT=setTimeout(loadRep,REP.building?8000:300000)}catch(e){if(TAB==="rep")$("view").innerHTML='<div class="card bad">No pude cargar Resultados: '+esc(e.message||e)+'</div>'}}
const WHEN={antes:["☀️","Antes de abrir"],despues:["🌙","Después del cierre"],durante:["🕐","Durante el día"]};
function viewRep(){if(!REP){loadRep();return'<div class="card mut">Cargando reportes de resultados…</div>'}
  const R=REP.rows||[],t=nyToday(),wk=R.filter(r=>r.date>=t&&daysTo(r.date)<=7),gi=wk.filter(r=>r.giant);
  const pct=(v,s)=>v==null?'<span class="mut">–</span>':'<span style="color:'+(v>0?"#3fd38a":v<0?"#ff5d6c":"var(--tx)")+'">'+(s&&v>0?"+":"")+v.toFixed(Math.abs(v)<10?1:0)+'%</span>';
  const eps=v=>v==null?'<span class="mut">–</span>':(v<0?"-$":"$")+Math.abs(v).toFixed(2);
  let h='<div class="card"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px"><div><div class="lbl" style="font-size:15px;color:var(--tx);font-weight:800;margin:0">📅 RESULTADOS (EARNINGS)</div><div class="sub">Reportes trimestrales de las '+REP.n_syms+' empresas grandes de tu lista · Yahoo Finance + opciones de Tradier</div></div>'
   +'<div class="tile" style="padding:8px 14px"><div class="mut" style="font-size:11.5px">PRÓXIMOS 7 DÍAS</div><b style="font-size:18px">'+wk.length+'</b> <span class="mut">reportes</span>'+(gi.length?' · <span style="color:#e8b04a">'+gi.length+' gigante'+(gi.length>1?"s":"")+'</span>':'')+'</div></div>'
   +(gi.length?'<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">'+gi.map(r=>'<span class="tchip" style="border-color:#e8b04a66"><i style="background:'+avCol(r.sym,.2)+';color:'+avCol(r.sym)+'">'+r.sym[0]+'</i>⭐ '+esc(r.sym)+' <span class="mut" style="font-weight:600">'+dshort(r.date)+' '+(WHEN[r.when]?WHEN[r.when][0]:"")+'</span>'+(r.exp_move?' <span style="color:#e8b04a">±'+r.exp_move.pct.toFixed(1)+'%</span>':'')+'</span>').join("")+'</div><div class="mut" style="font-size:11.5px;margin-top:4px">⭐ = empresas gigantes: sus reportes suelen mover al S&amp;P 500 (SPY) y a tus opciones 0DTE.</div>':'')
   +(REP.building?'<div style="color:#ffc04d;font-size:12.5px;margin-top:8px">Consultando fechas en Yahoo: '+REP.done+' de '+REP.total+' empresas… (solo la primera vez tarda; se actualiza sola)</div>':'')+(REP.err?'<div class="bad" style="font-size:12.5px;margin-top:6px">'+esc(REP.err)+'</div>':'')+'</div>';
  if(!R.length)return h+'<div class="card mut">'+(REP.building?"Aún no hay datos; espera un momento.":"Ninguna empresa de la lista reporta en estas fechas.")+'</div>';
  const g={};R.forEach(r=>{(g[r.date]=g[r.date]||[]).push(r)});
  h+='<div class="card"><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13.5px;min-width:760px"><thead><tr class="mut"><th style="text-align:left;padding:8px 6px">Empresa</th><th style="text-align:left">Momento</th><th style="text-align:right">EPS estimado</th><th style="text-align:right">EPS real</th><th style="text-align:right">Sorpresa</th><th style="text-align:right" title="Lo que descuentan las opciones: straddle al dinero ÷ precio">Mov. esperado</th><th style="text-align:right;padding-right:8px">Mov. real</th></tr></thead><tbody>';
  Object.keys(g).sort().forEach(d=>{const n=daysTo(d),past=d<t;
    h+='<tr><td colspan="7" style="text-align:center;padding:12px 6px 10px;border-top:2px solid '+(n===0?"#e8b04a88":"#2a3654")+';border-bottom:1px solid #202027;background:'+(n===0?"#e8b04a12":"#08080a")+'"><b style="font-size:14.5px">'+DLONG(d)+'</b>'+(n===0?' <span style="background:#e8b04a;color:#0a0a0d;font-size:11px;font-weight:800;padding:2px 8px;border-radius:999px;margin-left:6px">HOY</span>':n===1?' <span class="mut" style="font-size:12px;margin-left:6px">mañana</span>':past?' <span class="mut" style="font-size:12px;margin-left:6px">ya reportaron</span>':'')+' <span class="mut" style="font-size:12px">· '+g[d].length+' reporte'+(g[d].length>1?"s":"")+'</span></td></tr>';
    g[d].forEach(r=>{const w=WHEN[r.when],em=r.exp_move,rm=r.real_move,big=em&&rm!=null?Math.abs(rm)>em.pct:null;
      h+='<tr style="border-top:1px solid #202027'+(r.giant?";background:#e8b04a08":"")+'"><td style="padding:8px 6px"><div style="display:flex;gap:9px;align-items:center"><span style="width:28px;height:28px;border-radius:8px;display:grid;place-items:center;font-weight:900;font-size:12px;background:'+avCol(r.sym,.15)+';color:'+avCol(r.sym)+'">'+r.sym[0]+'</span><div><b>'+(r.giant?"⭐ ":"")+esc(r.sym)+'</b><div class="mut" style="font-size:11.5px">'+esc(r.name)+'</div></div></div></td>'
       +'<td style="white-space:nowrap">'+(w?w[0]+' <span style="font-size:12.5px">'+w[1]+'</span>':'<span class="mut">sin hora</span>')+'</td>'
       +'<td class="mono" style="text-align:right">'+eps(r.eps_est)+'</td><td class="mono" style="text-align:right;font-weight:800">'+eps(r.eps_act)+'</td><td class="mono" style="text-align:right">'+pct(r.surprise,true)+'</td>'
       +'<td class="mono" style="text-align:right;color:#e8b04a">'+(em?"±"+em.pct.toFixed(1)+'% <span class="mut" style="font-size:11px">(±$'+em.usd.toFixed(2)+')</span>':'<span class="mut">–</span>')+'</td>'
       +'<td class="mono" style="text-align:right;padding-right:8px">'+(rm==null?'<span class="mut">–</span>':pct(rm,true)+(big!=null?' <span style="font-size:11px;color:'+(big?"#ffc04d":"var(--mut)")+'">'+(big?"más de lo esperado":"dentro de lo esperado")+'</span>':''))+'</td></tr>'})});
  h+='</tbody></table></div><div class="mut" style="font-size:11.5px;line-height:1.5;margin-top:10px">Últimos 7 días y próximas 2 semanas. <b>Mov. esperado</b> = cuánto descuentan las opciones para el reporte: precio del straddle al dinero (call + put) ÷ precio de la acción, en el primer vencimiento que ya incluye el reporte. <b>Mov. real</b> = del cierre antes del reporte al cierre después. Sorpresa = EPS real vs estimado. Fechas y EPS de Yahoo (no oficial; a veces cambian o llegan tarde). Solo las empresas de tu lista, no todo el mercado.</div></div>';
  return h}
function viewRes(){if(!CD)loadCards();if(!TS&&!TE)loadAllPano();const ix="";
  return '<div class="cgrid" id="cards">'+cardsHTML()+'</div>'+'<div class="card" id="pn_tsy">'+tsyHTML()+'</div>'+'<div class="pgrid"><div class="card" id="pn_tech" style="margin:0">'+techHTML()+'</div><div class="card" id="pn_comm" style="margin:0">'+commHTML()+'</div><div class="card" id="pn_fx" style="margin:0">'+fxHTML()+'</div></div>'
   +'<div class="mut" style="font-size:12px;margin-top:4px">Amplitud y empresas que más suben o bajan: pestañas <a href="#" onclick="setTab(\'rank\');return false">Ranking</a> y <a href="#" onclick="setTab(\'mov\');return false">Movimientos</a>.</div>'}
function viewHeat(){const st=D.stocks.filter(inIdx);
  return '<div class="card"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;align-items:center"><div><div class="lbl">MAPA DE CALOR</div><div class="sub">Color = cambio del día · tamaño = capitalización aproximada (valores fijos del programa, no en vivo)</div></div>'+idxPills()+'</div><div id="heat"></div></div>'}
function drawHeat(){const el=$("heat");if(!el)return;const W=el.clientWidth,H=el.clientHeight,st=D.stocks.filter(inIdx);el.innerHTML="";
  const secs={};st.forEach(s=>{(secs[s.sector]=secs[s.sector]||{name:s.sector,v:0,items:[]});secs[s.sector].v+=s.cap;secs[s.sector].items.push(s)});
  squarify(Object.values(secs),0,0,W,H).forEach(r=>{const sc=r.it,hdr=r.h>40&&r.w>70?15:0;
    const avg=sc.items.reduce((t,s)=>t+s.pct*s.cap,0)/sc.v;
    if(hdr){const h=document.createElement("div");h.className="hs";h.style.cssText="left:"+r.x+"px;top:"+r.y+"px;width:"+r.w+"px";h.textContent=sc.name.toUpperCase()+" "+fp(avg);el.appendChild(h)}
    squarify(sc.items.map(s=>({v:s.cap,s})),r.x+1,r.y+hdr+1,r.w-2,r.h-hdr-2).forEach(c=>{const s=c.it.s,d=document.createElement("div");d.className="hc";
      d.style.cssText="left:"+c.x+"px;top:"+c.y+"px;width:"+c.w+"px;height:"+c.h+"px;background:"+heatCol(s.pct);
      d.title=s.name+" ("+s.sym+")\n$"+s.last.toFixed(2)+"  "+fp(s.pct)+"\n"+s.sector;
      const fs=Math.max(8,Math.min(26,Math.sqrt(c.w*c.h)/4.2));
      if(c.w>26&&c.h>18)d.innerHTML='<b style="font-size:'+fs+'px">'+s.sym+'</b>'+(c.h>34&&c.w>44?'<span style="font-size:'+Math.max(8,fs*.7)+'px">'+fp(s.pct)+'</span>':"");
      el.appendChild(d)})})}
function viewSec(){const S=D.sectors,spy=D.spy;const val=s=>PER==="hoy"?s.pct:(s.per||{})[PER];const sv=spy?(PER==="hoy"?spy.pct:(spy.per||{})[PER]):null;
  const L=[...S].filter(s=>val(s)!=null).sort((a,b)=>val(b)-val(a));
  if(!L.length)return'<div class="card mut">Sin datos para este periodo todavía.</div>';
  const mx=Math.max(1,...L.map(s=>Math.abs(val(s))));const g=L.filter(s=>val(s)>0).length;
  const cyc=L.filter(s=>s.cyc),def=L.filter(s=>!s.cyc),av=a=>a.reduce((t,s)=>t+val(s),0)/Math.max(1,a.length),diff=av(cyc)-av(def);
  const medals=["🥇","🥈","🥉"];
  const tops=L.slice(0,3).map((s,i)=>'<div class="tile"><div>'+medals[i]+' <b>'+esc(s.name)+'</b></div><div class="'+cl(val(s))+'" style="font-size:22px;font-weight:800">'+fp(val(s))+'</div><div class="mut" style="font-size:12px">'+(sv!=null?((val(s)-sv>=0?"+":"")+(val(s)-sv).toFixed(2)+" pp vs S&P"):"")+'</div></div>').join("");
  const pills=["hoy","1S","1M","YTD"].map(p=>'<span class="pill'+(PER===p?" on":"")+'" onclick="setPer(\''+p+'\')">'+({hoy:"Hoy","1S":"1S","1M":"1M",YTD:"En el año"})[p]+'</span>').join("");
  return '<div class="card"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px"><div><div class="lbl">SECTORES DEL S&amp;P 500</div><div class="sub">ETF sectoriales SPDR · rendimiento de precio</div></div><div style="display:flex;gap:6px">'+pills+'</div></div>'
   +'<div class="tiles" style="margin-bottom:12px">'+tops
   +'<div class="tile"><div class="mut" style="font-size:12px">AMPLITUD</div><div style="font-size:24px;font-weight:800">'+g+' <span class="mut" style="font-size:14px">/ '+L.length+'</span></div><div class="seg">'+L.map(s=>'<i style="background:'+(val(s)>=0?"var(--ok)":"var(--bad)")+'"></i>').join("")+'</div></div>'
   +'<div class="tile"><div class="mut" style="font-size:12px">APETITO POR RIESGO (derivado)</div><div style="font-weight:800;color:'+(diff>=0?"var(--ok)":"var(--bad)")+'">'+(diff>=0?"Risk-on":"Risk-off")+'</div><div class="mut" style="font-size:12px">Cíclicos '+(diff>=0?"+":"")+diff.toFixed(2)+' pp frente a defensivos</div></div></div>'
   +L.map((s,i)=>{const v=val(s),w=Math.abs(v)/mx*50;return '<div class="srow"><b class="mut">'+(i+1)+'</b><div><b>'+esc(s.name)+'</b><div class="mut" style="font-size:11px">'+s.sym+'</div></div><span class="mut xs"></span><div class="bar"><u></u><i style="'+(v>=0?"left:50%":"right:50%")+';width:'+w+'%;background:'+(v>=0?"var(--ok)":"var(--bad)")+'"></i></div><b class="'+cl(v)+'" style="text-align:right">'+fp(v)+'</b></div>'}).join("")+'</div>'}
function setPer(p){PER=p;localStorage.setItem("mk_per",p);paint()}
function viewMov(){const st=D.stocks.filter(inIdx).filter(s=>s.pct!=null);const mk=(arr,f)=>arr.slice(0,10).map(s=>'<div class="lrow"><span><b>'+s.sym+'</b> <span class="mut" style="font-size:11px">'+esc(s.name)+'</span></span><span class="mut">'+s.last.toFixed(2)+'</span>'+f(s)+'</div>').join("");
  const gan=[...st].sort((a,b)=>b.pct-a.pct),per=[...st].sort((a,b)=>a.pct-b.pct),act=[...st].filter(s=>s.vol).sort((a,b)=>b.vol*b.last-a.vol*a.last);
  const pc=s=>'<b class="'+cl(s.pct)+'">'+fp(s.pct)+'</b>';
  return '<div class="card"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px"><div><div class="lbl">MOVIMIENTOS DEL MERCADO</div><div class="sub">Solo las '+st.length+' empresas de la lista (no todo el mercado: Tradier no da un ranking general)</div></div>'+idxPills()+'</div>'
   +'<div class="g4"><div class="card"><div class="lbl">GANADORAS</div>'+mk(gan,pc)+'</div><div class="card"><div class="lbl">PERDEDORAS</div>'+mk(per,pc)+'</div><div class="card"><div class="lbl">MÁS ACTIVAS ($)</div>'+mk(act,s=>'<b>$'+fm(s.vol*s.last)+'</b>')+'</div></div></div>'}

let FG=null,VO=null,VSORT=localStorage.getItem("mk_vs")||"ivhv_d",lazyT=null;
async function getw(w){const r=await fetch("/api/market?what="+w,{cache:"no-store"});const j=await r.json();if(j.error)throw new Error(j.error);return j}
async function loadFG(){try{FG=await getw("fg");if(TAB!=="fg")return;paint();if(FG.building){clearTimeout(fgT);fgT=setTimeout(()=>{FG=null;loadFG()},3000)}}catch(e){$("view").innerHTML='<div class="card bad">No pude calcular el índice: '+esc(e.message||e)+'</div>'}}
async function loadVO(){try{VO=await getw("vol");paint();clearTimeout(lazyT);if(VO.running&&TAB==="vol")lazyT=setTimeout(loadVO,6000)}catch(e){$("view").innerHTML='<div class="card bad">No pude cargar volatilidad: '+esc(e.message||e)+'</div>'}}
const FGZ=[[0,25,"#d64550","Miedo extremo"],[25,45,"#e08a3c","Miedo"],[45,55,"#c9b04a","Neutral"],[55,75,"#7bbf5e","Codicia"],[75,100,"#2fae72","Codicia extrema"]];
const fgCol=v=>(FGZ.find(z=>v<z[1])||FGZ[4])[2];let fgT=null;
function gauge(v){const R=118,cx=150,cy=150,pt=(a,r)=>[cx+r*Math.cos(Math.PI*(1-a/100)),cy-r*Math.sin(Math.PI*(1-a/100))];
  const arc=(a,b,c,on)=>{const p=pt(a,R),q=pt(b,R);return '<path d="M'+p[0].toFixed(1)+" "+p[1].toFixed(1)+" A"+R+" "+R+" 0 0 1 "+q[0].toFixed(1)+" "+q[1].toFixed(1)+'" stroke="'+c+'" stroke-width="30" fill="none" opacity="'+(on?1:.28)+'"/>'};
  const lab=[25,45,55,75].map(x=>{const p=pt(x,R+26);return '<text x="'+p[0].toFixed(1)+'" y="'+(p[1]+4).toFixed(1)+'" text-anchor="middle" font-size="11" fill="#8a96ad" font-weight="700">'+x+'</text>'}).join("");
  const n=pt(v,R-34),b1=pt(v+90,11),b2=pt(v-90,11);
  return '<svg viewBox="0 0 300 165" style="width:100%;max-width:420px" role="img" aria-label="Indicador: '+v+'">'+FGZ.map(z=>arc(z[0]+.9,z[1]-.9,z[2],v>=z[0]&&(v<z[1]||z[1]===100))).join("")+lab
   +'<polygon points="'+n[0].toFixed(1)+','+n[1].toFixed(1)+' '+(cx+(b1[0]-cx)).toFixed(1)+','+(cy+(b1[1]-cy)).toFixed(1)+' '+(cx+(b2[0]-cx)).toFixed(1)+','+(cy+(b2[1]-cy)).toFixed(1)+'" fill="#e6ecf5"/><circle cx="'+cx+'" cy="'+cy+'" r="9" fill="#e6ecf5"/><circle cx="'+cx+'" cy="'+cy+'" r="4.5" fill="'+fgCol(v)+'"/></svg>'}
function fgBar(s){return '<div style="position:relative;height:10px;margin-top:8px;display:flex;gap:2px">'+FGZ.map(z=>'<i style="flex:'+(z[1]-z[0])+';background:'+z[2]+';opacity:.3;border-radius:3px"></i>').join("")
   +'<b style="position:absolute;top:50%;left:'+Math.max(1,Math.min(99,s))+'%;width:13px;height:13px;margin:-6.5px 0 0 -6.5px;border-radius:50%;background:'+fgCol(s)+';border:2px solid #e6ecf5"></b></div>'}
function fgChart(pts){if(!pts||pts.length<5)return'<div class="mut">Aún no hay suficiente historia.</div>';
  const W=900,H=180,P=4,x=i=>P+i*(W-2*P)/(pts.length-1),y=v=>H-P-(v/100)*(H-2*P);
  const bands=FGZ.map(z=>'<rect x="0" y="'+y(z[1]).toFixed(1)+'" width="'+W+'" height="'+(y(z[0])-y(z[1])).toFixed(1)+'" fill="'+z[2]+'" opacity=".09"/>').join("");
  const line=pts.map((p,i)=>(i?"L":"M")+x(i).toFixed(1)+" "+y(p.v).toFixed(1)).join("");
  let months="",lm="";pts.forEach((p,i)=>{const m=p.d.slice(0,7);if(m!==lm&&i>3&&i<pts.length-8){months+='<text x="'+x(i).toFixed(1)+'" y="'+(H+16)+'" font-size="11" fill="#8a96ad" text-anchor="middle">'+["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"][+p.d.slice(5,7)-1]+'</text>'}lm=m});
  const L=pts[pts.length-1];
  return '<svg viewBox="0 0 '+W+' '+(H+22)+'" style="width:100%;height:auto;display:block" role="img" aria-label="Índice en los últimos 12 meses">'+bands
   +'<line x1="0" x2="'+W+'" y1="'+y(50)+'" y2="'+y(50)+'" stroke="#8a96ad" stroke-dasharray="4 5" opacity=".6"/><path d="'+line+'" fill="none" stroke="#e6ecf5" stroke-width="2" stroke-linejoin="round"/>'
   +'<circle cx="'+x(pts.length-1).toFixed(1)+'" cy="'+y(L.v).toFixed(1)+'" r="4.5" fill="'+fgCol(L.v)+'" stroke="#e6ecf5" stroke-width="1.5"/>'+months+'</svg>'}
function fgPrev(lbl,o){return '<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;gap:8px"><span class="mut">'+lbl+'</span>'+(o?'<span style="white-space:nowrap"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:'+fgCol(o.value)+';margin-right:8px"></span><b style="font-size:17px">'+o.value+'</b> <span style="font-size:12px;font-weight:700;letter-spacing:.05em;color:'+fgCol(o.value)+'">'+o.zone.toUpperCase()+'</span></span>':'<span class="mut">–</span>')+'</div>'}
function viewFG(){if(!FG){loadFG();return'<div class="card mut">Calculando el índice con datos de Tradier…</div>'}
  if(FG.building)return '<div class="card"><div class="lbl">ÍNDICE DE MIEDO Y CODICIA</div><div class="mut">Preparando la historia (solo la primera vez del día): '+FG.done+' de '+(FG.total||"…")+' símbolos'+(FG.err?' · <span class="bad">'+esc(FG.err)+'</span>':'')+'.</div></div>';
  if(FG.error)return '<div class="card bad">'+esc(FG.error)+'</div>';
  const c=fgCol(FG.value),fd=d=>d?d.slice(8,10)+"/"+d.slice(5,7):"";
  return '<div class="card"><div class="lbl" style="font-size:14px;color:var(--tx);font-weight:800">ÍNDICE DE MIEDO Y CODICIA</div><div class="sub">Qué emoción mueve al mercado ahora · cálculo propio con datos de Tradier, <b>no</b> es el índice de CNN</div>'
   +'<div style="text-align:center;margin-top:6px">'+gauge(FG.value)+'<div style="font-size:56px;font-weight:900;line-height:1;margin-top:-6px;color:'+c+'">'+FG.value+'</div><div style="font-weight:800;letter-spacing:.08em;font-size:18px;margin-top:6px;color:'+c+'">'+FG.zone.toUpperCase()+'</div></div>'
   +'<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));column-gap:60px;border-top:1px solid var(--line);border-bottom:1px solid var(--line);margin-top:16px;padding:6px 0">'+fgPrev("Cierre anterior",FG.prev)+fgPrev("Hace 1 semana",FG.week)+fgPrev("Hace 1 mes",FG.month)+fgPrev("Hace 1 año",FG.year)+'</div>'
   +FG.comps.map(x=>'<div style="padding:14px 0;border-bottom:1px solid var(--line)"><div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;flex-wrap:wrap"><b style="font-size:15px">'+esc(x.name)+'</b><b style="font-size:12px;letter-spacing:.06em;color:'+fgCol(x.score)+'">'+x.zone.toUpperCase()+' · '+Math.round(x.score)+'</b></div><div class="mut" style="font-size:12px;margin-top:2px">'+esc(x.desc)+' &nbsp;<b style="color:var(--tx)">'+esc(x.detail)+'</b>'+(x.asof?' <i>al '+fd(x.asof)+'</i>':'')+(x.prov?' · <span style="color:var(--warn,#ffc04d)">provisional (aún sin historia propia)</span>':'')+'</div>'+fgBar(x.score)+'</div>').join("")
   +'<div class="lbl" style="margin-top:16px">ÚLTIMOS 12 MESES</div>'+fgChart(FG.chart)
   +'<div class="mut" style="font-size:11.5px;margin-top:12px;line-height:1.5">Cada componente se califica por cuántas desviaciones estándar se aleja de su propio promedio reciente (1 año para momento y volatilidad, 6 meses para el resto): 50 = normal, más alto = codicia, más bajo = miedo. El índice es el promedio de los '+FG.n+' componentes disponibles. La fuerza se mide con las '+FG.n_stocks+' empresas de la lista (no todo el mercado). El put/call es de SPY (no de todas las acciones) y se guarda un dato por día; tiene '+FG.pc_days+' día(s) guardado(s) y entra a la historia desde que existe. Se actualiza cada 5 min.</div></div>'}
function setVS(s){VSORT=s;localStorage.setItem("mk_vs",s);paint()}
function viewVol(){if(!VO){loadVO();return'<div class="card mut">Cargando volatilidad…</div>'}
  const v=VO.vix,rows=[...VO.rows],S={ivhv_d:["IV/HV alta (cara)",(a,b)=>(b.ivhv||0)-(a.ivhv||0)],ivhv_a:["IV/HV baja (barata)",(a,b)=>(a.ivhv||99)-(b.ivhv||99)],iv_d:["IV alta",(a,b)=>b.iv-a.iv],iv_a:["IV baja",(a,b)=>a.iv-b.iv],hv_d:["HV alta",(a,b)=>(b.hv||0)-(a.hv||0)]};
  rows.sort(S[VSORT][1]);
  const pills=Object.keys(S).map(k=>'<span class="pill'+(VSORT===k?" on":"")+'" onclick="setVS(\''+k+'\')">'+S[k][0]+'</span>').join("");
  const vt=v?'<div class="tile" style="max-width:260px"><div class="mut" style="font-size:12px">VIX</div><div style="font-size:26px;font-weight:800">'+v.last.toFixed(2)+'</div><div class="'+cl(v.pct)+'">'+fp(v.pct)+'</div></div>':'<div class="mut">VIX no disponible en esta cuenta.</div>';
  const prog=VO.running?'<div class="mut" style="margin:8px 0">Calculando… '+VO.done+' de '+VO.total+' empresas (con pausas para no saturar a Tradier; la tabla se llena sola).</div>':'';
  return ''
   +'<div class="card"><div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between"><div><div class="lbl">IV DE LA LISTA</div><div class="sub">IV 30d = volatilidad implícita ATM a ~30 días · HV 20d = volatilidad real · IV/HV alto = opciones caras frente a lo que se mueve la acción. Solo las '+VO.total+' empresas de la lista; no hay IV Rank (Tradier no da historial de IV).</div></div><div style="display:flex;gap:6px;flex-wrap:wrap">'+pills+'</div></div>'+prog
   +(VO.err&&!rows.length?'<div class="bad">'+esc(VO.err)+'</div>':'')
   +'<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr class="mut"><th style="text-align:left">#</th><th style="text-align:left">Símbolo</th><th>Precio</th><th>% Día</th><th>IV 30d</th><th>HV 20d</th><th>IV/HV</th></tr></thead><tbody>'
   +rows.slice(0,60).map((r,i)=>'<tr style="border-top:1px solid var(--line)"><td class="mut">'+(i+1)+'</td><td><b>'+r.sym+'</b> <span class="mut" style="font-size:11px">'+esc(r.name)+'</span></td><td style="text-align:right">'+r.last.toFixed(2)+'</td><td style="text-align:right" class="'+cl(r.pct)+'">'+fp(r.pct)+'</td><td style="text-align:right"><b>'+r.iv.toFixed(1)+'%</b></td><td style="text-align:right">'+(r.hv==null?"–":r.hv.toFixed(1)+"%")+'</td><td style="text-align:right"><b>'+(r.ivhv==null?"–":r.ivhv.toFixed(2))+'</b></td></tr>').join("")+'</tbody></table></div></div>'}
function paint(){if(!D)return;const _ae=document.activeElement,_fid=!!(_ae&&(_ae.id==="rk_q"||_ae.id==="iv_q")),_fidn=_ae&&_ae.id;$("view").innerHTML=({res:viewRes,rank:viewRank,inv:viewInv,eco:viewEco,rep:viewRep,heat:viewHeat,sec:viewSec,mov:viewMov,vol:viewVol,fg:viewFG})[TAB]();if(TAB==="heat")drawHeat();if(_fid&&$(_fidn)){const e=$(_fidn);e.focus();e.setSelectionRange(e.value.length,e.value.length)}}
async function load(){try{const r=await fetch("/api/market",{cache:"no-store"});const j=await r.json();if(j.error)throw new Error(j.error);D=j;
    $("msg").textContent=D.missing?"Sin cotización para "+D.missing+" símbolos de la lista (se omiten).":"";
    $("st").textContent=(D.live?"cuenta REAL · en vivo":"papel · ~15 min de retraso")+" · "+new Date(D.ts*1000).toLocaleTimeString("es",{hour:"2-digit",minute:"2-digit"});paint()}
  catch(e){$("msg").innerHTML='<span class="bad">No pude cargar el mercado: '+esc(e.message||e)+'</span>'}}
window.addEventListener("resize",()=>{if(TAB==="heat")drawHeat()});
tabs();load();setInterval(load,30000);loadCards();setInterval(loadCards,30000);setInterval(()=>{if(TAB==="res"){loadPano("tech");loadPano("comm");loadPano("fx")}},60000);setInterval(()=>{if(TAB==="res")loadPano("tsy")},300000);setInterval(clk,20000);
</script></main></body></html>"""
