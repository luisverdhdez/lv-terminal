"""Comisiones de tus operaciones, sacadas del historial de Tradier (/accounts/{id}/history, tipo trade).
Tradier cobra por contrato; aqui se calcula cuanto costo cada contrato de cada opcion (abrir + cerrar)
y se asigna a cada operacion de tus reportes. Se refresca en segundo plano cada 10 min (nunca frena la pagina)."""
import json
import os
import threading
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import trading
from trading import _as_list, _num

ET = ZoneInfo("America/New_York")
_C = {}
_BUSY = set()


def _file(k):
    return os.path.join(trading.DATA_DIR, f"comisiones_{k}.json")


def _key(live):
    k = trading.akey(live)
    return "h" if k == trading.H else ("real" if k else "papel")


def fetch(env, live, days=400):
    """-> {"by": {simbolo: [comision, contratos]}, "comm": total, "qty": total, "t": hora}"""
    start = (datetime.now(ET).date() - timedelta(days=days)).isoformat()
    by, page = {}, 1
    while page <= 30:
        j = trading._call_acct(env, live, "GET", "/accounts/{acct}/history",
                               params={"type": "trade", "start": start, "limit": 1000, "page": page})
        h = j.get("history") if isinstance(j, dict) else None
        ev = _as_list(h.get("event")) if isinstance(h, dict) else []
        for e in ev:
            t = e.get("trade") if isinstance(e, dict) else None
            if not isinstance(t, dict):
                continue
            s = str(t.get("symbol") or "")
            c = abs(_num(t.get("commission")) or 0)
            q = abs(_num(t.get("quantity")) or 0)
            if not s or not q:
                continue
            x = by.setdefault(s, [0.0, 0.0])
            x[0] += c
            x[1] += q
        if len(ev) < 1000:
            break
        page += 1
    tc = sum(v[0] for v in by.values())
    tq = sum(v[1] for v in by.values())
    return {"by": by, "comm": round(tc, 2), "qty": tq, "t": time.time()}


def _refresh(env, live):
    k = _key(live)
    try:
        d = fetch(env, live)
        _C[k] = d
        tmp = _file(k) + ".tmp"
        with open(tmp, "w") as f:
            json.dump(d, f)
        os.replace(tmp, _file(k))
    except Exception:  # noqa: BLE001 - sin datos nuevos se usa lo ultimo
        pass
    finally:
        _BUSY.discard(k)


def get(env, live):
    """Datos en cache (o None si todavia no hay). Lanza la actualizacion en segundo plano si tienen mas de 10 min."""
    k = _key(live)
    d = _C.get(k)
    if d is None:
        try:
            with open(_file(k)) as f:
                d = _C[k] = json.load(f)
        except (OSError, ValueError):
            d = None
    if (d is None or time.time() - d.get("t", 0) > 600) and k not in _BUSY:
        _BUSY.add(k)
        threading.Thread(target=_refresh, args=(env, live), daemon=True).start()
    return d


def row_comm(row, d):
    """Comision estimada de una operacion de los reportes: cada pata x contratos x (abrir + cerrar)."""
    if not d:
        return None
    avg = d["comm"] / d["qty"] if d.get("qty") else 0.0
    try:
        qty = abs(float(row.get("cantidad") or 0))
    except (TypeError, ValueError):
        qty = 0
    legs = [x.strip() for x in str(row.get("opcion") or "").split("/") if x.strip()]
    if not qty or not legs:
        return 0.0
    tot = 0.0
    for leg in legs:
        c, q = (d["by"].get(leg) or [None, None])
        rate = (c / q) if q else avg
        tot += rate * qty * 2
    return round(tot, 2)


def total(rows, d):
    if not d:
        return None
    return round(sum(row_comm(r, d) or 0 for r in rows), 2)
