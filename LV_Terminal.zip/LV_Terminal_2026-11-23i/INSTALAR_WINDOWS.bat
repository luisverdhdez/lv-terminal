@echo off
rem Doble clic aqui para instalar LV Options Terminal en Windows
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY goto instalar
echo No encontre Python. Lo instalo ahora (puede tardar 2-3 minutos)...
winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY goto instalar
echo.
echo No pude instalar Python solo. Instalalo desde https://www.python.org/downloads/
echo (marca "Add python.exe to PATH") y vuelve a dar doble clic a INSTALAR_WINDOWS.bat
goto fin
:instalar
%PY% instalar_windows.py
:fin
echo.
pause
