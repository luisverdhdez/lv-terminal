"""
Market → Resultados: calendario de reportes (earnings) de las empresas grandes de la lista, con EPS estimado vs real,
sorpresa, momento (antes de abrir / despues del cierre), movimiento ESPERADO por las opciones (straddle al dinero,
Tradier) y movimiento REAL despues del reporte.
- Yahoo (yfinance) se consulta en segundo plano cada 12 h, con pausas; se guarda en resultados.json.
- El movimiento esperado se guarda antes del reporte (resultados_mov.json) para compararlo despues con el real.
"""
import json
import math
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta

import trading
import market

BASE = os.path.dirname(os.path.abspath(__file__))
F_DATA = os.path.join(BASE, "resultados.json")
F_MOV = os.path.join(BASE, "resultados_mov.json")
GIANTS = {"NVDA", "AAPL", "MSFT", "AMZN", "GOOGL", "META", "AVGO", "TSLA", "BRK.B", "JPM", "LLY", "WMT", "NFLX"}
_S = {"running": False, "done": 0, "total": 0, "err": None}
_L = threading.RLock()
_MOV_C = {}


def _universe():
    try:
        import panorama
        extra = panorama.TECH
    except Exception:
        extra = []
    names = {u[0]: u[1] for u in market.U}
    syms = list(dict.fromkeys([u[0] for u in market.U] + list(extra)))
    return syms, names


def _jl(p, d):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return d


def _js(p, o):
    tmp = f"{p}.{threading.get_ident()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(o, f)
    os.replace(tmp, p)


def _f(x):
    try:
        v = float(x)
        return None if math.isnan(v) else v
    except (TypeError, ValueError):
        return None


def _when(ts):
    """'antes' (antes de abrir), 'despues' (despues del cierre), 'durante' o None si Yahoo no da la hora."""
    if ts is None or not hasattr(ts, "hour"):
        return None
    hm = ts.hour * 60 + ts.minute
    if hm == 0:
        return None            # sin hora
    return "antes" if hm < 9 * 60 + 30 else "despues" if hm >= 16 * 60 else "durante"


def _one(yf, sym):
    t = yf.Ticker(sym.replace(".", "-"))
    out = {"t": time.time(), "dates": [], "rev_est": None}
    try:
        df = t.get_earnings_dates(limit=8)
        if df is not None and len(df):
            for ts, row in df.iterrows():
                try:
                    ts2 = ts.tz_convert("America/New_York") if getattr(ts, "tzinfo", None) else ts
                except Exception:
                    ts2 = ts
                out["dates"].append({"date": str(ts2)[:10], "when": _when(ts2), "eps_est": _f(row.get("EPS Estimate")),
                                     "eps_act": _f(row.get("Reported EPS")), "surprise": _f(row.get("Surprise(%)"))})
    except Exception:
        pass
    try:
        cal = t.calendar
        if isinstance(cal, dict):
            eds = cal.get("Earnings Date") or []
            eds = eds if isinstance(eds, (list, tuple)) else [eds]
            have = {d["date"] for d in out["dates"]}
            for x in eds:
                s = str(x)[:10]
                if len(s) == 10 and s not in have:
                    out["dates"].append({"date": s, "when": None, "eps_est": _f(cal.get("Earnings Average")),
                                         "eps_act": None, "surprise": None})
            out["rev_est"] = _f(cal.get("Revenue Average"))
            if out["dates"]:
                nxt = min((d for d in out["dates"] if d["date"] >= date.today().isoformat()), key=lambda d: d["date"], default=None)
                if nxt and nxt["eps_est"] is None:
                    nxt["eps_est"] = _f(cal.get("Earnings Average"))
    except Exception:
        pass
    return out


def _worker():
    try:
        import fundamentales
        yf = fundamentales._yf()
    except Exception as e:
        _S.update(running=False, err=f"Falta yfinance ({e.__class__.__name__})")
        return
    syms, _ = _universe()
    d = _jl(F_DATA, {"ts": 0, "s": {}})
    d["tried"] = time.time()
    _S.update(done=0, total=len(syms), err=None)
    for i, s in enumerate(syms):
        try:
            d["s"][s] = _one(yf, s)
        except Exception:
            pass
        _S["done"] = i + 1
        if (i + 1) % 20 == 0:
            _js(F_DATA, d)
        time.sleep(0.4)
    d["ts"] = time.time()
    _js(F_DATA, d)
    _S["running"] = False


def _ensure():
    d = _jl(F_DATA, {"ts": 0, "s": {}})
    with _L:
        if not _S["running"] and time.time() - d.get("ts", 0) > 12 * 3600 and time.time() - d.get("tried", 0) > 3 * 3600:
            _S["running"] = True
            threading.Thread(target=_worker, daemon=True).start()
    return d


# ───────────── movimiento esperado (straddle al dinero) ─────────────
def expected_move(env, sym, rdate, when):
    """% que el mercado de opciones descuenta para el reporte: precio del straddle ATM / precio de la accion,
    en el primer vencimiento que ya incluye el reporte."""
    k = (sym, rdate, trading.MODE["live"])
    c = _MOV_C.get(k)
    if c and time.time() - c[0] < 900:
        return c[1]
    res = None
    try:
        ex = trading._call(env, "GET", "/markets/options/expirations", params={"symbol": sym})
        dates = trading._as_list((ex.get("expirations") or {}).get("date")) if isinstance(ex.get("expirations"), dict) else []
        need = rdate if when == "antes" else (date.fromisoformat(rdate) + timedelta(days=1)).isoformat()
        exp = min((x for x in dates if x >= need), default=None)
        q = market._quotes(env, [sym]).get(sym) or {}
        spot = _f(q.get("last"))
        if exp and spot:
            ch = trading._call(env, "GET", "/markets/options/chains", params={"symbol": sym, "expiration": exp})
            opts = trading._as_list((ch.get("options") or {}).get("option")) if isinstance(ch.get("options"), dict) else []
            ks = sorted({_f(o.get("strike")) for o in opts if _f(o.get("strike"))}, key=lambda x: abs(x - spot))
            if ks:
                atm = ks[0]

                def mid(t):
                    o = next((o for o in opts if o.get("option_type") == t and _f(o.get("strike")) == atm), None)
                    b, a = (_f(o.get("bid")), _f(o.get("ask"))) if o else (None, None)
                    return (b + a) / 2 if b is not None and a and a > 0 else None
                cm, pm = mid("call"), mid("put")
                if cm is not None and pm is not None:
                    res = {"pct": (cm + pm) / spot * 100, "usd": cm + pm, "exp": exp, "spot": spot}
    except trading.ApiError:
        res = None
    _MOV_C[k] = (time.time(), res)
    if res:
        with _L:                                   # varios hilos: uno a la vez escribe el archivo
            m = _jl(F_MOV, {})
            m[f"{sym}|{rdate}"] = dict(res, t=time.time())
            if len(m) > 2000:
                m = dict(sorted(m.items(), key=lambda kv: kv[1].get("t", 0))[-1500:])
            _js(F_MOV, m)
    return res


def real_move(env, sym, rdate, when):
    """Cambio % del cierre antes del reporte al cierre despues del reporte (None si aun no se sabe)."""
    k = ("real", sym, rdate)
    c = _MOV_C.get(k)
    if c and time.time() - c[0] < 1800:
        return c[1]
    res = None
    try:
        cl = market._closes(env, sym)
        before = [c for d, c in cl if d < rdate] if when != "despues" else [c for d, c in cl if d <= rdate]
        after = [c for d, c in cl if d >= rdate] if when != "despues" else [c for d, c in cl if d > rdate]
        if before and after:
            res = (after[0] / before[-1] - 1) * 100
    except trading.ApiError:
        res = None
    _MOV_C[k] = (time.time(), res)
    return res


def data(env):
    d = _ensure()
    syms, names = _universe()
    today = date.today()
    lo, hi = (today - timedelta(days=7)).isoformat(), (today + timedelta(days=14)).isoformat()
    rows = []
    for s, v in d.get("s", {}).items():
        for e in v.get("dates", []):
            if lo <= e["date"] <= hi:
                rows.append(dict(e, sym=s, name=names.get(s, s), giant=s in GIANTS, rev_est=v.get("rev_est") if e["date"] >= today.isoformat() else None))
    rows.sort(key=lambda r: (r["date"], {"antes": 0, "durante": 1, "despues": 2, None: 3}[r["when"]], not r["giant"], r["sym"]))
    saved = _jl(F_MOV, {})
    up = [r for r in rows if r["date"] >= today.isoformat() and r["date"] <= (today + timedelta(days=7)).isoformat()]
    past = [r for r in rows if r["date"] <= today.isoformat()]

    def mv(r):
        try:
            return r, expected_move(env, r["sym"], r["date"], r["when"])
        except Exception:                          # un reporte con problema no tumba la pagina
            return r, None
    with ThreadPoolExecutor(max_workers=4) as ex:
        for r, m in ex.map(mv, up[:40]):
            r["exp_move"] = m
    for r in past:
        if r.get("exp_move") is None:
            r["exp_move"] = saved.get(f'{r["sym"]}|{r["date"]}')
        if r["date"] < today.isoformat() or (r["when"] == "antes" and datetime.now().hour >= 16):
            try:
                r["real_move"] = real_move(env, r["sym"], r["date"], r["when"])
            except Exception:
                r["real_move"] = None
    return {"rows": rows, "today": today.isoformat(), "building": _S["running"], "done": _S["done"], "total": _S["total"],
            "err": _S["err"], "n_syms": len(syms), "ts": d.get("ts")}
