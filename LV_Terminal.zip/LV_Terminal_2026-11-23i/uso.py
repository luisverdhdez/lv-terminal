"""Contador de consultas a Tradier (para saber si la terminal se acerca al limite de Tradier).

Cuenta TODAS las consultas que el panel hace a Tradier (graficas, posiciones, gestor, robots, gamma...),
cuantas por minuto, cuales son las que mas se piden, y lo que Tradier dice que queda de su limite
(encabezados X-Ratelimit). Solo cuenta: no guarda tokens, numeros de cuenta ni respuestas.
"""
import collections
import json
import os
import re
import threading
import time
from datetime import datetime
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

import requests

NY = ZoneInfo("America/New_York")
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tradier_uso.json")
_L = threading.Lock()
EV = collections.deque(maxlen=20000)     # (t, host, ruta, codigo, segundos)
LIM = {}                                 # host -> {allowed, available, expiry, t}
DAY = {"day": None, "peak": 0, "peak_at": None, "e429": 0, "total": 0}
_INST = [False]


def _ruta(url):
    p = urlparse(url)
    path = re.sub(r"/accounts/[^/]+", "/accounts/{cuenta}", p.path)
    path = re.sub(r"/orders/\d+", "/orders/{id}", path)
    return p.netloc.split(".")[0], path


def _rec(url, code, secs, headers):
    host, path = _ruta(url)
    now = time.time()
    with _L:
        EV.append((now, host, path, code, secs))
        d = datetime.now(NY).strftime("%Y-%m-%d")
        if DAY["day"] != d:
            DAY.update(day=d, peak=0, peak_at=None, e429=0, total=0)
        DAY["total"] += 1
        if code == 429:
            DAY["e429"] += 1
        n = sum(1 for e in EV if e[0] >= now - 60)
        if n > DAY["peak"]:
            DAY["peak"], DAY["peak_at"] = n, datetime.now(NY).strftime("%H:%M:%S")
        if headers is not None and headers.get("X-Ratelimit-Allowed"):
            LIM[host + " " + path.split("/")[2] if path.count("/") >= 2 else host] = {
                "permitidas": headers.get("X-Ratelimit-Allowed"), "quedan": headers.get("X-Ratelimit-Available"),
                "hora": datetime.now(NY).strftime("%H:%M:%S")}


def install():
    """Envuelve requests para contar cada consulta a *.tradier.com (una sola vez)."""
    if _INST[0]:
        return
    _INST[0] = True
    orig = requests.sessions.Session.request

    def req(self, method, url, *a, **kw):
        t0 = time.time()
        try:
            r = orig(self, method, url, *a, **kw)
        except Exception:
            if "tradier.com" in str(url):
                _rec(str(url), 0, time.time() - t0, None)
            raise
        if "tradier.com" in str(url):
            _rec(str(url), r.status_code, time.time() - t0, r.headers)
        return r
    requests.sessions.Session.request = req
    threading.Thread(target=_writer, daemon=True).start()


def resumen():
    now = time.time()
    with _L:
        ev = list(EV)
        lim = dict(LIM)
        day = dict(DAY)
    m1 = [e for e in ev if e[0] >= now - 60]
    por_min = []
    for k in range(10, 0, -1):
        a, b = now - k * 60, now - (k - 1) * 60
        por_min.append(sum(1 for e in ev if a <= e[0] < b))
    top = collections.Counter(e[2] for e in m1).most_common(8)
    lentas = sum(1 for e in m1 if e[4] >= 3)
    return {"hora": datetime.now(NY).strftime("%H:%M:%S"), "ultimo_minuto": len(m1),
            "por_minuto_ultimos_10": por_min, "mas_pedidas_1min": top, "lentas_1min": lentas,
            "errores_1min": sum(1 for e in m1 if e[3] in (0, 429) or e[3] >= 500),
            "maximo_hoy": day["peak"], "maximo_hoy_a_las": day["peak_at"], "limite_429_hoy": day["e429"],
            "total_hoy": day["total"], "tradier_dice": lim}


def _writer():
    while True:
        time.sleep(10)
        try:
            with open(FILE, "w") as f:
                json.dump(resumen(), f, indent=1)
        except OSError:
            pass
