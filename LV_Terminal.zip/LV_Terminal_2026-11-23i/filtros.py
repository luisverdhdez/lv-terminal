"""
Modo sombra: FILTROS DE ENTRADA para el robot de SPY.
Toma todas las señales que registra senales.py (cuenta real) y, para cada una, calcula el CONTEXTO del momento
(horario, VWAP, tendencia de 5 min, apertura del dia, rango de apertura, VIX, tamaño de velas, Corona, cerca de HH/LL).
Luego compara: con cada filtro, ¿cuantas señales quedan y cuanto se movio SPY a favor a los 15 y 30 min?
- NUNCA envia ordenes; solo lee velas de 1 min (SPY y VIX) y las guarda por dia en filtros_cache/ (Tradier borra las viejas).
- "Consistente" = mejora el promedio en las DOS mitades de los dias (para no confundir suerte con ventaja).
- El movimiento de SPY es un sustituto: con una opcion de delta ~0.5, $0.10 de SPY son ~ $5 por contrato.
"""
import csv
import json
import os
import threading
import time
from datetime import datetime, time as dtime, timedelta

import tradier_bot as tb

ET = tb.ET
BASE = os.path.dirname(os.path.abspath(__file__))
SIGNALS = os.path.join(BASE, "senales_live.csv")
CACHE = os.path.join(BASE, "filtros_cache")
OUT = os.path.join(BASE, "filtros.json")
LOCK = threading.Lock()
STATE = {"busy": False, "err": None, "prog": ""}
MIN_N = 20


def _f(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _bars_day(api, sym, day):
    """Velas de 1 min de un dia (cache en disco: los dias pasados no cambian)."""
    os.makedirs(CACHE, exist_ok=True)
    fn = os.path.join(CACHE, f"{sym}_{day}.json")
    today = datetime.now(ET).strftime("%Y-%m-%d")
    if os.path.exists(fn) and day < today:
        with open(fn, encoding="utf-8") as f:
            return json.load(f)
    j = api._req("GET", "/markets/timesales", params={"symbol": sym, "interval": "1min", "session_filter": "open",
                                                       "start": f"{day} 09:30", "end": f"{day} 16:00"})
    out = []
    for d in tb.as_list((j.get("series") or {}).get("data")):
        try:
            out.append({"ts": int(d["timestamp"]), "o": float(d["open"]), "h": float(d["high"]), "l": float(d["low"]),
                        "c": float(d["close"]), "v": float(d.get("volume") or 0)})
        except (KeyError, TypeError, ValueError):
            pass
    out.sort(key=lambda b: b["ts"])
    if out and day < today:
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(out, f)
    return out


def _ema(v, n):
    o, k, e = [], 2 / (n + 1), None
    for x in v:
        e = x if e is None else x * k + e * (1 - k)
        o.append(e)
    return o


def _hm(ts):
    return datetime.fromtimestamp(ts, ET).strftime("%H:%M")


def context(sig, bars, vix):
    """Contexto de una señal (dict con las caracteristicas). bars/vix: velas de 1 min del dia."""
    hm, sg, px = sig["hora_vela"], (1 if sig["lado"] == "buy" else -1), _f(sig["precio"])
    idx = [i for i, b in enumerate(bars) if _hm(b["ts"] + 60) <= hm]
    if not idx or px is None:
        return None
    i = idx[-1]
    B = bars[:i + 1]
    # VWAP del dia
    pv = vv = 0.0
    for b in B:
        tp = (b["h"] + b["l"] + b["c"]) / 3
        pv += tp * b["v"]
        vv += b["v"]
    vwap = pv / vv if vv else None
    # tendencia en velas de 5 min
    c5 = [B[k]["c"] for k in range(4, len(B), 5)] or [B[-1]["c"]]
    e9, e21 = _ema(c5, 9)[-1], _ema(c5, 21)[-1]
    op = bars[0]["o"]
    orr = bars[:15]
    orh, orl = max(b["h"] for b in orr), min(b["l"] for b in orr)
    h = int(hm[:2]) * 60 + int(hm[3:])
    franja = ("9:30–10:00" if h < 600 else "10:00–11:30" if h < 690 else "11:30–13:30" if h < 810
              else "13:30–15:00" if h < 900 else "15:00–16:00")
    out = {"franja": franja,
           "vwap": None if vwap is None else ("a favor" if sg * (px - vwap) > 0 else "en contra"),
           "tend5": "a favor" if sg * (e9 - e21) > 0 else "en contra",
           "apertura": "a favor" if sg * (px - op) > 0 else "en contra",
           "rango_ap": (None if h < 585 else "rompió a favor" if (sg > 0 and px > orh) or (sg < 0 and px < orl)
                        else "rompió en contra" if (sg > 0 and px < orl) or (sg < 0 and px > orh) else "dentro"),
           "corona": "con Corona" if sig.get("corona") == "1" else "sin Corona",
           "hhll": "cerca de HH/LL" if sig.get("cerca_hhll") == "1" else "lejos de HH/LL"}
    vx = [b for b in vix if _hm(b["ts"] + 60) <= hm]
    if vx:
        lv = vx[-1]["c"]
        out["vix"] = "VIX < 18" if lv < 18 else "VIX 18–22" if lv < 22 else "VIX ≥ 22"
        prev = vx[-31]["c"] if len(vx) > 30 else vx[0]["c"]
        # VIX bajando ayuda a las compras; subiendo, a las ventas
        out["vix_dir"] = "VIX a favor" if sg * (prev - lv) > 0 else "VIX en contra"
    return out


FACTORS = [("franja", "Horario"), ("vwap", "VWAP"), ("tend5", "Tendencia 5 min (EMA 9/21)"), ("apertura", "Precio vs apertura"),
           ("rango_ap", "Rango de apertura (15 min)"), ("vix", "Nivel del VIX"), ("vix_dir", "Dirección del VIX (30 min)"),
           ("atr", "Tamaño de velas (ATR)"), ("corona", "Corona"), ("hhll", "Cerca de HH/LL")]
GOOD = {"vwap": "a favor", "tend5": "a favor", "apertura": "a favor", "rango_ap": "rompió a favor", "vix_dir": "VIX a favor",
        "corona": "con Corona"}


def _stats(rows, key="mov15"):
    v = [r[key] for r in rows if r.get(key) is not None]
    if not v:
        return None
    return {"n": len(v), "fav": round(100 * sum(1 for x in v if x > 0) / len(v)), "avg": round(sum(v) / len(v), 3)}


def evaluate(rows):
    """Tabla de filtros (uno y dos a la vez) contra el total. rows: señales con 'ctx', mov15, mov30, fecha."""
    rows = [r for r in rows if r.get("mov15") is not None]
    if not rows:
        return {"n": 0}
    days = sorted({r["fecha"] for r in rows})
    half = set(days[:len(days) // 2])
    base = {"m15": _stats(rows), "m30": _stats(rows, "mov30"), "dias": len(days)}
    b1, b2 = _stats([r for r in rows if r["fecha"] in half]), _stats([r for r in rows if r["fecha"] not in half])

    def line(name, sel):
        s15 = _stats(sel)
        if not s15 or s15["n"] < MIN_N:
            return None
        h1, h2 = _stats([r for r in sel if r["fecha"] in half]), _stats([r for r in sel if r["fecha"] not in half])
        cons = bool(h1 and h2 and b1 and b2 and h1["avg"] > b1["avg"] and h2["avg"] > b2["avg"])
        s30 = _stats(sel, "mov30")
        mfe = [r["mfe30"] for r in sel if r.get("mfe30") is not None]
        mae = [r["mae30"] for r in sel if r.get("mae30") is not None]
        return {"filtro": name, "n": s15["n"], "pct": round(100 * s15["n"] / base["m15"]["n"]), "fav15": s15["fav"],
                "avg15": s15["avg"], "avg30": s30["avg"] if s30 else None, "dif15": round(s15["avg"] - base["m15"]["avg"], 3),
                "mfe": round(sum(mfe) / len(mfe), 2) if mfe else None, "mae": round(sum(mae) / len(mae), 2) if mae else None,
                "consistente": cons}
    simples = []
    for k, nom in FACTORS:
        vals = sorted({r["ctx"].get(k) for r in rows if r["ctx"].get(k) is not None})
        for v in vals:
            ln = line(f"{nom}: {v}", [r for r in rows if r["ctx"].get(k) == v])
            if ln:
                ln["grupo"] = nom
                simples.append(ln)
    combos = []
    ks = list(GOOD) + ["franja"]
    for a in range(len(ks)):
        for b in range(a + 1, len(ks)):
            ka, kb = ks[a], ks[b]
            va = [GOOD[ka]] if ka in GOOD else sorted({r["ctx"].get(ka) for r in rows if r["ctx"].get(ka)})
            vb = [GOOD[kb]] if kb in GOOD else sorted({r["ctx"].get(kb) for r in rows if r["ctx"].get(kb)})
            for x in va:
                for y in vb:
                    ln = line(f"{dict(FACTORS)[ka]}: {x}  +  {dict(FACTORS)[kb]}: {y}",
                              [r for r in rows if r["ctx"].get(ka) == x and r["ctx"].get(kb) == y])
                    if ln:
                        combos.append(ln)
    combos.sort(key=lambda x: (not x["consistente"], -x["dif15"]))
    return {"n": base["m15"]["n"], "base": base, "simples": simples, "combos": combos[:15],
            "mejores": [x for x in sorted(simples + combos, key=lambda x: -x["dif15"]) if x["consistente"] and x["dif15"] > 0][:6]}


def run(env):
    """Calcula todo (baja las velas que falten). Guarda filtros.json."""
    with LOCK:
        if STATE["busy"]:
            return
        STATE.update(busy=True, err=None)
    try:
        tok = (env or {}).get("TRADIER_LIVE_TOKEN")
        if not tok:
            raise RuntimeError("Hace falta el token REAL (solo para leer velas)")
        api = tb.Tradier(tok, "", "live", True)
        with open(SIGNALS, encoding="utf-8") as f:
            sigs = list(csv.DictReader(f))
        rows, faltan = [], []
        atrs = sorted(_f(s["atr"]) / _f(s["precio"]) for s in sigs if _f(s.get("atr")) and _f(s.get("precio")))
        med = atrs[len(atrs) // 2] if atrs else None
        for day in sorted({s["fecha"] for s in sigs}):
            STATE["prog"] = f"Velas del {day}"
            try:
                bars, vix = _bars_day(api, "SPY", day), _bars_day(api, "VIX", day)
            except Exception:
                faltan.append(day)
                continue
            if not bars:
                faltan.append(day)
                continue
            for s in sigs:
                if s["fecha"] != day:
                    continue
                c = context(s, bars, vix)
                if not c:
                    continue
                a = _f(s.get("atr"))
                if a and med and _f(s["precio"]):
                    c["atr"] = "velas grandes" if a / _f(s["precio"]) >= med else "velas chicas"
                rows.append({"fecha": day, "hora": s["hora_vela"], "lado": s["lado"], "ctx": c,
                             "mov15": _f(s.get("mov15")), "mov30": _f(s.get("mov30")),
                             "mfe30": _f(s.get("mfe30")), "mae30": _f(s.get("mae30"))})
            time.sleep(0.3)
        res = evaluate(rows)
        res.update(ts=time.time(), faltan=faltan, senales=len(rows))
        tmp = OUT + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(res, f)
        os.replace(tmp, OUT)
    except Exception as e:
        STATE["err"] = f"{e.__class__.__name__}: {e}"
    finally:
        STATE.update(busy=False, prog="")


def loop(get_env):
    """Se recalcula solo cada dia habil a las 16:45 ET (despues de que senales.py completa sus mediciones)."""
    done = None
    while True:
        try:
            now = datetime.now(ET)
            if now.weekday() < 5 and now.time() >= dtime(16, 45) and done != now.date():
                done = now.date()
                run(get_env() or {})
        except Exception:
            pass
        time.sleep(60)


def summary():
    try:
        with open(OUT, encoding="utf-8") as f:
            r = json.load(f)
    except (OSError, ValueError):
        r = {}
    return dict(r, busy=STATE["busy"], prog=STATE["prog"], err=STATE["err"])
