"""
Seccion Fundamentales: ficha de la empresa, estados financieros, ratios, valoracion, dividendos y comparador.
Datos de Yahoo Finance mediante la libreria gratuita yfinance (sin clave). No es una API oficial de Yahoo:
puede fallar o limitar las consultas de vez en cuando. Lo sirve monitor_web.py (/fundamentales y /api/fund/*).
Solo lectura; no envia ordenes.
"""
import math
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import requests

SYM_RE = re.compile(r"^[A-Z][A-Z.\-]{0,5}$")
_CACHE = {}
TTL_INFO, TTL_LONG = 300, 6 * 3600


class FundError(Exception):
    def __init__(self, msg, need_install=False):
        super().__init__(msg)
        self.need_install = need_install


def _yf():
    try:
        import yfinance
        return yfinance
    except ImportError:
        raise FundError("Falta la librería de datos (yfinance). Presiona el botón para instalarla; el panel se reinicia solo.",
                        need_install=True)


def install():
    """pip install yfinance con el mismo Python que corre el panel. Si el panel lo lanza launchd, se reinicia solo."""
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "yfinance"], capture_output=True,
                           text=True, timeout=300)
    except Exception as e:
        return {"ok": False, "msg": f"No se pudo instalar ({e.__class__.__name__})"}
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()[-3:]
        return {"ok": False, "msg": "La instalación falló: " + " | ".join(tail)[:300]}
    return {"ok": True, "msg": "yfinance instalado.", "launchd": bool(os.environ.get("XPC_SERVICE_NAME", "").startswith("com.luis"))}


def _cached(key, ttl, fn):
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    val = fn()
    _CACHE[key] = (time.time(), val)
    return val


def _wrap(e):
    name = e.__class__.__name__
    if "RateLimit" in name or "429" in str(e) or "Too Many" in str(e):
        return FundError("Yahoo limitó las consultas por un rato (demasiadas seguidas). Espera unos minutos e intenta de nuevo.")
    return FundError(f"Yahoo no respondió ({name}). Revisa tu internet o intenta en unos minutos.")


def _n(v):
    try:
        f = float(v)
        return None if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return None


def _p(d, *keys):
    for k in keys:
        v = d.get(k)
        if v is not None and v != "":
            return v
    return None


def _sym(q):
    s = ((q.get("sym") or [""])[0]).strip().upper()
    if not SYM_RE.match(s):
        raise FundError("Símbolo no válido")
    return s


def _info(sym):
    yf = _yf()

    def go():
        try:
            d = yf.Ticker(sym).info
        except Exception as e:
            raise _wrap(e)
        if not isinstance(d, dict) or not (d.get("longName") or d.get("shortName") or d.get("regularMarketPrice") or d.get("currentPrice")):
            raise FundError(f"No encontré datos de {sym}. Revisa que el ticker exista.")
        return d
    return _cached(("info", sym), TTL_INFO, go)


def _div(a, b):
    a, b = _n(a), _n(b)
    return (a / b) if a is not None and b else None


def _ratios(i):
    """Normaliza lo que da Yahoo. Margenes, rendimientos y yields van como fraccion (0.25 = 25%)."""
    price = _n(_p(i, "currentPrice", "regularMarketPrice"))
    mc = _n(i.get("marketCap"))
    de = _n(i.get("debtToEquity"))
    nd = None
    if _n(i.get("totalDebt")) is not None and _n(i.get("totalCash")) is not None:
        nd = _div(_n(i["totalDebt"]) - _n(i["totalCash"]), i.get("ebitda"))
    dy = _div(i.get("dividendRate"), price)
    if dy is None:
        dy = _n(i.get("trailingAnnualDividendYield"))
    pe = _n(_p(i, "trailingPE"))
    return {
        "pe": pe, "pb": _n(i.get("priceToBook")), "ps": _n(i.get("priceToSalesTrailing12Months")),
        "peg": _n(_p(i, "trailingPegRatio", "pegRatio")), "p_fcf": _div(mc, i.get("freeCashflow")),
        "div_yield": dy, "payout": _n(i.get("payoutRatio")),
        "gross": _n(i.get("grossMargins")), "oper": _n(i.get("operatingMargins")), "net": _n(i.get("profitMargins")),
        "ebitda_m": _n(i.get("ebitdaMargins")),
        "de": (de / 100.0) if de is not None else None,        # Yahoo lo da en porcentaje
        "current": _n(i.get("currentRatio")), "quick": _n(i.get("quickRatio")), "int_cov": None,
        "ev_ebitda": _n(i.get("enterpriseToEbitda")), "roe": _n(i.get("returnOnEquity")), "roa": _n(i.get("returnOnAssets")),
        "roic": None, "earn_yield": (1.0 / pe) if pe else None, "fcf_yield": _div(i.get("freeCashflow"), mc),
        "net_debt_ebitda": nd, "ev": _n(i.get("enterpriseValue")),
    }


def overview(env, sym):
    i = _info(sym)
    offs = i.get("companyOfficers") or []
    ceo = next((o.get("name") for o in offs if "CEO" in str(o.get("title", "")).upper()), None) or (offs[0].get("name") if offs else None)
    price = _n(_p(i, "currentPrice", "regularMarketPrice"))
    rng = i.get("fiftyTwoWeekRange") or (f"{i['fiftyTwoWeekLow']}-{i['fiftyTwoWeekHigh']}" if i.get("fiftyTwoWeekLow") is not None else None)
    return {"sym": sym, "profile": {
        "name": _p(i, "longName", "shortName"), "exchange": _p(i, "fullExchangeName", "exchange"), "sector": i.get("sector"),
        "industry": i.get("industry"), "desc": i.get("longBusinessSummary"), "ceo": ceo, "web": i.get("website"),
        "employees": i.get("fullTimeEmployees"), "country": i.get("country"), "beta": _n(i.get("beta")), "range": rng,
        "last_div": _n(i.get("dividendRate")), "currency": i.get("currency"), "mktcap": _n(i.get("marketCap")), "price": price,
        "avg_vol": _n(i.get("averageVolume")), "volume": _n(_p(i, "volume", "regularMarketVolume"))},
        "quote": {"price": price, "pct": _n(i.get("regularMarketChangePercent")), "chg": _n(i.get("regularMarketChange")),
                  "volume": _n(_p(i, "regularMarketVolume", "volume")), "mktcap": _n(i.get("marketCap")), "pe": _n(i.get("trailingPE")),
                  "eps": _n(i.get("trailingEps")), "hi": _n(i.get("fiftyTwoWeekHigh")), "lo": _n(i.get("fiftyTwoWeekLow"))},
        "ratios": _ratios(i), "warn": []}


def _frame_rows(df, mapping, n=5, quarterly=False):
    """DataFrame de yfinance (filas = conceptos, columnas = fechas) -> lista de años, del mas viejo al mas reciente."""
    if df is None or getattr(df, "empty", True):
        return []
    cols = sorted(list(df.columns))[-n:]
    rows = []
    for c in cols:
        yr, mo = getattr(c, "year", int(str(c)[:4])), getattr(c, "month", int(str(c)[5:7]))
        row = {"date": str(c)[:10], "year": f"T{(mo - 1) // 3 + 1} {str(yr)[2:]}" if quarterly else str(yr)}
        for k, names in mapping.items():
            row[k] = None
            for nm in names:
                if nm in df.index:
                    row[k] = _n(df.loc[nm, c])
                    if row[k] is not None:
                        break
        rows.append(row)
    return rows


def financials(env, sym, per="a"):
    yf = _yf()
    qq = per == "q"
    n = 8 if qq else 5

    def go():
        try:
            t = yf.Ticker(sym)
            inc, bal, cf = ((t.quarterly_income_stmt, t.quarterly_balance_sheet, t.quarterly_cashflow) if qq
                            else (t.income_stmt, t.balance_sheet, t.cashflow))
        except Exception as e:
            raise _wrap(e)
        return {
            "income": _frame_rows(inc, {"revenue": ("Total Revenue", "Operating Revenue"), "gross": ("Gross Profit",),
                                        "oper": ("Operating Income", "Total Operating Income As Reported"),
                                        "net": ("Net Income", "Net Income Common Stockholders"),
                                        "eps": ("Diluted EPS", "Basic EPS"), "ebitda": ("EBITDA", "Normalized EBITDA")}, n, qq),
            "balance": _frame_rows(bal, {"assets": ("Total Assets",), "liab": ("Total Liabilities Net Minority Interest", "Total Liabilities"),
                                         "debt": ("Total Debt",), "cash": ("Cash And Cash Equivalents", "Cash Cash Equivalents And Short Term Investments"),
                                         "equity": ("Stockholders Equity", "Common Stock Equity", "Total Equity Gross Minority Interest")}, n, qq),
            "cash": _frame_rows(cf, {"cfo": ("Operating Cash Flow", "Cash Flow From Continuing Operating Activities"),
                                     "capex": ("Capital Expenditure",), "fcf": ("Free Cash Flow",),
                                     "div": ("Cash Dividends Paid", "Common Stock Dividend Paid")}, n, qq)}
    out = dict(_cached(("fin", sym, per), TTL_LONG, go), sym=sym, per=per)
    out["warn"] = [] if out["income"] else ["Yahoo no devolvió estados financieros para este símbolo."]
    return out


def dividends(env, sym):
    yf = _yf()

    def go():
        try:
            s = yf.Ticker(sym).dividends
        except Exception as e:
            raise _wrap(e)
        rows = []
        if s is not None and len(s):
            for d, v in list(s.items())[-24:][::-1]:
                rows.append({"date": str(d)[:10], "pay": None, "amount": _n(v), "yield": None, "freq": None})
        return rows
    return {"sym": sym, "rows": _cached(("div", sym), TTL_LONG, go)}


def _peer_syms(sym):
    """Empresas parecidas segun Yahoo (endpoint no oficial). Si falla, el comparador usa solo los tickers que tu agregues."""
    def go():
        try:
            r = requests.get(f"https://query2.finance.yahoo.com/v6/finance/recommendationsbysymbol/{sym}", timeout=10,
                             headers={"User-Agent": "Mozilla/5.0"})
            res = (r.json().get("finance") or {}).get("result") or []
            return [x.get("symbol") for x in (res[0].get("recommendedSymbols") or [])] if res else []
        except Exception:
            return []
    return _cached(("peers", sym), TTL_LONG, go)


def _row(sym):
    i = _info(sym)
    r = _ratios(i)
    return {"sym": sym, "name": _p(i, "shortName", "longName") or "", "price": _n(_p(i, "currentPrice", "regularMarketPrice")),
            "mktcap": _n(i.get("marketCap")), "pct": _n(i.get("regularMarketChangePercent")), "pe": r["pe"], "pb": r["pb"],
            "ps": r["ps"], "net": r["net"], "roe": r["roe"], "div_yield": r["div_yield"], "de": r["de"],
            "ev_ebitda": r["ev_ebitda"], "earn_yield": r["earn_yield"], "fcf_yield": r["fcf_yield"]}


def peers(env, sym, extra=None):
    _yf()
    syms = []
    for s in (extra or []) or _peer_syms(sym):
        if isinstance(s, str) and SYM_RE.match(s) and s != sym and s not in syms:
            syms.append(s)
    syms = [sym] + syms[:5]

    def one(s):
        try:
            return _row(s)
        except FundError as e:
            return {"sym": s, "name": "", "error": str(e)[:80]}
    with ThreadPoolExecutor(max_workers=4) as ex:
        rows = list(ex.map(one, syms))
    if rows[0].get("error"):
        raise FundError(rows[0]["error"])
    return {"sym": sym, "rows": rows}


def handle(path, q, env):
    try:
        sym = _sym(q)
        if path == "/api/fund/overview":
            return 200, overview(env, sym)
        if path == "/api/fund/financials":
            return 200, financials(env, sym, "q" if (q.get("p") or ["a"])[0] == "q" else "a")
        if path == "/api/fund/statements":
            import fund_fin
            return 200, fund_fin.statements(env, sym, "q" if (q.get("p") or ["a"])[0] == "q" else "a")
        if path == "/api/fund/divs":
            import fund_div
            return 200, fund_div.dividends(env, sym)
        if path == "/api/fund/ratios":
            import fund_ratios
            return 200, fund_ratios.ratios(env, sym, "q" if (q.get("p") or ["a"])[0] == "q" else "a")
        if path == "/api/fund/dividends":
            return 200, dividends(env, sym)
        if path == "/api/fund/peers":
            extra = [x.strip().upper() for x in ((q.get("with") or [""])[0]).split(",") if x.strip()][:6]
            return 200, peers(env, sym, extra)
        return 404, {"error": "No encontrado"}
    except FundError as e:
        return 200, {"error": str(e), "need_install": e.need_install}
    except Exception as e:
        return 200, {"error": f"Error inesperado: {e.__class__.__name__}"}


PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fundamentales · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 20px;margin-bottom:14px}
h1{font-size:20px;margin:0;letter-spacing:.06em}a{color:var(--cy);text-decoration:none;font-weight:700}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:8px}
.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}
button{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:6px 13px;cursor:pointer;font-weight:700;font-size:13px}
button.on{color:var(--tx);border-color:var(--cy)}
input{background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:7px 10px;font-size:14px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-top:12px}
.st{border:1px solid var(--line);border-radius:10px;padding:8px 10px}.st .k{color:var(--mut);font-size:11px}.st .v{font-size:17px;font-weight:700}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 8px;white-space:nowrap}
td{padding:6px 8px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
tr.me{background:#1a1a20}
.err{color:var(--bad);background:#2a1119;border:1px solid #5a1d2a;border-radius:10px;padding:10px 12px;margin-bottom:12px;line-height:1.5}
.charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;margin-bottom:12px}
svg text{fill:#9fb0cc;font:10px ui-monospace,Menlo,monospace}
#lw{height:420px;border-radius:8px}
.tag{font-size:12px;color:var(--mut)}
.rc{display:grid;grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:8px}
.rcard{border:1px solid var(--line);border-left:3px solid var(--line);border-radius:10px;padding:9px 11px;background:#08080a;display:grid;grid-template-columns:1fr auto;grid-template-rows:auto auto auto;gap:1px 8px;align-items:end}
.rcard.bien{border-left-color:#3fd38a;background:linear-gradient(90deg,#3fd38a14,#08080a 60%)}.rcard.mal{border-left-color:#ff5d6c;background:linear-gradient(90deg,#ff5d6c14,#08080a 60%)}.rcard.alerta{border-left-color:#ffc04d;background:linear-gradient(90deg,#ffc04d14,#08080a 60%)}
.rcard .n{font-size:11px;font-weight:800;letter-spacing:.07em;color:var(--mut);grid-column:1}.rcard .ic{grid-column:2;grid-row:1;text-align:right;font-size:14px}
.rcard .v{font:800 17px ui-monospace,Menlo,monospace;grid-column:1}.rcard .s{font-size:11px;color:var(--mut);grid-column:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rcard .sp{grid-column:2;grid-row:2/4;align-self:center}
.chip{display:inline-block;font-size:11.5px;font-weight:800;padding:2px 9px;border-radius:999px}
.c-ok{background:#3fd38a22;color:#3fd38a}.c-bad{background:#ff5d6c22;color:#ff5d6c}.c-warn{background:#ffc04d22;color:#ffc04d}.c-mut{background:#7d8aa522;color:#9fb0cc}
.pbar{height:8px;background:#202027;border-radius:5px;overflow:hidden;margin-top:6px}.pbar i{display:block;height:100%}
tr.sec td{background:#14181f;color:#e8b04a;font-weight:800;letter-spacing:.08em;font-size:11.5px;border-top:1px solid #3a3320}

</style><script src="https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js"></script>
</head><body><main>
<header><h1 class="mono">FUNDAMENTALES</h1>
 <div class="mono" style="font-size:13px"><a href="/">← Inicio</a> &nbsp; <a href="/portafolio">Portafolio →</a> &nbsp; <a href="/trade">Trading manual →</a></div></header>

<div class="card">
 <form class="row" onsubmit="go($('q').value);return false"><input id="q" placeholder="Ticker, ej. AAPL" maxlength="6" style="width:150px;text-transform:uppercase"><button class="on">Buscar</button>
  <span id="chips" class="row"></span></form>
</div>
<div id="err"></div>

<div class="card" id="head" style="border-left-color:var(--ok)">
 <div class="row" style="justify-content:space-between;align-items:flex-start">
  <div><div style="font-size:22px;font-weight:800"><span id="h_name">…</span> <span class="mut mono" style="font-size:15px" id="h_sym"></span></div>
   <div class="tag" id="h_sub"></div></div>
  <div style="text-align:right"><div class="mono" style="font-size:30px;font-weight:800" id="h_px">–</div><div class="mono" id="h_chg"></div></div></div>
 <div class="stats" id="h_stats"></div>
</div>

<div class="row" style="margin-bottom:12px" id="tabs"></div>
<div id="view"></div>
</main>
<script>
const $=id=>document.getElementById(id);
const esc=x=>String(x==null?"":x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const getj=async p=>{const r=await fetch(p,{cache:"no-store"});return r.json()};
const lsGet=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const num=(v,d=2)=>v==null?"–":v.toLocaleString("en-US",{minimumFractionDigits:d,maximumFractionDigits:d});
const big=v=>{if(v==null)return "–";const a=Math.abs(v),s=v<0?"-":"";return s+(a>=1e12?(a/1e12).toFixed(2)+" T":a>=1e9?(a/1e9).toFixed(2)+" B":a>=1e6?(a/1e6).toFixed(1)+" M":a>=1e3?(a/1e3).toFixed(0)+" K":a.toFixed(2))};
const usd=v=>v==null?"–":(v<0?"-$"+big(-v):"$"+big(v));
const usdc=v=>{if(v==null)return "–";const a=Math.abs(v),t=a>=1e12?(a/1e12).toFixed(1)+"T":a>=1e9?(a/1e9).toFixed(1)+"B":a>=1e6?(a/1e6).toFixed(0)+"M":a.toFixed(0);return (v<0?"-$":"$")+t};
const pc=v=>v==null?"–":(v*100).toFixed(1)+"%";
const cls=v=>v>0?"ok":v<0?"bad":"";
const TABS=[["precio","Precio"],["resumen","Resumen"],["fin","Financieros"],["ratios","Ratios"],["val","Valoración"],["div","Dividendos"],["comp","Comparador"]];
const P=new URLSearchParams(location.search);
let FINP=lsGet("f_per","a"),SYM=(P.get("sym")||lsGet("f_sym","AAPL")).toUpperCase(),TAB=lsGet("f_tab","resumen"),OV=null,FIN=null,PEERS=null,DIV=null,LW=null;

function go(s){s=(s||"").trim().toUpperCase();if(!s)return;SYM=s;lsSet("f_sym",s);OV=FIN=PEERS=DIV=null;try{FIN2=RAT=DIV2=null;DIVALL=false}catch(e){}LW=null;history.replaceState(null,"","?sym="+s);load()}
function tab(t){TAB=t;lsSet("f_tab",t);drawTabs();render()}
function drawTabs(){$("tabs").innerHTML=TABS.map(t=>'<button class="'+(t[0]===TAB?"on":"")+'" onclick="tab(\''+t[0]+'\')">'+t[1]+"</button>").join("")}
function err(m,inst){$("err").innerHTML=m?'<div class="err">'+esc(m)+(inst?'<div style="margin-top:8px"><button class="on" onclick="doInstall()">⬇ Instalar yfinance ahora</button> <span id="inst_msg" class="tag"></span></div>':"")+"</div>":""}
async function doInstall(){$("inst_msg").textContent="Instalando… (puede tardar 1-2 minutos)";try{const r=await fetch("/fund_install",{method:"POST"});const j=await r.json();$("inst_msg").textContent=j.msg+(j.ok?(j.launchd?" Reiniciando el panel…":" Reinicia el panel (comando launchctl kickstart) y recarga la página."):"");if(j.ok&&j.launchd)setTimeout(()=>location.reload(),9000)}catch(e){$("inst_msg").textContent="Error: "+e}}
async function chips(){try{const w=await getj("/api/watch");$("chips").innerHTML=(w.rows||[]).map(r=>'<button onclick="go(\''+r.sym+'\')">'+r.sym+"</button>").join("")}catch(e){}}

async function load(){
  $("q").value=SYM;err("");$("h_name").textContent="Cargando…";$("h_sym").textContent=SYM;$("view").innerHTML="";
  const [o,q]=await Promise.all([getj("/api/fund/overview?sym="+SYM),getj("/api/quote?sym="+SYM).catch(()=>({}))]);
  if(o.error){err(o.error,o.need_install);$("h_name").textContent=SYM;return}
  OV=o;const p=o.profile,qq=o.quote||{},r=o.ratios;
  $("h_name").textContent=p.name||SYM;$("h_sym").textContent=SYM+(p.exchange?" · "+p.exchange:"");
  $("h_sub").textContent=[p.sector,p.industry,p.country].filter(Boolean).join(" · ");
  const price=q&&q.last!=null?q.last:(qq.price!=null?qq.price:p.price);
  $("h_px").textContent=price==null?"–":price.toFixed(2);
  const pct=q&&q.chg!=null?q.chg:qq.pct;$("h_chg").className="mono "+cls(pct);
  $("h_chg").textContent=pct==null?"":(pct>=0?"▲ +":"▼ ")+pct.toFixed(2)+"%";
  const st=(k,v)=>'<div class="st"><div class="k">'+k+'</div><div class="v mono">'+v+"</div></div>";
  const mc=qq.mktcap||p.mktcap,pe=r.pe!=null?r.pe:qq.pe;
  $("h_stats").innerHTML=st("Cap. de mercado",usd(mc))+st("P/E (PER)",pe==null?"–":num(pe,1))+st("Dividendo (yield)",r.div_yield==null?"–":pc(r.div_yield))+
    st("Volumen",big(qq.volume||p.volume))+st("Beta",p.beta==null?"–":num(p.beta,2))+st("EPS",qq.eps==null?"–":num(qq.eps,2))+
    st("Rango 52 sem.",qq.lo!=null&&qq.hi!=null?num(qq.lo)+" – "+num(qq.hi):esc(p.range||"–"));
  if(o.warn&&o.warn.length)err(o.warn.join(" · "));
  render()}

function metric(k,v,hint){return '<div class="st"><div class="k">'+k+'</div><div class="v mono">'+v+"</div>"+(hint?'<div class="tag">'+hint+"</div>":"")+"</div>"}
function bars(title,labels,vals,fmt){
  const w=320,h=150,pad=26,n=vals.length;if(!n||vals.every(v=>v==null))return '<div class="card" style="margin:0"><div class="lbl">'+title+'</div><div class="mut">Sin datos</div></div>';
  const mx=Math.max(0,...vals.filter(v=>v!=null)),mn=Math.min(0,...vals.filter(v=>v!=null)),sp=(mx-mn)||1,bw=(w-2*pad)/n*0.6,zy=pad+(mx/sp)*(h-2*pad);
  let g="";vals.forEach((v,i)=>{if(v==null)return;const x=pad+(i+0.2)*(w-2*pad)/n,y1=pad+((mx-Math.max(v,0))/sp)*(h-2*pad),hh=Math.max(1,Math.abs(v)/sp*(h-2*pad));
    g+='<rect x="'+x+'" y="'+(v>=0?y1:zy)+'" width="'+bw+'" height="'+hh+'" rx="2" fill="'+(v>=0?"#4ff0b7":"#ff5d6c")+'"/><text x="'+(x+bw/2)+'" y="'+(h-6)+'" text-anchor="middle">'+esc(labels[i])+'</text><text x="'+(x+bw/2)+'" y="'+((v>=0?y1:zy+hh)+(v>=0?-3:11))+'" text-anchor="middle" style="fill:#e6ecf5">'+fmt(v)+"</text>"});
  return '<div class="card" style="margin:0"><div class="lbl">'+title+'</div><svg viewBox="0 0 '+w+" "+h+'" style="width:100%"><line x1="'+pad+'" x2="'+(w-pad)+'" y1="'+zy+'" y2="'+zy+'" stroke="#2b3a5e"/>'+g+"</svg></div>"}

async function render(){
  const v=$("view");if(!OV&&TAB!=="precio"){return}
  const r=OV?OV.ratios:{},p=OV?OV.profile:{};
  if(TAB==="precio"){
    v.innerHTML='<div class="card"><div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">PRECIO DIARIO · '+SYM+'</div><span class="tag">sandbox, ~15 min de retraso · EMA 20 naranja · SMA 50 azul</span></div><div id="lw"></div></div>';
    if(!window.LightweightCharts){$("lw").innerHTML='<div class="mut" style="padding:20px">No cargó la librería del gráfico (¿sin internet?)</div>';return}
    const c=await getj("/api/c?sym="+SYM+"&i=D");if(c.error){err(c.error);return}
    const ch=LightweightCharts.createChart($("lw"),{layout:{background:{color:"#0c0c0f"},textColor:"#9fb0cc"},grid:{vertLines:{color:"#1c1c22"},horzLines:{color:"#1c1c22"}},rightPriceScale:{borderColor:"#202027"},timeScale:{borderColor:"#202027"},autoSize:true,
      handleScroll:{mouseWheel:false,pressedMouseMove:false},handleScale:{mouseWheel:false,pinch:true}});
    const box=$("lw"),act=on=>ch.applyOptions({handleScroll:{mouseWheel:on,pressedMouseMove:on},handleScale:{mouseWheel:on,pinch:true}});
    box.addEventListener("mousedown",()=>act(true),true);box.addEventListener("mouseleave",()=>act(false));
    const cs=ch.addCandlestickSeries({upColor:"#4ff0b7",downColor:"#ff5d6c",borderVisible:false,wickUpColor:"#4ff0b7",wickDownColor:"#ff5d6c"});
    cs.setData(c.bars.map(b=>({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close})));
    ch.addLineSeries({color:"#f5a03a",lineWidth:2,priceLineVisible:false,lastValueVisible:false}).setData(c.ema);
    ch.addLineSeries({color:"#5cc8ff",lineWidth:2,priceLineVisible:false,lastValueVisible:false}).setData(c.sma);
    const n=c.bars.length;ch.timeScale().setVisibleLogicalRange({from:Math.max(-1,n-130),to:n+5});return}
  if(TAB==="resumen"){
    v.innerHTML='<div class="card"><div class="lbl">INDICADORES CLAVE (últimos 12 meses)</div><div class="cards">'+
      metric("ROE",pc(r.roe),"Rentab. sobre patrimonio")+metric("ROA",pc(r.roa),"Rentab. sobre activos")+metric("ROIC",pc(r.roic),"Rentab. sobre capital invertido")+
      metric("Margen bruto",pc(r.gross))+metric("Margen operativo",pc(r.oper))+metric("Margen neto",pc(r.net))+
      metric("Deuda / Capital",r.de==null?"–":num(r.de,2),"Apalancamiento")+metric("Razón corriente",r.current==null?"–":num(r.current,2),"Liquidez")+metric("Deuda neta / EBITDA",r.net_debt_ebitda==null?"–":num(r.net_debt_ebitda,2))+
      metric("P/E",r.pe==null?"–":num(r.pe,1))+metric("P/B",r.pb==null?"–":num(r.pb,2))+metric("P/S",r.ps==null?"–":num(r.ps,2))+metric("EV/EBITDA",r.ev_ebitda==null?"–":num(r.ev_ebitda,1))+
      metric("Rend. flujo libre",pc(r.fcf_yield))+metric("Payout",pc(r.payout),"% de utilidad pagado en dividendos")+"</div></div>"+
      '<div class="card"><div class="lbl">SOBRE LA EMPRESA</div><div style="line-height:1.55">'+esc(p.desc||"Sin descripción disponible.")+'</div><div class="tag" style="margin-top:8px">'+[p.ceo?"CEO: "+esc(p.ceo):"",p.employees?"Empleados: "+num(+p.employees,0):"",p.web?'<a href="'+esc(p.web)+'" target="_blank" rel="noopener">'+esc(p.web)+"</a>":""].filter(Boolean).join(" · ")+"</div></div>";return}
  if(TAB==="fin"){
    v.innerHTML='<div class="card"><div class="mut">Cargando estados financieros…</div></div>';
    if(!FIN2||FIN2.per!==FINP)FIN2=await getj("/api/fund/statements?sym="+SYM+"&p="+FINP);
    if(FIN2.error){v.innerHTML="";err(FIN2.error,FIN2.need_install);return}
    v.innerHTML=finHTML(FIN2);return}
  if(TAB==="ratios"){
    v.innerHTML='<div class="card"><div class="mut">Calculando ratios (la primera vez tarda unos segundos: baja estados financieros, precios y empresas comparables)…</div></div>';
    if(!RAT||RAT.per!==RATP)RAT=await getj("/api/fund/ratios?sym="+SYM+"&p="+RATP);
    if(RAT.error){v.innerHTML="";err(RAT.error,RAT.need_install);return}
    v.innerHTML=ratiosHTML(RAT);return}
  if(TAB==="val"||TAB==="comp"){
    v.innerHTML='<div class="card"><div class="mut">Cargando comparables…</div></div>';
    if(!PEERS)PEERS=await getj("/api/fund/peers?sym="+SYM+(lsGet("f_with_"+SYM,"")?"&with="+encodeURIComponent(lsGet("f_with_"+SYM,"")):""));
    if(PEERS.error){v.innerHTML="";err(PEERS.error,PEERS.need_install);return}
    const R=PEERS.rows,med=k=>{const a=R.slice(1).map(x=>x[k]).filter(x=>x!=null).sort((a,b)=>a-b);return a.length?a[Math.floor(a.length/2)]:null};
    if(TAB==="val"){
      const items=[["P/E","pe",x=>num(x,1)],["P/B","pb",num],["P/S","ps",num],["EV/EBITDA","ev_ebitda",x=>num(x,1)],["Rend. por utilidades","earn_yield",pc],["Rend. flujo libre","fcf_yield",pc]];
      v.innerHTML='<div class="card"><div class="lbl">VALORACIÓN VS. MEDIANA DE EMPRESAS COMPARABLES</div><table><thead><tr><th>Múltiplo</th><th>'+SYM+"</th><th>Mediana de pares</th><th>Diferencia</th></tr></thead><tbody>"+items.map(i=>{const me=(i[1] in r?r[i[1]]:null)!=null?r[i[1]]:(R[0]?R[0][i[1]]:null),md=med(i[1]);const df=me!=null&&md?(me/md-1):null;
        return "<tr><td>"+i[0]+'</td><td class="mono">'+(me==null?"–":i[2](me))+'</td><td class="mono">'+(md==null?"–":i[2](md))+'</td><td class="mono '+(df==null?"":df<0?"ok":"bad")+'">'+(df==null?"–":(df>0?"+":"")+(df*100).toFixed(0)+"%")+"</td></tr>"}).join("")+
        '</tbody></table><div class="tag" style="margin-top:8px">Datos de Yahoo Finance (vía yfinance, no oficial). Verde = más barata que sus comparables en ese múltiplo; rojo = más cara. Es una referencia, no una recomendación.</div></div>';return}
    v.innerHTML='<div class="card"><div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">COMPARADOR</div><form class="row" onsubmit="cmp();return false"><input id="cw" placeholder="Tickers a comparar: MSFT,GOOGL" style="width:230px" value="'+esc(lsGet("f_with_"+SYM,""))+'"><button class="on">Comparar</button></form></div>'+
      '<div style="overflow-x:auto"><table><thead><tr><th>Empresa</th><th>Precio</th><th>% Día</th><th>Cap. mercado</th><th>P/E</th><th>P/B</th><th>P/S</th><th>EV/EBITDA</th><th>Margen neto</th><th>ROE</th><th>Div. yield</th><th>Deuda/Cap.</th></tr></thead><tbody>'+
      R.map((x,i)=>x.error?'<tr><td>'+esc(x.sym)+'</td><td colspan="11" class="bad">'+esc(x.error)+"</td></tr>":'<tr class="'+(i===0?"me":"")+'"><td><a href="?sym='+x.sym+'" onclick="go(\''+x.sym+'\');return false"><b>'+esc(x.sym)+'</b></a> <span class="tag">'+esc((x.name||"").slice(0,18))+'</span></td><td class="mono">'+num(x.price)+'</td><td class="mono '+cls(x.pct)+'">'+(x.pct==null?"–":x.pct.toFixed(2)+"%")+'</td><td class="mono">'+usd(x.mktcap)+'</td><td class="mono">'+num(x.pe,1)+'</td><td class="mono">'+num(x.pb)+'</td><td class="mono">'+num(x.ps)+'</td><td class="mono">'+num(x.ev_ebitda,1)+'</td><td class="mono">'+pc(x.net)+'</td><td class="mono">'+pc(x.roe)+'</td><td class="mono">'+pc(x.div_yield)+'</td><td class="mono">'+num(x.de)+"</td></tr>").join("")+"</tbody></table></div></div>";return}
  if(TAB==="div"){
    v.innerHTML='<div class="card"><div class="mut">Cargando dividendos…</div></div>';
    if(!DIV2)DIV2=await getj("/api/fund/divs?sym="+SYM);
    if(DIV2.error){v.innerHTML="";err(DIV2.error,DIV2.need_install);return}
    v.innerHTML=divHTML(DIV2);return}
}
function setPer(p){FINP=p;lsSet("f_per",p);FIN=null;FIN2=null;render()}
let DIV2=null,DIVALL=false;
const MESES=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
const fdate=d=>d?(+d.slice(8,10))+" "+MESES[+d.slice(5,7)-1]+" "+d.slice(0,4):"–";
function divChart(Y){const W=900,H=200,L=44,R=48,T=14,B=30,n=Y.length;if(!n)return"";
  const mx=Math.max(...Y.map(y=>y.dps))*1.15||1,ys=Y.map(y=>y.yield).filter(v=>v!=null),ymx=ys.length?Math.max(...ys)*1.15:1,gw=(W-L-R)/n,bw=Math.min(90,gw*0.6);
  const y=v=>T+(1-v/mx)*(H-T-B),yy=v=>T+(1-v/ymx)*(H-T-B);
  let g='';[0,0.5,1].forEach(f=>{const v=mx*f;g+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v)+'" y2="'+y(v)+'" stroke="#202027"/><text x="'+(L-6)+'" y="'+(y(v)+4)+'" text-anchor="end">$'+v.toFixed(2)+'</text><text x="'+(W-R+6)+'" y="'+(yy(ymx*f)+4)+'">'+(ymx*f*100).toFixed(1)+'%</text>'});
  let line="",dots="";Y.forEach((r,i)=>{const cx=L+gw*(i+.5);g+='<rect x="'+(cx-bw/2)+'" y="'+y(r.dps)+'" width="'+bw+'" height="'+(H-B-y(r.dps))+'" rx="3" fill="#c9973f" opacity="'+(r.est?.35:1)+'"><title>'+r.year+': $'+r.dps.toFixed(2)+(r.est?" (incluye estimado)":"")+'</title></rect><text x="'+cx+'" y="'+(H-10)+'" text-anchor="middle">'+r.year+(r.est?"e":"")+'</text>';
    if(r.yield!=null){line+=(line?"L":"M")+cx+" "+yy(r.yield);dots+='<circle cx="'+cx+'" cy="'+yy(r.yield)+'" r="3" fill="#3fd38a"><title>Rendimiento '+r.year+': '+(r.yield*100).toFixed(2)+'%</title></circle>'}});
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%">'+g+'<path d="'+line+'" fill="none" stroke="#3fd38a" stroke-width="2"/>'+dots+'</svg><div style="display:flex;gap:16px;justify-content:center;font-size:11.5px"><span><b style="color:#c9973f">■</b> Dividendo por acción</span><span><b style="color:#c9973f;opacity:.4">■</b> Estimado</span><span><b style="color:#3fd38a">━</b> Rendimiento</span></div>'}
function divHTML(D){if(!D.has)return '<div class="card"><div class="lbl">DIVIDENDOS · '+SYM+'</div><div class="mut">'+esc((D.warn||[]).join(" · ")||"Sin dividendos.")+'</div></div>';
  const pc2=v=>v==null?"–":(v*100).toFixed(2)+"%",sg=v=>v==null?"–":(v>=0?"+":"")+(v*100).toFixed(1)+"%";
  const box=(k,v,sub,c)=>'<div class="st"><div class="k" style="font-weight:800;letter-spacing:.07em">'+k+'</div><div class="v mono"'+(c?' style="color:'+c+'"':'')+'>'+v+'</div><div class="tag">'+sub+'</div></div>';
  let h='<div class="card"><div class="lbl" style="margin:0;color:var(--tx);font-weight:800">DIVIDENDOS · '+SYM+'</div><div class="tag">Historial de pagos · últimos 12 meses, proyectado y crecimiento · Yahoo Finance</div><div class="stats">'
   +box("ÚLTIMOS 12 MESES","$"+num(D.ttm,2),pc2(D.ttm_yield)+" de rendimiento")
   +box("ANUAL PROYECTADO",D.fwd==null?"–":"$"+num(D.fwd,2),pc2(D.fwd_yield)+" al precio actual","#e8b04a")
   +box("FRECUENCIA",esc(D.freq_name),D.freq?D.freq+" pagos al año":"")
   +box("PRÓXIMO EX-DIVIDENDO",fdate(D.next),"$"+num(D.next_amount,D.next_amount<1?4:2)+" · "+(D.next_est?"estimado":"anunciado"))
   +box("PAYOUT",D.payout==null?"–":(D.payout*100).toFixed(1)+"%",D.payout!=null&&D.payout>1?'<span class="bad">paga más de lo que gana</span>':"de la utilidad (12 meses)",D.payout!=null&&D.payout>1?"#ff5d6c":null)
   +box("CRECIMIENTO",sg(D.growth),(D.growth_year?"a/a "+D.growth_year:"")+(D.cagr5!=null?" · 5 años: "+sg(D.cagr5)+"/año":""),D.growth==null?null:D.growth>0?"#3fd38a":D.growth<0?"#ff5d6c":null)+'</div></div>';
  h+='<div class="card"><div style="overflow-x:auto"><div style="min-width:620px">'+divChart(D.years)+'</div></div></div>';
  const Y=[...D.years].reverse(),H=D.history,shown=DIVALL?H:H.slice(0,24);
  h+='<div class="charts" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,520px),1fr));align-items:start"><div class="card" style="margin:0"><div class="lbl" style="color:var(--tx);font-weight:800">POR AÑO</div><div style="overflow-x:auto"><table><thead><tr><th>Año</th><th>Dividendo</th><th>a/a</th><th>Rendimiento</th><th>Payout</th><th>Pagos</th></tr></thead><tbody>'
   +Y.map(r=>'<tr'+(r.est?' style="font-style:italic;color:var(--mut)"':'')+'><td>'+r.year+(r.est?'<sup>e</sup>':'')+(r.partial&&!r.est?' <span class="tag">(en curso)</span>':'')+'</td><td class="mono">$'+num(r.dps,2)+'</td><td class="mono '+cls(r.yoy)+'">'+(r.yoy==null?"–":sg(r.yoy))+'</td><td class="mono">'+pc2(r.yield)+'</td><td class="mono'+(r.payout!=null&&r.payout>1?" bad":"")+'">'+(r.payout==null?"–":(r.payout*100).toFixed(1)+"%")+'</td><td class="mono">'+r.n+'</td></tr>').join("")+'</tbody></table></div>'
   +'<div class="tag" style="margin-top:8px">e = estimado (incluye pagos que faltan, con el mismo monto y frecuencia). Rendimiento = dividendo del año ÷ precio promedio del año. Payout = dividendo ÷ EPS diluido (Yahoo da ~5 años).</div></div>'
   +'<div class="card" style="margin:0"><div class="row" style="justify-content:space-between"><div class="lbl" style="color:var(--tx);font-weight:800;margin:0">HISTORIAL DE PAGOS</div><div class="tag"><b style="color:#9fb0cc">●</b> Pagado · <b style="color:#3fd38a">●</b> Anunciado · <b style="color:#e8b04a">●</b> Estimado</div></div><div style="overflow-x:auto"><table><thead><tr><th>Ex-dividendo</th><th>Monto</th><th>Cambio</th><th>Rendimiento</th></tr></thead><tbody>'
   +shown.map(x=>{const c=x.est?"#e8b04a":x.anunciada?"#3fd38a":"#9fb0cc";return '<tr'+(x.est?' style="font-style:italic;color:var(--mut)"':'')+'><td><b style="color:'+c+'">●</b> '+fdate(x.date)+'</td><td class="mono"><b>$'+num(x.amount,x.amount<1?4:2)+'</b></td><td class="mono '+(x.chg==null?"":x.chg>0.0005?"ok":x.chg<-0.0005?"bad":"")+'">'+(x.chg==null||Math.abs(x.chg)<0.0005?"–":sg(x.chg))+'</td><td class="mono">'+pc2(x.yield)+'</td></tr>'}).join("")+'</tbody></table></div>'
   +(H.length>24?'<div style="text-align:center;margin-top:8px"><button onclick="DIVALL=!DIVALL;render()">'+(DIVALL?"Ver menos":"Ver "+(H.length-24)+" más")+'</button></div>':'')
   +'<div class="tag" style="margin-top:8px">Rendimiento de cada pago = monto × pagos al año ÷ precio de ese día. Yahoo no da la fecha de pago ni la de anuncio, solo la fecha ex-dividendo (el día desde el cual ya no te toca ese pago si compras).</div></div></div>';
  return h}
let FIN2=null,FST=lsGet("f_st","income"),FMODE=lsGet("f_mode","v");
function setFST(s){FST=s;lsSet("f_st",s);render()}
const NEUTRAL=new Set(["cogs","rnd","sga","int","tax","shares","capex","acq","cfi","divp","buy","ndebt","cff","ret","debt","ltd","liab","cl","ap","inv","recv","sh_out","wc","sbc","da"]);
function fmtC(v,fmt){if(v==null||!isFinite(v))return"–";if(fmt&&fmt!==fmtM&&fmt!==fmtN)return fmt(v);const a=Math.abs(v),s=v<0?"-":"",p=fmt===fmtN?"":"$";return s+p+(a>=1e12?(a/1e12).toFixed(1)+"T":a>=1e9?(a/1e9).toFixed(1)+"B":a>=1e6?(a/1e6).toFixed(0)+"M":a>=1e3?(a/1e3).toFixed(0)+"K":a.toFixed(0))}
function setFM(m){FMODE=m;lsSet("f_mode",m);render()}
const fmtM=v=>{if(v==null||!isFinite(v))return"–";const a=Math.abs(v),s=v<0?"-":"";return s+"$"+(a>=1e12?(a/1e12).toFixed(2)+"T":a>=1e9?(a/1e9).toFixed(2)+"B":a>=1e6?(a/1e6).toFixed(2)+"M":a>=1e3?(a/1e3).toFixed(1)+"K":a.toFixed(0))};
const fmtN=v=>{if(v==null||!isFinite(v))return"–";const a=Math.abs(v);return (v<0?"-":"")+(a>=1e9?(a/1e9).toFixed(2)+"B":a>=1e6?(a/1e6).toFixed(2)+"M":a>=1e3?(a/1e3).toFixed(1)+"K":a.toFixed(0))};
function fval(f,v){if(v==null||!isFinite(v))return"–";return f==="$"?fmtM(v):f==="n"?fmtN(v):f==="%"?(v*100).toFixed(1)+"%":f==="x"?v.toFixed(2):f==="eps"?(v<0?"-$":"$")+Math.abs(v).toFixed(2):String(v)}
function fchg(f,a,b,mode){if(a==null||b==null||!isFinite(a)||!isFinite(b))return"–";
  if(f==="%")return (a-b>=0?"+":"")+((a-b)*100).toFixed(1)+" pp";
  if(mode==="p"){if(!b)return"–";const r=(a-b)/Math.abs(b);return (r>=0?"+":"")+(r*100).toFixed(1)+"%"}
  const d=a-b;return (d>=0?"+":"")+(f==="$"?fmtM(d):f==="n"?fmtN(d):f==="eps"?(d<0?"-$":"$")+Math.abs(d).toFixed(2):d.toFixed(2))}
function groupBars(title,labels,series){const W=430,H=170,L=58,R=8,T=14,B=34,n=labels.length;const all=[];series.forEach(s=>s[1].forEach(v=>{if(v!=null)all.push(v)}));
  if(!all.length)return'<div class="card" style="margin:0"><div class="lbl">'+title+'</div><div class="mut">Sin datos</div></div>';
  const mx=Math.max(0,...all),mn=Math.min(0,...all),sp=(mx-mn)||1,y=v=>T+(mx-v)/sp*(H-T-B),gw=(W-L-R)/n,bw=Math.min(28,gw*0.7/series.length);
  let g='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(0)+'" y2="'+y(0)+'" stroke="#2b3a5e"/>';[mx,0,mn].filter((v,i,a)=>a.indexOf(v)===i).forEach(v=>{g+='<text x="'+(L-6)+'" y="'+(y(v)+4)+'" text-anchor="end">'+fmtC(v)+'</text>'});
  labels.forEach((lb,i)=>{const cx=L+gw*(i+.5);g+='<text x="'+cx+'" y="'+(H-B+16)+'" text-anchor="middle">'+esc(lb)+'</text>';
    series.forEach((s,j)=>{const v=s[1][i];if(v==null)return;const x=cx-bw*series.length/2+j*bw,y0=y(Math.max(v,0)),hh=Math.max(1,Math.abs(v)/sp*(H-T-B));g+='<rect x="'+x+'" y="'+y0+'" width="'+(bw-2)+'" height="'+hh+'" rx="2" fill="'+s[2]+'"><title>'+esc(s[0])+' '+esc(lb)+': '+fmtM(v)+'</title></rect>'})});
  return '<div class="card" style="margin:0"><div class="lbl">'+title+'</div><svg viewBox="0 0 '+W+' '+H+'" style="width:100%">'+g+'</svg><div style="display:flex;gap:14px;justify-content:center;font-size:11.5px">'+series.map(s=>'<span><b style="color:'+s[2]+'">●</b> '+esc(s[0])+'</span>').join("")+'</div></div>'}
function valBars(title,labels,vals,fmt){const W=360,H=170,T=22,B=24,n=labels.length,ok=vals.filter(v=>v!=null),many=n>6;
  if(!ok.length)return'<div class="card" style="margin:0"><div class="lbl">'+title+'</div><div class="mut">Sin datos</div></div>';
  const mx=Math.max(0,...ok),mn=Math.min(0,...ok),sp=(mx-mn)||1,y=v=>T+(mx-v)/sp*(H-T-B),gw=W/n,bw=Math.min(40,gw*0.68),id="vb"+Math.random().toString(36).slice(2,7);
  let g='<defs><linearGradient id="'+id+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8b04a"/><stop offset="1" stop-color="#e8b04a" stop-opacity=".15"/></linearGradient></defs>';
  vals.forEach((v,i)=>{const cx=gw*(i+.5),last=i===n-1;g+='<text x="'+cx+'" y="'+(H-6)+'" text-anchor="middle" style="'+(last?"fill:#e8b04a;font-weight:700":"")+'">'+esc(labels[i])+'</text>';if(v==null)return;
    const y0=y(Math.max(v,0)),hh=Math.max(2,Math.abs(v)/sp*(H-T-B)),fill=v<0?"#ff5d6c":last?"url(#"+id+")":"#b8893a";
    g+='<rect x="'+(cx-bw/2)+'" y="'+y0+'" width="'+bw+'" height="'+hh+'" rx="3" fill="'+fill+'"/><text x="'+cx+'" y="'+(y0-5)+'" text-anchor="middle" style="fill:#e6ecf5;font-size:'+(many?9:10.5)+'px">'+(many?fmtC(v,fmt):fmt(v))+'</text>'});
  return '<div class="card" style="margin:0"><div class="lbl" style="color:var(--tx);font-weight:800">'+title+'</div><svg viewBox="0 0 '+W+' '+H+'" style="width:100%">'+g+'</svg></div>'}
const FCH={income:{g:["INGRESOS Y UTILIDAD NETA",[["rev","Ingresos","#e8b04a"],["net","Utilidad neta","#5c8cff"]]],l:["MÁRGENES",[["gross_m","Bruto","#3fd38a"],["oper_m","Operativo","#e8b04a"],["net_m","Neto","#5c8cff"]],"%"],b:[["rev","Ingresos","$"],["eps","EPS (diluido)","eps"],["shares","Acciones en circulación","n"]]},
  balance:{g:["ACTIVOS Y PASIVOS",[["assets","Activos totales","#e8b04a"],["liab","Pasivos totales","#ff8a5c"]]],l:["LIQUIDEZ Y DEUDA",[["current_r","Razón corriente","#3fd38a"],["de","Deuda / Patrimonio","#ff8a5c"]],"x"],b:[["cash","Efectivo","$"],["debt","Deuda total","$"],["equity","Patrimonio","$"]]},
  cash:{g:["FLUJO DE OPERACIÓN Y FLUJO LIBRE",[["cfo","Flujo de operación","#e8b04a"],["fcf","Flujo libre","#3fd38a"]]],l:["MARGEN DE FLUJO LIBRE",[["fcf_m","Flujo libre / ingresos","#3fd38a"]],"%"],b:[["fcf","Flujo de caja libre","$"],["capex","Inversión (CapEx)","$"],["ret","Devuelto a accionistas","$"]]}};
function finHTML(D){const Q=D.per==="q",S=D.st[FST]||D.st.income,lab=S.labels,K={};S.sections.forEach(s=>s.rows.forEach(r=>{K[r.key]=r}));const st=D.yoy_step||1;
  const vv=k=>(K[k]||{vals:lab.map(()=>null)}).vals,C=FCH[FST],ff={"$":fmtM,"eps":v=>(v<0?"-$":"$")+Math.abs(v).toFixed(2),"n":fmtN};
  const rowsObj=lab.map((l,i)=>{const o={label:l};Object.keys(K).forEach(k=>o[k]=K[k].vals[i]);return o});
  let h='<div class="card"><div class="row" style="justify-content:space-between"><div><div class="lbl" style="margin:0;color:var(--tx);font-weight:800">ESTADOS FINANCIEROS · '+SYM+'</div><div class="tag">'+(Q?"Trimestral":"Anual")+' · últimos '+lab.length+' periodos · Yahoo Finance</div></div><div class="row"><button class="'+(Q?"":"on")+'" onclick="setPer(\'a\')">Anual</button><button class="'+(Q?"on":"")+'" onclick="setPer(\'q\')">Trimestral</button></div></div>'
   +'<div class="row" style="justify-content:space-between;margin-top:12px"><div class="row">'+[["income","Estado de resultados"],["balance","Balance general"],["cash","Flujo de caja"]].map(x=>'<button class="'+(FST===x[0]?"on":"")+'" onclick="setFST(\''+x[0]+'\')">'+x[1]+'</button>').join("")+'</div>'
   +'<div class="row"><span class="tag">MOSTRAR:</span>'+[["v","Valores"],["d","Cambio $"],["p","Cambio %"]].map(x=>'<button class="'+(FMODE===x[0]?"on":"")+'" onclick="setFM(\''+x[0]+'\')">'+x[1]+'</button>').join("")+'</div></div></div>';
  if(D.warn&&D.warn.length)h+='<div class="err">'+esc(D.warn.join(" · "))+'</div>';
  h+='<div class="charts" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,460px),1fr))">'+groupBars(C.g[0],lab,C.g[1].map(s=>[s[1],vv(s[0]),s[2]]))+lineChart(C.l[0],rowsObj,C.l[1],C.l[2]==="%"?(v=>(v*100).toFixed(0)+"%"):(v=>v.toFixed(1)+"×"))+'</div>'
   +'<div class="charts">'+C.b.map(b=>valBars(b[1],lab,vv(b[0]),ff[b[2]]||fmtM)).join("")+'</div>';
  const rv=lab.map((l,i)=>i).reverse(),hasT=!Q&&S.ttm_label&&FMODE==="v";
  const head='<tr><th>Renglón</th><th style="text-align:center">Tendencia</th>'+(hasT?'<th style="background:#16161b">'+esc(S.ttm_label)+'</th>':'')+rv.map(i=>'<th>'+esc(lab[i])+'</th>').join("")+'</tr>';
  const cell=(r,i)=>{if(FMODE==="v"){const x=r.vals[i];return '<td class="mono'+(x!=null&&x<0?" bad":"")+'">'+fval(r.fmt,x)+'</td>'}
    const a=r.vals[i],b=i-st>=0?r.vals[i-st]:null,txt=fchg(r.fmt,a,b,FMODE),neg=txt.startsWith("-");return '<td class="mono '+(txt==="–"?"mut":NEUTRAL.has(r.key)?"":neg?"bad":"ok")+'">'+txt+'</td>'};
  h+='<div class="card"><div style="overflow-x:auto"><table><thead>'+head+'</thead><tbody>'+S.sections.map(s=>'<tr class="sec"><td colspan="'+(rv.length+2+(hasT?1:0))+'">■ '+esc(s.name)+'</td></tr>'+s.rows.map(r=>'<tr'+(r.bold?' style="font-weight:700"':'')+'><td'+(r.bold?' style="color:#e8b04a"':'')+'>'+esc(r.name)+'</td><td style="text-align:center">'+sparkBars(r.vals)+'</td>'
     +(hasT?'<td class="mono'+(r.ttm!=null&&r.ttm<0?" bad":"")+'" style="background:#16161b">'+fval(r.fmt,r.ttm)+'</td>':'')+rv.map(i=>cell(r,i)).join("")+'</tr>').join("")).join("")+'</tbody></table></div>'
   +'<div class="tag" style="margin-top:8px">'+(FMODE!=="v"?"Cambio contra "+(Q?"el mismo trimestre del año anterior":"el año anterior")+"; en márgenes y razones se muestra la diferencia en puntos (pp). ":"")+(hasT?"TTM = suma de los últimos 4 trimestres"+(FST==="balance"?" (en el balance, el dato del último trimestre)":"")+". ":"")+'En el flujo de caja los montos negativos son salidas de dinero (inversión, dividendos, recompras). En costos, deuda y salidas de dinero el cambio va sin color: subir o bajar no es bueno ni malo por sí solo. "–" = Yahoo no da el dato.</div></div>';
  return h}

let RAT=null,RATP=lsGet("f_rper","a");
function setRP(p){RATP=p;lsSet("f_rper",p);RAT=null;render()}
const rfmt=(f,v)=>v==null||!isFinite(v)?"NM":f==="%"?(v*100).toFixed(1)+"%":Math.abs(v)>=1000?num(v,0):num(v,2);
function sparkBars(vals,good){const v=(vals||[]).map(x=>x==null||!isFinite(x)?null:x);if(!v.some(x=>x!=null))return"";const W=70,H=22,n=v.length,mx=Math.max(...v.filter(x=>x!=null).map(Math.abs))||1,bw=W/n-2;
  return '<svg viewBox="0 0 '+W+' '+H+'" style="width:70px;height:22px" aria-hidden="true">'+v.map((x,i)=>{if(x==null)return'<rect x="'+(i*W/n)+'" y="'+(H-2)+'" width="'+bw+'" height="2" fill="#2b3550"/>';const h=Math.max(2,Math.abs(x)/mx*(H-2)),last=i===n-1;
    return '<rect x="'+(i*W/n)+'" y="'+(H-h)+'" width="'+bw+'" height="'+h+'" rx="1" fill="'+(x<0?"#ff5d6c":last?(good===false?"#ff5d6c":"#e8b04a"):"#5d6987")+'"/>'}).join("")+'</svg>'}
function lineChart(title,rows,series,fmt){const W=430,H=170,L=38,R=20,T=14,B=34,n=rows.length;if(n<2)return'<div class="card" style="margin:0"><div class="lbl">'+title+'</div><div class="mut">Pocos periodos</div></div>';
  let all=[];series.forEach(s=>rows.forEach(r=>{const x=r[s[0]];if(x!=null&&isFinite(x))all.push(x)}));if(!all.length)return'<div class="card" style="margin:0"><div class="lbl">'+title+'</div><div class="mut">Sin datos</div></div>';
  const srt=[...all].sort((a,b)=>a-b),q=p=>srt[Math.min(srt.length-1,Math.floor(p*(srt.length-1)))],iqr=q(0.75)-q(0.25),mx=srt[srt.length-1],mn=Math.min(0,srt[0]);
  const p75=Math.max(...[q(0.75),Math.abs(q(0.25))]);let hi=mx,lo=mn;if(p75>0&&mx>4*p75)hi=4*p75;if(p75>0&&mn<-2*p75)lo=-2*p75;if(hi<=lo)hi=lo+1;const cut=hi<mx||lo>mn;
  const x=i=>L+i*(W-L-R)/(n-1),y=v=>T+(1-(Math.max(lo,Math.min(hi,v))-lo)/(hi-lo))*(H-T-B);
  let g='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(0)+'" y2="'+y(0)+'" stroke="#2b3a5e"/><text x="'+(L-4)+'" y="'+(y(hi)+4)+'" text-anchor="end">'+fmt(hi)+'</text><text x="'+(L-4)+'" y="'+(y(0)+4)+'" text-anchor="end">'+fmt(0)+'</text>';
  rows.forEach((r,i)=>{g+='<text x="'+x(i)+'" y="'+(H-B+15)+'" text-anchor="middle">'+esc(r.label)+'</text>'});
  series.forEach(s=>{let d="",dots="";rows.forEach((r,i)=>{const v=r[s[0]];if(v==null||!isFinite(v)){return}d+=(d?"L":"M")+x(i).toFixed(1)+" "+y(v).toFixed(1);dots+='<circle cx="'+x(i)+'" cy="'+y(v)+'" r="2.6" fill="'+s[2]+'"><title>'+s[1]+' '+r.label+': '+fmt(v)+'</title></circle>'});g+='<path d="'+d+'" fill="none" stroke="'+s[2]+'" stroke-width="1.8"/>'+dots});
  return '<div class="card" style="margin:0"><div class="lbl">'+title+'</div><svg viewBox="0 0 '+W+' '+H+'" style="width:100%">'+g+'</svg><div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;font-size:11.5px">'+series.map(s=>'<span><b style="color:'+s[2]+'">━</b> '+s[1]+'</span>').join("")+'</div>'+(cut?'<div class="tag" style="text-align:center;margin-top:4px">Valores extremos recortados para que se lea la gráfica.</div>':'')+'</div>'}
function ratiosHTML(R){const rows=R.rows||[],Q=R.per==="q",C=R.cards||[];
  const nb=C.filter(c=>c.verdict==="bien").length,nm=C.filter(c=>c.verdict==="mal").length,na=C.filter(c=>c.verdict==="alerta").length,pct=nb+nm?Math.round(100*nb/(nb+nm)):null;
  const ic={bien:"👍",mal:"👎",alerta:"⚠️"};
  let h='<div class="card"><div class="row" style="justify-content:space-between"><div><div class="lbl" style="margin:0;color:var(--tx);font-weight:800">RATIOS · '+SYM+'</div><div class="tag">'+(Q?"Trimestral":"Anual")+' · últimos '+rows.length+' periodos · Yahoo Finance</div></div><div class="row"><button class="'+(Q?"":"on")+'" onclick="setRP(\'a\')">Anual</button><button class="'+(Q?"on":"")+'" onclick="setRP(\'q\')">Trimestral</button></div></div>'
   +'<div class="row" style="justify-content:space-between;margin:12px 0 8px"><div class="tag">'+(R.peers&&R.peers.length?'Comparado con la mediana de '+R.peers.length+' empresas parecidas (según Yahoo): '+esc(R.peers.join(" · ")):'Yahoo no dio empresas comparables: solo se califican los ratios con un ideal fijo.')+'</div>'
   +'<div class="row"><span class="chip c-ok">👍 '+nb+'</span><span class="chip c-bad">👎 '+nm+'</span>'+(na?'<span class="chip c-warn">⚠️ '+na+'</span>':'')+(pct!=null?'<span class="chip '+(pct>=60?"c-ok":pct>=40?"c-warn":"c-bad")+'">'+pct+'% a favor</span>':'')+'</div></div>'
   +'<div class="rc">'+C.map(c=>{const sub=c.key==="fpe"&&c.med!=null?"Actual: "+rfmt(c.fmt,c.med):c.ideal&&c.ideal!=="CAGR"?c.ideal:c.ideal==="CAGR"?"Crec. anual compuesto":c.med!=null?"Pares: "+rfmt(c.fmt,c.med):"";
     return '<div class="rcard '+(c.verdict||"")+'" title="'+esc(c.name)+(c.med!=null?" · mediana de pares "+rfmt(c.fmt,c.med):"")+'"><div class="n">'+esc(c.name.toUpperCase())+'</div><div class="ic">'+(ic[c.verdict]||"")+'</div><div class="v">'+rfmt(c.fmt,c.v)+'</div><div class="s">'+(esc(sub)||"&nbsp;")+'</div><div class="sp">'+sparkBars(c.spark,c.verdict!=="mal")+'</div></div>'}).join("")+'</div>'
   +'<div class="tag" style="margin-top:8px">👍 mejor que la mediana de sus pares (o cumple el ideal) · 👎 peor · ⚠️ el valor no tiene sentido para comparar (p. ej. P/E negativo por pérdidas). Las tarjetas usan los últimos 12 meses; la minigráfica, cada periodo.</div></div>';
  const pf=v=>(v*100).toFixed(0)+"%",xf=v=>v.toFixed(0)+"×";
  h+='<div class="charts">'+lineChart("MÁRGENES",rows,[["gross_m","Bruto","#3fd38a"],["oper_m","Operativo","#e8b04a"],["net_m","Neto","#5c8cff"],["fcf_m","Flujo libre","#a77bff"]],pf)
   +lineChart("RENTABILIDAD",rows,[["roe","ROE","#e8b04a"],["roa","ROA","#5c8cff"],["roic","ROIC","#3fd38a"]],pf)
   +lineChart("VALORACIÓN",rows,[["pe","P/E","#e8b04a"],["ev_ebitda","EV/EBITDA","#5c8cff"],["p_fcf","P/FCF","#a77bff"]],xf)+'</div>';
  const S=R.score;
  if(S&&S.total!=null){const lv=S.total>=70?["Rentabilidad sana","c-ok"]:S.total>=45?["Rentabilidad aceptable","c-warn"]:["Rentabilidad débil","c-bad"];
    const chip=l=>!l?"–":'<span class="chip '+({"Excepcional":"c-ok","Sólido":"c-ok","Aceptable":"c-warn","Débil":"c-bad","Malo":"c-bad"}[l])+'">'+l+'</span>';
    const tr=t=>t==="mejora"?'<span class="ok">▲ Mejorando</span>':t==="empeora"?'<span class="bad">▼ Empeorando</span>':t==="estable"?'<span class="mut">● Estable</span>':"–";
    const K=S.checks,fx=v=>v==null?"–":(v>=0?"+":"-")+usd(Math.abs(v)).replace("$","$");
    const posL=K.pos_n?(K.pos===K.pos_n?["BUENO","c-ok"]:K.pos>=K.pos_n-1?["ACEPTABLE","c-warn"]:["DÉBIL","c-bad"]):null,conL=K.conv==null?null:K.conv>=1?["BUENO","c-ok"]:K.conv>=0.7?["ACEPTABLE","c-warn"]:["DÉBIL","c-bad"];
    const box=(t,l,body)=>'<div class="st" style="padding:10px 12px"><div class="row" style="justify-content:space-between"><b style="font-size:11.5px;letter-spacing:.07em">'+t+'</b>'+(l?'<span class="chip '+l[1]+'">'+l[0]+'</span>':'')+'</div><div class="tag" style="margin-top:4px;color:var(--tx)">'+body+'</div></div>';
    h+='<div class="card"><div class="row" style="justify-content:space-between;align-items:flex-start"><div><div class="lbl" style="margin:0;color:var(--tx);font-weight:800">PUNTAJE DE RENTABILIDAD · '+SYM+'</div><div class="tag">Periodo '+esc(S.period)+' · '+(Q?"trimestral (ROE y ROIC anualizados)":"anual")+'</div>'
     +'<div style="margin-top:6px"><b>'+lv[0]+'.</b> Lo más fuerte: '+esc((S.best||"").toLowerCase())+'. Lo más débil: '+esc((S.worst||"").toLowerCase())+'.</div></div><div class="chip '+lv[1]+'" style="font-size:26px;padding:6px 14px">'+S.total+'<span style="font-size:13px">/100</span></div></div>'
     +'<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin:12px 0">'+S.parts.map(p=>'<div><div class="row" style="justify-content:space-between"><span><b>'+p.name+'</b> <span class="tag">'+Math.round(p.w*100)+'%</span></span><b>'+(p.s==null?"–":p.s)+'</b></div><div class="pbar"><i style="width:'+(p.s||0)+'%;background:'+(p.s>=65?"#3fd38a":p.s>=45?"#e8b04a":"#ff5d6c")+'"></i></div></div>').join("")+'</div>'
     +'<div style="overflow-x:auto"><table><thead><tr><th>Métrica</th><th>Actual</th><th style="text-align:center">Nivel</th><th>Prom. 3 periodos</th><th style="text-align:center">Tendencia</th><th>vs. pares</th><th>Puntos</th></tr></thead><tbody>'
     +S.table.map(t=>'<tr><td>'+t.name+'</td><td class="mono">'+rfmt("%",t.v)+'</td><td style="text-align:center">'+chip(t.level)+'</td><td class="mono">'+rfmt("%",t.avg3)+(t.volatile?' <span class="chip c-warn">volátil</span>':'')+'</td><td style="text-align:center">'+sparkBars(t.spark)+' '+tr(t.trend)+'</td><td class="mono '+(t.vs_peer==null?"":t.vs_peer>=0?"ok":"bad")+'">'+(t.vs_peer==null?"–":(t.vs_peer>0?"+":"")+(t.vs_peer*100).toFixed(0)+"%")+'</td><td class="mono"><b>'+(t.pts==null?"–":t.pts)+'</b></td></tr>').join("")+'</tbody></table></div>'
     +'<div class="lbl" style="margin-top:14px">REVISIONES DEL FLUJO DE CAJA LIBRE</div><div class="stats">'
     +box("FLUJO LIBRE POSITIVO",posL,K.pos_n?K.pos+" de "+K.pos_n+" periodos":"Sin datos")
     +box("CONVERSIÓN DE CAJA",conL,K.conv==null?"Sin datos (utilidad negativa o faltante)":K.conv.toFixed(2)+"× la utilidad neta (3 periodos)")
     +box("PROMEDIO 3 PERIODOS",null,K.avg==null?"–":usd(K.avg)+" por periodo"+(K.avg_m!=null?" · margen "+(K.avg_m*100).toFixed(1)+"%":""))
     +box("CAMBIO DESDE "+esc(K.since),null,"Flujo libre "+fx(K.chg.fcf)+" = operaciones "+fx(K.chg.cfo)+" · capital de trabajo "+fx(K.chg.wc)+" · inversión "+fx(K.chg.capex))+'</div>'
     +'<div class="tag" style="margin-top:10px">Puntaje propio del programa: márgenes 35% (bruto, operativo y neto), flujo libre 30% y rendimiento del capital 35% (ROE y ROIC). Es una referencia rápida, no una recomendación.</div></div>'}
  const G=[["VALORACIÓN",[["P/E","pe","x"],["P/B","pb","x"],["P/S","ps","x"],["P/FCF","p_fcf","x"],["EV/EBITDA","ev_ebitda","x"],["PEG","peg","x"]]],
    ["RENTABILIDAD",[["ROE","roe","%"],["ROA","roa","%"],["ROIC","roic","%"],["Margen bruto","gross_m","%"],["Margen operativo","oper_m","%"],["Margen neto","net_m","%"],["Margen de flujo libre","fcf_m","%"]]],
    ["LIQUIDEZ",[["Razón corriente","current","x"],["Razón rápida","quick","x"],["Razón de efectivo","cash_r","x"]]],
    ["DEUDA",[["Deuda / Capital","de","x"],["Cobertura de intereses","int_cov","x"],["Deuda / Activos","debt_r","x"],["Payout","payout","%"]]],
    ["EFICIENCIA",[["Rotación de activos","asset_t","x"],["Rotación de cuentas por cobrar","recv_t","x"],["Rotación de inventario","inv_t","x"]]]];
  const rv=[...rows].reverse();
  h+='<div class="card"><div class="lbl">TODOS LOS RATIOS POR PERIODO</div><div style="overflow-x:auto"><table><thead><tr><th>Ratio</th><th style="text-align:center">Tendencia</th>'+rv.map(r=>'<th>'+esc(r.label)+'</th>').join("")+'</tr></thead><tbody>'
   +G.map(g=>'<tr class="sec"><td colspan="'+(rv.length+2)+'">■ '+g[0]+'</td></tr>'+g[1].map(m=>'<tr><td>'+m[0]+'</td><td style="text-align:center">'+sparkBars(rows.map(r=>r[m[1]]))+'</td>'+rv.map(r=>'<td class="mono'+(r[m[1]]==null?" mut":"")+'">'+(r[m[1]]==null?"<i>NM</i>":rfmt(m[2],r[m[1]]))+'</td>').join("")+'</tr>').join("")).join("")
   +'</tbody></table></div><div class="tag" style="margin-top:8px">NM = no tiene sentido (por ejemplo, utilidad o capital negativos) o Yahoo no da el dato. Los múltiplos de cada periodo usan el precio al cierre de ese periodo'+(Q?" y los flujos de los últimos 4 trimestres":"")+'. En bancos, aseguradoras y REIT algunos ratios (márgenes, liquidez) se interpretan distinto.</div></div>';
  return h}

function cmp(){const w=$("cw").value.split(",").map(s=>s.trim().toUpperCase()).filter(Boolean).join(",");lsSet("f_with_"+SYM,w);PEERS=null;render()}
drawTabs();chips();load();
</script></body></html>
"""
