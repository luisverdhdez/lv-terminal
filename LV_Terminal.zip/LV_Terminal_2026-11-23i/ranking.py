"""
Pestaña Market → Ranking: empresas y fondos más grandes, amplitud del día, club del billón y los mayores movimientos.
Valor de mercado = precio de Tradier (en vivo o con retraso segun la cuenta) × acciones en circulacion de Yahoo.
Las acciones (y el patrimonio de los ETF) casi no cambian: se bajan de Yahoo en segundo plano cada 3 dias y se guardan
en rank_shares.json. Mientras no esten, se usa el valor aproximado fijo de la lista y se marca como "aprox.".
"""
import json
import os
import threading
import time

import trading
import market

BASE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(BASE, "rank_shares.json")
REFRESH = 3 * 86400
EXTRA = [("BRK.B", "Berkshire Hathaway", "Financiero", 1000, "")]
ETFS = [("SPY", "SPDR S&P 500 ETF"), ("VOO", "Vanguard S&P 500 ETF"), ("IVV", "iShares Core S&P 500 ETF"),
        ("VTI", "Vanguard Total Stock Market ETF"), ("QQQ", "Invesco QQQ (Nasdaq 100)"), ("VUG", "Vanguard Growth ETF"),
        ("VEA", "Vanguard FTSE Developed Markets"), ("IEFA", "iShares Core MSCI EAFE"), ("BND", "Vanguard Total Bond Market"),
        ("GLD", "SPDR Gold Shares")]
_S = {"running": False, "done": 0, "total": 0, "err": None, "cache": (0, None, None)}
_L = threading.RLock()


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {"ts": 0, "d": {}}
    except (OSError, ValueError):
        return {"ts": 0, "d": {}}


def _save(d):
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _worker(syms):
    try:
        import fundamentales as F
        yf = F._yf()
    except Exception as e:
        _S.update(running=False, err=f"Falta yfinance: {e.__class__.__name__}")
        return
    d = _load()
    d["tried"] = time.time()      # aunque Yahoo no responda, no reintenta hasta dentro de 6 horas
    _save(d)
    _S.update(done=0, total=len(syms), err=None)
    ok = 0
    for i, s in enumerate(syms):
        try:
            info = yf.Ticker(s.replace(".", "-")).info or {}
            sh = market._num(info.get("sharesOutstanding") or info.get("impliedSharesOutstanding"))
            aum = market._num(info.get("totalAssets") or info.get("netAssets"))
            if sh or aum:
                d["d"][s] = {"shares": sh, "aum": aum, "name": info.get("shortName") or info.get("longName"), "t": time.time()}
                ok += 1
        except Exception:
            pass
        _S["done"] = i + 1
        if (i + 1) % 15 == 0:
            _save(d)
        time.sleep(0.35)
    if ok:
        d["ts"] = time.time()
    _save(d)
    _S["running"] = False


def _ensure(syms):
    d = _load()
    with _L:
        if not _S["running"] and time.time() - d.get("ts", 0) > REFRESH and time.time() - d.get("tried", 0) > 6 * 3600:
            _S["running"] = True
            threading.Thread(target=_worker, args=(syms,), daemon=True).start()
    return d


def rank(env):
    mode = trading.MODE["live"]
    with _L:
        ts, val, m = _S["cache"]
        if val is not None and time.time() - ts < 20 and m == mode:
            return dict(val, building=_S["running"], done=_S["done"], total=_S["total"])
    stocks = list(market.U) + EXTRA
    syms = [u[0] for u in stocks] + [e[0] for e in ETFS]
    sh = _ensure(syms)["d"]
    q = market._quotes(env, syms)
    rows = []

    def base(sym, q1):
        return {"sym": sym, "last": market._num(q1.get("last")), "pct": market._num(q1.get("change_percentage")),
                "vol": market._num(q1.get("volume")), "desc": q1.get("description")}
    for sym, name, sec, cap, idx in stocks:
        q1 = q.get(sym) or {}
        r = base(sym, q1)
        if r["last"] is None:
            continue
        s = (sh.get(sym) or {}).get("shares")
        r.update(name=name, sector=sec, idx=idx, etf=False, cap=r["last"] * s if s else cap * 1e9, approx=not s)
        rows.append(r)
    for sym, name in ETFS:
        q1 = q.get(sym) or {}
        r = base(sym, q1)
        if r["last"] is None:
            continue
        a = (sh.get(sym) or {}).get("aum")
        if not a:
            continue          # sin patrimonio conocido no se puede ordenar: el ETF se omite hasta tener el dato
        r.update(name=name, sector="ETF", idx="", etf=True, cap=a, approx=False)
        rows.append(r)
    rows.sort(key=lambda r: -(r["cap"] or 0))
    st = [r for r in rows if not r["etf"] and r["pct"] is not None]
    up = sum(1 for r in st if r["pct"] > 0)
    dn = sum(1 for r in st if r["pct"] < 0)
    big = [r for r in st if r["cap"] >= 10e9]
    gain = max(big, key=lambda r: r["pct"], default=None)
    lose = min(big, key=lambda r: r["pct"], default=None)
    tri = [r["sym"] for r in rows if not r["etf"] and r["cap"] >= 1e12]
    out = {"rows": rows, "breadth": {"up": up, "down": dn, "n": len(st)}, "trillion": tri,
           "gain": gain and {k: gain[k] for k in ("sym", "name", "pct")}, "lose": lose and {k: lose[k] for k in ("sym", "name", "pct")},
           "live": mode, "approx": sum(1 for r in rows if r["approx"]), "err": _S["err"]}
    with _L:
        _S["cache"] = (time.time(), out, mode)
    return dict(out, building=_S["running"], done=_S["done"], total=_S["total"])
