"""
Reportes y metricas del panel: lee trades.csv (robot) y manual_trades.csv (manual), calcula metricas
(Sharpe, drawdown, promedio ganancia/perdida, aciertos por hora) y genera Excel (.xlsx) y una pagina
lista para imprimir / guardar como PDF. Solo libreria estandar. Lo usa monitor_web.py.
"""
import csv
import html
import io
import math
import os
import re
import zipfile
from collections import defaultdict, deque
from datetime import datetime, timedelta

ROBOT_CSV = "trades.csv"
ROBOT_LIVE_CSV = "trades_live.csv"
MANUAL_CSV = "manual_trades.csv"
FILLS_CSV = "manual_fills.csv"
MANUAL_LIVE_CSV = "manual_trades_real.csv"     # operaciones manuales de la cuenta REAL (aparte de las de papel)
FILLS_LIVE_CSV = "manual_fills_real.csv"
MANUAL_H_CSV = "manual_trades_h.csv"           # cuenta REAL 2 (familiar): aparte de todo lo demas
FILLS_H_CSV = "manual_fills_h.csv"
ROBOT_H_CSV = "trades_h.csv"
TRADE_COLS = ["fecha", "hora", "lado", "opcion", "cantidad", "entrada", "pnl_usd", "motivo", "capital"]
OCC = re.compile(r"^[A-Z.]{1,6}(\d{6})([CP])(\d{8})$")
FILL_COLS = ["order_id", "fecha", "hora", "opcion", "lado", "cantidad", "precio"]


# ───────────── lectura ─────────────
def _read(path, src):
    rows = []
    if not os.path.exists(path):
        return rows
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        for r in csv.DictReader(f):
            try:
                cap = None
                try:
                    if src == "Manual":
                        cap = float(r["capital"]) if r.get("capital") not in (None, "") else None
                    else:  # robot: prima pagada x contratos x 100
                        cap = float(r["entrada"]) * float(r["cantidad"]) * 100
                except (KeyError, ValueError):
                    cap = None
                rows.append({"fecha": r["fecha"], "hora": r.get("hora", ""), "pnl": float(r["pnl_usd"]), "src": src,
                             "lado": r.get("lado", ""), "opcion": r.get("opcion", ""), "cantidad": r.get("cantidad", ""),
                             "entrada": r.get("entrada", ""), "motivo": r.get("motivo", ""),
                             "capital": cap if cap and cap > 0 else None,
                             "roc": (float(r["pnl_usd"]) / cap) if cap and cap > 0 else None})
            except (KeyError, ValueError):
                pass
    return rows


def load_rows(base, src="robot", live=False):
    """live=True: manual Y robot vienen de la cuenta REAL (trades_live.csv del robot en real). Nunca se mezcla papel con real."""
    rows = []
    h = live == "H"
    if src in ("robot", "all"):
        rows += _read(os.path.join(base, ROBOT_H_CSV if h else ROBOT_LIVE_CSV if live else ROBOT_CSV), "Robot")
    if src in ("manual", "all"):
        man = _read(os.path.join(base, MANUAL_H_CSV if h else MANUAL_LIVE_CSV if live else MANUAL_CSV), "Manual")
        try:   # los covered calls (largo plazo) NO son trading del dia: se ven aparte en Portafolio
            import cc as _ccmod
            man = [r for r in man if not _ccmod.is_cc_row(r.get("opcion"))]
        except Exception:  # noqa: BLE001
            pass
        rows += man
    rows.sort(key=lambda r: (r["fecha"], r["hora"]))
    return rows


def in_range(rows, rng, today):
    if rng == "hoy":
        return [r for r in rows if r["fecha"] == today]
    if rng == "semana":
        d = datetime.strptime(today, "%Y-%m-%d")
        a = (d - timedelta(days=d.weekday())).strftime("%Y-%m-%d")
        return [r for r in rows if a <= r["fecha"] <= today]
    if rng == "mes":
        return [r for r in rows if r["fecha"][:7] == today[:7]]
    return list(rows)


# ───────────── metricas ─────────────
def metrics(rows):
    p = [r["pnl"] for r in rows]
    n = len(p)
    wins = [x for x in p if x > 0]
    losses = [x for x in p if x < 0]
    gains, lossum = sum(wins), -sum(losses)
    avg_w = gains / len(wins) if wins else None
    avg_l = lossum / len(losses) if losses else None
    # curva y maximo drawdown (caida desde el maximo acumulado, empezando en 0)
    cum = peak = dd = 0.0
    streak = best_streak = 0
    for x in p:
        cum += x
        peak = max(peak, cum)
        dd = max(dd, peak - cum)
        streak = streak + 1 if x < 0 else 0
        best_streak = max(best_streak, streak)
    daily = defaultdict(float)
    for r in rows:
        daily[r["fecha"]] += r["pnl"]
    sharpe = None
    if len(daily) >= 5:
        v = list(daily.values())
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1))
        sharpe = (mu / sd) * math.sqrt(252) if sd > 0 else None
    by_hour = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    for r in rows:
        try:
            h = int(r["hora"][:2])
        except ValueError:
            continue
        b = by_hour[h]
        b["n"] += 1
        b["wins"] += r["pnl"] > 0
        b["pnl"] += r["pnl"]
    capr = [r for r in rows if r.get("capital")]
    cap_total = sum(r["capital"] for r in capr)
    rocs = [r["roc"] for r in capr]
    return {
        "cap_n": len(capr), "cap_total": cap_total if capr else None,
        "cap_avg": (cap_total / len(capr)) if capr else None,
        "cap_max": max((r["capital"] for r in capr), default=None),
        "roc_total": (sum(r["pnl"] for r in capr) / cap_total) if capr and cap_total else None,
        "roc_avg": (sum(rocs) / len(rocs)) if rocs else None,
        "roc_best": max(rocs) if rocs else None, "roc_worst": min(rocs) if rocs else None,
        "n": n, "wins": len(wins), "losses": len(losses), "total": round(sum(p), 2),
        "win_rate": (len(wins) / n) if n else None,
        "avg_win": avg_w, "avg_loss": avg_l,
        "payoff": (avg_w / avg_l) if avg_w and avg_l else None,
        "pf": (gains / lossum) if lossum else None,
        "expectancy": (sum(p) / n) if n else None,
        "best": max(p) if p else None, "worst": min(p) if p else None,
        "max_dd": round(dd, 2), "max_losing_streak": best_streak,
        "sharpe": sharpe, "days": len(daily),
        "by_hour": [{"h": h, "n": b["n"], "wins": b["wins"], "pnl": round(b["pnl"], 2),
                     "wr": b["wins"] / b["n"]} for h, b in sorted(by_hour.items())],
    }


def cumulative(rows):
    """Por operacion: capital y P&L acumulados, y retorno sobre el capital acumulado."""
    out, cc, cp = [], 0.0, 0.0
    for r in rows:
        cp += r["pnl"]
        if r.get("capital"):
            cc += r["capital"]
        out.append({"cap_acum": cc, "pnl_acum": cp, "roc_acum": (cp / cc) if cc else None})
    return out


# ───────────── cierres manuales (FIFO por pata) ─────────────
def fifo_trades(fills):
    """fills: dicts de manual_fills.csv. Devuelve una fila por ORDEN DE CIERRE (un spread cuenta como 1 operacion)."""
    longs, shorts = defaultdict(deque), defaultdict(deque)
    closes = {}
    for f in sorted(fills, key=lambda x: (x["fecha"], x["hora"], str(x["order_id"]))):
        occ, side, q, px = f["opcion"], f["lado"], f["cantidad"], f["precio"]
        left = q
        if side == "buy_to_open":
            longs[occ].append([q, px])
            continue
        if side == "sell_to_open":
            shorts[occ].append([q, px])
            continue
        book = longs[occ] if side == "sell_to_close" else shorts[occ]
        c = closes.setdefault(f["order_id"], {"fecha": f["fecha"], "hora": f["hora"], "pnl": 0.0, "occ": [], "qty": 0,
                                              "entry": None, "long": 0.0, "short": 0.0, "legs": []})
        while left > 1e-9 and book:
            lot = book[0]
            m = min(left, lot[0])
            c["pnl"] += ((px - lot[1]) if side == "sell_to_close" else (lot[1] - px)) * m * 100
            c["long" if side == "sell_to_close" else "short"] += lot[1] * m * 100   # costo de lo comprado / credito recibido
            c["legs"].append((occ, m))
            if c["entry"] is None:
                c["entry"] = lot[1]
            lot[0] -= m
            left -= m
            c["qty"] = max(c["qty"], q - left)
            if lot[0] <= 1e-9:
                book.popleft()
        if occ not in c["occ"]:
            c["occ"].append(occ)
    out = []
    for oid, c in closes.items():
        if c["qty"] <= 0:
            continue
        net = c["long"] - c["short"]          # debito neto pagado (si es positivo, ese es el capital en riesgo)
        cap = None
        if net > 0:
            cap = net
        elif c["long"] > 0:                   # credito: riesgo maximo = ancho x contratos x 100 - credito
            w = 0.0
            for typ in "CP":
                ks = [int(m.group(3)) / 1000 for o, _ in c["legs"] for m in [OCC.match(o)] if m and m.group(2) == typ]
                if len(ks) >= 2:
                    w = max(w, max(ks) - min(ks))
            if w > 0:
                cap = max(w * 100 * c["qty"] + net, 0) or None
        out.append({"fecha": c["fecha"], "hora": c["hora"], "lado": "manual", "opcion": " / ".join(sorted(c["occ"])),
                    "cantidad": int(c["qty"]) if float(c["qty"]).is_integer() else c["qty"],
                    "entrada": "" if len(c["occ"]) > 1 or c["entry"] is None else f"{c['entry']:.2f}",
                    "pnl_usd": f"{c['pnl']:.2f}", "motivo": "cierre manual",
                    "capital": "" if cap is None else f"{cap:.2f}"})
    out.sort(key=lambda r: (r["fecha"], r["hora"]))
    return out


# ───────────── Excel minimo (.xlsx) sin dependencias ─────────────
def _col(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _sheet(rows):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
    for ri, row in enumerate(rows, 1):
        out.append(f'<row r="{ri}">')
        for ci, v in enumerate(row):
            ref = f"{_col(ci)}{ri}"
            bold = ' s="1"' if ri == 1 else ""
            if v is None or v == "":
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                out.append(f'<c r="{ref}"{bold}><v>{v}</v></c>')
            else:
                out.append(f'<c r="{ref}" t="inlineStr"{bold}><is><t>{html.escape(str(v))}</t></is></c>')
        out.append("</row>")
    out.append("</sheetData></worksheet>")
    return "".join(out)


def _fmt(v, kind="n"):
    if v is None:
        return "–"
    if kind == "pct":
        return f"{100 * v:.0f}%"
    if kind == "usd":
        return f"{'+' if v >= 0 else '-'}${abs(v):.2f}"
    return f"{v:.2f}"


def _usd0(v):
    return "–" if v is None else f"${v:,.2f}"


def summary_pairs(m):
    return [("Capital invertido total", _usd0(m["cap_total"])),
            ("Capital promedio por operación", _usd0(m["cap_avg"])),
            ("Mayor capital en una operación", _usd0(m["cap_max"])),
            ("Retorno s/ capital invertido (total)", _fmt(m["roc_total"] * 100, "n") + "%" if m["roc_total"] is not None else "–"),
            ("Retorno promedio por operación", _fmt(m["roc_avg"] * 100, "n") + "%" if m["roc_avg"] is not None else "–"),
            ("Mejor / peor retorno por operación", (_fmt(m["roc_best"] * 100) + "% / " + _fmt(m["roc_worst"] * 100) + "%") if m["roc_best"] is not None else "–")] + [("Operaciones", m["n"]), ("Ganadoras", m["wins"]), ("Perdedoras", m["losses"]),
            ("Tasa de aciertos", _fmt(m["win_rate"], "pct")), ("P&L total", _fmt(m["total"], "usd")),
            ("Ganancia promedio", _fmt(m["avg_win"], "usd")),
            ("Pérdida promedio", _fmt(-m["avg_loss"], "usd") if m["avg_loss"] is not None else "–"),
            ("Risk/Reward real (gan. prom. / pérd. prom.)", _fmt(m["payoff"])),
            ("Profit factor", _fmt(m["pf"])), ("Expectativa por operación", _fmt(m["expectancy"], "usd")),
            ("Mejor operación", _fmt(m["best"], "usd")), ("Peor operación", _fmt(m["worst"], "usd")),
            ("Máximo drawdown", _fmt(-m["max_dd"], "usd")), ("Racha máxima de pérdidas", m["max_losing_streak"]),
            ("Sharpe (diario, anualizado)", _fmt(m["sharpe"]) if m["sharpe"] is not None else "n/d (necesita 5+ días)"),
            ("Días operados", m["days"])]


def xlsx_bytes(rows, m, title):
    sheets = [
        ("Resumen", [["Métrica", "Valor"], ["Reporte", title]] + [list(p) for p in summary_pairs(m)]),
        ("Operaciones", [["Fecha", "Hora", "Origen", "Lado", "Opción", "Cantidad", "Entrada", "Capital USD", "P&L USD", "Retorno %",
                          "Capital acumulado", "P&L acumulado", "Retorno acumulado %", "Motivo"]] +
         [[r["fecha"], r["hora"], r["src"], r["lado"], r["opcion"], r["cantidad"], r["entrada"],
           None if not r.get("capital") else round(r["capital"], 2), r["pnl"],
           None if r.get("roc") is None else round(r["roc"] * 100, 2), round(c["cap_acum"], 2), round(c["pnl_acum"], 2),
           None if c["roc_acum"] is None else round(c["roc_acum"] * 100, 2), r["motivo"]]
          for r, c in zip(rows, cumulative(rows))]),
        ("Por hora", [["Hora", "Operaciones", "Ganadoras", "Aciertos %", "P&L USD"]] +
         [[f"{b['h']:02d}:00", b["n"], b["wins"], round(100 * b["wr"]), b["pnl"]] for b in m["by_hour"]]),
    ]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
                   "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets) + 1)) + "</Types>")
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
                   "".join(f'<sheet name="{n}" sheetId="{i}" r:id="rId{i}"/>' for i, (n, _) in enumerate(sheets, 1)) + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                   "".join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(sheets) + 1)) +
                   f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/styles.xml", '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>')
        for i, (_, data) in enumerate(sheets, 1):
            z.writestr(f"xl/worksheets/sheet{i}.xml", _sheet(data))
    return buf.getvalue()


# ───────────── pagina para imprimir / guardar como PDF ─────────────
def print_html(rows, m, title):
    e = html.escape
    kv = "".join(f"<tr><td>{e(str(k))}</td><td class=r>{e(str(v))}</td></tr>" for k, v in summary_pairs(m))
    hr = "".join(f"<tr><td>{b['h']:02d}:00</td><td class=r>{b['n']}</td><td class=r>{round(100 * b['wr'])}%</td>"
                 f"<td class='r {'g' if b['pnl'] >= 0 else 'b'}'>{_fmt(b['pnl'], 'usd')}</td></tr>" for b in m["by_hour"])
    tr = "".join(f"<tr><td>{e(r['fecha'])}</td><td>{e(r['hora'])}</td><td>{e(r['src'])}</td><td>{e(r['opcion'])}</td>"
                 f"<td class=r>{e(str(r['cantidad']))}</td><td class=r>{_usd0(r.get('capital'))}</td>"
                 f"<td class='r {'g' if r['pnl'] >= 0 else 'b'}'>{_fmt(r['pnl'], 'usd')}</td>"
                 f"<td class=r>{'–' if r.get('roc') is None else format(r['roc'] * 100, '.1f') + '%'}</td>"
                 f"<td class=r>{_usd0(c['cap_acum'])}</td><td class=r>{'–' if c['roc_acum'] is None else format(c['roc_acum'] * 100, '.1f') + '%'}</td>"
                 f"<td>{e(r['motivo'])}</td></tr>" for r, c in zip(rows, cumulative(rows)))
    return f"""<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{e(title)}</title><style>
body{{font:13px -apple-system,Helvetica,Arial,sans-serif;color:#111;margin:28px;max-width:900px}}
h1{{font-size:22px;margin:0 0 4px}}h2{{font-size:15px;margin:22px 0 6px}}.s{{color:#666;margin-bottom:12px}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #ddd;padding:5px 8px;text-align:left}}th{{background:#f3f4f6}}
.r{{text-align:right}}.g{{color:#0a8f5b}}.b{{color:#c62839}}button{{padding:8px 16px;font-size:14px;margin-bottom:14px;cursor:pointer}}
@media print{{button{{display:none}}body{{margin:10mm}}}}</style></head><body>
<button onclick="window.print()">Imprimir / Guardar como PDF</button>
<h1>{e(title)}</h1><div class="s">Generado {datetime.now().strftime('%Y-%m-%d %H:%M')} · cuenta sandbox (dinero de práctica) · horas en la zona de tu Mac</div>
<h2>Resumen</h2><table>{kv}</table>
<h2>Aciertos por hora del día</h2><table><tr><th>Hora</th><th class=r>Operaciones</th><th class=r>Aciertos</th><th class=r>P&amp;L</th></tr>{hr or '<tr><td colspan=4>Sin datos</td></tr>'}</table>
<h2>Operaciones</h2><table><tr><th>Fecha</th><th>Hora</th><th>Origen</th><th>Opción</th><th class=r>Cant.</th><th class=r>Capital</th><th class=r>P&amp;L</th><th class=r>Retorno</th><th class=r>Cap. acum.</th><th class=r>Ret. acum.</th><th>Motivo</th></tr>{tr or '<tr><td colspan=11>Sin operaciones</td></tr>'}</table>
</body></html>"""


# ───────────── PDF real (sin dependencias) ─────────────
def _pdf_text(t):
    t = str(t).replace("≈", "~").replace("→", "->").replace("▲", "+").replace("▼", "-")
    return t.encode("cp1252", "replace").decode("cp1252").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


class _Pdf:
    W, H, M = 612, 792, 40

    def __init__(self):
        self.pages, self.cur, self.y = [], [], 0
        self.new_page()

    def new_page(self):
        if self.cur:
            self.pages.append("\n".join(self.cur))
        self.cur, self.y = [], self.H - self.M

    def text(self, x, y, t, size=9, bold=False, color=(0, 0, 0), right=False):
        t = _pdf_text(t)
        if right:  # estimacion del ancho de Helvetica
            x -= len(t) * size * (0.56 if bold else 0.52)
        self.cur.append(f"BT /{'F2' if bold else 'F1'} {size} Tf {color[0]} {color[1]} {color[2]} rg {x:.1f} {y:.1f} Td ({t}) Tj ET")

    def line(self, x1, y1, x2, y2, color=(0.8, 0.8, 0.8), w=0.5):
        self.cur.append(f"{color[0]} {color[1]} {color[2]} RG {w} w {x1:.1f} {y1:.1f} m {x2:.1f} {y2:.1f} l S")

    def need(self, h):
        if self.y - h < self.M:
            self.new_page()

    def save(self):
        self.pages.append("\n".join(self.cur))
        objs = ["<< /Type /Catalog /Pages 2 0 R >>", None,
                "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
                "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"]
        kids = []
        for i, content in enumerate(self.pages):
            pid, cid = 5 + 2 * i, 6 + 2 * i
            kids.append(f"{pid} 0 R")
            while len(objs) < pid - 1:
                objs.append("")
            objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.W} {self.H}] /Contents {cid} 0 R "
                        f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>")
            data = content.encode("cp1252", "replace")
            objs.append(("STREAM", data))
        objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>"
        out = io.BytesIO()
        out.write(b"%PDF-1.4\n")
        offs = []
        for i, o in enumerate(objs, 1):
            offs.append(out.tell())
            out.write(f"{i} 0 obj\n".encode())
            if isinstance(o, tuple):
                out.write(f"<< /Length {len(o[1])} >>\nstream\n".encode() + o[1] + b"\nendstream")
            else:
                out.write(o.encode("latin-1", "replace"))
            out.write(b"\nendobj\n")
        x = out.tell()
        out.write(f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode())
        for o in offs:
            out.write(f"{o:010d} 00000 n \n".encode())
        out.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF\n".encode())
        return out.getvalue()


def pdf_bytes(rows, m, title):
    G, R, K, GR = (0.04, 0.56, 0.36), (0.78, 0.15, 0.22), (0, 0, 0), (0.4, 0.4, 0.4)
    p = _Pdf()
    p.text(p.M, p.y, title, 16, True); p.y -= 16
    p.text(p.M, p.y, f"Generado {datetime.now().strftime('%Y-%m-%d %H:%M')} - cuenta sandbox (dinero de práctica) - horas de tu Mac", 8, color=GR)
    p.y -= 22
    # resumen en dos columnas
    pairs = summary_pairs(m)
    half = (len(pairs) + 1) // 2
    top = p.y
    for col, chunk in enumerate((pairs[:half], pairs[half:])):
        x0 = p.M + col * 270
        y = top
        for k, v in chunk:
            p.text(x0, y, k[:46], 8, color=GR)
            p.text(x0 + 255, y, v, 8, True, right=True)
            p.line(x0, y - 3, x0 + 255, y - 3, (0.9, 0.9, 0.9))
            y -= 13
    p.y = top - 13 * half - 12
    # curva de P&L acumulado
    cum = cumulative(rows)
    if len(cum) >= 2:
        p.text(p.M, p.y, "P&L acumulado por operación", 10, True); p.y -= 8
        h, w, x0, y0 = 90, p.W - 2 * p.M, p.M, p.y - 90
        vals = [0.0] + [c["pnl_acum"] for c in cum]
        lo, hi = min(vals), max(vals)
        span = (hi - lo) or 1.0
        p.line(x0, y0, x0 + w, y0, (0.7, 0.7, 0.7))
        zy = y0 + (0 - lo) / span * h
        p.line(x0, zy, x0 + w, zy, (0.6, 0.6, 0.6), 0.8)
        pts = [(x0 + i / (len(vals) - 1) * w, y0 + (v - lo) / span * h) for i, v in enumerate(vals)]
        for a, b in zip(pts, pts[1:]):
            p.line(a[0], a[1], b[0], b[1], G if b[1] >= zy else R, 1.4)
        p.text(x0, y0 - 10, f"min {_fmt(lo, 'usd')}", 7, color=GR)
        p.text(x0 + w, y0 - 10, f"max {_fmt(hi, 'usd')}", 7, color=GR, right=True)
        p.y = y0 - 26
    # por hora
    p.need(30 + 12 * max(1, len(m["by_hour"])))
    p.text(p.M, p.y, "Aciertos por hora del día", 10, True); p.y -= 14
    for b in m["by_hour"] or []:
        p.text(p.M, p.y, f"{b['h']:02d}:00", 8)
        p.line(p.M + 40, p.y + 2, p.M + 40 + 120 * b["wr"], p.y + 2, G if b["wr"] >= 0.5 else R, 5)
        p.text(p.M + 170, p.y, f"{round(100 * b['wr'])}% ({b['wins']}/{b['n']})", 8)
        p.text(p.M + 290, p.y, _fmt(b["pnl"], "usd"), 8, True, G if b["pnl"] >= 0 else R)
        p.y -= 12
    if not m["by_hour"]:
        p.text(p.M, p.y, "Sin datos", 8, color=GR); p.y -= 12
    p.y -= 10
    # operaciones
    cols = [("Fecha", 40, 0), ("Hora", 92, 0), ("Orig.", 128, 0), ("Opción", 160, 0), ("Cant", 330, 1), ("Capital", 380, 1),
            ("P&L", 430, 1), ("Ret.%", 472, 1), ("Cap.acum", 525, 1), ("Ret.ac%", 572, 1)]

    def header():
        p.need(40)
        for name, x, rt in cols:
            p.text(x, p.y, name, 7.5, True, right=bool(rt))
        p.line(p.M, p.y - 3, p.W - p.M, p.y - 3, (0.3, 0.3, 0.3))
        p.y -= 13
    p.text(p.M, p.y, "Operaciones (capital invertido y retorno sobre el capital)", 10, True); p.y -= 14
    header()
    for r, c in zip(rows, cum):
        if p.y < p.M + 14:
            p.new_page()
            header()
        opt = r["opcion"].replace("SPY", "")[:34]
        p.text(40, p.y, r["fecha"], 7.5)
        p.text(92, p.y, r["hora"][:5], 7.5)
        p.text(128, p.y, r["src"][:6], 7.5)
        p.text(160, p.y, opt, 7)
        p.text(330, p.y, r["cantidad"], 7.5, right=True)
        p.text(380, p.y, "-" if not r.get("capital") else f"{r['capital']:,.0f}", 7.5, right=True)
        p.text(430, p.y, _fmt(r["pnl"], "usd"), 7.5, True, G if r["pnl"] >= 0 else R, right=True)
        p.text(472, p.y, "-" if r.get("roc") is None else f"{r['roc'] * 100:.1f}", 7.5, right=True)
        p.text(525, p.y, f"{c['cap_acum']:,.0f}", 7.5, right=True)
        p.text(572, p.y, "-" if c["roc_acum"] is None else f"{c['roc_acum'] * 100:.1f}", 7.5, right=True)
        p.y -= 11
    if not rows:
        p.text(p.M, p.y, "Sin operaciones en este periodo", 8, color=GR)
    return p.save()
