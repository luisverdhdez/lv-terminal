"""
Market → Inversionistas: portafolios 13F de grandes gestores (fuente oficial: SEC EDGAR, gratis) y su consenso.
- Una vez al dia, en segundo plano, revisa los 13F de cada gestor. Los reportes ya bajados no se vuelven a pedir
  (se guardan en sec_cache/), asi que despues del primer dia solo hace ~1 consulta por gestor.
- Respeta las reglas de la SEC: maximo ~5 consultas por segundo e identificacion (User-Agent).
- CUSIP -> ticker con OpenFIGI (gratis), solo para lo que se muestra, guardado para siempre.
- Un 13F llega hasta 45 dias despues del trimestre: es lo que hicieron, no lo que hacen hoy. No incluye ventas en corto.
"""
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from datetime import date

import requests

BASE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(BASE, "sec_cache")
F_STATE = os.path.join(CACHE, "estado.json")
F_FIGI = os.path.join(CACHE, "cusip_ticker.json")
MAX_POS_CONSENSO = 300      # los "quants" con miles de posiciones no cuentan para el consenso
N_HIST = 6                  # trimestres de historia del valor total

# (CIK, firma, gestor, palabra que debe aparecer en el nombre registrado en la SEC)
GURUS = [
    (1067983, "Berkshire Hathaway", "Warren Buffett", "BERKSHIRE"),
    (1350694, "Bridgewater Associates", "Ray Dalio", "BRIDGEWATER"),
    (1336528, "Pershing Square Capital", "Bill Ackman", "PERSHING"),
    (1649339, "Scion Asset Management", "Michael Burry", "SCION"),
    (1536411, "Duquesne Family Office", "Stanley Druckenmiller", "DUQUESNE"),
    (1037389, "Renaissance Technologies", "Jim Simons", "RENAISSANCE"),
    (1656456, "Appaloosa", "David Tepper", "APPALOOSA"),
    (1040273, "Third Point", "Daniel Loeb", "THIRD POINT"),
    (1079114, "Greenlight Capital", "David Einhorn", "GREENLIGHT"),
    (1167483, "Tiger Global Management", "Chase Coleman", "TIGER GLOBAL"),
    (1061768, "Baupost Group", "Seth Klarman", "BAUPOST"),
    (1603466, "Point72 Asset Management", "Steven Cohen", "POINT72"),
    (921669, "Icahn Enterprises", "Carl Icahn", "ICAHN"),
    (1029160, "Soros Fund Management", "George Soros", "SOROS"),
    (1103804, "Viking Global Investors", "Andreas Halvorsen", "VIKING"),
    (1061165, "Lone Pine Capital", "Steve Mandel", "LONE PINE"),
    (1179392, "Two Sigma Investments", "John Overdeck", "TWO SIGMA"),
    (1135730, "Coatue Management", "Philippe Laffont", "COATUE"),
    (923093, "Tudor Investment", "Paul Tudor Jones", "TUDOR"),
    (1167557, "AQR Capital Management", "Cliff Asness", "AQR"),
    (1791786, "Elliott Investment Management", "Paul Singer", "ELLIOTT"),
    (1709323, "Himalaya Capital", "Li Lu", "HIMALAYA"),
    (1166559, "Gates Foundation Trust", "Bill Gates", "GATES"),
    (949509, "Oaktree Capital", "Howard Marks", "OAKTREE"),
    (783412, "Daily Journal", "Charlie Munger", "DAILY JOURNAL"),
    (1697748, "ARK Investment Management", "Cathie Wood", "ARK INVEST"),
    (1549575, "Pabrai Investment Funds", "Mohnish Pabrai", "DALAL"),
    (1510387, "Gotham Asset Management", "Joel Greenblatt", "GOTHAM"),
    (807249, "GAMCO Investors", "Mario Gabelli", "GAMCO"),
    (915191, "Fairfax Financial", "Prem Watsa", "FAIRFAX"),
    (1096343, "Markel Group", "Tom Gayner", "MARKEL"),
    (807985, "Southeastern Asset Mgmt", "Mason Hawkins", "SOUTHEASTERN"),
    (1056831, "Fairholme Capital", "Bruce Berkowitz", "FAIRHOLME"),
    (1112520, "Akre Capital Management", "Chuck Akre", "AKRE"),
    (936753, "Ariel Investments", "John Rogers", "ARIEL"),
    (905567, "Yacktman Asset Management", "Yacktman", "YACKTMAN"),
]
_S = {"running": False, "done": 0, "total": 0, "err": None, "msg": None}
_L = threading.RLock()
_last = [0.0]


def _ua():
    try:
        from monitor_web import load_env
        e = load_env() or {}
    except Exception:
        e = {}
    c = (e.get("SEC_CONTACT") or "").strip()
    return f"LVOptionsTerminal/1.0 {c}" if c else "LVOptionsTerminal/1.0 (programa de uso personal)"


def _get(url, as_json=True):
    """GET con pausa minima de 0.22 s entre consultas (limite de la SEC: 10/s)."""
    with _L:
        w = 0.22 - (time.time() - _last[0])
        if w > 0:
            time.sleep(w)
        _last[0] = time.time()
    r = requests.get(url, headers={"User-Agent": _ua(), "Accept-Encoding": "gzip, deflate"}, timeout=30)
    if r.status_code == 403:
        raise RuntimeError("La SEC rechazó la consulta (403). Agrega SEC_CONTACT=tu_correo en ~/.tradier_env y reinicia el panel.")
    r.raise_for_status()
    return r.json() if as_json else r.text


def _jload(p, d):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return d


def _jsave(p, obj):
    os.makedirs(CACHE, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, p)


def _strip(tag):
    return tag.split("}")[-1]


def _num(x):
    try:
        return float(str(x).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def parse_infotable(xml_text, dollars=True):
    """XML de la tabla de posiciones del 13F -> {cusip: {name, value($), shares, opt}} (acciones y opciones aparte)."""
    root = ET.fromstring(xml_text.encode("utf-8") if isinstance(xml_text, str) else xml_text)
    out = {}
    for it in root.iter():
        if _strip(it.tag) != "infoTable":
            continue
        d = {}
        for ch in it.iter():
            t = _strip(ch.tag)
            if t in ("nameOfIssuer", "cusip", "value", "sshPrnamt", "sshPrnamtType", "putCall", "titleOfClass"):
                d[t] = (ch.text or "").strip()
        cus = (d.get("cusip") or "").upper()
        if not cus:
            continue
        opt = (d.get("putCall") or "").upper()
        key = cus + ("|" + opt if opt else "")
        val = (_num(d.get("value")) or 0) * (1 if dollars else 1000)
        sh = _num(d.get("sshPrnamt")) or 0
        o = out.setdefault(key, {"cusip": cus, "name": d.get("nameOfIssuer", ""), "value": 0.0, "shares": 0.0, "opt": opt or None})
        o["value"] += val
        o["shares"] += sh
    return out


def parse_primary(xml_text):
    """primary_doc.xml -> (valor total, numero de renglones) del resumen."""
    root = ET.fromstring(xml_text.encode("utf-8") if isinstance(xml_text, str) else xml_text)
    tot = ent = None
    for ch in root.iter():
        t = _strip(ch.tag)
        if t == "tableValueTotal":
            tot = _num(ch.text)
        elif t == "tableEntryTotal":
            ent = _num(ch.text)
    return tot, ent


def _filings(cik):
    j = _get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json")
    rec = (j.get("filings") or {}).get("recent") or {}
    rows = []
    for f, acc, rep, fd in zip(rec.get("form", []), rec.get("accessionNumber", []), rec.get("reportDate", []), rec.get("filingDate", [])):
        if f == "13F-HR":
            rows.append({"acc": acc, "period": rep, "filed": fd})
    by = {}
    for r in sorted(rows, key=lambda r: r["filed"]):
        by[r["period"]] = r          # si hay dos del mismo trimestre, el mas reciente
    return j.get("name", ""), sorted(by.values(), key=lambda r: r["period"])[-N_HIST:]


def _filing(cik, f, need_table):
    """Baja (o lee del cache) el resumen y, si hace falta, la tabla de posiciones de un 13F."""
    p = os.path.join(CACHE, f"{cik}_{f['acc']}.json")
    c = _jload(p, None)
    if c and (c.get("pos") is not None or not need_table):
        return c
    accn = f["acc"].replace("-", "")
    idx = _get(f"https://www.sec.gov/Archives/edgar/data/{cik}/{accn}/index.json")
    items = [i for i in (idx.get("directory") or {}).get("item", []) if str(i.get("name", "")).lower().endswith(".xml")]
    prim = next((i["name"] for i in items if i["name"].lower() == "primary_doc.xml"), None)
    tab = [i for i in items if i["name"].lower() != "primary_doc.xml"]
    tab = max(tab, key=lambda i: _num(i.get("size")) or 0)["name"] if tab else None
    c = c or {"period": f["period"], "filed": f["filed"], "acc": f["acc"]}
    dollars = f["filed"] >= "2023-01-03"      # desde 2023 la SEC pide el valor en dolares (antes, en miles)
    if prim and c.get("total") is None:
        tot, ent = parse_primary(_get(f"https://www.sec.gov/Archives/edgar/data/{cik}/{accn}/{prim}", False))
        c["total"] = (tot or 0) * (1 if dollars else 1000) if tot is not None else None
        c["entries"] = ent
    if need_table and tab:
        c["pos"] = parse_infotable(_get(f"https://www.sec.gov/Archives/edgar/data/{cik}/{accn}/{tab}", False), dollars)
        if c.get("total") is None:
            c["total"] = sum(x["value"] for x in c["pos"].values())
    _jsave(p, c)
    return c


def _worker():
    st = _jload(F_STATE, {"ts": 0, "g": {}})
    _S.update(done=0, total=len(GURUS), err=None)
    for cik, firm, mgr, kw in GURUS:
        g = {"cik": cik, "firm": firm, "mgr": mgr}
        try:
            name, fl = _filings(cik)
            g["sec_name"] = name
            if kw not in name.upper():
                g["err"] = f"El CIK {cik} es de «{name}», no de {firm}"
            elif not fl:
                g["err"] = "Sin 13F en la SEC"
            else:
                hist = []
                for i, f in enumerate(fl):
                    c = _filing(cik, f, need_table=i >= len(fl) - 2)
                    hist.append({"period": c["period"], "total": c.get("total"), "entries": c.get("entries")})
                g["hist"] = hist
                g["acc"] = [f["acc"] for f in fl[-2:]]
        except Exception as e:
            g["err"] = str(e)[:160]
            if "403" in str(e):
                _S["err"] = str(e)
        st["g"][str(cik)] = g
        _S["done"] += 1
    st["ts"] = time.time()
    _jsave(F_STATE, st)
    _S["running"] = False


def _ensure():
    st = _jload(F_STATE, {"ts": 0, "g": {}})
    with _L:
        if not _S["running"] and time.time() - st.get("ts", 0) > 20 * 3600:
            _S["running"] = True
            threading.Thread(target=_worker, daemon=True).start()
    return st


def _tables(cik, g):
    if not g.get("acc"):
        return None, None
    a = [_jload(os.path.join(CACHE, f"{cik}_{acc}.json"), {}) for acc in g["acc"]]
    cur = a[-1].get("pos") or {}
    prev = a[0].get("pos") if len(a) == 2 else {}
    return cur, prev or {}


def _stocks(pos):
    return {k: v for k, v in (pos or {}).items() if not v.get("opt")}


def _qlabel(p):
    return f"T{(int(p[5:7]) - 1) // 3 + 1} {p[:4]}" if p else "–"


# ───────────── CUSIP -> ticker (OpenFIGI) ─────────────
def tickers(cusips):
    m = _jload(F_FIGI, {})
    miss = [c for c in dict.fromkeys(cusips) if c not in m][:50]
    for i in range(0, len(miss), 10):
        try:
            r = requests.post("https://api.openfigi.com/v3/mapping", json=[{"idType": "ID_CUSIP", "idValue": c} for c in miss[i:i + 10]],
                              headers={"Content-Type": "application/json"}, timeout=15)
            if r.status_code == 429:
                break
            for c, res in zip(miss[i:i + 10], r.json()):
                d = (res.get("data") or [])
                eq = [x for x in d if x.get("exchCode") == "US"] or d
                m[c] = eq[0].get("ticker") if eq else ""
        except Exception:
            break
        time.sleep(0.3)
    if miss:
        _jsave(F_FIGI, m)
    return {c: m.get(c) or "" for c in cusips}


# ───────────── resumen para la pagina ─────────────
_SUM = {"key": None, "v": None}


def summary():
    st = _ensure()
    key = (st.get("ts"), _S["running"], _S["done"])
    if _SUM["key"] == key and _SUM["v"]:
        return _SUM["v"]
    v = _summary(st)
    _SUM.update(key=key, v=v)
    return v


def _summary(st):
    G = st.get("g", {})
    periods = [g["hist"][-1]["period"] for g in G.values() if g.get("hist")]
    curq = max(set(periods), key=periods.count) if periods else None
    cards, cons = [], {}
    n_cons = 0
    for cik, firm, mgr, kw in GURUS:
        g = G.get(str(cik)) or {"firm": firm, "mgr": mgr}
        card = {"cik": cik, "firm": firm, "mgr": mgr, "err": g.get("err")}
        if g.get("hist"):
            h = g["hist"]
            last = h[-1]
            prev = h[-2] if len(h) > 1 else None
            cur, pv = _tables(cik, g)
            cs, ps = _stocks(cur), _stocks(pv)
            new = [k for k in cs if k not in ps]
            gone = [k for k in ps if k not in cs]
            card.update(value=last["total"], period=last["period"], q=_qlabel(last["period"]), pos=len(cur) if cur else last.get("entries"),
                        new=len(new) if pv else None, exited=len(gone) if pv else None,
                        chg=(last["total"] / prev["total"] - 1) if prev and prev.get("total") and last.get("total") else None,
                        bars=[x.get("total") for x in h], stale=bool(curq and last["period"] < curq))
            if curq and last["period"] == curq and cur and pv and len(cs) <= MAX_POS_CONSENSO:
                n_cons += 1
                for k in set(cs) | set(ps):
                    a, b = cs.get(k, {}).get("shares", 0), ps.get(k, {}).get("shares", 0)
                    nm = (cs.get(k) or ps.get(k))["name"]
                    e = cons.setdefault(k, {"cusip": k, "name": nm, "buy": [], "sell": [], "new": 0, "exit": 0})
                    if a > 0 and (b == 0 or a >= b * 1.01):
                        e["buy"].append(mgr)
                        e["new"] += b == 0
                    elif b > 0 and (a == 0 or a <= b * 0.99):
                        e["sell"].append(mgr)
                        e["exit"] += a == 0
        cards.append(card)
    rows = list(cons.values())
    for r in rows:
        r["net"] = len(r["buy"]) - len(r["sell"])
    top_b = sorted([r for r in rows if r["net"] > 0], key=lambda r: (-r["net"], -len(r["buy"])))[:8]
    top_s = sorted([r for r in rows if r["net"] < 0], key=lambda r: (r["net"], -len(r["sell"])))[:8]
    tk = tickers([r["cusip"] for r in top_b + top_s])
    for r in top_b + top_s:
        r["ticker"] = tk.get(r["cusip"], "")
    return {"curq": _qlabel(curq) if curq else None, "n_cons": n_cons, "buy": top_b, "sell": top_s, "cards": cards,
            "building": _S["running"], "done": _S["done"], "total": _S["total"], "err": _S["err"],
            "ts": st.get("ts"), "max_pos": MAX_POS_CONSENSO}


def detail(cik):
    st = _jload(F_STATE, {"g": {}})
    g = st["g"].get(str(cik))
    if not g or not g.get("acc"):
        return {"error": "Sin datos de este gestor todavía"}
    cur, pv = _tables(cik, g)
    tot = sum(v["value"] for v in cur.values()) or 1
    rows = []
    for k, v in sorted(cur.items(), key=lambda kv: -kv[1]["value"])[:30]:
        b = (pv.get(k) or {}).get("shares", 0)
        a = v["shares"]
        chg = "nueva" if b == 0 else ("aumentó" if a >= b * 1.01 else "redujo" if a <= b * 0.99 else "igual")
        rows.append({"cusip": v["cusip"], "name": v["name"], "opt": v["opt"], "value": v["value"], "pct": v["value"] / tot,
                     "chg": chg, "chg_pct": (a / b - 1) if b else None})
    gone = sorted([v for k, v in pv.items() if k not in cur], key=lambda v: -v["value"])[:10]
    tk = tickers([r["cusip"] for r in rows] + [v["cusip"] for v in gone])
    for r in rows:
        r["ticker"] = tk.get(r["cusip"], "")
    exited = [{"name": v["name"], "ticker": tk.get(v["cusip"], ""), "value": v["value"], "opt": v["opt"]} for v in gone]
    return {"cik": cik, "firm": g["firm"], "mgr": g["mgr"], "q": _qlabel(g["hist"][-1]["period"]), "rows": rows, "exited": exited,
            "filed": None}


def handle(q):
    try:
        if q.get("cik"):
            return detail(int(q["cik"][0]))
        return summary()
    except Exception as e:
        return {"error": f"{e.__class__.__name__}: {str(e)[:150]}"}
