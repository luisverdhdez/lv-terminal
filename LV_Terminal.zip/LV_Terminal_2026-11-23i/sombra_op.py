"""
Modo sombra de CONTRATOS (0DTE): en cada señal del indicador compara, sin enviar ninguna orden:
  A) la opcion que compra el robot hoy: delta 0,30-0,35, vencimiento del dia habil siguiente (entra al ask, sale al bid);
  B) un debit spread 0DTE: compra la opcion al dinero y vende la de 3 puntos mas lejos (entra pagando ask - bid, sale al bid - ask);
  C) la MISMA opcion del robot (mismo rango de delta) pero con vencimiento a ~3 dias habiles (entra al ask, sale al bid).
Despues sigue los precios REALES de ambas cada minuto durante 35 minutos y guarda cuanto habrian ganado o perdido (por contrato).
Necesita el token REAL (precios en vivo): con el sandbox los precios llevan atraso y la comparacion no sirve.
Lee las señales de senales_live.csv (las mismas que ve el robot). No toca al robot ni envia ordenes.
Limites: no incluye comisiones; el robot real ademas usa stop/trailing/parcial, aqui se miden los puntos de salida fijos (5/10/15/30 min).
"""
import json
import os
import threading
import time
from datetime import datetime, time as dtime, timedelta

import tradier_bot as tb
import senales

ET = tb.ET
BASE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(BASE, "sombra_op.json")
LOCK = threading.RLock()
STATE = {"err": None, "last": None}
WIDTH = 3.0
FOLLOW_MIN = 35
HORIZ = (5, 10, 15, 30)
MAX_AGE = 240      # segundos: si la señal ya tiene mas edad, no se registra (el precio de entrada ya no seria real)
HIT = 0.08         # dolares por accion (= $8 por contrato), el primer objetivo del robot


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {"seen": [], "ent": []}
    except (OSError, ValueError):
        return {"seen": [], "ent": []}


def _save(d):
    d["seen"] = d["seen"][-400:]
    d["ent"] = d["ent"][-600:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _f(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def pick_spread(chain0, side, spot):
    """Debit spread 0DTE: compra al dinero y vende `WIDTH` puntos mas lejos. Devuelve dict o None."""
    typ = "call" if side == "buy" else "put"
    by = {}
    for o in chain0:
        if o.get("option_type") == typ and _f(o.get("strike")) is not None:
            by[_f(o["strike"])] = o
    if not by:
        return None
    k_long = min(by, key=lambda k: abs(k - spot))
    k_short = k_long + WIDTH if typ == "call" else k_long - WIDTH
    lo, sh = by.get(k_long), by.get(k_short)
    if not lo or not sh:
        return None
    lb, la, sb, sa = _f(lo.get("bid")), _f(lo.get("ask")), _f(sh.get("bid")), _f(sh.get("ask"))
    if None in (lb, la, sb, sa) or la <= 0 or sa < 0:
        return None
    return {"long_occ": lo["symbol"], "short_occ": sh["symbol"], "k_long": k_long, "k_short": k_short,
            "debit": round(la - sb, 2), "debit_mid": round((la + lb) / 2 - (sa + sb) / 2, 2)}


def exp_3d(exps, today):
    """Vencimiento a ~3 dias habiles: el primero que este a 3 o mas dias habiles de hoy."""
    for d in sorted(x for x in exps if isinstance(x, str)):
        try:
            dd = datetime.strptime(d, "%Y-%m-%d").date()
        except ValueError:
            continue
        n, x = 0, today
        while x < dd:
            x += timedelta(days=1)
            if x.weekday() < 5:
                n += 1
        if n >= 3:
            return d
    return None


def snapshot(api, cfg, row, now):
    today = now.strftime("%Y-%m-%d")
    q = api._req("GET", "/markets/quotes", params={"symbols": cfg.symbol})
    spot = _f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))
    if spot is None:
        return None
    side = row["lado"]
    ent = {"key": f'{row["fecha"]} {row["hora_vela"]} {side}', "fecha": row["fecha"], "hora": row["hora_vela"], "lado": side,
           "cerca": row.get("cerca_hhll") == "1", "corona": row.get("corona") == "1", "horario": row.get("en_horario") == "1",
           "spot": spot, "t0": time.time(), "samples": [], "single": None, "spread": None, "single3": None}
    nxt = api.next_expiration(cfg.symbol, now.date())
    if nxt:
        c = tb.pick_contract(api.chain(cfg.symbol, nxt), side, cfg)
        if c:
            ent["single"] = {"occ": c["symbol"], "strike": c["strike"], "delta": round(c["delta"], 2), "ask": c["ask"], "bid": c["bid"], "exp": nxt}
    try:
        exps = tb.as_list((api._req("GET", "/markets/options/expirations", params={"symbol": cfg.symbol}).get("expirations") or {}).get("date"))
    except Exception:
        exps = []
    e3 = exp_3d(exps, now.date())
    if e3:
        c3 = tb.pick_contract(api.chain(cfg.symbol, e3), side, cfg)
        if c3:
            ent["single3"] = {"occ": c3["symbol"], "strike": c3["strike"], "delta": round(c3["delta"], 2), "ask": c3["ask"], "bid": c3["bid"], "exp": e3}
    if today in exps:
        sp = pick_spread(api.chain(cfg.symbol, today), side, spot)
        if sp:
            ent["spread"] = sp
    return ent if (ent["single"] or ent["spread"] or ent["single3"]) else None


def scan_new(tok):
    cfg = tb.Config()
    now = datetime.now(ET)
    today = now.strftime("%Y-%m-%d")
    rows = [r for r in senales.read_rows("live") if r.get("fecha") == today]
    with LOCK:
        d = _load()
        seen = set(d["seen"])
    api = tb.Tradier(tok, "", "live", True)
    for r in rows:
        key = f'{r["fecha"]} {r["hora_vela"]} {r["lado"]}'
        if key in seen:
            continue
        try:
            close = datetime.strptime(r["fecha"] + " " + r["hora_vela"], "%Y-%m-%d %H:%M").replace(tzinfo=ET)
        except ValueError:
            continue
        seen.add(key)
        with LOCK:
            d = _load()
            if key not in d["seen"]:
                d["seen"].append(key)
            _save(d)
        if (now - close).total_seconds() > MAX_AGE or r.get("en_horario") != "1":
            continue
        try:
            ent = snapshot(api, cfg, r, now)
        except Exception as e:
            STATE["err"] = e.__class__.__name__
            ent = None
        if ent:
            with LOCK:
                d = _load()
                d["ent"].append(ent)
                _save(d)


def poll(tok):
    with LOCK:
        d = _load()
    now = time.time()
    act = [e for e in d["ent"] if now - e["t0"] <= FOLLOW_MIN * 60 + 60 and not e.get("done")]
    if not act:
        return
    occs = set()
    for e in act:
        if e["single"]:
            occs.add(e["single"]["occ"])
        if e.get("single3"):
            occs.add(e["single3"]["occ"])
        if e["spread"]:
            occs.update((e["spread"]["long_occ"], e["spread"]["short_occ"]))
    api = tb.Tradier(tok, "", "live", True)
    j = api._req("GET", "/markets/quotes", params={"symbols": ",".join(sorted(occs))})
    qs = {x["symbol"]: x for x in tb.as_list((j.get("quotes") or {}).get("quote")) if isinstance(x, dict) and x.get("symbol")}
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e.get("done") or now - e["t0"] > FOLLOW_MIN * 60 + 60:
                e["done"] = True if now - e["t0"] > FOLLOW_MIN * 60 + 60 else e.get("done")
                continue
            s = {"m": round((now - e["t0"]) / 60, 2), "spy": None}
            if e["single"]:
                s["s"] = _f((qs.get(e["single"]["occ"]) or {}).get("bid"))
            if e.get("single3"):
                s["s3"] = _f((qs.get(e["single3"]["occ"]) or {}).get("bid"))
            if e["spread"]:
                lg, sh = qs.get(e["spread"]["long_occ"]) or {}, qs.get(e["spread"]["short_occ"]) or {}
                lb, sa = _f(lg.get("bid")), _f(sh.get("ask"))
                s["p"] = round(lb - sa, 2) if lb is not None and sa is not None else None
            e["samples"].append(s)
        _save(d)
    STATE["last"] = time.time()


def loop(get_env):
    while True:
        try:
            now = datetime.now(ET)
            if now.weekday() < 5 and dtime(9, 40) <= now.time() <= dtime(16, 10):
                tok = (get_env() or {}).get("TRADIER_LIVE_TOKEN")
                if tok:
                    try:
                        scan_new(tok)
                        poll(tok)
                        STATE["err"] = None
                    except Exception as e:  # nunca tumbar el panel
                        STATE["err"] = e.__class__.__name__
        except Exception:
            pass
        time.sleep(20)


# ───────────── resultados ─────────────
def _at(samples, key, h):
    best = None
    for s in samples:
        if s.get(key) is None:
            continue
        if abs(s["m"] - h) <= 1.6 and (best is None or abs(s["m"] - h) < abs(best["m"] - h)):
            best = s
    return None if best is None else best[key]


def _pnls(e, kind):
    """P&L en dolares por contrato en cada horizonte + mejor/peor punto y si toco +$8."""
    if kind == "s":
        if not e["single"]:
            return None
        cost = e["single"]["ask"]
    elif kind == "s3":
        if not e.get("single3"):
            return None
        cost = e["single3"]["ask"]
    else:
        if not e["spread"]:
            return None
        cost = e["spread"]["debit"]
    smp = [s for s in e["samples"] if s["m"] <= 30.5 and s.get(kind) is not None]
    out = {}
    for h in HORIZ:
        v = _at(e["samples"], kind, h)
        out[h] = None if v is None else round((v - cost) * 100, 1)
    vals = [(s[kind] - cost) * 100 for s in smp]
    out["mfe"] = round(max(vals), 1) if vals else None
    out["mae"] = round(min(vals), 1) if vals else None
    out["hit"] = (max(vals) >= HIT * 100 - 1e-9) if vals else None
    out["cost"] = round(cost * 100, 0)
    return out


def _agg(items):
    r = {"n": len(items)}
    for h in HORIZ:
        v = [x[h] for x in items if x[h] is not None]
        r[f"avg{h}"] = round(sum(v) / len(v), 1) if v else None
        r[f"win{h}"] = round(100 * sum(1 for x in v if x > 0) / len(v)) if v else None
        r[f"n{h}"] = len(v)
    for k in ("mfe", "mae"):
        v = [x[k] for x in items if x[k] is not None]
        r[k] = round(sum(v) / len(v), 1) if v else None
    hv = [x["hit"] for x in items if x["hit"] is not None]
    r["hit"] = round(100 * sum(hv) / len(hv)) if hv else None
    cv = [x["cost"] for x in items]
    r["cost"] = round(sum(cv) / len(cv)) if cv else None
    return r


def summary():
    d = _load()
    ents = d["ent"]
    groups = {"todas": ents, "cerca": [e for e in ents if e["cerca"]], "cerca_corona": [e for e in ents if e["cerca"] and e["corona"]]}
    out = {}
    for g, lst in groups.items():
        a = [p for p in (_pnls(e, "s") for e in lst) if p]
        b = [p for p in (_pnls(e, "p") for e in lst) if p]
        out[g] = {"robot": _agg(a), "spread": _agg(b)}
    ult = []
    for e in ents[-15:][::-1]:
        ult.append({"fecha": e["fecha"], "hora": e["hora"], "lado": e["lado"], "cerca": e["cerca"], "corona": e["corona"],
                    "single": e["single"] and {"strike": e["single"]["strike"], "ask": e["single"]["ask"]},
                    "spread": e["spread"] and {"k": f'{e["spread"]["k_long"]}/{e["spread"]["k_short"]}', "debit": e["spread"]["debit"]},
                    "a": _pnls(e, "s"), "b": _pnls(e, "p"), "muestras": len(e["samples"])})
    return {"n": len(ents), "grupos": out, "ultimas": ult, "err": STATE["err"], "last": STATE["last"]}


def handle():
    return 200, summary()
