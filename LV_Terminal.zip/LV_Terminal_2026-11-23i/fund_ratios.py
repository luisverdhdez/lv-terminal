"""
Pestaña Ratios de Fundamentales: ratios por periodo (anual o trimestral), comparacion con empresas parecidas,
puntaje de rentabilidad 0-100 y revisiones del flujo de caja libre.
Datos: Yahoo Finance via yfinance (no oficial). Yahoo da ~4-5 años o ~5 trimestres de estados financieros.
Los multiplos de cada periodo usan el precio de cierre al final de ese periodo.
"""
import math
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta

import fundamentales as F

N_A, N_Q = 5, 6


def _ser(df, names):
    """{fecha: valor} del primer concepto que exista en el DataFrame de yfinance."""
    if df is None or getattr(df, "empty", True):
        return {}
    for nm in names:
        if nm in df.index:
            out = {}
            for c in df.columns:
                v = F._n(df.loc[nm, c])
                if v is not None and not (isinstance(v, float) and math.isnan(v)):
                    out[str(c)[:10]] = v
            if out:
                return out
    return {}


def _d(a, b, pos=True):
    """a/b; None si falta algo o si el denominador no es positivo (cuando pos=True)."""
    if a is None or b is None or b == 0 or (pos and b < 0):
        return None
    return a / b


def _price_at(hist, date):
    """Cierre del ultimo dia <= fecha."""
    if hist is None or getattr(hist, "empty", True):
        return None
    try:
        s = hist["Close"]
        s = s[[str(i)[:10] <= date for i in s.index]]
        return float(s.iloc[-1]) if len(s) else None
    except Exception:
        return None


def periods(sym, per="a"):
    yf = F._yf()
    qq = per == "q"

    def go():
        try:
            t = yf.Ticker(sym)
            inc, bal, cf = ((t.quarterly_income_stmt, t.quarterly_balance_sheet, t.quarterly_cashflow) if qq
                            else (t.income_stmt, t.balance_sheet, t.cashflow))
            hist = t.history(period="6y", interval="1d", auto_adjust=False)
        except Exception as e:
            raise F._wrap(e)
        S = {
            "rev": _ser(inc, ("Total Revenue", "Operating Revenue")), "cogs": _ser(inc, ("Cost Of Revenue", "Reconciled Cost Of Revenue")),
            "gross": _ser(inc, ("Gross Profit",)), "oper": _ser(inc, ("Operating Income", "Total Operating Income As Reported")),
            "ebit": _ser(inc, ("EBIT",)), "ebitda": _ser(inc, ("EBITDA", "Normalized EBITDA")),
            "net": _ser(inc, ("Net Income", "Net Income Common Stockholders")), "int": _ser(inc, ("Interest Expense", "Interest Expense Non Operating")),
            "tax": _ser(inc, ("Tax Provision",)), "pretax": _ser(inc, ("Pretax Income",)),
            "shares": _ser(inc, ("Diluted Average Shares", "Basic Average Shares")),
            "assets": _ser(bal, ("Total Assets",)), "equity": _ser(bal, ("Stockholders Equity", "Common Stock Equity")),
            "debt": _ser(bal, ("Total Debt",)), "cash": _ser(bal, ("Cash And Cash Equivalents", "Cash Cash Equivalents And Short Term Investments")),
            "ca": _ser(bal, ("Current Assets",)), "cl": _ser(bal, ("Current Liabilities",)), "inv": _ser(bal, ("Inventory",)),
            "recv": _ser(bal, ("Accounts Receivable", "Receivables")), "sh_bal": _ser(bal, ("Ordinary Shares Number", "Share Issued")),
            "cfo": _ser(cf, ("Operating Cash Flow", "Cash Flow From Continuing Operating Activities")),
            "capex": _ser(cf, ("Capital Expenditure",)), "fcf": _ser(cf, ("Free Cash Flow",)),
            "divp": _ser(cf, ("Cash Dividends Paid", "Common Stock Dividend Paid")), "wc": _ser(cf, ("Change In Working Capital",)),
        }
        dates = sorted(set(S["rev"]) | set(S["net"]) | set(S["assets"]))[-(N_Q if qq else N_A):]
        rows = []
        for i, d in enumerate(dates):
            g = lambda k: S[k].get(d)
            # en trimestral, flujos (ingresos, utilidad, FCF...) se suman 4 trimestres para los multiplos (TTM)
            def ttm(k):
                if not qq:
                    return g(k)
                ds = [x for x in sorted(S[k]) if x <= d][-4:]
                return sum(S[k][x] for x in ds) if len(ds) == 4 else None
            rev, net, fcf = g("rev"), g("net"), g("fcf")
            if fcf is None and g("cfo") is not None and g("capex") is not None:
                fcf = g("cfo") + g("capex")
            px = _price_at(hist, d)
            sh = g("sh_bal") or g("shares")
            mc = px * sh if px and sh else None
            ev = mc + (g("debt") or 0) - (g("cash") or 0) if mc else None
            gross = g("gross") if g("gross") is not None else (rev - g("cogs") if rev is not None and g("cogs") is not None else None)
            ebit = g("ebit") if g("ebit") is not None else g("oper")
            tr = _d(g("tax"), g("pretax"))
            tr = 0.21 if tr is None or not 0 <= tr <= 0.5 else tr
            ic = (g("debt") or 0) + (g("equity") or 0) - (g("cash") or 0)
            r_ttm, n_ttm, f_ttm, e_ttm = ttm("rev"), ttm("net"), ttm("fcf"), ttm("ebitda")
            if qq and f_ttm is None:
                c4, x4 = ttm("cfo"), ttm("capex")
                f_ttm = c4 + x4 if c4 is not None and x4 is not None else None
            ann = 4 if qq else 1
            row = {"date": d, "label": (f"T{(int(d[5:7]) - 1) // 3 + 1} {d[2:4]}" if qq else d[:4]),
                   "pe": _d(mc, n_ttm), "pb": _d(mc, g("equity")), "ps": _d(mc, r_ttm), "p_fcf": _d(mc, f_ttm), "ev_ebitda": _d(ev, e_ttm),
                   "roe": _d((net or 0) * ann, g("equity")) if net is not None else None,
                   "roa": _d((net or 0) * ann, g("assets")) if net is not None else None,
                   "roic": _d(ebit * (1 - tr) * ann, ic) if ebit is not None else None,
                   "gross_m": _d(gross, rev), "oper_m": _d(g("oper"), rev, False) if rev and rev > 0 else None,
                   "net_m": _d(net, rev) if rev and rev > 0 else None, "fcf_m": _d(fcf, rev) if rev and rev > 0 else None,
                   "current": _d(g("ca"), g("cl")), "quick": _d((g("ca") or 0) - (g("inv") or 0), g("cl")) if g("ca") is not None else None,
                   "cash_r": _d(g("cash"), g("cl")),
                   "de": _d(g("debt"), g("equity")), "int_cov": _d(ebit, abs(g("int")) if g("int") else None) if ebit is not None else None,
                   "debt_r": _d(g("debt"), g("assets")),
                   "asset_t": _d((rev or 0) * ann, g("assets")) if rev is not None else None,
                   "recv_t": _d((rev or 0) * ann, g("recv")) if rev is not None else None,
                   "inv_t": _d((g("cogs") or 0) * ann, g("inv")) if g("cogs") is not None else None,
                   "payout": _d(abs(g("divp")), net) if g("divp") is not None and net and net > 0 else None,
                   "rev": rev, "net": net, "fcf": fcf, "cfo": g("cfo"), "capex": g("capex"), "wc": g("wc"), "price": px}
            rows.append(row)
        # crecimiento y PEG (anual: frente al ano anterior; trimestral: frente al mismo trimestre del ano anterior)
        st = 4 if qq else 1
        for i, r in enumerate(rows):
            p = rows[i - st] if i >= st else None
            gr = (r["net"] / p["net"] - 1) * 100 if p and p["net"] and p["net"] > 0 and r["net"] is not None else None
            r["peg"] = r["pe"] / gr if r["pe"] and gr and gr > 0 else None
        return rows
    return F._cached(("ratios_p", sym, per), F.TTL_LONG, go)


def _cagr(a, b, n):
    if a is None or b is None or a <= 0 or b <= 0 or n <= 0:
        return None
    return (b / a) ** (1 / n) - 1


# ───────────── comparacion con pares ─────────────
def _peer_ratios(sym):
    peers = [s for s in F._peer_syms(sym) if isinstance(s, str) and F.SYM_RE.match(s) and s != sym][:8]

    def one(s):
        try:
            return s, F._ratios(F._info(s))
        except Exception:
            return s, None
    with ThreadPoolExecutor(max_workers=4) as ex:
        got = [(s, r) for s, r in ex.map(one, peers) if r]
    return got


def _median(v):
    v = sorted(x for x in v if x is not None)
    if not v:
        return None
    m = len(v) // 2
    return v[m] if len(v) % 2 else (v[m - 1] + v[m]) / 2


# (clave, nombre, formato, mejor="low"/"high"/"range", ideal (texto), clave en _ratios de Yahoo o None, clave en periodos)
CARDS = [
    ("pe", "P/E", "x", "low", None, "pe", "pe"),
    ("fpe", "P/E futuro", "x", "low", None, None, None),
    ("peg", "PEG", "x", "low", "Ideal < 1", "peg", "peg"),
    ("ps", "P/S", "x", "low", None, "ps", "ps"),
    ("ev_ebitda", "EV / EBITDA", "x", "low", None, "ev_ebitda", "ev_ebitda"),
    ("quick", "Razón rápida", "x", "high", "Ideal > 1", "quick", "quick"),
    ("current", "Razón corriente", "x", "range", "Ideal 1 – 3", "current", "current"),
    ("roe", "ROE", "%", "high", None, "roe", "roe"),
    ("roa", "ROA", "%", "high", None, "roa", "roa"),
    ("roic", "ROIC", "%", "high", "Ideal > 10%", None, "roic"),
    ("gross_m", "Margen bruto", "%", "high", None, "gross", "gross_m"),
    ("net_m", "Margen neto", "%", "high", None, "net", "net_m"),
    ("de", "Deuda / Capital", "x", "low", "Ideal < 1", "de", "de"),
    ("int_cov", "Cobertura de intereses", "x", "high", "Ideal > 5×", None, "int_cov"),
    ("payout", "Payout", "%", "low", "Ideal < 60%", "payout", "payout"),
    ("g_rev", "Crec. ingresos", "%", "high", "CAGR", None, None),
    ("g_net", "Crec. utilidad neta", "%", "high", "CAGR", None, None),
    ("g_fcf", "Crec. flujo libre", "%", "high", "CAGR", None, None),
]
IDEAL = {"peg": lambda v: v < 1, "quick": lambda v: v > 1, "current": lambda v: 1 <= v <= 3, "roic": lambda v: v > 0.10,
         "de": lambda v: v < 1, "int_cov": lambda v: v > 5, "payout": lambda v: v < 0.6}


def _verdict(key, best, v, med):
    """'bien' / 'mal' / 'alerta' (valor sin sentido, p. ej. negativo) / None."""
    if v is None:
        return None
    if key in ("pe", "fpe", "ps", "ev_ebitda", "peg") and v <= 0:
        return "alerta"
    if key == "fpe":
        return None if med is None or med <= 0 else ("bien" if v < med else "mal")   # aqui med = P/E actual
    if key in IDEAL:
        return "bien" if IDEAL[key](v) else "mal"
    if key.startswith("g_"):
        return "bien" if v > 0.001 else "mal" if v < -0.001 else None
    if med is None or abs(v - med) <= 1e-9 * max(1.0, abs(med)):
        return None
    return "bien" if (v < med if best == "low" else v > med) else "mal"


# ───────────── puntaje de rentabilidad ─────────────
PTS = {  # (umbral en %, puntos), interpolado
    "gross_m": [(0, 0), (10, 25), (25, 50), (40, 75), (60, 100)],
    "oper_m": [(0, 10), (5, 35), (10, 55), (20, 80), (30, 100)],
    "net_m": [(0, 10), (2, 30), (6, 55), (12, 80), (20, 100)],
    "fcf_m": [(-5, 0), (0, 20), (5, 50), (10, 75), (20, 100)],
    "roe": [(0, 10), (5, 35), (10, 60), (15, 80), (25, 100)],
    "roic": [(0, 10), (4, 35), (8, 60), (12, 80), (20, 100)],
}


def _pts(k, v):
    if v is None:
        return None
    x, t = v * 100, PTS[k]
    if x <= t[0][0]:
        return 0 if x < t[0][0] else t[0][1]
    for (a, pa), (b, pb) in zip(t, t[1:]):
        if x <= b:
            return round(pa + (pb - pa) * (x - a) / (b - a))
    return 100


def _level(p):
    return None if p is None else "Excepcional" if p >= 85 else "Sólido" if p >= 65 else "Aceptable" if p >= 45 else "Débil" if p >= 25 else "Malo"


def score(rows, peer_med):
    if not rows:
        return None
    last = rows[-1]
    prev = rows[-4:-1]
    names = {"gross_m": "Margen bruto", "oper_m": "Margen operativo", "net_m": "Margen neto", "fcf_m": "Margen de flujo libre", "roe": "ROE", "roic": "ROIC"}
    table = []
    for k, nm in names.items():
        v = last.get(k)
        hist = [r.get(k) for r in prev if r.get(k) is not None]
        avg = sum(hist) / len(hist) if hist else None
        vol = None
        if len(hist) >= 2 and avg:
            sd = (sum((h - avg) ** 2 for h in hist) / (len(hist) - 1)) ** 0.5
            vol = abs(sd / avg) > 0.5
        trend = None
        if v is not None and avg is not None:
            d = v - avg
            trend = "mejora" if d > max(0.01, abs(avg) * 0.1) else "empeora" if d < -max(0.01, abs(avg) * 0.1) else "estable"
        pm = peer_med.get(k)
        table.append({"key": k, "name": nm, "v": v, "pts": _pts(k, v), "level": _level(_pts(k, v)), "avg3": avg, "volatile": vol,
                      "trend": trend, "spark": [r.get(k) for r in rows], "vs_peer": (v - pm) / abs(pm) if v is not None and pm else None})
    P = {t["key"]: t["pts"] for t in table}
    grp = lambda ks: (lambda v: round(sum(v) / len(v)) if v else None)([P[k] for k in ks if P[k] is not None])
    parts = [("Márgenes", 0.35, grp(["gross_m", "oper_m", "net_m"])), ("Flujo de caja libre", 0.30, grp(["fcf_m"])),
             ("Rendimiento del capital", 0.35, grp(["roe", "roic"]))]
    ok = [(w, s) for _, w, s in parts if s is not None]
    total = round(sum(w * s for w, s in ok) / sum(w for w, _ in ok)) if ok else None
    best = max((p for p in parts if p[2] is not None), key=lambda p: p[2], default=None)
    worst = min((p for p in parts if p[2] is not None), key=lambda p: p[2], default=None)
    # revisiones del flujo libre (ultimos 5 periodos y 3 para el promedio)
    f5 = [r["fcf"] for r in rows[-5:] if r.get("fcf") is not None]
    f3 = [r for r in rows[-3:] if r.get("fcf") is not None]
    conv = (sum(r["fcf"] for r in f3) / sum(r["net"] for r in f3)) if f3 and all(r.get("net") for r in f3) and sum(r["net"] for r in f3) > 0 else None
    avg_fcf = sum(r["fcf"] for r in f3) / len(f3) if f3 else None
    avg_rev = sum(r["rev"] for r in f3 if r.get("rev")) / len(f3) if f3 and all(r.get("rev") for r in f3) else None
    first, lastf = (rows[-4] if len(rows) >= 4 else rows[0]), rows[-1]
    dchg = lambda k: (lastf.get(k) - first.get(k)) if lastf.get(k) is not None and first.get(k) is not None else None
    checks = {"pos": sum(1 for x in f5 if x > 0), "pos_n": len(f5), "conv": conv, "avg": avg_fcf,
              "avg_m": avg_fcf / avg_rev if avg_fcf is not None and avg_rev else None,
              "chg": {"fcf": dchg("fcf"), "cfo": dchg("cfo"), "wc": dchg("wc"), "capex": dchg("capex")}, "since": first["label"]}
    return {"total": total, "parts": [{"name": n, "w": w, "s": s} for n, w, s in parts], "table": table,
            "best": best and best[0], "worst": worst and worst[0], "checks": checks, "period": last["label"]}


def ratios(env, sym, per="a"):
    rows = periods(sym, per)
    info = F._info(sym)
    cur = F._ratios(info)
    peers = F._cached(("peer_ratios", sym), F.TTL_LONG, lambda: _peer_ratios(sym))
    pmed = {}
    for k in ("pe", "peg", "ps", "ev_ebitda", "quick", "current", "roe", "roa", "gross", "net", "oper", "de", "payout", "pb"):
        pmed[k] = _median([r.get(k) for _, r in peers])
    last = rows[-1] if rows else {}
    years = [r for r in rows]
    st = 4 if per == "q" else 1
    span = (len(years) - 1) / (4 if per == "q" else 1)
    cagr = lambda k: _cagr(years[0].get(k), years[-1].get(k), span) if len(years) >= 2 else None
    cur_vals = {"pe": cur["pe"], "fpe": F._n(info.get("forwardPE")), "peg": cur["peg"], "ps": cur["ps"], "ev_ebitda": cur["ev_ebitda"],
                "quick": cur["quick"], "current": cur["current"], "roe": cur["roe"], "roa": cur["roa"], "roic": last.get("roic"),
                "gross_m": cur["gross"], "net_m": cur["net"], "de": cur["de"], "int_cov": last.get("int_cov"),
                "payout": cur["payout"], "g_rev": cagr("rev"), "g_net": cagr("net"), "g_fcf": cagr("fcf")}
    cards = []
    for key, name, fmt, best, ideal, ykey, pkey in CARDS:
        v = cur_vals.get(key)
        if v is None and pkey:
            v = last.get(pkey)
        med = pmed.get(ykey) if ykey else (cur_vals.get("pe") if key == "fpe" else None)
        cards.append({"key": key, "name": name, "fmt": fmt, "v": v, "med": med, "ideal": ideal, "best": best,
                      "verdict": _verdict(key, best, v, med), "spark": [r.get(pkey) for r in rows] if pkey else []})
    peer_med_score = {"gross_m": pmed.get("gross"), "oper_m": pmed.get("oper"), "net_m": pmed.get("net"), "roe": pmed.get("roe")}
    return {"sym": sym, "per": per, "rows": rows, "cards": cards, "peers": [s for s, _ in peers],
            "score": score(rows, peer_med_score), "span": span,
            "warn": [] if rows else ["Yahoo no devolvió estados financieros para este símbolo."]}
