"""Modo sombra: estrategias NUEVAS (pedidas por Luis el 19-nov-2026). NUNCA envia ordenes (dry=True, solo GET).
1) qqq_ic  · Iron condor SEMANAL en QQQ: lun-mie 10:00, ventas en delta 0.10 / 0.15 / 0.20, alas de $5, vence el viernes.
2) spy_pcs · Put credit spread SEMANAL en SPY: lun-mie 10:00, venta en delta 0.15 / 0.20 / 0.30, ancho $5, vence el viernes.
3) spx_0dte· Dos iron condors 0DTE en SPX a las 9:35: (A) delta 0.10 con alas de 20 y (B) delta 0.20 con alas de 10.
   Se mide cada 2 min para encontrar la MEJOR HORA para cerrarlos y comparar objetivo/stop.
Precios a precio MEDIO y "natural"; ademas un estimado REAL con como se llenan tus ordenes reales de condor SPX
(condor_noche.slippage) y restando comisiones aproximadas."""
import json
import os
import threading
import time
from datetime import datetime, date, time as dtime, timedelta

import condor as cw
import tradier_bot as tb

ET = cw.ET
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sombra2.json")
LOCK = threading.RLock()
STATE = {"err": None, "last": {}, "msg": {}}
_f, _mid = cw._f, cw._mid

WEEKLY_RULES = [("vence", "Dejarlo hasta el vencimiento"), ("tp50", "Cerrar al ganar 50% del crédito"),
                ("tp50_stop2", "50% de ganancia o pérdida de 2× (lo que llegue antes)"),
                ("tp50_stop2_dia", "Lo anterior + cerrar el día antes del vencimiento")]
TIMES_0DTE = ["10:00", "10:30", "11:00", "11:30", "12:00", "13:00", "14:00", "15:00", "15:30", "15:50"]
RULES_0DTE = ([("c" + t.replace(":", ""), "Cerrar a las " + t) for t in TIMES_0DTE] +
              [("tp25_s2", "Objetivo 25% o stop 2× · si no, a las 15:50"), ("tp50_s2", "Objetivo 50% o stop 2× · si no, a las 15:50"),
               ("vence", "Dejarlo vencer (liquida al cierre)")])

STRATS = {
    "qqq_ic": {"name": "Iron condor semanal en QQQ", "sym": "QQQ", "kind": "ic", "weekly": True,
               "variants": [{"id": f"d{int(d * 100)}", "label": f"Delta {d:.2f} · alas $5", "delta": d, "width": 5.0} for d in (0.10, 0.15, 0.20)],
               "entry": (dtime(10, 0), dtime(10, 45)), "days": (0, 1, 2), "poll": 300, "comm": 2.60,
               "desc": "Lunes a miércoles a las 10:00 ET, un condor por cada delta de venta (0.10, 0.15 y 0.20), alas de $5, vence el viernes. Igual que el de SPX pero en QQQ (Nasdaq 100)."},
    "spy_pcs": {"name": "Put credit spread semanal en SPY", "sym": "SPY", "kind": "pcs", "weekly": True,
                "variants": [{"id": f"d{int(d * 100)}", "label": f"Delta {d:.2f} · ancho $5", "delta": d, "width": 5.0} for d in (0.15, 0.20, 0.30)],
                "entry": (dtime(10, 0), dtime(10, 45)), "days": (0, 1, 2), "poll": 300, "comm": 1.30,
                "desc": "Lunes a miércoles a las 10:00 ET vende un put en delta 0.15 / 0.20 / 0.30 y compra otro $5 más abajo, vence el viernes. Solo el lado alcista: gana si SPY no cae hasta el put vendido."},
    "spx_0dte": {"name": "Iron condors 0DTE en SPX (apertura)", "sym": "SPX", "kind": "ic", "weekly": False,
                 "variants": [{"id": "a", "label": "A · delta 0.10 · alas de 20", "delta": 0.10, "width": 20.0},
                              {"id": "b", "label": "B · delta 0.20 · alas de 10", "delta": 0.20, "width": 10.0}],
                 "entry": (dtime(9, 35), dtime(9, 50)), "days": (0, 1, 2, 3, 4), "poll": 120, "comm": 7.60,
                 "desc": "Cada día hábil a las 9:35 ET dos condors que vencen HOY: A) ventas en delta 0.10 con alas de 20 puntos y B) ventas en delta 0.20 con alas de 10. Se mide cada 2 min para ver a qué hora conviene cerrarlos."},
}


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) and isinstance(d.get("ent"), list) else {"ent": []}
    except (OSError, ValueError):
        return {"ent": []}


def _save(d):
    d["ent"] = d["ent"][-1500:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _exps(api, sym):
    j = api._req("GET", "/markets/options/expirations", params={"symbol": sym, "includeAllRoots": "true"})
    return sorted(d for d in tb.as_list((j.get("expirations") or {}).get("date")) if isinstance(d, str))


def pick_exp(exps, today, weekly):
    if not weekly:
        return today.isoformat() if today.isoformat() in exps else None
    fri = today + timedelta(days=4 - today.weekday())
    ok = [d for d in exps if today.isoformat() < d <= fri.isoformat()]
    return max(ok) if ok else None


def pick(chain, spot, kind, delta, width, T):
    """Spread de puts (pcs) o condor (ic) con ventas en `delta` (con la delta de AHORA) y alas de `width`."""
    by = {"put": {}, "call": {}}
    for o in chain:
        t, k = o.get("option_type"), _f(o.get("strike"))
        if t in by and k is not None:
            by[t][k] = o
    dl = lambda o: cw.live_delta(o, spot, T)
    def side(t, below):
        c = [o for k, o in by[t].items() if (k < spot if below else k > spot) and (_f(o.get("bid")) or 0) > 0 and dl(o) is not None]
        if not c:
            return None, None
        s = min(c, key=lambda o: abs(abs(dl(o)) - delta))
        kl = _f(s["strike"]) + (-width if below else width)
        return s, by[t].get(kl)
    sp, lp = side("put", True)
    if not sp or not lp:
        return None
    legs = {"sp": sp, "lp": lp}
    if kind == "ic":
        sc, lc = side("call", False)
        if not sc or not lc:
            return None
        legs.update(sc=sc, lc=lc)
    m = {k: _mid(o) for k, o in legs.items()}
    if None in m.values():
        return None
    cr = m["sp"] - m["lp"] + (m.get("sc", 0) - m.get("lc", 0))
    try:
        nat = _f(sp["bid"]) - _f(lp["ask"]) + ((_f(legs["sc"]["bid"]) - _f(legs["lc"]["ask"])) if kind == "ic" else 0)
    except (TypeError, KeyError):
        return None
    if cr <= 0.05:
        return None
    out = {"kp": _f(sp["strike"]), "kpl": _f(lp["strike"]), "occ": {k: o["symbol"] for k, o in legs.items()},
           "dp": round(abs(dl(sp)), 3), "credit": round(cr, 2), "credit_nat": round(nat, 2), "width": width}
    if kind == "ic":
        out.update(kc=_f(legs["sc"]["strike"]), kcl=_f(legs["lc"]["strike"]), dc=round(abs(dl(legs["sc"])), 3))
    return out


def _quote_last(api, sym):
    q = api._req("GET", "/markets/quotes", params={"symbols": sym})
    return _f((tb.as_list((q.get("quotes") or {}).get("quote")) or [{}])[0].get("last"))


def enter(api, key, now):
    S = STRATS[key]
    today = now.date()
    with LOCK:
        have = {(e["est"], e["var"]) for e in _load()["ent"] if e["fecha"] == today.isoformat()}
    todo = [v for v in S["variants"] if (key, v["id"]) not in have]
    if not todo:
        return 0
    exp = pick_exp(_exps(api, S["sym"]), today, S["weekly"])
    if not exp:
        STATE["msg"][key] = f"{today}: sin vencimiento {'de hoy' if not S['weekly'] else 'esta semana'}"
        return 0
    spot = _quote_last(api, S["sym"])
    if not spot:
        return 0
    chain = api.chain(S["sym"], exp)
    if S["sym"] == "SPX":
        chain = cw._weekly(chain)
    T = cw.years_to(exp, now)
    n = 0
    with LOCK:
        d = _load()
        for v in todo:
            p = pick(chain, spot, S["kind"], v["delta"], v["width"], T)
            if not p:
                STATE["msg"][key] = f"{today}: sin strikes válidos para {v['label']}"
                continue
            d["ent"].append(dict(p, est=key, var=v["id"], fecha=today.isoformat(), hora=now.strftime("%H:%M"), exp=exp,
                                 spot=round(spot, 2), samples=[], done=False, settle=None))
            n += 1
        _save(d)
    return n


def close_cost(q, kind):
    """(medio, natural) de lo que cuesta CERRAR (recomprar) la posicion."""
    m = {k: _mid(v) for k, v in q.items()}
    if None in m.values():
        return None, None
    mid = m["sp"] - m["lp"] + (m.get("sc", 0) - m.get("lc", 0))
    try:
        nat = _f(q["sp"]["ask"]) - _f(q["lp"]["bid"]) + ((_f(q["sc"]["ask"]) - _f(q["lc"]["bid"])) if kind == "ic" else 0)
    except (TypeError, KeyError):
        nat = None
    return mid, nat


def poll(api, key, now):
    S = STRATS[key]
    with LOCK:
        act = [e for e in _load()["ent"] if e["est"] == key and not e.get("done") and e["exp"] >= now.date().isoformat()]
    if not act:
        return
    occs = sorted({o for e in act for o in e["occ"].values()})
    j = api._req("GET", "/markets/quotes", params={"symbols": ",".join(occs + [S["sym"]])})
    qs = {x["symbol"]: x for x in tb.as_list((j.get("quotes") or {}).get("quote")) if isinstance(x, dict) and x.get("symbol")}
    px = _f((qs.get(S["sym"]) or {}).get("last"))
    t = now.strftime("%Y-%m-%d %H:%M")
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e["est"] != key or e.get("done") or e["exp"] < now.date().isoformat():
                continue
            mid, nat = close_cost({k: qs.get(o) or {} for k, o in e["occ"].items()}, S["kind"])
            if mid is not None:
                e["samples"].append({"t": t, "px": px, "mid": round(max(0.0, min(e["width"], mid)), 2),
                                     "nat": None if nat is None else round(nat, 2)})
        _save(d)
    STATE["last"][key] = time.time()


def settle_value(e, s):
    w = e["width"]
    v = max(0.0, min(w, e["kp"] - s))
    if "kc" in e:
        v += max(0.0, min(w, s - e["kc"]))
    return v


def settle(api, key, now):
    S = STRATS[key]
    with LOCK:
        pend = [e for e in _load()["ent"] if e["est"] == key and not e.get("done") and
                (e["exp"] < now.date().isoformat() or (e["exp"] == now.date().isoformat() and now.time() >= dtime(16, 10)))]
    if not pend:
        return
    closes = {}
    for ex in sorted({e["exp"] for e in pend}):
        j = api._req("GET", "/markets/history", params={"symbol": S["sym"], "interval": "daily", "start": ex, "end": ex})
        day = tb.as_list(((j.get("history") or {}) if isinstance(j.get("history"), dict) else {}).get("day"))
        c = _f(day[0].get("close")) if day else None
        if c is None and ex == now.date().isoformat():
            c = _quote_last(api, S["sym"])
        if c is not None:
            closes[ex] = c
    with LOCK:
        d = _load()
        for e in d["ent"]:
            if e["est"] == key and not e.get("done") and e["exp"] in closes and \
                    any(p["fecha"] == e["fecha"] and p["var"] == e["var"] for p in pend):
                e["settle"] = {"px": closes[e["exp"]], "valor": round(settle_value(e, closes[e["exp"]]), 2)}
                e["done"] = True
        _save(d)


def loop(get_env):
    last = {k: 0.0 for k in STRATS}
    while True:
        try:
            now = datetime.now(ET)
            tok = (get_env() or {}).get("TRADIER_LIVE_TOKEN")
            if tok and now.weekday() < 5:
                api = tb.Tradier(tok, "", "live", True)   # dry=True: nunca envia ordenes
                for key, S in STRATS.items():
                    try:
                        a, b = S["entry"]
                        if now.weekday() in S["days"] and a <= now.time() <= b:
                            enter(api, key, now)
                        if dtime(9, 30) <= now.time() <= dtime(16, 2) and time.time() - last[key] >= S["poll"] - 5:
                            last[key] = time.time()
                            poll(api, key, now)
                        if now.time() >= dtime(16, 10) or now.time() <= dtime(9, 0):
                            settle(api, key, now)
                        STATE["err"] = None
                    except Exception as ex:  # nunca tumbar el panel
                        STATE["err"] = f"{key}: {ex.__class__.__name__}"
        except Exception:
            pass
        time.sleep(30)


# ───────────── resultados ─────────────
def _px(s, frac):
    if frac is None:
        return s["mid"]
    if s.get("nat") is None:
        return None
    return s["mid"] + frac * (s["nat"] - s["mid"])


def _entry(e, frac):
    return e["credit"] if frac is None else e["credit"] - frac * (e["credit"] - e["credit_nat"])


def result(e, rule, frac=None):
    """Dolares por posicion (1 contrato por pata). frac=None: a precio medio; frac 0-1: cediendo esa parte hacia el natural."""
    cr0, cr = e["credit"], _entry(e, frac)
    smp = e["samples"]
    if e["est"] == "spx_0dte":
        if rule.startswith("c") and rule[1:].isdigit():
            hm = rule[1:3] + ":" + rule[3:]
            c = [s for s in smp if s["t"][11:] >= hm]
            if not c or not e.get("done"):
                return None
            v = _px(c[0], frac)
            return None if v is None else round((cr - v) * 100)
        if rule in ("tp25_s2", "tp50_s2"):
            tp = 0.25 if rule == "tp25_s2" else 0.5
            for s in smp:
                if s["t"][11:] > "15:50":
                    break
                if s["mid"] <= cr0 * (1 - tp) or s["mid"] >= cr0 * 3:
                    v = _px(s, frac)
                    return None if v is None else round((cr - v) * 100)
            return result(e, "c1550", frac)
    else:
        if rule.endswith("_dia"):
            smp = [s for s in smp if s["t"][:10] < e["exp"]]
        for s in smp:
            if "tp50" in rule and s["mid"] <= cr0 * 0.5 or "stop2" in rule and s["mid"] >= cr0 * 3:
                v = _px(s, frac)
                return None if v is None else round((cr - v) * 100)
        if rule.endswith("_dia") and e.get("done"):
            days = sorted({s["t"][:10] for s in e["samples"] if s["t"][:10] < e["exp"]})
            c = [s for s in e["samples"] if days and s["t"][:10] == days[-1] and s["t"][11:] >= "15:30"]
            if c:
                v = _px(c[-1], frac)
                return None if v is None else round((cr - v) * 100)
    if not e.get("done") or not e.get("settle"):
        return None
    return round((cr - e["settle"]["valor"]) * 100)


def _frac():
    try:
        import condor_noche
        sl = condor_noche.slippage()
        return sl["frac"] if sl["n"] >= 3 else condor_noche.SLIP_DEFAULT
    except Exception:  # noqa: BLE001
        return 0.5


def summary():
    ents = _load()["ent"]
    frac = _frac()
    out = {"frac": frac, "err": STATE["err"], "est": {}}
    for key, S in STRATS.items():
        rules = RULES_0DTE if key == "spx_0dte" else WEEKLY_RULES
        es_all = [e for e in ents if e["est"] == key]
        tabla = []
        for v in S["variants"]:
            es = [e for e in es_all if e["var"] == v["id"]]
            cr = [e["credit"] for e in es]
            for rk, nom in rules:
                vals = [x for x in (result(e, rk) for e in es) if x is not None]
                comm = S["comm"] / 2 if rk == "vence" else S["comm"]   # si vence, no hay comision de cierre
                real = [x - comm for x in (result(e, rk, frac) for e in es) if x is not None]
                tabla.append({"var": v["id"], "label": v["label"], "regla": rk, "nombre": nom, "n": len(vals),
                              "abiertos": sum(1 for e in es if not e.get("done")),
                              "credito": round(sum(cr) / len(cr) * 100) if cr else None,
                              "avg": round(sum(vals) / len(vals)) if vals else None,
                              "avg_real": round(sum(real) / len(real)) if real else None,
                              "win_real": round(100 * sum(1 for x in real if x > 0) / len(real)) if real else None,
                              "peor": min(real) if real else None, "total_real": round(sum(real)) if real else None})
        best = {}
        for v in S["variants"]:
            rows = [r for r in tabla if r["var"] == v["id"] and r["avg_real"] is not None]
            if rows:
                b = max(rows, key=lambda r: r["avg_real"])
                best[v["id"]] = {"regla": b["nombre"], "avg_real": b["avg_real"]}
        lista = []
        for e in es_all[::-1][:12]:
            last = e["samples"][-1] if e["samples"] else None
            lista.append({"fecha": e["fecha"], "hora": e["hora"], "var": e["var"], "exp": e["exp"],
                          "put": f'{e["kp"]:g}/{e["kpl"]:g}', "call": f'{e["kc"]:g}/{e["kcl"]:g}' if "kc" in e else None,
                          "credito": round(e["credit"] * 100), "credito_nat": round(e["credit_nat"] * 100), "spot": e["spot"],
                          "done": bool(e.get("done")),
                          "pnl": (result(e, "vence") if e.get("done") else (round((e["credit"] - last["mid"]) * 100) if last else None))})
        out["est"][key] = {"name": S["name"], "desc": S["desc"], "variants": S["variants"], "tabla": tabla, "best": best,
                           "lista": lista, "n": len(es_all), "terminados": sum(1 for e in es_all if e.get("done")),
                           "dias": len({e["fecha"] for e in es_all}), "comm": S["comm"],
                           "last": STATE["last"].get(key), "msg": STATE["msg"].get(key)}
    return out
