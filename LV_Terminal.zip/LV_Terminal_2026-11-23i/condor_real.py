"""
IRON CONDOR REAL AUTOMATICO (cuenta REAL de Tradier). Luis lo activa escribiendo ROBOT REAL.
- Lunes y martes, de 10:00 a 10:45 ET, abre UN iron condor por dia en SPX (opciones SPXW) que vence el viernes de esa semana.
- Ventas en delta 0.10 (calculada con el precio del momento), alas de 10 puntos, 1 contrato.
- Orden LIMITE de credito al precio medio; si no se llena en 4 min baja 0.05 (maximo 3 intentos, nunca por debajo del natural).
- El gestor la vigila: objetivo 50% del credito (orden limite), stop si pierde 2 veces el credito (cerrar cuesta 3x),
  y el viernes a las 15:30 cierra lo que quede.
- Nunca encima: ninguna pata nueva usa un strike que ya tengas abierto en ese vencimiento; si choca, ese lado se
  mueve hacia afuera (mas lejos del precio).
- Si algo no cuadra (sin claves, sin strikes validos, Tradier rechaza), NO envia nada ese dia y avisa.
"""
import json
import math
import os
import threading
import time
from datetime import datetime, time as dtime

import condor as cw
import mkt_cal
import gestor
import tradier_bot as tb

ET = cw.ET
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "condor_real.json")
ACCT = True      # True = tu cuenta real · "H" = la cuenta 2 (otra copia de este robot, con su archivo y su activacion)
TAG = "🔴 REAL"
LOCK = threading.RLock()
SYM, DELTA, QTY = "SPX", 0.10, 1
DAYS = (0, 1)                                   # lunes y martes
ENTRY_FROM, ENTRY_TO, GIVE_UP = dtime(10, 0), dtime(10, 30), dtime(10, 45)
REPRICE_SEC, MAX_TRIES, TICK = 240, 3, 0.05
CFG = {"unit": "pct", "tp_pct": 50, "stop_pct": 200, "at_target": "close", "trail_on": False, "partial_on": False,
       "time_on": True, "time_exit": "15:30"}
STATE = {"err": None, "msg": None}


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    d.setdefault("log", [])
    d["log"] = d["log"][-200:]
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _log(d, txt):
    d.setdefault("log", []).append([datetime.now(ET).strftime("%Y-%m-%d %H:%M:%S"), txt])


def _round_down(x):
    return round(math.floor(x / TICK + 1e-9) * TICK, 2)


def _order_data(p, price):
    data = {"class": "multileg", "symbol": SYM, "type": "credit", "duration": "day", "price": f"{price:.2f}"}
    legs = [(p["occ"]["sp"], "sell_to_open"), (p["occ"]["lp"], "buy_to_open"),
            (p["occ"]["sc"], "sell_to_open"), (p["occ"]["lc"], "buy_to_open")]
    for i, (o, s) in enumerate(legs):
        data[f"option_symbol[{i}]"], data[f"side[{i}]"], data[f"quantity[{i}]"] = o, s, str(QTY)
    return data, [{"occ": o, "side": s} for o, s in legs]


def _send(env, d, day, price, notices):
    """Vista previa + envio de la orden de credito; la registra en el gestor con las reglas del condor."""
    p = day["plan"]
    data, legs = _order_data(p, price)
    pv = gestor._api(env, ACCT, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
    po = pv.get("order") or {}
    if po.get("result") is False or po.get("status") in ("rejected", "error"):
        raise gestor.GestorError("Tradier no acepta la orden en la vista previa: " + str(po.get("status") or po)[:150])
    j = gestor._api(env, ACCT, "POST", "/accounts/{acct}/orders", data=data)
    o = j.get("order") or {}
    oid = str(o.get("id") or "")
    if not oid:
        raise gestor.GestorError("Tradier no devolvió número de orden: " + str(j)[:150])
    watch, cfg = gestor.prepare("credit", True, CFG)
    cfg["auto"] = True   # el condor del ROBOT siempre lo vigila el gestor (stop 200%, objetivo 50%), aunque tu gestor manual este apagado
    gestor.on_spread_entry(o, legs, QTY, ACCT, "credit", cfg, SYM)
    day.update(status="enviada", order=oid, price=price, tries=day.get("tries", 0) + 1, sent_ts=time.time())
    _log(d, f"orden #{oid} enviada: crédito límite ${price:.2f} (intento {day['tries']})")
    if day["tries"] == 1:
        notices.append((TAG + " · Iron condor automático enviado",
                        f"SPX {p['kpl']:g}/{p['kp']:g}P · {p['kc']:g}/{p['kcl']:g}C vence {day['exp']} · crédito límite ${price:.2f} "
                        f"(medio ${p['credit']:.2f}, natural ${p['credit_nat']:.2f}). El gestor lo vigila: objetivo 50%, stop 2× el crédito."))


def open_strikes(env, exp):
    """Strikes de SPX/SPXW ya abiertos en la cuenta REAL para ese vencimiento (para no encimar condors)."""
    j = gestor._api(env, ACCT, "GET", "/accounts/{acct}/positions")
    pos = tb.as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    tag = exp[2:4] + exp[5:7] + exp[8:10]
    out = {"put": set(), "call": set()}
    for p in pos:
        s = str(p.get("symbol") or "")
        if not s.startswith("SPX") or len(s) < 15 or not float(p.get("quantity") or 0):
            continue
        body = s[-15:]                       # AAMMDD + P/C + strike*1000 (8 digitos)
        if body[:6] != tag:
            continue
        out["put" if body[6] == "P" else "call"].add(int(body[7:]) / 1000)
    return out


def trading_creds(env):
    import trading
    return trading.creds(env, ACCT)


def step(env, now, notices):
    """Una pasada. Devuelve nada; deja avisos en 'notices'."""
    with LOCK:
        d = _load()
        if not d.get("activo"):
            return
        today = now.date().isoformat()
        day = d.setdefault("dias", {}).get(today)
        if now.weekday() not in DAYS or mkt_cal.cerrado(now):
            return
        if not all(trading_creds(env)[1:]):
            STATE["msg"] = "Faltan las claves de la cuenta REAL en ~/.tradier_env"
            return
        api = tb.Tradier(env.get("TRADIER_LIVE_TOKEN") or trading_creds(env)[1], "", "live", True)   # solo consultas de precios (dry=True); las ordenes van por gestor._api a la cuenta ACCT
        try:
            if day is not None and day.get("status") in ("sin_entrada", "error") and day.get("retry") and now.time() <= ENTRY_TO:
                if time.time() - day.get("ts_try", 0) < 55:
                    return
                day = None   # Tradier fallo al buscar strikes: vuelve a intentar (cada minuto hasta las 10:30)
                d["dias"].pop(today, None)
            if day is None:
                if not (ENTRY_FROM <= now.time() <= ENTRY_TO):
                    return
                day = d["dias"][today] = {"status": "armando"}
                exp = cw.friday_exp(api, now.date())
                spot = cw._spot(api)
                if not exp or not spot:
                    day.update(status="sin_entrada", motivo="sin vencimiento del viernes o sin precio del SPX")
                    _log(d, "no entré: " + day["motivo"])
                    notices.append((TAG + " · Iron condor automático", "Hoy no entré: " + day["motivo"]))
                    return
                busy = open_strikes(env, exp)
                p = cw.pick(cw._weekly(api.chain(SYM, exp)), spot, DELTA, cw.years_to(exp, now), avoid=busy)
                if not p or p["credit"] < 0.20:
                    day.update(status="sin_entrada", retry=True, ts_try=time.time(), motivo=("no encontré strikes libres (sin encimar con el condor ya abierto) con crédito suficiente"
                                                             if busy["put"] or busy["call"] else "la cadena no tenía strikes válidos para delta 0.10 y alas de 10"))
                    _log(d, "no entré: " + day["motivo"])
                    notices.append((TAG + " · Iron condor automático", "Hoy no entré: " + day["motivo"]))
                    return
                day.update(exp=exp, spot=spot, plan=p)
                if p.get("movido"):
                    _log(d, "para no encimar con el condor abierto moví hacia afuera el lado " + " y ".join(p["movido"]) +
                         f" (delta put {p['dp']}, call {p['dc']})")
                _send(env, d, day, _round_down(p["credit"]), notices)
                return
            if day.get("status") != "enviada":
                return
            o = gestor._order(env, ACCT, day["order"])
            st = o.get("status")
            if st == "filled":
                day["status"] = "abierta"
                px = gestor._fill_px(o) or day["price"]
                _log(d, f"orden #{day['order']} LLENADA a ${px:.2f}; el gestor la vigila")
                notices.append((TAG + " · Iron condor abierto", f"Se llenó a ${px:.2f} (crédito ${px * 100:.0f}). El gestor lo vigila."))
            elif st in ("rejected", "error", "expired"):
                day.update(status="rechazada", motivo=f"Tradier: {st}")
                _log(d, f"orden #{day['order']} terminó como {st}; no reintento hoy")
                notices.append(("⚠️ " + TAG + " · Iron condor automático", f"La orden terminó como {st}. Hoy no se abre nada."))
            elif st == "canceled":
                if day.get("cancel_reprice"):
                    day.pop("cancel_reprice")
                    _send(env, d, day, day["next_price"], notices)
                else:
                    day.update(status="cancelada", motivo="cancelada fuera del panel")
                    _log(d, "la orden se canceló fuera del panel; no reintento hoy")
            elif st in ("open", "pending", "partially_filled") and time.time() - day.get("sent_ts", 0) >= REPRICE_SEC:
                nat = day["plan"]["credit_nat"]
                nxt = round(day["price"] - TICK, 2)
                if now.time() >= GIVE_UP or day.get("tries", 0) >= MAX_TRIES or nxt < max(0.20, nat):
                    gestor._api(env, ACCT, "DELETE", "/accounts/{acct}/orders/" + day["order"])
                    day.update(status="sin_llenar", motivo="no se llenó a un precio razonable")
                    _log(d, f"orden #{day['order']} sin llenar tras {day.get('tries')} intento(s): la cancelo; hoy no se abre")
                    notices.append((TAG + " · Iron condor automático", "No se llenó a un precio razonable; cancelé la orden. Hoy no se abre nada."))
                else:
                    gestor._api(env, ACCT, "DELETE", "/accounts/{acct}/orders/" + day["order"])
                    day.update(cancel_reprice=True, next_price=nxt)
                    _log(d, f"orden #{day['order']} sin llenar en {REPRICE_SEC // 60} min: la cancelo y vuelvo a mandar a ${nxt:.2f}")
            STATE["err"] = None
        except (gestor.GestorError, Exception) as e:   # nunca tumbar el panel
            if day is not None and day.get("status") in ("armando",):
                day.update(status="error", retry=True, ts_try=time.time(), motivo=str(e)[:160])
                notices.append(("⚠️ " + TAG + " · Iron condor automático", "Hoy no entré: " + str(e)[:160]))
            _log(d, "error: " + str(e)[:160])
            STATE["err"] = str(e)[:160]
        finally:
            _save(d)


def loop(get_env, send_notice):
    global TAG
    while True:
        try:
            if ACCT == "H":
                TAG = "🟣 " + ((get_env() or {}).get("TRADIER_H_NAME") or "Cuenta 2").upper()
            notices = []
            step(get_env() or {}, datetime.now(ET), notices)
            with LOCK:   # anota el final de cada condor mientras el gestor todavia lo recuerda
                d = _load()
                if _sync_closed(d):
                    _save(d)
            for t, x in notices:
                send_notice(t, x)
        except Exception:
            pass
        time.sleep(30)


def _sync_closed(d):
    """Los dias 'abierta' toman su final del gestor (que es quien la cierra): cerrada, P&L y por que."""
    ch = False
    with gestor.LOCK:
        items = {str(i.get("id")): i for i in gestor.S.get("items", [])}
    for v in (d.get("dias") or {}).values():
        if v.get("status") != "abierta" or not v.get("order"):
            continue
        it = items.get(str(v["order"]))
        if not it and v.get("exp") and v["exp"] < datetime.now(ET).date().isoformat():
            v.update(status="terminada", salida="ya venció (el gestor ya no la tiene en su lista)")   # el gestor olvida las cerradas a los 3 dias
            _log(d, f"orden #{v['order']}: terminada (vencida)")
            ch = True
            continue
        if it and it.get("status") in ("cerrada", "liberada", "cancelada"):
            v["status"] = "cerrada" if it["status"] == "cerrada" else ("soltada del gestor" if it["status"] == "liberada" else "cancelada")
            v["pnl"] = it.get("realized")
            v["salida"] = it.get("close_reason") or it["status"]
            _log(d, f"orden #{v['order']}: {v['status']} ({v['salida']}) · P&L {v['pnl'] if v['pnl'] is not None else '–'}")
            ch = True
    return ch


def handle(method, body):
    """GET: estado. POST {activo: true, confirm: 'ROBOT REAL'} para activar; {activo: false} para apagar."""
    with LOCK:
        d = _load()
        if method == "POST":
            if body.get("activo"):
                if (body.get("confirm") or "").strip() != "ROBOT REAL":
                    return {"error": "Para activarlo escribe exactamente ROBOT REAL"}
                d.update(activo=True, activado=datetime.now(ET).strftime("%Y-%m-%d %H:%M"))
                _log(d, "ACTIVADO en cuenta REAL")
            else:
                d["activo"] = False
                _log(d, "apagado")
            _save(d)
        if _sync_closed(d):
            _save(d)
        dias = sorted((d.get("dias") or {}).items(), reverse=True)[:10]
        return {"activo": bool(d.get("activo")), "activado": d.get("activado"), "err": STATE["err"], "msg": STATE["msg"],
                "reglas": "Lun y mar 10:00 ET · SPX delta 0.10 · alas 10 · 1 contrato · vence el viernes · objetivo 50% · stop 2× crédito · viernes 15:30",
                "dias": [{"fecha": k, "status": v.get("status"), "motivo": v.get("motivo"), "exp": v.get("exp"), "order": v.get("order"),
                          "price": v.get("price"), "tries": v.get("tries"), "pnl": v.get("pnl"), "salida": v.get("salida"),
                          "strikes": (f"{v['plan']['kpl']:g}/{v['plan']['kp']:g}P · {v['plan']['kc']:g}/{v['plan']['kcl']:g}C" if v.get("plan") else None)}
                         for k, v in dias],
                "log": (d.get("log") or [])[-15:][::-1]}
