#!/bin/zsh
# Instalacion unica: guarda tu token en un archivo privado y deja el panel arrancando solo al encender la Mac.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
case "$DIR" in
  "$HOME/Desktop"*|"$HOME/Documents"*|"$HOME/Downloads"*)
    echo "macOS bloquea los servicios automaticos en Escritorio/Documentos/Descargas."
    echo "Mueve la carpeta con este comando y vuelve a ejecutar instalar.sh desde ahi:"
    echo "  mv \"$DIR\" \"$HOME/bot\""
    exit 1;;
esac

PY="$(command -v python3)"
ENVF="$HOME/.tradier_env"
if [ ! -f "$ENVF" ]; then
  echo "Pega tu TRADIER_TOKEN de SANDBOX y presiona Enter (no se vera al escribir):"
  read -s TOKEN; echo
  echo "Escribe tu TRADIER_ACCOUNT_ID y presiona Enter:"
  read ACC
  ( umask 077
    printf 'export TRADIER_TOKEN="%s"\nexport TRADIER_ACCOUNT_ID="%s"\nexport TRADIER_ENV=sandbox\nexport DRY_RUN=1\n' "$TOKEN" "$ACC" > "$ENVF" )
  chmod 600 "$ENVF"
  echo "Guardado en $ENVF (solo tu usuario puede leerlo)."
else
  echo "Ya existe $ENVF; no lo toco."
fi

PLIST="$HOME/Library/LaunchAgents/com.luis.tradierpanel.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.luis.tradierpanel</string>
  <key>ProgramArguments</key><array><string>$PY</string><string>$DIR/monitor_web.py</string></array>
  <key>WorkingDirectory</key><string>$DIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$DIR/panel.log</string>
  <key>StandardErrorPath</key><string>$DIR/panel.log</string>
</dict>
</plist>
PL

launchctl bootout "gui/$(id -u)/com.luis.tradierpanel" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo
echo "Listo. Abre en Safari: http://localhost:8765"
echo "Desde ahora el panel arranca solo al iniciar sesion y el bot arranca solo de lunes a viernes a las 9:35 (NY)."
echo "Opcional, para que la Mac se despierte sola:  sudo pmset repeat wakeorpoweron MTWRF 09:55:00"
