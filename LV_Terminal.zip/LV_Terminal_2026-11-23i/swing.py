"""Escaner de SWING en ACCIONES (compra de acciones, no opciones).
Cada dia despues del cierre busca 4 patrones en velas diarias y propone entrada, stop y objetivo (2 a 1).
- Prueba hacia atras: cada patron se simula en los ultimos ~2 anos con las MISMAS reglas (entra a la apertura del dia
  siguiente; sale en el stop, en el objetivo o a los 20 dias de bolsa). Resultados en R: 1R = lo que arriesgas.
- Modo sombra: las señales nuevas se congelan el dia que salen y se miden con los dias que van llegando (sin dinero).
- NUNCA manda ordenes. Solo lee precios (token real si existe; si no, el del sandbox).
Ojo: la lista de acciones es la de HOY (empresas que sobrevivieron y crecieron), asi que la prueba hacia atras tiende a
verse mejor que la realidad. Por eso cuenta mas el modo sombra."""
import json
import os
import threading
import time
from datetime import datetime, timedelta, time as dtime
from zoneinfo import ZoneInfo

import escaner

ET = ZoneInfo("America/New_York")
BASE = os.path.dirname(os.path.abspath(__file__))
F_BARS = os.path.join(BASE, "swing_bars.json")
F_RES = os.path.join(BASE, "swing_res.json")
F_SOMBRA = os.path.join(BASE, "swing_sombra.json")
LOCK = threading.RLock()
STATE = {"busy": False, "prog": "", "err": ""}

RR = 2.0          # objetivo = 2 veces el riesgo
MAX_DAYS = 20     # salida por tiempo (dias de bolsa)
GAP = 10          # no repetir la misma señal del mismo simbolo en menos de 10 dias
PATTERNS = {
    "ruptura": {"name": "Ruptura con volumen", "desc": "Tendencia alcista, semanas de lado en un rango apretado y hoy rompe el máximo de 20 días con 1.5× el volumen normal."},
    "retroceso": {"name": "Retroceso a la media", "desc": "Acción fuerte en tendencia que bajó a su media de 20 días y hoy rebota (cierra arriba del máximo de ayer)."},
    "gap": {"name": "Gap con volumen (noticia / earnings)", "desc": "Abrió 4% o más arriba del cierre de ayer con el doble de volumen y aguantó (cerró arriba de su apertura)."},
    "maximo": {"name": "Máximo de 52 semanas + fuerza relativa", "desc": "Entre el 10% de acciones más fuertes de la lista y hoy cierra en máximo de un año por primera vez en 20 días."},
}


def _load(p, d):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return d


def _save(p, obj):
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, p)


# ───────────── datos ─────────────
def fetch_bars(api, sym, days=760):
    end = datetime.now(ET).date()
    j = api.get("/markets/history", {"symbol": sym, "interval": "daily",
                                     "start": (end - timedelta(days=days)).isoformat(), "end": end.isoformat()})
    h = j.get("history") if isinstance(j.get("history"), dict) else {}
    out = []
    for d in escaner._as_list((h or {}).get("day")):
        o, hi, lo, c, v = (escaner._n(d.get(k)) for k in ("open", "high", "low", "close", "volume"))
        if None in (o, hi, lo, c) or c <= 0:
            continue
        out.append([d.get("date"), o, hi, lo, c, v or 0.0])
    out.sort(key=lambda x: x[0])
    return out


# ───────────── indicadores ─────────────
def atr(b, n=14):
    out, prev, run = [None] * len(b), None, []
    for i, (_, o, h, l, c, v) in enumerate(b):
        tr = h - l if prev is None else max(h - l, abs(h - prev), abs(l - prev))
        run.append(tr)
        prev = c
        if i == n - 1:
            out[i] = sum(run[:n]) / n
        elif i >= n:
            out[i] = (out[i - 1] * (n - 1) + tr) / n
    return out


def indicators(b):
    c = [x[4] for x in b]
    v = [x[5] for x in b]
    return {"c": c, "ema20": escaner.ema(c, 20), "sma50": escaner.sma(c, 50), "sma200": escaner.sma(c, 200),
            "vol50": escaner.sma(v, 50), "atr": atr(b), "rsi": escaner.rsi(c)}


def rs_score(c, i):
    if i < 126:
        return None
    return 0.4 * (c[i] / c[i - 63] - 1) + 0.6 * (c[i] / c[i - 126] - 1)


def rs_ranks(data):
    """{fecha: {sym: percentil 0-100}} de fuerza relativa (3 y 6 meses) dentro de la lista."""
    by = {}
    for sym, (b, ind) in data.items():
        for i in range(len(b)):
            s = rs_score(ind["c"], i)
            if s is not None:
                by.setdefault(b[i][0], []).append((s, sym))
    out = {}
    for d, lst in by.items():
        lst.sort()
        n = len(lst)
        out[d] = {sym: (k / (n - 1) * 100 if n > 1 else 50.0) for k, (s, sym) in enumerate(lst)}
    return out


def _clamp_stop(c, a, stop):
    return min(max(stop, c - 2.5 * a), c - 0.5 * a)


def detect(b, ind, i, rank):
    """Patrones que salen al cierre del dia i -> lista de (patron, stop)."""
    if i < 200 or ind["atr"][i] is None or ind["sma200"][i] is None or ind["vol50"][i] in (None, 0):
        return []
    d, o, h, l, c, v = b[i]
    a, s50, s200, e20 = ind["atr"][i], ind["sma50"][i], ind["sma200"][i], ind["ema20"][i]
    trend = c > s50 > s200
    out = []
    hi20 = max(x[2] for x in b[i - 20:i])
    lo20 = min(x[3] for x in b[i - 20:i])
    if trend and rank is not None and rank >= 70 and c > hi20 and v >= 1.5 * ind["vol50"][i] and (hi20 - lo20) / c <= 0.12:
        out.append(("ruptura", _clamp_stop(c, a, min(l, c - a))))
    rs = ind["rsi"][i]
    recent_high = max(ind["c"][i - 10:i]) >= max(ind["c"][i - 30:i - 10] or [0])
    if trend and rank is not None and rank >= 60 and recent_high and min(x[3] for x in b[i - 2:i + 1]) <= e20 * 1.01 \
            and c >= s50 and rs is not None and 35 <= rs <= 60 and c > b[i - 1][2]:
        out.append(("retroceso", _clamp_stop(c, a, min(x[3] for x in b[i - 3:i + 1]) - 0.25 * a)))
    if o >= b[i - 1][4] * 1.04 and v >= 2 * ind["vol50"][i] and c >= o and c > s50:
        out.append(("gap", _clamp_stop(c, a, l - 0.25 * a)))
    hi252 = max(x[4] for x in b[max(0, i - 252):i])
    prev_new = any(b[k][4] >= max(x[4] for x in b[max(0, k - 252):k]) for k in range(i - 20, i))
    if trend and rank is not None and rank >= 90 and c >= hi252 and not prev_new:
        out.append(("maximo", _clamp_stop(c, a, c - 2 * a)))
    return out


def simulate(b, i, stop):
    """Entra a la apertura del dia i+1. -> dict con resultado en R (o abierto si faltan dias)."""
    if i + 1 >= len(b):
        return {"status": "pendiente"}
    entry = b[i + 1][1]
    if entry <= stop:
        return {"status": "saltada", "why": "abrió abajo del stop"}
    risk = entry - stop
    target = entry + RR * risk
    for k in range(i + 1, min(len(b), i + 1 + MAX_DAYS)):
        _, o, h, l, c, v = b[k]
        if k > i + 1 and o <= stop:
            return {"status": "stop", "r": round((o - entry) / risk, 2), "entry": entry, "exit": o, "days": k - i, "d_out": b[k][0]}
        if l <= stop:   # si el mismo dia toca stop y objetivo, se cuenta el stop (conservador)
            return {"status": "stop", "r": -1.0, "entry": entry, "exit": stop, "days": k - i, "d_out": b[k][0]}
        if k > i + 1 and o >= target:
            return {"status": "objetivo", "r": round((o - entry) / risk, 2), "entry": entry, "exit": o, "days": k - i, "d_out": b[k][0]}
        if h >= target:
            return {"status": "objetivo", "r": RR, "entry": entry, "exit": target, "days": k - i, "d_out": b[k][0]}
    if i + MAX_DAYS < len(b):
        k = i + MAX_DAYS
        return {"status": "tiempo", "r": round((b[k][4] - entry) / risk, 2), "entry": entry, "exit": b[k][4], "days": MAX_DAYS, "d_out": b[k][0]}
    last = b[-1][4]
    return {"status": "abierta", "r_now": round((last - entry) / risk, 2), "entry": entry, "days": len(b) - 1 - i}


def stats(results):
    done = [r for r in results if "r" in r]
    if not done:
        return {"n": 0, "open": len([r for r in results if r.get("status") == "abierta"])}
    rs = [r["r"] for r in done]
    wins = [x for x in rs if x > 0]
    loss = [x for x in rs if x <= 0]
    streak = mx = 0
    for x in rs:
        streak = streak + 1 if x <= 0 else 0
        mx = max(mx, streak)
    return {"n": len(done), "win": round(len(wins) / len(done) * 100), "avg_r": round(sum(rs) / len(done), 2),
            "total_r": round(sum(rs), 1), "pf": round(sum(wins) / -sum(loss), 2) if loss and sum(loss) < 0 else None,
            "days": round(sum(r["days"] for r in done) / len(done), 1), "streak": mx,
            "open": len([r for r in results if r.get("status") == "abierta"])}


def run_all(data, ranks, spy=None):
    """Recorre toda la historia: señales con su resultado. -> lista de dicts ordenada por fecha."""
    sigs = []
    spy_ok = {}
    if spy:
        b, ind = spy
        spy_ok = {b[i][0]: ind["sma50"][i] is not None and b[i][4] > ind["sma50"][i] for i in range(len(b))}
    for sym, (b, ind) in data.items():
        last = {}
        for i in range(200, len(b)):
            d = b[i][0]
            for pat, stop in detect(b, ind, i, ranks.get(d, {}).get(sym)):
                if i - last.get(pat, -999) < GAP:
                    continue
                last[pat] = i
                res = simulate(b, i, stop)
                c, a = b[i][4], ind["atr"][i]
                sigs.append(dict(res, sym=sym, pat=pat, d=d, close=round(c, 2), stop=round(stop, 2),
                                 target=round(c + RR * (c - stop), 2), atr_pct=round(a / c * 100, 1),
                                 rank=round(ranks.get(d, {}).get(sym) or 0), mkt=spy_ok.get(d)))
    sigs.sort(key=lambda s: (s["d"], s["sym"]))
    return sigs


def summarize(sigs, since=None):
    out = {}
    for pat in PATTERNS:
        lst = [s for s in sigs if s["pat"] == pat and (since is None or s["d"] >= since)]
        out[pat] = dict(stats(lst), mkt_up=stats([s for s in lst if s.get("mkt")]), mkt_down=stats([s for s in lst if s.get("mkt") is False]))
    return out


# ───────────── escaneo diario ─────────────
def scan(env):
    with LOCK:
        if STATE["busy"]:
            return
        STATE.update(busy=True, err="", prog="Empezando…")
    try:
        api = escaner.Api(env)
        syms = escaner.get_list()
        if "SPY" not in syms:
            syms = ["SPY"] + syms
        bars = {}
        for k, s in enumerate(syms):
            STATE["prog"] = f"Descargando velas {k + 1}/{len(syms)}: {s}"
            try:
                b = fetch_bars(api, s)
                if len(b) >= 260:
                    bars[s] = b
            except Exception:  # noqa: BLE001 - un simbolo malo no tumba el escaneo
                pass
            time.sleep(0.25)
        if len(bars) < 10:
            raise RuntimeError("No pude descargar suficientes velas (revisa la conexión con Tradier)")
        STATE["prog"] = "Calculando patrones y prueba hacia atrás…"
        data = {s: (b, indicators(b)) for s, b in bars.items()}
        ranks = rs_ranks(data)
        sigs = run_all(data, ranks, data.get("SPY"))
        last_d = max(b[-1][0] for b in bars.values())
        today_sigs = [s for s in sigs if s["d"] == last_d]
        for s in today_sigs:
            try:
                s["earn"] = escaner.earnings_date(s["sym"])
            except Exception:  # noqa: BLE001
                s["earn"] = None
        sombra = update_sombra(today_sigs, data)
        first = min((x["d"] for x in sombra["sigs"]), default=last_d)
        res = {"fecha": last_d, "hecho": datetime.now(ET).strftime("%Y-%m-%d %H:%M"), "n_syms": len(bars),
               "hoy": today_sigs, "bt": summarize(sigs), "bt_desde": min(s["d"] for s in sigs) if sigs else None,
               "recientes": [s for s in sigs if s["d"] >= (datetime.fromisoformat(last_d) - timedelta(days=45)).date().isoformat()][-80:],
               "sombra": summarize(sombra["sigs"]), "sombra_desde": first, "sombra_sigs": sombra["sigs"][-60:]}
        _save(F_RES, res)
        STATE["prog"] = f"Listo: {len(today_sigs)} señales hoy · {len(sigs)} en la prueba hacia atrás"
    except Exception as e:  # noqa: BLE001
        STATE["err"] = str(e)[:200]
        STATE["prog"] = ""
    finally:
        STATE["busy"] = False


def update_sombra(today_sigs, data):
    """Congela las señales nuevas y vuelve a medir todas con las velas que han llegado."""
    sh = _load(F_SOMBRA, {"sigs": []})
    have = {(s["d"], s["sym"], s["pat"]) for s in sh["sigs"]}
    for s in today_sigs:
        k = (s["d"], s["sym"], s["pat"])
        if k not in have:
            sh["sigs"].append({kk: s[kk] for kk in ("d", "sym", "pat", "close", "stop", "target", "rank", "atr_pct", "mkt") if kk in s})
    for s in sh["sigs"]:
        b = (data.get(s["sym"]) or (None,))[0]
        if not b:
            continue
        idx = next((i for i, x in enumerate(b) if x[0] == s["d"]), None)
        if idx is not None:
            for k in ("status", "r", "r_now", "entry", "exit", "days", "d_out", "why"):
                s.pop(k, None)
            s.update(simulate(b, idx, s["stop"]))
    _save(F_SOMBRA, sh)
    return sh


def loop(get_env):
    """Hilo del panel: escaneo diario a las 16:55 ET (despues del escaner de spreads) o al arrancar si ya paso y falta."""
    time.sleep(60)
    while True:
        try:
            now = datetime.now(ET)
            env = get_env() or {}
            res = _load(F_RES, {})
            stale = res.get("hecho", "")[:10] != now.date().isoformat()
            after = now.weekday() < 5 and now.time() >= dtime(16, 55)
            if (env.get("TRADIER_LIVE_TOKEN") or env.get("TRADIER_TOKEN")) and not STATE["busy"] \
                    and not escaner.STATE.get("busy") and ((after and stale) or not res):
                scan(env)
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


def handle(method, path, body, env):
    if method == "GET":
        return 200, {"res": _load(F_RES, {}), "busy": STATE["busy"], "prog": STATE["prog"], "err": STATE["err"],
                     "patterns": PATTERNS, "rr": RR, "max_days": MAX_DAYS, "n_lista": len(escaner.get_list())}
    if path == "/api/swing_scan":
        if STATE["busy"]:
            return 200, {"error": "Ya hay un escaneo en curso"}
        threading.Thread(target=scan, args=(env,), daemon=True).start()
        return 200, {"ok": True}
    return 404, {"error": "No encontrado"}


PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Swing · LV Options Terminal</title>
<style>
:root{--bg:#000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:1700px;margin:0 auto;padding:16px 24px}.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 20px;margin-bottom:14px}
h1{font-size:20px;margin:0;letter-spacing:.06em;color:var(--ok)}a{color:var(--cy);text-decoration:none;font-weight:700}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.card.g{border-left-color:var(--ok)}.card.w{border-left-color:var(--warn)}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:8px}.tag{font-size:12px;color:var(--mut)}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 6px;white-space:nowrap}
td{padding:6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child,th.l,td.l{text-align:left}
.ok{color:var(--ok)}.bad{color:var(--bad)}.warn{color:var(--warn)}.mut{color:var(--mut)}
button{background:var(--card);color:var(--ok);border:1px solid var(--ok);border-radius:8px;padding:6px 12px;cursor:pointer;font-weight:700;font-size:13px}
input{background:#000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 8px;font-size:14px}
.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between}
.pill{display:inline-block;border:1px solid var(--line);border-radius:99px;padding:1px 8px;font-size:11px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px}
.pt{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:10px 12px;font-size:13px;line-height:1.45}
.pt b{color:var(--tx)}.sep{border-left:2px solid var(--line)}
</style></head><body><main>
<header><h1 class="mono">SWING · ACCIONES</h1>
 <div class="mono" style="font-size:13px"><a href="/">← Inicio</a> &nbsp; <a href="/portafolio">Portafolio →</a> &nbsp; <a href="/escaner">Escáner (spreads) →</a> &nbsp; <a href="/fundamentales">Fundamentales →</a></div></header>

<div class="card w"><div class="pt" style="border:0;background:none;padding:0">
 ⚠️ <b>Ningún patrón adivina el futuro.</b> Estos solo inclinan un poco las probabilidades; aun los buenos fallan seguido.
 Lo que decide si ganas es <b>arriesgar poco en cada operación</b> y respetar el stop. Esta página <b>no manda órdenes</b>:
 primero mide en el <b>modo sombra</b> qué patrón funciona antes de poner dinero.</div></div>

<div class="card g">
 <div class="row"><div class="lbl" style="margin:0">SEÑALES DEL ÚLTIMO CIERRE · <b id="fecha" style="color:var(--tx)"></b> <span class="tag" id="info"></span></div>
  <div class="row" style="justify-content:flex-end"><span class="tag">Arriesgo por operación $</span><input id="risk" type="number" min="1" step="10" style="width:100px">
   <button id="bscan" onclick="scanNow()">🔎 Escanear ahora</button></div></div>
 <div class="tag" id="prog" style="margin:6px 0"></div>
 <div style="overflow-x:auto"><table><thead><tr><th>Acción</th><th class="l">Patrón</th><th>Cierre</th><th>Stop</th><th>Objetivo (2:1)</th><th>Riesgo / acción</th><th>Acciones a comprar</th><th>Costo</th><th>Pierdes si toca stop</th><th>Ganas si llega</th><th>Fuerza rel.</th><th class="l">Earnings</th></tr></thead>
  <tbody id="hoy"><tr><td colspan="12" class="mut">Cargando…</td></tr></tbody></table></div>
 <div class="tag" style="margin-top:8px">Entrada: a la <b>apertura del día siguiente</b>. Si abre muy arriba del cierre, el riesgo crece (las acciones a comprar se calculan con el cierre). Si abre abajo del stop, la señal no vale. Salida: stop, objetivo o a los 20 días de bolsa (lo que llegue primero).</div>
</div>

<div class="card">
 <div class="lbl">RESULTADOS POR PATRÓN · <span class="tag">R = lo que arriesgas. +2R = ganaste el doble de lo arriesgado; −1R = tocó el stop. "Promedio R" arriba de 0 = el patrón gana con el tiempo.</span></div>
 <div style="overflow-x:auto"><table><thead>
  <tr><th></th><th colspan="7" class="l" style="color:var(--cy)">PRUEBA HACIA ATRÁS · <span id="btd"></span></th><th colspan="4" class="l sep" style="color:var(--ok)">MODO SOMBRA (de verdad, desde <span id="shd"></span>)</th></tr>
  <tr><th>Patrón</th><th>Ops</th><th>Gana %</th><th>Promedio R</th><th>Total R</th><th>Profit factor</th><th>Días prom.</th><th>Prom. R con SPY ↑ / ↓</th><th class="sep">Ops</th><th>Gana %</th><th>Promedio R</th><th>Abiertas</th></tr></thead>
  <tbody id="pats"></tbody></table></div>
 <div class="tag" style="margin-top:8px">Ojo: la prueba hacia atrás usa la lista de acciones de HOY (empresas que ya sabemos que crecieron), así que tiende a verse mejor que la realidad. Lo que vale de verdad es la columna del modo sombra, que se llena día a día. "SPY ↑" = días en que SPY estaba arriba de su media de 50.</div>
</div>

<div class="card"><div class="lbl">QUÉ BUSCA CADA PATRÓN</div><div class="grid" id="desc"></div></div>

<div class="card"><div class="lbl">MODO SOMBRA · SEÑALES REGISTRADAS</div>
 <div style="overflow-x:auto"><table><thead><tr><th>Fecha</th><th class="l">Acción</th><th class="l">Patrón</th><th>Entrada</th><th>Stop</th><th>Objetivo</th><th class="l">Estado</th><th>Resultado</th></tr></thead><tbody id="sh"></tbody></table></div></div>

<div class="card"><div class="lbl">SEÑALES DE LAS ÚLTIMAS SEMANAS (prueba hacia atrás)</div>
 <div style="overflow-x:auto"><table><thead><tr><th>Fecha</th><th class="l">Acción</th><th class="l">Patrón</th><th>Entrada</th><th>Stop</th><th>Objetivo</th><th class="l">Estado</th><th>Resultado</th></tr></thead><tbody id="rec"></tbody></table></div></div>
</main>
<script>
const $=id=>document.getElementById(id);const esc=x=>String(x==null?"":x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const usd=v=>v==null?"–":"$"+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const rr=v=>v==null?"–":(v>0?"+":"")+v.toFixed(2)+"R";const cls=v=>v>0?"ok":v<0?"bad":"";
let J=null,PN={};
try{$("risk").value=localStorage.getItem("sw_risk")||"100"}catch(e){$("risk").value="100"}
$("risk").oninput=()=>{try{localStorage.setItem("sw_risk",$("risk").value)}catch(e){}paintHoy()};
function dte(d){return Math.round((new Date(d+"T00:00:00")-new Date(new Date().toDateString()))/864e5)}
function paintHoy(){if(!J)return;const r=J.res||{},risk=Math.max(0,parseFloat($("risk").value)||0),L=r.hoy||[];
  $("hoy").innerHTML=L.length?L.map(s=>{const per=s.close-s.stop,n=per>0?Math.floor(risk/per):0,e=s.earn,soon=e&&dte(e)>=0&&dte(e)<=20;
   return '<tr><td><b>'+esc(s.sym)+'</b></td><td class="l">'+esc((PN[s.pat]||{}).name||s.pat)+'</td><td class="mono">'+s.close.toFixed(2)+'</td><td class="mono bad">'+s.stop.toFixed(2)+'</td><td class="mono ok">'+s.target.toFixed(2)+'</td><td class="mono">'+usd(per)+' <span class="tag">('+(per/s.close*100).toFixed(1)+'%)</span></td><td class="mono"><b>'+n+'</b></td><td class="mono">'+usd(n*s.close)+'</td><td class="mono bad">-'+usd(n*per)+'</td><td class="mono ok">+'+usd(n*per*2)+'</td><td class="mono">'+s.rank+'</td><td class="l'+(soon?" warn":"")+'">'+(e?(soon?"⚠ ":"")+e:'<span class="mut">sin dato</span>')+'</td></tr>'}).join("")
   :'<tr><td colspan="12" class="mut">'+(r.fecha?"Sin señales en el último cierre. Es normal: los buenos patrones no salen todos los días.":"Todavía no hay escaneo. Se hace solo a las 4:55 pm (NY) o toca Escanear ahora (tarda 1–3 minutos).")+'</td></tr>'}
function st(s){const m={objetivo:["✅ objetivo","ok"],stop:["❌ stop","bad"],tiempo:["⏱ 20 días",""],abierta:["⏳ abierta","warn"],pendiente:["⏳ entra mañana","warn"],saltada:["— saltada","mut"]}[s.status]||[s.status,""];
  return '<td class="l '+m[1]+'">'+m[0]+'</td><td class="mono '+cls(s.r!=null?s.r:s.r_now)+'">'+(s.r!=null?rr(s.r):s.r_now!=null?rr(s.r_now)+' <span class="tag">ahora</span>':"–")+'</td>'}
function sigRows(L){return L.slice().reverse().map(s=>'<tr><td class="mono">'+s.d+'</td><td class="l"><b>'+esc(s.sym)+'</b></td><td class="l">'+esc((PN[s.pat]||{}).name||s.pat)+'</td><td class="mono">'+(s.entry!=null?s.entry.toFixed(2):"–")+'</td><td class="mono">'+s.stop.toFixed(2)+'</td><td class="mono">'+s.target.toFixed(2)+'</td>'+st(s)+'</tr>').join("")}
function paint(){const r=J.res||{};PN=J.patterns||{};
  $("fecha").textContent=r.fecha||"–";$("info").textContent=r.fecha?"· "+r.n_syms+" acciones de tu lista del Escáner · hecho "+r.hecho:"";
  $("btd").textContent=r.bt_desde?"desde "+r.bt_desde:"";$("shd").textContent=r.sombra_desde||"hoy";
  paintHoy();const B=r.bt||{},S=r.sombra||{},f=v=>v==null?"–":v;
  $("pats").innerHTML=Object.keys(PN).map(k=>{const b=B[k]||{},s=S[k]||{};
   return '<tr><td><b>'+esc(PN[k].name)+'</b></td><td class="mono">'+f(b.n)+'</td><td class="mono">'+(b.n?b.win+"%":"–")+'</td><td class="mono '+cls(b.avg_r)+'"><b>'+(b.n?rr(b.avg_r):"–")+'</b></td><td class="mono '+cls(b.total_r)+'">'+(b.n?(b.total_r>0?"+":"")+b.total_r+"R":"–")+'</td><td class="mono">'+f(b.pf)+'</td><td class="mono">'+f(b.days)+'</td><td class="mono"><span class="'+cls((b.mkt_up||{}).avg_r)+'">'+((b.mkt_up||{}).n?rr(b.mkt_up.avg_r):"–")+'</span> / <span class="'+cls((b.mkt_down||{}).avg_r)+'">'+((b.mkt_down||{}).n?rr(b.mkt_down.avg_r):"–")+'</span></td>'
    +'<td class="mono sep">'+f(s.n)+'</td><td class="mono">'+(s.n?s.win+"%":"–")+'</td><td class="mono '+cls(s.avg_r)+'">'+(s.n?rr(s.avg_r):"–")+'</td><td class="mono">'+f(s.open)+'</td></tr>'}).join("");
  $("desc").innerHTML=Object.keys(PN).map(k=>'<div class="pt"><b>'+esc(PN[k].name)+'</b><br>'+esc(PN[k].desc)+'</div>').join("");
  $("sh").innerHTML=sigRows(r.sombra_sigs||[])||'<tr><td colspan="8" class="mut">Todavía no hay señales registradas.</td></tr>';
  $("rec").innerHTML=sigRows(r.recientes||[])||'<tr><td colspan="8" class="mut">–</td></tr>'}
async function load(){try{J=await (await fetch("/api/swing",{cache:"no-store"})).json()}catch(e){return}
  $("prog").textContent=J.err?"Error: "+J.err:(J.prog||"");$("prog").className="tag"+(J.err?" bad":"");$("bscan").disabled=J.busy;paint();if(J.busy)setTimeout(load,2000)}
async function scanNow(){$("bscan").disabled=true;$("prog").textContent="Empezando…";
  const j=await (await fetch("/api/swing_scan",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json();
  if(j.error)$("prog").textContent=j.error;setTimeout(load,1500)}
load();setInterval(()=>{if(!document.hidden)load()},60000);
</script></body></html>"""
