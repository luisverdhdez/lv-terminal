"""
Pestaña Financieros de Fundamentales: estado de resultados, balance y flujo de caja por periodo (anual o trimestral),
con columna TTM (ultimos 12 meses), secciones, tendencia y cambios contra el periodo anterior.
Datos: Yahoo Finance via yfinance (no oficial). Yahoo da ~4-5 años o ~5-8 trimestres.
"""
import fundamentales as F
from fund_ratios import _ser

N_A, N_Q = 5, 8

# (clave, nombre, formato, negrita, nombres en yfinance)   formato: $ dinero · eps · n acciones · % margen · x veces
INCOME = [
    ("INGRESOS", [("rev", "Ingresos", "$", 1, ("Total Revenue", "Operating Revenue")),
                  ("cogs", "Costo de ventas", "$", 0, ("Cost Of Revenue", "Reconciled Cost Of Revenue")),
                  ("gross", "Utilidad bruta", "$", 1, ("Gross Profit",)),
                  ("gross_m", "Margen bruto", "%", 0, None)]),
    ("OPERACIÓN", [("rnd", "Investigación y desarrollo", "$", 0, ("Research And Development",)),
                   ("sga", "Gastos generales y de venta", "$", 0, ("Selling General And Administration",)),
                   ("oper", "Utilidad operativa", "$", 1, ("Operating Income", "Total Operating Income As Reported")),
                   ("oper_m", "Margen operativo", "%", 0, None)]),
    ("RESULTADO FINAL", [("int", "Gasto por intereses", "$", 0, ("Interest Expense", "Interest Expense Non Operating")),
                         ("pretax", "Utilidad antes de impuestos", "$", 0, ("Pretax Income",)),
                         ("tax", "Impuestos", "$", 0, ("Tax Provision",)),
                         ("net", "Utilidad neta", "$", 1, ("Net Income", "Net Income Common Stockholders")),
                         ("net_m", "Margen neto", "%", 0, None)]),
    ("POR ACCIÓN", [("eps", "EPS (diluido)", "eps", 1, ("Diluted EPS", "Basic EPS")),
                    ("shares", "Acciones (diluidas)", "n", 0, ("Diluted Average Shares", "Basic Average Shares"))]),
    ("EBITDA", [("ebitda", "EBITDA", "$", 1, ("EBITDA", "Normalized EBITDA")),
                ("ebitda_m", "Margen EBITDA", "%", 0, None)]),
]
BALANCE = [
    ("ACTIVOS", [("cash", "Efectivo y equivalentes", "$", 0, ("Cash And Cash Equivalents",)),
                 ("sti", "Inversiones de corto plazo", "$", 0, ("Other Short Term Investments",)),
                 ("recv", "Cuentas por cobrar", "$", 0, ("Accounts Receivable", "Receivables")),
                 ("inv", "Inventario", "$", 0, ("Inventory",)),
                 ("ca", "Activo circulante", "$", 1, ("Current Assets",)),
                 ("ppe", "Propiedad, planta y equipo", "$", 0, ("Net PPE",)),
                 ("gw", "Crédito mercantil e intangibles", "$", 0, ("Goodwill And Other Intangible Assets", "Goodwill")),
                 ("assets", "Activos totales", "$", 1, ("Total Assets",))]),
    ("PASIVOS", [("ap", "Cuentas por pagar", "$", 0, ("Accounts Payable",)),
                 ("cl", "Pasivo circulante", "$", 1, ("Current Liabilities",)),
                 ("ltd", "Deuda de largo plazo", "$", 0, ("Long Term Debt",)),
                 ("debt", "Deuda total", "$", 0, ("Total Debt",)),
                 ("liab", "Pasivos totales", "$", 1, ("Total Liabilities Net Minority Interest", "Total Liabilities"))]),
    ("PATRIMONIO", [("re", "Utilidades retenidas", "$", 0, ("Retained Earnings",)),
                    ("equity", "Patrimonio de los accionistas", "$", 1, ("Stockholders Equity", "Common Stock Equity")),
                    ("sh_out", "Acciones en circulación", "n", 0, ("Ordinary Shares Number", "Share Issued"))]),
    ("CLAVES", [("net_debt", "Deuda neta (deuda − efectivo)", "$", 1, None),
                ("wcap", "Capital de trabajo", "$", 0, None),
                ("current_r", "Razón corriente", "x", 0, None),
                ("de", "Deuda / Patrimonio", "x", 0, None),
                ("bvps", "Valor en libros por acción", "eps", 0, None)]),
]
CASH = [
    ("OPERACIÓN", [("cf_net", "Utilidad neta", "$", 0, ("Net Income From Continuing Operations", "Net Income")),
                   ("da", "Depreciación y amortización", "$", 0, ("Depreciation And Amortization", "Depreciation Amortization Depletion")),
                   ("sbc", "Pagos en acciones", "$", 0, ("Stock Based Compensation",)),
                   ("wc", "Cambio en capital de trabajo", "$", 0, ("Change In Working Capital",)),
                   ("cfo", "Flujo de operación", "$", 1, ("Operating Cash Flow", "Cash Flow From Continuing Operating Activities"))]),
    ("INVERSIÓN", [("capex", "Inversión en activos (CapEx)", "$", 0, ("Capital Expenditure",)),
                   ("acq", "Adquisiciones", "$", 0, ("Net Business Purchase And Sale", "Purchase Of Business")),
                   ("cfi", "Flujo de inversión", "$", 1, ("Investing Cash Flow", "Cash Flow From Continuing Investing Activities"))]),
    ("FINANCIAMIENTO", [("divp", "Dividendos pagados", "$", 0, ("Cash Dividends Paid", "Common Stock Dividend Paid")),
                        ("buy", "Recompra de acciones", "$", 0, ("Repurchase Of Capital Stock", "Common Stock Payments")),
                        ("ndebt", "Deuda emitida / pagada (neto)", "$", 0, ("Net Issuance Payments Of Debt",)),
                        ("cff", "Flujo de financiamiento", "$", 1, ("Financing Cash Flow", "Cash Flow From Continuing Financing Activities"))]),
    ("FLUJO LIBRE", [("fcf", "Flujo de caja libre", "$", 1, ("Free Cash Flow",)),
                     ("fcf_m", "Margen de flujo libre", "%", 0, None),
                     ("fcf_ps", "Flujo libre por acción", "eps", 0, None),
                     ("ret", "Devuelto a accionistas (div. + recompras)", "$", 0, None)]),
]
FLOW = {"income": True, "balance": False, "cash": True}   # balance = foto al cierre (TTM = ultimo trimestre)


def _d(a, b):
    return a / b if a is not None and b not in (None, 0) else None


def _derive(st, v, rev=None, sh=None):
    """Completa renglones calculados de un periodo (dict clave->valor)."""
    g = v.get
    if st == "income":
        if g("gross") is None and g("rev") is not None and g("cogs") is not None:
            v["gross"] = g("rev") - g("cogs")
        r = g("rev") if g("rev") and g("rev") > 0 else None
        v["gross_m"], v["oper_m"], v["net_m"], v["ebitda_m"] = _d(g("gross"), r), _d(g("oper"), r), _d(g("net"), r), _d(g("ebitda"), r)
        if g("eps") is None and g("net") is not None and g("shares"):
            v["eps"] = g("net") / g("shares")
    elif st == "balance":
        v["net_debt"] = (g("debt") - (g("cash") or 0)) if g("debt") is not None else None
        v["wcap"] = (g("ca") - g("cl")) if g("ca") is not None and g("cl") is not None else None
        v["current_r"] = _d(g("ca"), g("cl"))
        v["de"] = _d(g("debt"), g("equity")) if g("equity") and g("equity") > 0 else None
        v["bvps"] = _d(g("equity"), g("sh_out"))
    else:
        if g("fcf") is None and g("cfo") is not None and g("capex") is not None:
            v["fcf"] = g("cfo") + g("capex")
        v["fcf_m"] = _d(g("fcf"), rev) if rev and rev > 0 else None
        v["fcf_ps"] = _d(g("fcf"), sh)
        parts = [x for x in (g("divp"), g("buy")) if x is not None]
        v["ret"] = -sum(parts) if parts else None
    return v


def _load(sym):
    yf = F._yf()

    def go():
        try:
            t = yf.Ticker(sym)
            return {"a": (t.income_stmt, t.balance_sheet, t.cashflow), "q": (t.quarterly_income_stmt, t.quarterly_balance_sheet, t.quarterly_cashflow)}
        except Exception as e:
            raise F._wrap(e)
    return F._cached(("fin2", sym), F.TTL_LONG, go)


def _series(dfs, defs):
    S = {}
    for _, items in defs:
        for k, _, _, _, names in items:
            if names:
                S[k] = _ser(dfs, names)
    return S


def statements(env, sym, per="a"):
    raw = _load(sym)
    qq = per == "q"
    out = {"sym": sym, "per": per, "st": {}}
    inc_q = _series(raw["q"][0], INCOME)
    for st, idx, defs in (("income", 0, INCOME), ("balance", 1, BALANCE), ("cash", 2, CASH)):
        S = _series(raw[per][idx], defs)
        Q = _series(raw["q"][idx], defs) if not qq else None
        dates = sorted(set().union(*[set(s) for s in S.values()]) if S else set())[-(N_Q if qq else N_A):]
        inc_a = _series(raw[per][0], INCOME) if st == "cash" else None
        cols = []
        for d in dates:
            v = {k: s.get(d) for k, s in S.items()}
            rev = (inc_a.get("rev") or {}).get(d) if inc_a else None
            sh = (inc_a.get("shares") or {}).get(d) if inc_a else None
            cols.append(_derive(st, v, rev, sh))
        labels = [(f"T{(int(d[5:7]) - 1) // 3 + 1} {d[2:4]}" if qq else d[:4]) for d in dates]
        ttm, ttm_lbl = None, None
        if Q is not None:
            qd = sorted(set().union(*[set(s) for s in Q.values()]) if Q else set())
            if qd and dates and qd[-1] > dates[-1]:
                last4 = qd[-4:]
                if FLOW[st]:
                    if len(last4) == 4:
                        ttm = {}
                        for k, s in Q.items():
                            vals = [s.get(d) for d in last4]
                            ttm[k] = sum(vals) if all(x is not None for x in vals) else None
                        if st == "income":
                            ttm["eps"] = sum(Q["eps"].get(d) for d in last4) if all(Q["eps"].get(d) is not None for d in last4) else None
                            ttm["shares"] = Q["shares"].get(qd[-1])
                else:
                    ttm = {k: s.get(qd[-1]) for k, s in Q.items()}
                if ttm is not None:
                    rev4 = [inc_q["rev"].get(d) for d in last4]
                    rv = sum(rev4) if len(last4) == 4 and all(x is not None for x in rev4) else None
                    ttm = _derive(st, ttm, rv, inc_q["shares"].get(qd[-1]))
                    ttm_lbl = f"TTM T{(int(qd[-1][5:7]) - 1) // 3 + 1} {qd[-1][2:4]}" if FLOW[st] else f"Último T{(int(qd[-1][5:7]) - 1) // 3 + 1} {qd[-1][2:4]}"
        secs = []
        for name, items in defs:
            rows = [{"key": k, "name": nm, "fmt": f, "bold": bool(b), "vals": [c.get(k) for c in cols], "ttm": ttm.get(k) if ttm else None}
                    for k, nm, f, b, _ in items]
            rows = [r for r in rows if any(x is not None for x in r["vals"]) or r["ttm"] is not None]
            if rows:
                secs.append({"name": name, "rows": rows})
        out["st"][st] = {"labels": labels, "dates": dates, "ttm_label": ttm_lbl, "sections": secs}
    yoy_step = 4 if qq else 1
    out["yoy_step"] = yoy_step
    out["warn"] = [] if out["st"]["income"]["labels"] else ["Yahoo no devolvió estados financieros para este símbolo."]
    return out
