"""
Escaner de SWING: busca acciones que acaban de cruzar HACIA ARRIBA su media de 50 dias (velas diarias), las confirma con volumen,
MACD y RSI, revisa que no haya reporte de resultados (earnings) antes del vencimiento y propone un PUT CREDIT SPREAD a ~45 dias.

- NUNCA envia ordenes. "Abrir spread" solo carga el constructor de Trading manual (alli sigues viendo vista previa y confirmacion).
- Revision pesada 1 vez al dia, despues del cierre (16:40 ET). Durante el dia solo refresca precios (1 consulta para toda la lista).
- Modo sombra: cada señal verde queda guardada y se mide si el spread llego al 25 % / 50 % del credito y en cuantos dias.
- Datos: se usa tu token REAL solo para LEER (velas, precios, cadenas); si no hay, el del sandbox (para velas diarias sirve).
- Fecha de earnings: se intenta con yfinance (el mismo que usa la pagina Fundamentales). Si no se puede, la columna dice "sin dato"
  y la señal avisa que debes verificarlo a mano antes de operar.
"""
import json
import os
import re
import threading
import time
from datetime import date, datetime, timedelta, time as dtime
from zoneinfo import ZoneInfo

import requests

ET = ZoneInfo("America/New_York")
BASE = os.path.dirname(os.path.abspath(__file__))
F_LIST = os.path.join(BASE, "escaner_lista.json")
F_RES = os.path.join(BASE, "escaner_res.json")
F_HIST = os.path.join(BASE, "escaner_hist.json")
F_EARN = os.path.join(BASE, "escaner_earn.json")
F_MAN = os.path.join(BASE, "escaner_manual.json")
F_PEND = os.path.join(BASE, "escaner_pendientes.json")   # entradas armadas esperando tu confirmacion
LOCK = threading.RLock()
SYM_RE = re.compile(r"^[A-Z][A-Z.\-]{0,5}$")

DEFAULT_LIST = (
    "SPY QQQ IWM DIA XLF XLE XLK XLV GLD TLT AAPL MSFT NVDA AMZN GOOGL META TSLA AVGO COST NFLX AMD ADBE CRM ORCL INTC CSCO QCOM TXN "
    "AMAT MU JPM BAC WFC GS MS V MA AXP BLK C UNH JNJ LLY PFE MRK ABBV TMO ABT BMY AMGN GILD WMT HD MCD NKE SBUX TGT LOW DIS KO PEP PG "
    "XOM CVX COP SLB OXY CAT DE BA HON GE LMT RTX UPS FDX UNP T VZ TMUS CMCSA PYPL UBER IBM NOW INTU MRVL PANW ISRG"
).split()

# criterios (ajustables aqui)
P = {"cross_days": 3, "vol_min": 1.2, "rsi_lo": 50, "rsi_hi": 70, "max_ext": 5.0, "near_pct": 1.5,
     "dte_target": 45, "delta_target": 0.25, "min_ratio": 0.25, "tp_pct": 50, "pace": 0.5}
WIDTHS = (1, 2, 3, 5, 10, 15)

STATE = {"busy": False, "prog": "", "err": None, "last_quote": 0}
MSTATE = {"busy": False, "prog": "", "err": None}      # busqueda manual (aparte: no toca Candidatos ni el modo sombra)
_HC = {}                                                # velas diarias del dia en memoria: {sym: (clave, velas)}
_MEM_EARN = {}
_WHY = {}


# ───────────── utilidades ─────────────
def _load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _save(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)


def _as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def _n(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def get_list():
    lst = _load(F_LIST, None)
    if not isinstance(lst, list) or not lst:
        return list(DEFAULT_LIST)
    return [s for s in lst if isinstance(s, str) and SYM_RE.match(s)]


def set_list(symbols):
    out = []
    for s in symbols:
        s = str(s).strip().upper()
        if SYM_RE.match(s) and s not in out:
            out.append(s)
    if not out:
        raise ValueError("La lista está vacía o no tiene símbolos válidos")
    if len(out) > 300:
        raise ValueError("Máximo 300 símbolos")
    _save(F_LIST, out)
    return out


class Api:
    """Lectura de Tradier (solo GET). Token real si existe (datos en vivo); si no, el del sandbox."""

    def __init__(self, env):
        tok = env.get("TRADIER_LIVE_TOKEN")
        if tok:
            self.base, self.tok, self.src = "https://api.tradier.com/v1", tok, "live"
        else:
            self.base, self.tok, self.src = "https://sandbox.tradier.com/v1", env.get("TRADIER_TOKEN"), "sandbox"
        if not self.tok:
            raise RuntimeError("Falta configurar una cuenta de Tradier en ⚙ Cuentas")
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {self.tok}", "Accept": "application/json"})

    def get(self, path, params=None, tries=3):
        for i in range(tries):
            try:
                r = self.s.get(self.base + path, params=params, timeout=15)
                if r.status_code in (400, 429) and "uota" in r.text:
                    time.sleep(20 + 10 * i)      # limite de consultas: espera y reintenta
                    continue
                r.raise_for_status()
                return r.json()
            except requests.RequestException:
                if i == tries - 1:
                    raise
                time.sleep(2 + i)
        return {}

    def history(self, sym, days=420):
        end = datetime.now(ET).date()
        j = self.get("/markets/history", {"symbol": sym, "interval": "daily",
                                         "start": (end - timedelta(days=days)).isoformat(), "end": end.isoformat()})
        rows = _as_list(((j.get("history") or {}) if isinstance(j.get("history"), dict) else {}).get("day"))
        out = []
        for d in rows:
            c, h, l, v = _n(d.get("close")), _n(d.get("high")), _n(d.get("low")), _n(d.get("volume"))
            if c is None or h is None or l is None:
                continue
            out.append({"d": d.get("date"), "c": c, "h": h, "l": l, "v": v or 0.0})
        out.sort(key=lambda x: x["d"])
        return out

    def quotes(self, syms):
        out = {}
        syms = list(syms)
        for k in range(0, len(syms), 100):
            j = self.get("/markets/quotes", {"symbols": ",".join(syms[k:k + 100])})
            qs = _as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
            for q in qs:
                if isinstance(q, dict) and q.get("symbol"):
                    out[q["symbol"]] = q
        return out


# ───────────── indicadores ─────────────
def sma(v, n):
    out, run = [None] * len(v), 0.0
    for i, x in enumerate(v):
        run += x
        if i >= n:
            run -= v[i - n]
        if i >= n - 1:
            out[i] = run / n
    return out


def ema(v, n):
    out = [None] * len(v)
    if len(v) < n:
        return out
    e = sum(v[:n]) / n
    out[n - 1] = e
    k = 2.0 / (n + 1)
    for i in range(n, len(v)):
        e = v[i] * k + e * (1 - k)
        out[i] = e
    return out


def rsi(c, n=14):
    out = [None] * len(c)
    if len(c) <= n:
        return out
    g = l = 0.0
    for i in range(1, n + 1):
        d = c[i] - c[i - 1]
        g += max(d, 0)
        l += max(-d, 0)
    g, l = g / n, l / n
    out[n] = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
    for i in range(n + 1, len(c)):
        d = c[i] - c[i - 1]
        g = (g * (n - 1) + max(d, 0)) / n
        l = (l * (n - 1) + max(-d, 0)) / n
        out[i] = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
    return out


def macd_hist(c):
    e12, e26 = ema(c, 12), ema(c, 26)
    line = [(a - b) if a is not None and b is not None else None for a, b in zip(e12, e26)]
    idx = [i for i, x in enumerate(line) if x is not None]
    if not idx:
        return [None] * len(c)
    sig = ema([line[i] for i in idx], 9)
    hist = [None] * len(c)
    for k, i in enumerate(idx):
        if sig[k] is not None:
            hist[i] = line[i] - sig[k]
    return hist


def analyze(bars, spy_ret=None, p=None):
    """Calcula los filtros de una accion con velas diarias CERRADAS. Devuelve dict o None si faltan datos.
    p: criterios (por defecto los normales P; la busqueda manual pasa los suyos)."""
    p = p or P
    n = len(bars)
    if n < 70:
        return None
    c = [b["c"] for b in bars]
    v = [b["v"] for b in bars]
    s50 = sma(c, int(p.get("ma", 50)))
    r = rsi(c)
    h = macd_hist(c)
    i = n - 1
    if s50[i] is None or s50[i - 5] is None or r[i] is None or h[i] is None or h[i - 2] is None:
        return None
    out = {"price": c[i], "sma50": s50[i], "vs": (c[i] / s50[i] - 1) * 100, "rsi": r[i], "hist": h[i],
           "slope_ok": s50[i] >= s50[i - 5] * 0.999, "age": None, "vol_ratio": None}
    if c[i] > s50[i]:
        j = i
        while j > 0 and s50[j - 1] is not None and c[j - 1] > s50[j - 1]:
            j -= 1
        if j > 0 and s50[j - 1] is not None:
            out["age"] = i - j
            base = v[max(0, i - 20):i]
            avg = sum(base) / len(base) if base else 0
            out["vol_ratio"] = (max(v[j:i + 1]) / avg) if avg else None
    out["cross_ok"] = (out["age"] is not None and out["age"] <= p["cross_days"] and out["slope_ok"]
                       and out["vs"] <= p["max_ext"])
    out["vol_ok"] = out["vol_ratio"] is not None and out["vol_ratio"] >= p["vol_min"]
    rising = h[i] > h[i - 1] > h[i - 2]
    out["macd_ok"] = h[i] > 0 or rising
    out["macd_txt"] = ("▲ histograma +" if h[i] > 0 else "↗ mejorando") if out["macd_ok"] else "▼ débil"
    if out["macd_ok"] and h[i - 1] is not None and h[i - 1] <= 0 < h[i]:
        out["macd_txt"] = "▲ cruce alcista"
    out["rsi_ok"] = p["rsi_lo"] <= out["rsi"] <= p["rsi_hi"]
    out["near"] = (c[i] <= s50[i] and out["vs"] >= -p["near_pct"] and h[i] > h[i - 1] and s50[i] >= s50[i - 5] * 0.995)
    # tendencia de fondo: SMA 200 (precio arriba o a menos de 3 % por debajo, y la SMA 200 no cae)
    s200 = sma(c, 200)
    if s200[i] is not None and s200[i - 10] is not None:
        out["sma200"] = s200[i]
        out["trend_ok"] = c[i] >= s200[i] * 0.97 and s200[i] >= s200[i - 10] * 0.999
        out["trend_txt"] = ("✓ sobre SMA 200" if c[i] >= s200[i] else "≈ cerca de SMA 200") if out["trend_ok"] else \
                           ("✗ bajo SMA 200" if c[i] < s200[i] * 0.97 else "✗ SMA 200 cayendo")
    else:
        out["sma200"], out["trend_ok"], out["trend_txt"] = None, None, "sin datos"
    # fuerza relativa: rendimiento de ~60 velas contra SPY
    out["ret60"] = (c[i] / c[i - 60] - 1) * 100 if i >= 60 else None
    out["rs"] = (out["ret60"] - spy_ret) if (out["ret60"] is not None and spy_ret is not None) else None
    out["rs_ok"] = None if out["rs"] is None else out["rs"] > 0
    out["low"] = bars[-1]["l"]
    out["date"] = bars[-1]["d"]
    return out


# ───────────── earnings ─────────────
def earnings_date(sym):
    """Proxima fecha de reporte (YYYY-MM-DD) o None si no se pudo saber. Cache de 12 h."""
    now = time.time()
    m = _MEM_EARN.get(sym)
    if m and now - m[0] < 12 * 3600:
        return m[1]
    disk = _load(F_EARN, {})
    d = disk.get(sym)
    if d and now - d[0] < 12 * 3600:
        _MEM_EARN[sym] = (d[0], d[1])
        return d[1]
    val = None
    try:
        import fundamentales
        yf = fundamentales._yf()
        cal = yf.Ticker(sym).calendar
        ed = None
        if isinstance(cal, dict):
            ed = cal.get("Earnings Date")
        elif cal is not None and hasattr(cal, "loc"):
            ed = list(cal.loc["Earnings Date"]) if "Earnings Date" in cal.index else None
        for x in _as_list(ed):
            s = str(x)[:10]
            if re.match(r"^\d{4}-\d{2}-\d{2}$", s) and s >= date.today().isoformat():
                val = s if val is None else min(val, s)
    except Exception:
        val = None
    if val is not None:
        _MEM_EARN[sym] = (now, val)
        disk[sym] = [now, val]
        try:
            _save(F_EARN, disk)
        except OSError:
            pass
    return val


# ───────────── spread propuesto ─────────────
def _width_for(price):
    w = 5 if price >= 100 else 2 if price >= 40 else 1
    return w if w in WIDTHS else 2


def pick_expiration(api, sym, today, p=None):
    p = p or P
    j = api.get("/markets/options/expirations", {"symbol": sym})
    ds = _as_list((j.get("expirations") or {}).get("date")) if isinstance(j.get("expirations"), dict) else []
    best, bd = None, None
    for d in ds:
        try:
            dte = (date.fromisoformat(d) - today).days
        except ValueError:
            continue
        if dte < min(25, max(5, int(p["dte_target"] * 0.6))):
            continue
        diff = abs(dte - p["dte_target"])
        if bd is None or diff < bd:
            best, bd = (d, dte), diff
    return best


def propose_spread(api, sym, price, sma50, exp, dte, p=None):
    p = p or P
    j = api.get("/markets/options/chains", {"symbol": sym, "expiration": exp, "greeks": "true"})
    opts = _as_list((j.get("options") or {}).get("option")) if isinstance(j.get("options"), dict) else []
    puts = {}
    for o in opts:
        if o.get("option_type") != "put":
            continue
        k = _n(o.get("strike"))
        if k is not None:
            puts[k] = o
    _WHY[sym] = "La cadena de opciones no trajo puts (¿sin datos en vivo?)"
    if not puts:
        return None
    width = _width_for(price)
    cands = []
    for k, o in puts.items():
        d = _n((o.get("greeks") or {}).get("delta"))
        bid, ask = _n(o.get("bid")), _n(o.get("ask"))
        if d is None or bid is None or ask is None or bid <= 0 or ask < bid or not max(0.03, p["delta_target"] - 0.13) <= abs(d) <= min(0.5, p["delta_target"] + 0.10):
            continue
        cands.append((abs(abs(d) - p["delta_target"]), k, abs(d), o))
    cands.sort()
    if not cands:
        _WHY[sym] = "Sin puts con delta 0.12–0.35 y precios válidos (Tradier no mandó griegas o bid/ask)"
    best = None
    for _, k, d, o in cands[:8]:
        lo = puts.get(round(k - width, 3)) or puts.get(float(k - width))
        if lo is None:      # strikes con otra separacion (0.5, 2.5...): usa el strike real mas cercano al ancho buscado
            below = [x for x in puts if x < k and 0.6 * width <= k - x <= 1.6 * width]
            if not below:
                continue
            lo = puts[min(below, key=lambda x: abs((k - x) - width))]
        w = round(k - _n(lo.get("strike")), 3)
        lb, la = _n(lo.get("bid")), _n(lo.get("ask"))
        if lb is None or la is None or la <= 0:
            continue
        sb, sa = _n(o.get("bid")), _n(o.get("ask"))
        credit = round((sb + sa) / 2 - (lb + la) / 2, 2)
        if credit <= 0:
            continue
        ratio = credit / w
        spread = {"exp": exp, "dte": dte, "short": k, "long": _n(lo.get("strike")), "width": w, "delta": round(d, 2),
                  "credit": credit, "ratio": round(ratio * 100, 0), "max_loss": round((w - credit) * 100, 0),
                  "be": round(k - credit, 2), "short_occ": o.get("symbol"), "long_occ": lo.get("symbol"),
                  "oi": o.get("open_interest"), "below_sma": k <= sma50,
                  "liquid": (sa - sb) <= 0.15 and (la - lb) <= 0.15,
                  "tp": round(credit * 100 * p["tp_pct"] / 100), "stop": round(credit * 100)}
        if ratio >= p["min_ratio"]:
            return spread
        if best is None or ratio > best["ratio"] / 100:
            best = spread
    if best:
        best["low_credit"] = True
    elif cands:
        _WHY[sym] = "No encontré la pata comprada a $%s debajo del put vendido" % width
    return best


# ───────────── escaneo ─────────────
def classify(sym, a, earn, exp_info, mkt_ok=True, p=None):
    """Devuelve (estado, motivo, filtros_cumplidos). En la busqueda manual los filtros apagados (req_*) no se exigen."""
    p = p or P
    req = lambda k: p.get("req_" + k, True)
    if a["cross_ok"]:
        fails = []
        if req("vol") and not a["vol_ok"]:
            fails.append("volumen")
        if req("macd") and not a["macd_ok"]:
            fails.append("MACD")
        if req("rsi") and not a["rsi_ok"]:
            fails.append("RSI alto" if a["rsi"] > p["rsi_hi"] else "RSI bajo")
        if req("trend") and a.get("trend_ok") is False:
            fails.append("tendencia (SMA 200)")
        if req("rs") and a.get("rs_ok") is False:
            fails.append("fuerza relativa")
        if req("mkt") and not mkt_ok:
            fails.append("mercado débil (SPY bajo su SMA 50)")
        e_bad = bool(earn and exp_info and earn <= exp_info[0]) and req("earn")
        dots = (1 + (a["vol_ok"]) + (a["macd_ok"]) + (a["rsi_ok"]) + (0 if e_bad else 1 if earn else 0)
                + (a.get("trend_ok") is not False) + (a.get("rs_ok") is not False))
        if e_bad or (req("rsi") and a["rsi"] > p["rsi_hi"]):
            why = []
            if e_bad:
                why.append("reporte de resultados dentro de los ~45 días")
            if req("rsi") and a["rsi"] > p["rsi_hi"]:
                why.append("RSI alto")
            return "descartada", " · ".join(why), dots
        if not fails:
            return "senal", "", dots
        if len(fails) <= 2:
            return "falta", "Falta: " + ", ".join(fails), dots
        return None, "", dots
    if a["near"]:
        return "cerca", f"A {abs(a['vs']):.1f}% de cruzar la SMA {int(p.get('ma', 50))}", 3
    return None, "", 0


def scan(env, notify=None):
    """Revision diaria completa. Guarda el resultado y devuelve la lista de señales verdes NUEVAS."""
    with LOCK:
        if STATE["busy"]:
            return []
        STATE["busy"], STATE["err"] = True, None
    new_signals = []
    try:
        api = Api(env)
        syms = get_list()
        now = datetime.now(ET)
        today = now.date()
        after_close = now.time() >= dtime(16, 5)
        rows, errs = [], 0
        prev = _load(F_RES, {})
        prev_green = {r["sym"] for r in prev.get("rows", []) if r.get("estado") == "senal"}
        def _closed(b):
            return b[:-1] if (b and b[-1]["d"] == today.isoformat() and now.weekday() < 5 and not after_close) else b
        mkt = {"ok": True, "txt": "sin datos de SPY"}
        spy_ret = None
        try:
            sb = _closed(api.history("SPY"))
            sc = [x["c"] for x in sb]
            s50 = sma(sc, 50)
            if len(sc) > 60 and s50[-1] is not None:
                spy_ret = (sc[-1] / sc[-61] - 1) * 100
                mkt = {"ok": sc[-1] > s50[-1], "spy": round(sc[-1], 2), "sma50": round(s50[-1], 2), "ret60": round(spy_ret, 1),
                       "txt": "SPY %.2f %s su SMA 50 (%.2f)" % (sc[-1], "sobre" if sc[-1] > s50[-1] else "BAJO", s50[-1])}
        except Exception:
            pass
        for k, sym in enumerate(syms):
            STATE["prog"] = f"Escaneando {k + 1}/{len(syms)} · {sym}"
            try:
                bars = api.history(sym)
                _HC[sym] = ((today.isoformat(), after_close, api.src), bars)
                # con el mercado abierto la ultima vela diaria es parcial: se usa solo hasta el cierre anterior
                if bars and bars[-1]["d"] == today.isoformat() and (now.weekday() < 5 and not after_close):
                    bars = bars[:-1]
                a = analyze(bars, spy_ret)
            except Exception:
                errs += 1
                a = None
            time.sleep(P["pace"])
            if not a:
                continue
            earn, exp_info = None, None
            if a["cross_ok"]:
                try:
                    exp_info = pick_expiration(api, sym, today)
                    exp_info = (exp_info[0], exp_info[1]) if exp_info else None
                except Exception:
                    exp_info = None
                earn = earnings_date(sym)
            est, motivo, dots = classify(sym, a, earn, exp_info, mkt["ok"])
            if est is None:
                continue
            spread = None
            if est == "senal" and exp_info:
                try:
                    spread = propose_spread(api, sym, a["price"], a["sma50"], exp_info[0], exp_info[1])
                except Exception as e:
                    spread = None
                    _WHY[sym] = "Error al leer la cadena: " + e.__class__.__name__
                time.sleep(P["pace"])
            rows.append({"sym": sym, "estado": est, "motivo": motivo, "dots": dots, "price": round(a["price"], 2),
                         "sma50": round(a["sma50"], 2), "vs": round(a["vs"], 1), "age": a["age"],
                         "vol_ratio": None if a["vol_ratio"] is None else round(a["vol_ratio"], 1),
                         "macd": a["macd_txt"], "rsi": round(a["rsi"]), "trend": a["trend_txt"], "trend_ok": a["trend_ok"],
                         "rs": None if a["rs"] is None else round(a["rs"], 1), "earn": earn,
                         "earn_known": earn is not None, "earn_bad": bool(earn and exp_info and earn <= exp_info[0]),
                         "spread": spread, "exp_hint": exp_info[0] if exp_info else None,
                         "spread_err": (_WHY.get(sym) or ("No se encontró vencimiento cercano a 45 días" if not exp_info else None)) if (est == "senal" and not spread) else None, "bar_date": a["date"], "low": a["low"]})
        order = {"senal": 0, "falta": 1, "cerca": 2, "descartada": 3}
        rows.sort(key=lambda r: (order[r["estado"]], -r["dots"], r["sym"]))
        new_signals = [r["sym"] for r in rows if r["estado"] == "senal" and r["sym"] not in prev_green]
        res = {"ts": time.time(), "fecha": today.isoformat(), "rows": rows, "total": len(syms), "errs": errs,
               "mercado": mkt, "src": api.src, "base": "cierre de hoy" if (after_close or now.weekday() >= 5) else "cierre anterior",
               "nuevas": new_signals, "alertados": []}
        _save(F_RES, res)
        _track(api, rows, today)
        add_pending([r for r in rows if r["sym"] in new_signals and r.get("spread")], today)
        STATE["prog"] = ""
        if notify and new_signals:
            for s in new_signals:
                r = next(x for x in rows if x["sym"] == s)
                sp = r.get("spread")
                txt = f"{s}: cruzó la SMA 50 con volumen." + (f" Put credit spread {sp['short']}/{sp['long']} a {sp['dte']}d, crédito ${sp['credit']:.2f}."
                                                              f" ✅ Entrada lista para confirmar en Escáner." if sp else "")
                if not r["earn_known"]:
                    txt += " (verifica earnings)"
                notify("🔭 Escáner: señal verde", txt)
    except Exception as e:  # nunca tumbar el panel
        STATE["err"] = f"{e.__class__.__name__}: {e}"
    finally:
        STATE["busy"] = False
    return new_signals


# ───────────── entradas armadas esperando tu confirmacion ─────────────
PEND_DAYS = 3   # despues de 3 dias habiles la señal ya es vieja: queda como vencida


def add_pending(rows, today):
    """Deja armada la entrada de cada señal verde NUEVA (no envia nada)."""
    if not rows:
        return
    with LOCK:
        pend = _load(F_PEND, [])
        have = {(x["sym"], x["fecha"]) for x in pend}
        for r in rows:
            sp = r["spread"]
            if (r["sym"], today.isoformat()) in have:
                continue
            pend.append({"id": f"{r['sym']}-{today.isoformat()}", "sym": r["sym"], "fecha": today.isoformat(), "status": "pendiente",
                         "price": r["price"], "exp": sp["exp"], "dte": sp["dte"], "short": sp["short"], "long": sp["long"],
                         "short_occ": sp["short_occ"], "long_occ": sp["long_occ"], "width": sp["width"], "delta": sp["delta"],
                         "credit": sp["credit"], "max_loss": sp["max_loss"], "tp": sp["tp"], "stop": sp["stop"],
                         "earn": r.get("earn"), "earn_known": r.get("earn_known"), "ts": time.time()})
        _save(F_PEND, pend[-60:])


def pending_list(today=None):
    today = today or datetime.now(ET).date()
    pend = _load(F_PEND, [])
    for x in pend:
        if x["status"] == "pendiente" and _bdays(date.fromisoformat(x["fecha"]), today) > PEND_DAYS:
            x["status"] = "vencida"
    return sorted(pend, key=lambda x: (x["status"] != "pendiente", -x.get("ts", 0)))[:20]


REMIND_FROM, REMIND_TO = dtime(9, 45), dtime(11, 0)


def remind_pending(env, now, notify):
    """Dias habiles a las 9:45 ET: si hay entradas listas, te avisa UNA vez con el precio de ahora vs el de la señal."""
    if not notify or now.weekday() >= 5 or not (REMIND_FROM <= now.time() <= REMIND_TO):
        return False
    today = now.date().isoformat()
    with LOCK:
        pend = _load(F_PEND, [])
        live = [x for x in pending_list(now.date()) if x["status"] == "pendiente" and x["fecha"] < today]
        todo = [x for x in pend if x["id"] in {y["id"] for y in live} and x.get("recordada") != today]
        if not todo:
            return False
        try:
            qs = Api(env).quotes([x["sym"] for x in todo])
        except Exception:
            qs = {}
        lines = []
        for x in todo:
            px = _n((qs.get(x["sym"]) or {}).get("last"))
            ch = (px / x["price"] - 1) * 100 if px else None
            warn = " ⚠ abrió muy abajo: revísala" if ch is not None and ch <= -2 else ""
            lines.append(f"• {x['sym']} put spread {x['short']:g}/{x['long']:g} (vence {x['exp']}) · señal ${x['price']:.2f}"
                         + (f" → ahora ${px:.2f} ({ch:+.1f}%)" if px else "") + warn)
            x["recordada"] = today
        _save(F_PEND, pend)
    notify("📝 Entradas listas para confirmar", f"Tienes {len(todo)} entrada(s) del escáner esperando tu confirmación:\n"
           + "\n".join(lines) + "\nConfírmalas o descártalas en la pestaña Escáner.")
    return True


def pending_update(body):
    pid, act = str(body.get("id") or ""), body.get("action")
    if act not in ("descartar", "enviada"):
        raise ValueError("Acción no válida")
    with LOCK:
        pend = _load(F_PEND, [])
        x = next((p for p in pend if p["id"] == pid), None)
        if not x:
            raise ValueError("Entrada no encontrada")
        x["status"] = "descartada" if act == "descartar" else "enviada"
        if act == "enviada":
            x["order"] = str(body.get("order") or "")
            x["sent_price"] = body.get("price")
            x["sent_live"] = bool(body.get("live"))
        x["ts_upd"] = time.time()
        _save(F_PEND, pend)
    return pending_list()


# ───────────── busqueda MANUAL con tus propios criterios ─────────────
NUM = {"cross_days": (1, 20, int), "vol_min": (0.5, 5, float), "rsi_lo": (0, 100, float), "rsi_hi": (0, 100, float),
       "max_ext": (0.5, 30, float), "near_pct": (0.2, 10, float), "ma": (10, 200, int), "dte_target": (7, 120, int),
       "delta_target": (0.05, 0.45, float), "min_ratio": (0.05, 0.6, float), "tp_pct": (10, 90, float)}
REQ = ("vol", "macd", "rsi", "trend", "rs", "mkt", "earn")


def clean_params(new):
    """Criterios de la busqueda manual: parte de los normales (P) y valida cada campo."""
    out = dict(P)
    out.update({"ma": 50, **{"req_" + k: True for k in REQ}})
    for k, (lo, hi, t) in NUM.items():
        if k in (new or {}):
            try:
                v = t(float(new[k]))
            except (TypeError, ValueError):
                raise ValueError(f"Valor no válido en {k}")
            if not lo <= v <= hi:
                raise ValueError(f"{k} debe estar entre {lo} y {hi}")
            out[k] = v
    for k in REQ:
        if "req_" + k in (new or {}):
            out["req_" + k] = bool(new["req_" + k])
    if out["rsi_lo"] >= out["rsi_hi"]:
        raise ValueError("El RSI mínimo debe ser menor que el máximo")
    return out


def scan_manual(env, params, symbols=None):
    """Busca con TUS criterios. Guarda en escaner_manual.json. No avisa, no entra al modo sombra, no cambia Candidatos."""
    with LOCK:
        if MSTATE["busy"]:
            return
        MSTATE.update(busy=True, err=None)
    try:
        p = clean_params(params)
        api = Api(env)
        syms = [x for x in (symbols or get_list()) if SYM_RE.match(x)][:300]
        now = datetime.now(ET)
        today = now.date()
        after_close = now.time() >= dtime(16, 5)
        key = (today.isoformat(), after_close, api.src)

        def bars_of(sym):
            hit = _HC.get(sym)
            if hit and hit[0] == key:
                return hit[1], False
            b = api.history(sym)
            _HC[sym] = (key, b)
            return b, True

        def closed(b):
            return b[:-1] if (b and b[-1]["d"] == today.isoformat() and now.weekday() < 5 and not after_close) else b
        mkt_ok, spy_ret = True, None
        try:
            sb, _ = bars_of("SPY")
            sc = [x["c"] for x in closed(sb)]
            s50 = sma(sc, 50)
            if len(sc) > 60 and s50[-1] is not None:
                spy_ret, mkt_ok = (sc[-1] / sc[-61] - 1) * 100, sc[-1] > s50[-1]
        except Exception:
            pass
        rows, errs = [], 0
        for k, sym in enumerate(syms):
            MSTATE["prog"] = f"Buscando {k + 1}/{len(syms)} · {sym}"
            try:
                b, fetched = bars_of(sym)
                a = analyze(closed(b), spy_ret, p)
                if fetched:
                    time.sleep(P["pace"])
            except Exception:
                errs += 1
                a = None
            if not a:
                continue
            earn, exp_info = None, None
            if a["cross_ok"]:
                try:
                    exp_info = pick_expiration(api, sym, today, p)
                except Exception:
                    exp_info = None
                earn = earnings_date(sym) if p["req_earn"] else None
            est, motivo, dots = classify(sym, a, earn, exp_info, mkt_ok, p)
            if est is None:
                continue
            spread = None
            if est == "senal" and exp_info:
                try:
                    spread = propose_spread(api, sym, a["price"], a["sma50"], exp_info[0], exp_info[1], p)
                except Exception:
                    spread = None
                time.sleep(P["pace"])
            rows.append({"sym": sym, "estado": est, "motivo": motivo, "dots": dots, "price": round(a["price"], 2),
                         "sma50": round(a["sma50"], 2), "vs": round(a["vs"], 1), "age": a["age"],
                         "vol_ratio": None if a["vol_ratio"] is None else round(a["vol_ratio"], 1),
                         "macd": a["macd_txt"], "rsi": round(a["rsi"]), "trend": a["trend_txt"], "trend_ok": a["trend_ok"],
                         "rs": None if a["rs"] is None else round(a["rs"], 1), "earn": earn, "earn_known": earn is not None,
                         "earn_bad": bool(earn and exp_info and earn <= exp_info[0]), "spread": spread,
                         "exp_hint": exp_info[0] if exp_info else None,
                         "spread_err": (_WHY.get(sym) or ("No se encontró vencimiento" if not exp_info else None)) if (est == "senal" and not spread) else None,
                         "bar_date": a["date"], "low": a["low"]})
        order = {"senal": 0, "falta": 1, "cerca": 2, "descartada": 3}
        rows.sort(key=lambda r: (order[r["estado"]], -r["dots"], r["sym"]))
        _save(F_MAN, {"ts": time.time(), "params": p, "rows": rows, "total": len(syms), "errs": errs, "mkt_ok": mkt_ok,
                      "custom_list": bool(symbols)})
        MSTATE["prog"] = ""
    except Exception as e:
        MSTATE["err"] = f"{e.__class__.__name__}: {e}"
    finally:
        MSTATE["busy"] = False


# ───────────── modo sombra del escaner ─────────────
def _bdays(a, b):
    n, d = 0, a
    while d < b:
        d += timedelta(days=1)
        if d.weekday() < 5:
            n += 1
    return n


def _track(api, rows, today):
    """Guarda las señales verdes nuevas y actualiza las abiertas (cuanto del credito se ha capturado)."""
    with LOCK:
        hist = _load(F_HIST, [])
        for r in rows:
            sp = r.get("spread")
            if r["estado"] != "senal" or not sp:
                continue
            if any(h["sym"] == r["sym"] and (today - date.fromisoformat(h["fecha"])).days <= 10 for h in hist):
                continue
            hist.append({"fecha": today.isoformat(), "sym": r["sym"], "price": r["price"], "exp": sp["exp"], "short": sp["short"],
                         "long": sp["long"], "credit": sp["credit"], "short_occ": sp["short_occ"], "long_occ": sp["long_occ"],
                         "max_pct": 0.0, "last_pct": None, "d25": None, "d50": None, "touched": False, "closed": False,
                         "stop_hit": False})
        _save(F_HIST, hist)
    update_tracking(api, today)


def update_tracking(api, today=None):
    today = today or datetime.now(ET).date()
    with LOCK:
        hist = _load(F_HIST, [])
        act = [h for h in hist if not h.get("closed")]
        if not act:
            return
        occs = sorted({h["short_occ"] for h in act} | {h["long_occ"] for h in act})
        syms = sorted({h["sym"] for h in act})
    try:
        q = api.quotes(occs + syms)
    except Exception:
        return
    with LOCK:
        hist = _load(F_HIST, [])
        for h in hist:
            if h.get("closed"):
                continue
            s, lg, u = q.get(h["short_occ"]), q.get(h["long_occ"]), q.get(h["sym"])
            fd = date.fromisoformat(h["fecha"])
            if date.fromisoformat(h["exp"]) < today or (today - fd).days > 60:
                h["closed"] = True
                continue
            if s and lg:
                sb, sa, lb, la = _n(s.get("bid")), _n(s.get("ask")), _n(lg.get("bid")), _n(lg.get("ask"))
                if None not in (sb, sa, lb, la) and sa > 0 and la > 0:
                    val = (sb + sa) / 2 - (lb + la) / 2
                    pct = (h["credit"] - val) / h["credit"] * 100
                    h["last_pct"] = round(pct, 1)
                    h["max_pct"] = round(max(h["max_pct"], pct), 1)
                    days = _bdays(fd, today)
                    if pct >= 25 and h["d25"] is None:
                        h["d25"] = days
                    if pct >= 50 and h["d50"] is None:
                        h["d50"] = days
                    if pct <= -100:
                        h["stop_hit"] = True
            if u and _n(u.get("low")) is not None and _n(u["low"]) <= h["short"]:
                h["touched"] = True
        _save(F_HIST, hist)


def _med(v):
    v = sorted(x for x in v if x is not None)
    if not v:
        return None
    m = len(v) // 2
    return v[m] if len(v) % 2 else (v[m - 1] + v[m]) / 2


def hist_summary():
    hist = _load(F_HIST, [])
    n = len(hist)
    return {"n": n, "abiertas": sum(1 for h in hist if not h.get("closed")),
            "n25": sum(1 for h in hist if h.get("d25") is not None), "n50": sum(1 for h in hist if h.get("d50") is not None),
            "med25": _med([h.get("d25") for h in hist]), "med50": _med([h.get("d50") for h in hist]),
            "tocaron": sum(1 for h in hist if h.get("touched")), "stops": sum(1 for h in hist if h.get("stop_hit")),
            "ultimas": hist[-12:][::-1]}


# ───────────── refresco de precios durante el dia ─────────────
def refresh_prices(env, notify=None):
    """1 consulta de precios para toda la lista de candidatos + actualiza el seguimiento. No cambia los estados (eso es al cierre)."""
    res = _load(F_RES, None)
    if not res or STATE["busy"]:
        return
    try:
        api = Api(env)
        syms = [r["sym"] for r in res.get("rows", [])]
        q = api.quotes(syms) if syms else {}
        alertados = set(res.get("alertados", []))
        today = datetime.now(ET).date().isoformat()
        for r in res["rows"]:
            x = q.get(r["sym"])
            px = _n(x.get("last")) if x else None
            if px is None:
                continue
            r["live"] = round(px, 2)
            r["live_vs"] = round((px / r["sma50"] - 1) * 100, 1)
            r["cruza_vivo"] = bool(r["estado"] in ("cerca", "falta") and px > r["sma50"] and r["estado"] == "cerca")
            key = f"{today}:{r['sym']}"
            if r["cruza_vivo"] and key not in alertados:
                alertados.add(key)
                if notify:
                    notify("🔭 Escáner", f"{r['sym']} cruzó la SMA 50 en vivo ({px:.2f}). Se confirma con el cierre de hoy.")
        res["alertados"] = sorted(alertados)[-200:]
        res["live_ts"] = time.time()
        _save(F_RES, res)
        update_tracking(api)
    except Exception as e:
        STATE["err"] = f"{e.__class__.__name__}"


def loop(get_env, notify):
    """Hilo del panel: revision diaria a las 16:40 ET (y al arrancar si ya paso y falta) + refresco de precios cada 5 min."""
    last_q = 0.0
    while True:
        try:
            now = datetime.now(ET)
            env = get_env() or {}
            if env.get("TRADIER_LIVE_TOKEN") or env.get("TRADIER_TOKEN"):
                res = _load(F_RES, {})
                done_today = res.get("fecha") == now.date().isoformat() and res.get("base") == "cierre de hoy"
                if now.weekday() < 5 and now.time() >= dtime(16, 40) and not done_today and not STATE["busy"]:
                    threading.Thread(target=scan, args=(env, notify), daemon=True).start()
                elif now.weekday() < 5 and dtime(9, 30) <= now.time() <= dtime(16, 5) and time.time() - last_q >= 300:
                    last_q = time.time()
                    refresh_prices(env, notify)
                remind_pending(env, now, notify)   # 9:45 ET: recordatorio de entradas listas para confirmar
        except Exception:
            pass
        time.sleep(30)


# ───────────── API de la pagina ─────────────
def handle(method, path, q, body, env):
    if method == "GET":
        res = _load(F_RES, {"rows": []})
        return 200, {"res": res, "busy": STATE["busy"], "prog": STATE["prog"], "err": STATE["err"], "lista": get_list(),
                     "sombra": hist_summary(), "params": P, "src": "live" if env.get("TRADIER_LIVE_TOKEN") else "sandbox",
                     "pend": pending_list(),
                     "manual": {"res": _load(F_MAN, {}), "busy": MSTATE["busy"], "prog": MSTATE["prog"], "err": MSTATE["err"],
                                "defaults": clean_params({})}}
    if path == "/api/escaner_scan":
        if STATE["busy"]:
            return 200, {"error": "Ya hay un escaneo en curso"}
        threading.Thread(target=scan, args=(env, None), daemon=True).start()
        return 200, {"ok": True}
    if path == "/api/escaner_pend":
        try:
            return 200, {"pend": pending_update(body or {})}
        except ValueError as e:
            return 200, {"error": str(e)}
    if path == "/api/escaner_manual":
        if MSTATE["busy"]:
            return 200, {"error": "Ya hay una búsqueda manual en curso"}
        try:
            prm = clean_params(body.get("params") or {})
        except ValueError as e:
            return 200, {"error": str(e)}
        syms = [x.strip().upper() for x in (body.get("symbols") or []) if isinstance(x, str) and x.strip()]
        bad = [x for x in syms if not SYM_RE.match(x)]
        if bad:
            return 200, {"error": "Símbolos no válidos: " + ", ".join(bad[:5])}
        threading.Thread(target=scan_manual, args=(env, prm, syms or None), daemon=True).start()
        return 200, {"ok": True}
    if path == "/api/escaner_lista":
        try:
            return 200, {"lista": set_list(body.get("symbols") or [])}
        except ValueError as e:
            return 200, {"error": str(e)}
    return 404, {"error": "No encontrado"}


PAGE = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Escáner · LV Options Terminal</title><style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:14px -apple-system,BlinkMacSystemFont,sans-serif;padding:16px 24px;max-width:2000px;margin:0 auto}
a{color:var(--cy);text-decoration:none;font-weight:700}h1{font:700 17px ui-monospace,Menlo,monospace;margin:4px 0}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:14px 16px;margin-bottom:12px}
.lbl{color:var(--mut);font-size:11px;letter-spacing:.08em;margin-bottom:8px}.mono{font-family:ui-monospace,Menlo,monospace}
.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}.warn{color:var(--warn)}
table{width:100%;border-collapse:collapse;font-size:12.5px}th{color:var(--mut);text-align:right;padding:5px 6px;font-weight:600;white-space:nowrap}
td{padding:7px 6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
button,.btn{background:var(--card);color:var(--cy);border:1px solid var(--cy);border-radius:8px;padding:5px 10px;font-weight:700;font-size:12px;cursor:pointer;display:inline-block}
button.g{color:var(--mut);border-color:var(--line)}
.pill{display:inline-block;border-radius:99px;padding:2px 9px;font-size:11px;font-weight:800}
.pg{background:rgba(79,240,183,.15);color:var(--ok)}.py{background:rgba(255,192,77,.15);color:var(--warn)}.pr{background:rgba(255,93,108,.15);color:var(--bad)}
.tl{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.tl div{border:1px solid var(--line);border-radius:10px;padding:10px;background:#0a0a0d;font-size:12px;line-height:1.45}.tl b{display:block;color:var(--cy);margin-bottom:4px}
textarea{width:100%;height:90px;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px;font:12px ui-monospace,Menlo,monospace}
@media(max-width:900px){.tl{grid-template-columns:1fr}}
</style></head><body>
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px">
 <h1>🔭 ESCÁNER DE SWING · Put Credit Spread a ~45 días</h1><div class="mono" style="font-size:12px"><a href="/">← Inicio</a></div></div>
<div class="card"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span class="mut mono" id="meta" style="font-size:12px"></span><button onclick="scanNow()" id="bscan">⟳ Escanear ahora</button><button class="g" onclick="$('lst').style.display=$('lst').style.display==='none'?'block':'none'">✎ Mi lista de acciones</button><span class="mono" id="mkt" style="font-size:12px"></span><span class="mono" id="prog" style="font-size:12px;color:var(--warn)"></span></div>
 <div id="lst" style="display:none;margin-top:10px"><div class="mut" style="font-size:12px;margin-bottom:6px">Una acción o ETF por espacio o línea (máx. 300). El escáner revisa su gráfico diario.</div><textarea id="lsta"></textarea><div style="margin-top:6px"><button onclick="saveList()">Guardar lista</button> <span id="lmsg" class="mono" style="font-size:12px"></span></div></div></div>
<div class="card"><div class="lbl">CÓMO TRABAJA</div><div class="tl">
 <div><b>① Después del cierre (16:40 ET)</b>Baja las velas diarias de toda tu lista y calcula SMA 50, MACD, RSI y volumen. Es la revisión pesada: una vez al día. Si abres el panel más tarde, se pone al día sola.</div>
 <div><b>② Durante el día (cada 5 min)</b>Solo actualiza el precio de los candidatos (una consulta para toda la lista). Una acción "cerca" que cruza en vivo te avisa; se confirma con el cierre.</div>
 <div><b>③ Aviso</b>Sonido y aviso en pantalla (y los canales de aviso que tengas configurados, como macOS o Telegram) cuando aparece una señal verde nueva.</div>
 <div><b>④ Tú decides</b>"Abrir spread" carga el constructor de Trading manual con las patas propuestas y tus reglas de salida. El escáner nunca envía órdenes.</div></div></div>
<div class="card" id="pendcard" style="border-left-color:#4ff0b7;display:none"><div class="lbl">📝 ENTRADAS LISTAS PARA CONFIRMAR · señales verdes nuevas con su put credit spread armado</div>
 <div class="mut" style="font-size:12px;margin-bottom:6px" id="pendacct"></div>
 <div style="overflow-x:auto"><table><thead><tr><th>Acción</th><th>Señal</th><th>Spread</th><th>Vence</th><th>Crédito (al armarla)</th><th>Máx. pérdida</th><th>Gestor</th><th>Contratos</th><th>Estado</th><th></th></tr></thead><tbody id="pendrows"></tbody></table></div>
 <div class="mut" style="font-size:11px;margin-top:6px">Nada se envía solo. Al confirmar, el panel actualiza el precio, hace la vista previa con Tradier y te pide el Sí final. La orden va a la cuenta que tengas en el botón PAPEL / REAL de arriba. Una señal de más de 3 días hábiles queda como vencida.</div></div>
<div class="card" style="border-left-color:#ffd23f"><div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><div class="lbl" style="margin:0">🔧 BÚSQUEDA MANUAL · prueba tus variantes (no cambia Candidatos ni el modo sombra)</div><button class="g" onclick="$('mform').style.display=$('mform').style.display==='none'?'block':'none'">⚙ Criterios</button></div>
 <div id="mform" style="margin-top:10px">
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px" id="mfields"></div>
  <div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:10px;font-size:12px" id="mreq"></div>
  <div style="margin-top:8px"><label class="mut" style="font-size:12px">Acciones a revisar (vacío = tu lista)</label><input id="msyms" placeholder="Ej.: AAPL NVDA AMD XLE" style="width:100%;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:7px;font:12px ui-monospace,Menlo,monospace"></div>
  <div style="display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap"><button onclick="mRun()" id="mbtn">🔍 Buscar con estos criterios</button><button class="g" onclick="mFill(MDEF)">↺ Valores normales</button><span class="mono" id="mprog" style="font-size:12px"></span></div>
 </div>
 <div class="mut mono" id="mmeta" style="font-size:12px;margin-top:10px"></div>
 <div style="overflow-x:auto;margin-top:6px"><table><thead><tr><th>Acción</th><th>Estado</th><th>Precio</th><th>vs SMA 50</th><th>Cruce</th><th>Volumen</th><th>MACD</th><th>RSI</th><th>Tendencia</th><th>vs SPY 60d</th><th>Earnings</th><th>Filtros</th><th>Spread propuesto</th><th>Crédito</th><th>Máx. pérdida</th><th></th></tr></thead><tbody id="mrows"></tbody></table></div>
 <div class="mut" style="font-size:11px;margin-top:6px">Los resultados manuales son solo para explorar: no avisan, no se siguen en el modo sombra y no reemplazan los Candidatos. La primera búsqueda del día baja las velas; las siguientes usan las mismas y son mucho más rápidas.</div></div>
<div class="card"><div class="lbl">CANDIDATOS · los que cumplen más filtros primero</div><div style="overflow-x:auto"><table><thead><tr><th>Acción</th><th>Estado</th><th>Precio</th><th>vs SMA 50</th><th>Cruce</th><th>Volumen</th><th>MACD</th><th>RSI</th><th>Tendencia</th><th>vs SPY 60d</th><th>Earnings</th><th>Filtros</th><th>Spread propuesto</th><th>Crédito</th><th>Máx. pérdida</th><th></th></tr></thead><tbody id="rows"><tr><td colspan="16" class="mut">Cargando…</td></tr></tbody></table></div>
 <div class="mut" style="font-size:11px;margin-top:8px">Filtros (7 puntos): cruce reciente (≤3 días, SMA 50 no bajista y precio a menos de 5% sobre ella) · volumen ≥ 1.2× el promedio · MACD alcista · RSI entre 50 y 70 · sin reporte de resultados antes del vencimiento · tendencia de fondo (precio sobre o cerca de su SMA 200, que no caiga) · fuerza relativa (rinde más que SPY en 60 velas). Además, si SPY está bajo su SMA 50 ninguna señal sale verde (mercado débil). Spread: vencimiento más cercano a 45 días, put vendido de delta ~0.25, crédito ≥ 25% del ancho.</div></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px" id="bot2">
<div class="card" style="border-left-color:var(--ok)"><div class="lbl">TU META DE SALIDA · no esperar los 45 días</div><div style="line-height:1.55;font-size:13px">"Abrir spread" deja el gestor listo con:<br>• <b class="ok">Tomar ganancia al 50% del crédito</b> (lo cambias a 25% si prefieres) · cierra solo.<br>• <b class="bad">Stop</b> cuando la pérdida iguala el crédito cobrado (el spread vale 2× el crédito).<br>Puedes ajustar ambos antes de enviar la orden.</div></div>
<div class="card" style="border-left-color:var(--warn)"><div class="lbl">MODO SOMBRA · ¿el método funciona?</div><div style="font-size:13px" id="sombra">…</div></div></div>
<script>
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ST={senal:'<span class="pill pg">🟢 SEÑAL</span>',falta:'<span class="pill py">🟡 FALTA</span>',cerca:'<span class="pill py">🟡 CERCA</span>',descartada:'<span class="pill pr">🔴 DESCARTADA</span>'};
function dots(r){const n=r.dots||0,c=r.estado==="senal"?"ok":r.estado==="descartada"?"bad":"warn";return '<span class="'+c+'" style="letter-spacing:2px">'+"●".repeat(n)+"○".repeat(7-n)+"</span>"}
function earnCell(r){if(r.earn_bad)return '<span class="bad">'+esc(r.earn)+" ✖ antes del venc.</span>";if(r.earn)return '<span class="ok">'+esc(r.earn)+" ✔ fuera</span>";if(r.estado==="cerca"||r.estado==="falta")return '<span class="mut">–</span>';return '<span class="warn">⚠ sin dato: verifícalo</span>'}
function spreadCells(r){const s=r.spread;if(!s)return '<td class="mut" style="text-align:left">'+esc(r.motivo||(r.spread_err?"⚠ No pude proponer el spread: "+r.spread_err+". Puedes armarlo tú con el botón.":""))+'</td><td>–</td><td>–</td>';
  return '<td class="mono">Vende '+s.short+' Put · Compra '+s.long+' Put <span class="mut">(Δ .'+String(Math.round(s.delta*100)).padStart(2,"0")+" · "+s.dte+' días · '+s.exp+')</span>'+(s.low_credit?' <span class="warn">crédito bajo</span>':"")+(s.liquid?"":' <span class="warn">poca liquidez</span>')+'</td><td class="mono ok">$'+s.credit.toFixed(2)+' <span class="mut">('+s.ratio+'% del ancho)</span></td><td class="mono bad">-$'+s.max_loss+"</td>"}
function openBtn(r){const s=r.spread;if(!s){if(r.estado!=="senal"||!r.exp_hint)return"";return '<a class="btn" href="/trade#pcs='+[r.sym,r.exp_hint,0,r.price>=100?5:r.price>=40?2:1,0,0,0].join("|")+'" title="Abre el constructor con el vencimiento a ~45 días y el put de delta ~0.25; tú revisas">Abrir (armar yo)</a>'}return '<a class="btn" href="/trade#pcs='+[r.sym,s.exp,s.short,s.width,s.credit,s.tp,s.stop].join("|")+'">Abrir spread</a>'}
function rowHtml(r){return '<tr><td><b>'+esc(r.sym)+'</b></td><td>'+ST[r.estado]+'</td><td class="mono">'+r.price.toFixed(2)+(r.live?'<br><span class="mut" style="font-size:10px">ahora '+r.live.toFixed(2)+'</span>':"")+'</td><td class="mono '+(r.vs>=0?"ok":"bad")+'">'+(r.vs>=0?"+":"")+r.vs+'%</td><td>'+(r.age==null?"por debajo":r.age===0?"hoy ↑":"hace "+r.age+" d ↑")+'</td><td class="mono '+(r.vol_ratio!=null&&r.vol_ratio>=1.2?"ok":"mut")+'">'+(r.vol_ratio==null?"–":r.vol_ratio+"× prom.")+'</td><td>'+esc(r.macd)+'</td><td class="mono">'+r.rsi+'</td><td class="'+(r.trend_ok===false?"bad":r.trend_ok?"ok":"mut")+'" style="font-size:12px">'+esc(r.trend||"–")+'</td><td class="mono '+(r.rs==null?"mut":r.rs>0?"ok":"bad")+'">'+(r.rs==null?"–":(r.rs>0?"+":"")+r.rs+"%")+'</td><td>'+earnCell(r)+'</td><td>'+dots(r)+'</td>'+spreadCells(r)+'<td>'+openBtn(r)+'</td></tr>'}
function seen(){try{return JSON.parse(localStorage.getItem("esc_seen")||"[]")}catch(e){return[]}}
async function load(){
  const j=await (await fetch("/api/escaner",{cache:"no-store"})).json();const res=j.res||{rows:[]};
  const mk=res.mercado;$("mkt").innerHTML=mk?'<span class="'+(mk.ok?"ok":"bad")+'">'+(mk.ok?"🟢 Mercado a favor":"🔴 Mercado débil: sin señales verdes")+'</span> · <span class="mut">'+esc(mk.txt||"")+'</span>':"";
  $("meta").textContent=res.ts?("Lista: "+(res.total||j.lista.length)+" acciones · Último escaneo: "+new Date(res.ts*1000).toLocaleString("es")+" ("+(res.base||"")+") · datos "+(res.src==="live"?"en vivo":"del sandbox")+(res.live_ts?" · precios: "+new Date(res.live_ts*1000).toLocaleTimeString("es"):"")):"Aún no hay escaneo. Se hace solo a las 16:40 (ET) o pulsa «Escanear ahora».";
  $("prog").textContent=j.busy?(j.prog||"Escaneando…"):(j.err?"Error: "+j.err:"");$("bscan").disabled=j.busy;
  if(document.activeElement!==$("lsta")&&!$("lsta").dataset.d){$("lsta").value=j.lista.join(" ");}
  mPaint(j.manual);pendPaint(j.pend);
  const R=res.rows||[];
  $("rows").innerHTML=R.length?R.map(rowHtml).join(""):'<tr><td colspan="16" class="mut">Sin candidatos todavía.</td></tr>';
  const s=j.sombra||{};$("sombra").innerHTML=s.n?('Señales verdes seguidas: <b>'+s.n+'</b> ('+s.abiertas+' abiertas).<br>Llegaron al 25% del crédito: <b>'+s.n25+'</b>'+(s.med25!=null?" (mediana "+s.med25+" días hábiles)":"")+' · al 50%: <b>'+s.n50+'</b>'+(s.med50!=null?" (mediana "+s.med50+" días)":"")+'<br>Tocaron el strike vendido: <b>'+s.tocaron+'</b> · Perdieron el crédito completo: <b>'+s.stops+'</b><div class="mut" style="font-size:11px;margin-top:6px">Es seguimiento teórico a precio medio, no son operaciones tuyas. Con pocas señales no prueba nada.</div>'):'Todavía no hay señales verdes guardadas. Cada una que aparezca se sigue sola y aquí verás cuántas llegan al 25% y 50% del crédito, y en cuántos días.';
  const now=R.filter(r=>r.estado==="senal").map(r=>r.sym),old=seen();const nuevas=now.filter(x=>!old.includes(x));
  if(nuevas.length&&old.length+1&&window.evAlert&&localStorage.getItem("esc_init")){window.evAlert("🔭 Escáner: señal verde\n"+nuevas.join(", "),"ok")}
  try{localStorage.setItem("esc_seen",JSON.stringify(now));localStorage.setItem("esc_init","1")}catch(e){}
}
async function scanNow(){const j=await (await fetch("/api/escaner_scan",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json();if(j.error)$("prog").textContent=j.error;setTimeout(load,800)}
$("lsta").addEventListener("input",()=>{$("lsta").dataset.d="1"});
async function saveList(){const sy=$("lsta").value.split(/[\s,;]+/).filter(Boolean);const j=await (await fetch("/api/escaner_lista",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({symbols:sy})})).json();
  $("lmsg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">✓ Guardada ('+j.lista.length+' símbolos). Se usa en el próximo escaneo.</span>';if(!j.error)delete $("lsta").dataset.d}

/* ===== busqueda manual ===== */
let MDEF=null,MINIT=false;
const MF=[["cross_days","Cruce hace máx. (días)",1],["ma","Media móvil (días)",1],["max_ext","Máx. % sobre la media",0.5],["vol_min","Volumen mín. (× promedio)",0.1],
  ["rsi_lo","RSI mínimo",1],["rsi_hi","RSI máximo",1],["near_pct","«Cerca» a menos de %",0.1],["dte_target","Días al vencimiento",1],
  ["delta_target","Delta del put vendido",0.01],["min_ratio","Crédito mín. (fracción del ancho)",0.01]];
const MR=[["vol","Volumen"],["macd","MACD"],["rsi","RSI"],["trend","Tendencia SMA 200"],["rs","Fuerza vs SPY"],["mkt","Mercado (SPY sobre SMA 50)"],["earn","Sin earnings antes del vencimiento"]];
function mFill(p){if(!p)return;$("mfields").innerHTML=MF.map(([k,l,st])=>'<div><label class="mut" style="font-size:11px">'+l+'</label><input type="number" id="mf_'+k+'" step="'+st+'" value="'+p[k]+'" style="width:100%;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px;font:13px ui-monospace,Menlo,monospace"></div>').join("");
  $("mreq").innerHTML='<span class="mut">Exigir:</span>'+MR.map(([k,l])=>'<label style="display:flex;gap:5px;align-items:center"><input type="checkbox" id="mr_'+k+'" '+(p["req_"+k]?"checked":"")+'> '+l+'</label>').join("")}
async function mRun(){const prm={};for(const [k] of MF)prm[k]=+$("mf_"+k).value;for(const [k] of MR)prm["req_"+k]=$("mr_"+k).checked;
  const sy=$("msyms").value.split(/[\s,;]+/).filter(Boolean);
  const j=await (await fetch("/api/escaner_manual",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({params:prm,symbols:sy})})).json();
  $("mprog").innerHTML=j.error?'<span class="bad">'+esc(j.error)+'</span>':"Buscando…";setTimeout(load,800)}
function mPaint(m){if(!m)return;MDEF=m.defaults;const r=m.res||{};
  if(!MINIT){mFill(r.params||m.defaults);MINIT=true}
  $("mprog").innerHTML=m.busy?esc(m.prog||"Buscando…"):(m.err?'<span class="bad">Error: '+esc(m.err)+'</span>':"");$("mbtn").disabled=m.busy;
  const R=r.rows||[];
  if(r.ts){const p=r.params||{},on=MR.filter(([k])=>p["req_"+k]).map(([,l])=>l);
    $("mmeta").textContent="Última búsqueda: "+new Date(r.ts*1000).toLocaleString("es")+" · "+(r.total||0)+" acciones"+(r.custom_list?" (lista propia)":"")+" · cruce ≤"+p.cross_days+"d sobre SMA "+p.ma+" · volumen ≥"+p.vol_min+"× · RSI "+p.rsi_lo+"–"+p.rsi_hi+" · "+p.dte_target+" días · delta "+p.delta_target+" · exige: "+(on.join(", ")||"nada");
    $("mrows").innerHTML=R.length?R.map(rowHtml).join(""):'<tr><td colspan="16" class="mut">Ninguna acción cumple estos criterios.</td></tr>'}
  else{$("mmeta").textContent="Todavía no has hecho una búsqueda manual.";$("mrows").innerHTML=""}}

/* ===== entradas listas para confirmar ===== */
let PEND=[];
function pendPaint(list){PEND=list||[];const c=$("pendcard");if(!c)return;c.style.display=PEND.length?"":"none";
  $("pendacct").innerHTML=window.LIVE?'<b style="color:#ff9f43">🔴 Cuenta REAL: al confirmar se usa dinero real.</b>':'🧪 Cuenta de PAPEL (práctica). Cambia a REAL con el botón de arriba si quieres operar en real.';
  const ST={pendiente:'<span class="pill pg">lista</span>',enviada:'<span class="pill pg">✔ enviada</span>',descartada:'<span class="pill pr">descartada</span>',vencida:'<span class="pill py">vencida</span>'};
  $("pendrows").innerHTML=PEND.map((x,i)=>'<tr><td><b>'+esc(x.sym)+'</b><br><span class="mut" style="font-size:10px">'+esc(x.fecha)+'</span></td><td class="mono">'+x.price.toFixed(2)+(x.earn_known?"":' <span class="warn">⚠ verifica earnings</span>')+'</td>'
    +'<td class="mono">Vende '+x.short+' Put · Compra '+x.long+' Put<br><span class="mut">Δ '+x.delta+' · ancho $'+x.width+'</span></td><td class="mono">'+esc(x.exp)+' <span class="mut">('+x.dte+'d)</span></td>'
    +'<td class="mono ok">$'+x.credit.toFixed(2)+'</td><td class="mono bad">$'+x.max_loss+'</td><td class="mono" style="font-size:11px">objetivo +$'+x.tp+'<br>stop −$'+x.stop+'</td>'
    +'<td>'+(x.status==="pendiente"?'<input type="number" id="pq_'+i+'" min="1" max="10" value="1" style="width:56px;background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:6px;padding:4px">':(x.order?'<span class="mono mut">#'+esc(x.order)+'</span>':"–"))+'</td>'
    +'<td>'+(ST[x.status]||esc(x.status))+'</td><td>'+(x.status==="pendiente"?'<button onclick="pendConfirm('+i+')">✅ Confirmar</button> <button class="g" onclick="pendDrop('+i+')">Descartar</button>':"")+'</td></tr>').join("")}
async function pendPost(b){return (await fetch("/api/escaner_pend",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)})).json()}
async function pendDrop(i){const x=PEND[i];if(!x||!confirm("¿Descartar la entrada de "+x.sym+"?"))return;const j=await pendPost({id:x.id,action:"descartar"});if(j.error)alert(j.error);else pendPaint(j.pend)}
const jpost=async(u,b)=>(await fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)})).json();
async function pendConfirm(i){const x=PEND[i];if(!x)return;
  const q=Math.max(1,Math.min(10,Math.floor(+($("pq_"+i)||{}).value||1)));
  // 1) precio de ahora
  const ch=await (await fetch("/api/chain?exp="+encodeURIComponent(x.exp)+"&sym="+encodeURIComponent(x.sym),{cache:"no-store"})).json();
  if(ch.error){alert("No pude leer la cadena de opciones: "+ch.error);return}
  const S=(ch.options||[]).find(o=>o.occ===x.short_occ),L=(ch.options||[]).find(o=>o.occ===x.long_occ);
  if(!S||!L||S.bid==null||S.ask==null||L.bid==null||L.ask==null){alert("No encontré precios actuales de esas opciones. Ábrela con «Abrir spread» en Candidatos y ármala en Trading manual.");return}
  const price=Math.round(((S.bid+S.ask)/2-(L.bid+L.ask)/2)*100)/100;
  if(!(price>0)){alert("El crédito actual no es positivo ("+price+"). Hoy no conviene: descártala o revísala a mano.");return}
  const body={symbol:x.sym,type:"credit",qty:q,price:price,legs:[{occ:x.short_occ,side:"sell_to_open"},{occ:x.long_occ,side:"buy_to_open"}]};
  // 2) vista previa en Tradier
  const pv=await jpost("/api/preview",body);
  if(pv.error){alert("✖ Vista previa rechazada: "+pv.error);return}
  const o=pv.preview||{},info=[["order_cost","Costo"],["margin_change","Cambio de margen"],["commission","Comisión"],["fees","Tarifas"]].filter(([k])=>o[k]!==undefined).map(([k,n])=>n+": "+o[k]).join("\n");
  const tp=Math.max(1,Math.round(price*100*0.5)),st=Math.max(1,Math.round(price*100));
  const cfg={unit:"usd",stop_usd:st,tp_usd:tp,at_target:"close",trail_usd:10,time_exit:"15:30"};
  const txt="¿Enviar esta entrada?\n\n"+x.sym+" · Put credit spread · vence "+x.exp+"\nVende "+x.short+" Put · Compra "+x.long+" Put\n"+q+" contrato(s) · crédito límite $"+price.toFixed(2)+(Math.abs(price-x.credit)>=0.01?" (al armarla era $"+x.credit.toFixed(2)+")":"")
    +"\nPérdida máxima: $"+Math.round((x.width-price)*100*q)+"\n\n✔ Vista previa correcta"+(info?"\n"+info:"")+"\n\n🤖 Gestor: objetivo +$"+tp+"/contrato (orden límite) · stop −$"+st+"/contrato";
  const g=window.guard?await window.guard(txt):(confirm(txt)?{}:null);if(!g)return;
  // 3) envio
  const j=await jpost("/api/order",Object.assign({},body,{managed:true,mgr_cfg:cfg},g));
  if(j.error){alert("✖ "+j.error);return}
  const oid=(j.order||{}).id||"";const u=await pendPost({id:x.id,action:"enviada",order:oid,price,live:!!window.LIVE});
  alert("✔ Orden enviada (#"+oid+")."+(j.managed?" 🤖 El gestor la vigilará en cuanto se ejecute.":"")+" Revísala en Trading manual → Órdenes.");if(!u.error)pendPaint(u.pend)}
load();setInterval(load,15000);
</script></body></html>"""
