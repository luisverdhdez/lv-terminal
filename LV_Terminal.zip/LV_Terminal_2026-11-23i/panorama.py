"""
Bloques extra de Market → Resumen:
  - Bonos del Tesoro: curva OFICIAL diaria (archivo publico de home.treasury.gov) + ultimo dato CBOE (^FVX, ^TNX, ^TYX via Yahoo).
  - Tecnologicas populares y materias primas: Tradier (materias primas = precio de su ETF, no del contrato).
  - Divisas: Yahoo Finance (endpoint no oficial; Tradier no da divisas).
Todo con cache para no saturar a nadie. Si una fuente falla, ese bloque muestra el error y los demas siguen.
"""
import csv
import io
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, date, timedelta

import requests

import trading

UA = {"User-Agent": "Mozilla/5.0"}
_C, _L = {}, threading.RLock()


def _num(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _cached(key, ttl, fn):
    with _L:
        c = _C.get(key)
        if c and time.time() - c[0] < ttl:
            return c[1]
    v = fn()
    with _L:
        _C[key] = (time.time(), v)
    return v


# ───────────── periodos ─────────────
PERIODS = {"1D": 1, "1W": 5, "1M": 21, "3M": 63, "1Y": 252}


def periods(closes, last, today):
    """closes: [(fecha, cierre)] diarios. Devuelve {periodo: {"pct", "spark"}} usando `last` como precio actual."""
    cs = [(d, c) for d, c in closes if d < today and c]
    out = {}
    if not cs or not last:
        return out
    for k, n in PERIODS.items():
        if len(cs) >= n:
            seg = [c for _, c in cs[-n:]]
            base = seg[0] if k != "1D" else cs[-1][1]
            sp = [c for _, c in cs[-max(n, 10):]] + [last]
            if len(sp) > 60:
                step = len(sp) / 60
                sp = [sp[int(i * step)] for i in range(60)] + [last]
            out[k] = {"pct": round((last / base - 1) * 100, 2), "spark": [round(x, 4) for x in sp]}
    py = [c for d, c in cs if d < f"{today[:4]}-01-01"]
    if py:
        ytd = [c for d, c in cs if d >= f"{today[:4]}-01-01"]
        out["YTD"] = {"pct": round((last / py[-1] - 1) * 100, 2), "spark": [round(x, 4) for x in ([py[-1]] + ytd)[-60:] + [last]]}
    return out


# ───────────── Yahoo (divisas y CBOE) ─────────────
def _yahoo(sym):
    r = requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}", params={"range": "1y", "interval": "1d"},
                     headers=UA, timeout=10)
    r.raise_for_status()
    res = ((r.json().get("chart") or {}).get("result") or [None])[0]
    if not res:
        raise ValueError("sin datos")
    meta = res.get("meta") or {}
    ts = res.get("timestamp") or []
    cl = (((res.get("indicators") or {}).get("quote") or [{}])[0].get("close")) or []
    closes = [(datetime.utcfromtimestamp(t).strftime("%Y-%m-%d"), _num(c)) for t, c in zip(ts, cl) if _num(c) is not None]
    last = _num(meta.get("regularMarketPrice"))
    mt = meta.get("regularMarketTime")
    today = datetime.utcfromtimestamp(mt).strftime("%Y-%m-%d") if mt else datetime.utcnow().strftime("%Y-%m-%d")
    return {"last": last, "closes": closes, "today": today, "time": mt}


def _many_yahoo(syms):
    def one(s):
        try:
            return s, _cached(("y", s), 300, lambda: _yahoo(s))
        except Exception as e:
            return s, {"error": e.__class__.__name__}
    with ThreadPoolExecutor(max_workers=6) as ex:
        return dict(ex.map(one, syms))


# ───────────── Bonos del Tesoro ─────────────
TSY_URL = ("https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/{y}/all"
           "?type=daily_treasury_yield_curve&field_tdr_date_value={y}&page&_format=csv")
TENORS = [("1M", "1 Mo"), ("3M", "3 Mo"), ("6M", "6 Mo"), ("1Y", "1 Yr"), ("2Y", "2 Yr"), ("5Y", "5 Yr"), ("10Y", "10 Yr"), ("30Y", "30 Yr")]
CBOE = [("5Y", "^FVX"), ("10Y", "^TNX"), ("30Y", "^TYX")]


def _tsy_year(y):
    r = requests.get(TSY_URL.format(y=y), headers=UA, timeout=25)
    r.raise_for_status()
    rows = []
    for row in csv.DictReader(io.StringIO(r.text.lstrip("﻿"))):
        raw = (row.get("Date") or "").strip()
        try:
            d = datetime.strptime(raw, "%m/%d/%Y").date().isoformat()
        except ValueError:
            try:
                d = date.fromisoformat(raw).isoformat()
            except ValueError:
                continue
        v = {t: _num(row.get(col)) for t, col in TENORS}
        if v["10Y"] is not None:
            rows.append(dict(v, d=d))
    return rows


def _at_or_before(rows, d):
    c = [r for r in rows if r["d"] <= d]
    return c[-1] if c else None


def treasury():
    y = date.today().year
    rows = []
    for yy in (y - 1, y):
        try:
            rows += _cached(("tsy", yy), 6 * 3600 if yy == y else 7 * 86400, lambda yy=yy: _tsy_year(yy))
        except Exception as e:
            if yy == y:
                raise RuntimeError(f"No pude bajar la curva del Tesoro ({e.__class__.__name__})")
    rows = sorted({r["d"]: r for r in rows}.values(), key=lambda r: r["d"])
    if not rows:
        raise RuntimeError("El Tesoro no devolvió datos")
    cur = rows[-1]
    ld = date.fromisoformat(cur["d"])
    mon = _at_or_before(rows, (ld - timedelta(days=30)).isoformat())
    yr = _at_or_before(rows, (ld - timedelta(days=365)).isoformat())
    prev = rows[-2] if len(rows) > 1 else None

    def bp(a, b):
        return None if a is None or b is None else round((a - b) * 100)
    curve = [{"t": t, "v": cur[t], "m": mon and mon[t], "y": yr and yr[t], "d1": bp(cur[t], prev and prev[t]), "dm": bp(cur[t], mon and mon[t])} for t, _ in TENORS]
    spreads = {"10Y-2Y": bp(cur["10Y"], cur["2Y"]), "30Y-2Y": bp(cur["30Y"], cur["2Y"]), "10Y-3M": bp(cur["10Y"], cur["3M"])}
    s102 = [{"d": r["d"], "v": bp(r["10Y"], r["2Y"])} for r in rows if r["d"] > (ld - timedelta(days=365)).isoformat() and r["2Y"] is not None]
    inv_days = sum(1 for x in s102 if x["v"] < 0)
    a, b = spreads["10Y-2Y"], spreads["10Y-3M"]
    if (a is not None and a < 0) or (b is not None and b < 0):
        estado = ("invertida", "Curva invertida", "Algún plazo corto paga más que el de 10 años: históricamente ha precedido recesiones, con meses o años de retraso y no siempre.")
    elif a is not None and abs(a) < 15:
        estado = ("plana", "Curva plana", "Los plazos cortos y largos pagan casi lo mismo: el mercado no ve mucho crecimiento adelante.")
    else:
        estado = ("normal", "Curva normal", "Los plazos largos pagan más que los cortos: expectativa normal de crecimiento.")
    live = []
    for t, s in CBOE:
        try:
            q = _cached(("y", s), 300, lambda s=s: _yahoo(s))
            prevc = [c for d, c in q["closes"] if d < q["today"]]
            last = q["last"]
            live.append({"t": t, "v": round(last, 3) if last else None, "bps": round((last - prevc[-1]) * 100, 1) if last and prevc else None})
        except Exception:
            live.append({"t": t, "v": None, "bps": None})
    return {"fecha": cur["d"], "curve": curve, "spreads": spreads, "estado": estado, "s102": s102, "inv_days": inv_days,
            "fecha_mes": mon and mon["d"], "fecha_ano": yr and yr["d"], "live": live}


# ───────────── Tecnologicas, materias primas (Tradier) ─────────────
TECH = ["NVDA", "TSLA", "SOFI", "AMD", "AMZN", "PLTR", "AAPL", "MSFT", "GOOGL", "META", "AVGO", "NFLX", "COIN"]
COMM = [("Metales", [("Oro", "GLD"), ("Plata", "SLV"), ("Cobre", "CPER"), ("Platino", "PPLT")]),
        ("Energía", [("Petróleo WTI", "USO"), ("Petróleo Brent", "BNO"), ("Gas natural", "UNG")]),
        ("Agricultura", [("Maíz", "CORN"), ("Trigo", "WEAT"), ("Soya", "SOYB"), ("Azúcar", "CANE")])]


def _tr_quotes(env, syms):
    j = trading._call(env, "GET", "/markets/quotes", params={"symbols": ",".join(syms)})
    qs = trading._as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
    return {q.get("symbol"): q for q in qs if isinstance(q, dict)}


def _tr_closes(env, sym):
    start = (datetime.now() - timedelta(days=400)).strftime("%Y-%m-%d")
    j = trading._call(env, "GET", "/markets/history", params={"symbol": sym, "interval": "daily", "start": start})
    h = j.get("history") if isinstance(j, dict) else None
    ds = trading._as_list(h.get("day")) if isinstance(h, dict) else []
    return [(d.get("date"), _num(d.get("close"))) for d in ds if _num(d.get("close")) is not None]


def tech(env):
    def go():
        q = _tr_quotes(env, TECH)
        return [{"sym": s, "last": _num((q.get(s) or {}).get("last")), "pct": _num((q.get(s) or {}).get("change_percentage")),
                 "name": (q.get(s) or {}).get("description") or s} for s in TECH if _num((q.get(s) or {}).get("last"))]
    return {"rows": _cached(("tech", trading.MODE["live"]), 20, go)}


def commodities(env):
    mode = trading.MODE["live"]
    syms = [s for _, g in COMM for _, s in g]
    q = _cached(("cq", mode), 20, lambda: _tr_quotes(env, syms))
    today = datetime.now().strftime("%Y-%m-%d")
    out = []
    for grp, items in COMM:
        rows = []
        for nm, s in items:
            last = _num((q.get(s) or {}).get("last"))
            if not last:
                continue
            try:
                cl = _cached(("ch", s, mode), 1800, lambda s=s: _tr_closes(env, s))
            except trading.ApiError:
                cl = []
            per = periods(cl, last, today)
            p1 = _num((q.get(s) or {}).get("change_percentage"))
            if p1 is not None:
                per.setdefault("1D", {"spark": []})["pct"] = round(p1, 2)
            rows.append({"name": nm, "sym": s, "last": last, "per": per})
        out.append({"grupo": grp, "rows": rows})
    return {"grupos": out}


# ───────────── Divisas (Yahoo) ─────────────
FX_MAJ = [("EUR/USD", "EURUSD=X", -1), ("GBP/USD", "GBPUSD=X", -1), ("USD/JPY", "JPY=X", 1), ("USD/CHF", "CHF=X", 1),
          ("AUD/USD", "AUDUSD=X", -1), ("USD/CAD", "CAD=X", 1), ("NZD/USD", "NZDUSD=X", -1)]
FX_CROSS = [("EUR/GBP", "EURGBP=X", 0), ("EUR/JPY", "EURJPY=X", 0), ("GBP/JPY", "GBPJPY=X", 0)]


def fx():
    data = _many_yahoo([s for _, s, _ in FX_MAJ + FX_CROSS])

    def rows(lst):
        out = []
        for nm, s, usd in lst:
            q = data.get(s) or {}
            if not q.get("last"):
                continue
            out.append({"name": nm, "sym": s, "last": q["last"], "usd": usd, "per": periods(q["closes"], q["last"], q["today"])})
        return out
    maj, cro = rows(FX_MAJ), rows(FX_CROSS)
    dol = {}
    for k in list(PERIODS) + ["YTD"]:
        v = [r["per"][k]["pct"] * r["usd"] for r in maj if k in r["per"]]
        dol[k] = round(sum(v) / len(v), 2) if v else None
    errs = [s for s, q in data.items() if q.get("error")]
    return {"majors": maj, "crosses": cro, "dollar": dol, "errors": errs}


def handle(what, env):
    try:
        if what == "tsy":
            return 200, _cached(("tsyout",), 300, treasury)
        if what == "tech":
            return 200, tech(env)
        if what == "comm":
            return 200, commodities(env)
        if what == "fx":
            return 200, _cached(("fxout",), 120, fx)
    except trading.ApiError as e:
        return 502, {"error": str(e)}
    except Exception as e:
        return 502, {"error": f"{e.__class__.__name__}: {str(e)[:150]}"}
    return 404, {"error": "?"}
