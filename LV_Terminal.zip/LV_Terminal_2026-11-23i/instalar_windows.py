"""Instalacion de LV Options Terminal en WINDOWS (la llama INSTALAR_WINDOWS.bat con doble clic).
Solo hace esto: instala las librerias de Python, copia la terminal a C:\\Users\\TU_USUARIO\\LVTerminal,
la deja abriendo sola al prender la computadora, crea 2 accesos en el Escritorio y la abre en el navegador.
No toca tus claves ni tus datos."""
import os
import shutil
import socket
import subprocess
import sys
import time
import webbrowser

SRC = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.expanduser("~")
DEST = os.path.join(HOME, "LVTerminal")
PORT = 8765


def carpeta(nombre, defecto):
    """Ruta real de Escritorio / Inicio (puede estar en OneDrive)."""
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
        v = os.path.expandvars(winreg.QueryValueEx(k, nombre)[0])
        if os.path.isdir(v):
            return v
    except OSError:
        pass
    return defecto


def ocupado():
    s = socket.socket()
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", PORT)) == 0
    finally:
        s.close()


def main():
    print("\n=== LV Options Terminal - instalacion para Windows ===")
    print("Python:", sys.executable)
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pyw):
        pyw = sys.executable

    print("Instalando librerias (requests, yfinance, numpy, tzdata). Puede tardar 1-2 minutos...")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--upgrade", "--no-warn-script-location",
                        "requests", "yfinance", "numpy", "tzdata"])
    print("Librerias listas." if r.returncode == 0 else "Aviso: algunas librerias no se instalaron; sigo.")

    if os.path.normcase(SRC) != os.path.normcase(DEST):
        os.makedirs(DEST, exist_ok=True)
        malos = []
        for n in os.listdir(SRC):
            if n.upper() == "INSTALAR_WINDOWS.BAT" or n.lower() == "instalar_windows.py":
                continue   # el instalador no hace falta dentro de la terminal
            if n.lower().endswith((".py", ".bat", ".txt")) and os.path.isfile(os.path.join(SRC, n)):
                try:
                    shutil.copy2(os.path.join(SRC, n), os.path.join(DEST, n))
                except OSError:
                    malos.append(n)   # archivo bloqueado (antivirus o abierto): se sigue con lo demas
        if malos:
            print("Aviso: no pude copiar", ", ".join(malos), "(bloqueados); no son necesarios para que funcione, sigo.")
        print("Terminal copiada a:", DEST)
    with open(os.path.join(DEST, "python_path.txt"), "w", encoding="ascii") as f:
        f.write(pyw)

    lanzar = f'@echo off\r\nstart "" "{pyw}" "{os.path.join(DEST, "lanzador.py")}"\r\n'
    startup = carpeta("Startup", os.path.join(os.environ.get("APPDATA", HOME), r"Microsoft\Windows\Start Menu\Programs\Startup"))
    try:
        with open(os.path.join(startup, "LV Terminal.cmd"), "w", encoding="ascii") as f:
            f.write(lanzar)
    except OSError:
        print("Aviso: el antivirus no dejo crear el arranque automatico. Abre la terminal con 'Reiniciar LV Terminal'.")
    print("Listo el arranque automatico (se abre sola al prender la computadora).")
    desk = carpeta("Desktop", os.path.join(HOME, "Desktop"))
    for d in (desk, DEST):   # si el antivirus protege el Escritorio, quedan dentro de la carpeta LVTerminal
        try:
            with open(os.path.join(d, "LV Terminal.url"), "w", encoding="ascii") as f:
                f.write(f"[InternetShortcut]\r\nURL=http://localhost:{PORT}/\r\n")
            with open(os.path.join(d, "Reiniciar LV Terminal.cmd"), "w", encoding="ascii") as f:
                f.write(f'@echo off\r\n"{sys.executable}" "{os.path.join(DEST, "reiniciar_windows.py")}"\r\ntimeout /t 3 >nul\r\n')
            print("Accesos 'LV Terminal' y 'Reiniciar LV Terminal' creados en:", d)
            break
        except OSError:
            print("Aviso: el antivirus no deja crear accesos en", d, "- los pongo en otra carpeta.")

    if not ocupado():
        subprocess.Popen([pyw, os.path.join(DEST, "lanzador.py")], cwd=DEST,
                         creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    print("Abriendo la terminal (espera unos segundos)...")
    for _ in range(45):
        if ocupado():
            webbrowser.open(f"http://localhost:{PORT}/")
            print("\nLISTO. La terminal esta abierta en tu navegador: http://localhost:%d" % PORT)
            print("Siempre arranca en PAPEL. Desde ahora se abre sola al prender la computadora.")
            return
        time.sleep(1)
    print("\nLa terminal no contesto todavia. Abre el archivo", os.path.join(DEST, "panel.log"), "y manda una captura.")


if __name__ == "__main__":
    main()
