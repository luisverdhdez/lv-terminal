"""Grabadora del precio MEDIO de tus posiciones abiertas: cada minuto en horario de mercado guarda el (bid+ask)/2 de cada
pata abierta, en cada cuenta (papel, tu real y la cuenta 2). Con eso el boton 📈 de Posiciones dibuja el P&L real en dolares.
Solo hace consultas (GET); nunca manda ordenes. Archivo: pnl_hist.json."""
import json
import os
import threading
import time
from datetime import datetime

import trading

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pnl_hist.json")
LOCK = threading.RLock()
KEEP_DAYS = 6
ACCTS = {"P": False, "L": True, "H": trading.H}


def _key(live):
    k = trading.akey(live)
    return "H" if k == trading.H else ("L" if k else "P")


def _load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FILE)


def _ready(env, live):
    return all(trading.creds(env, live)[1:])


def record(env, now_ts=None):
    """Una pasada: para cada cuenta configurada, guarda el medio de cada pata abierta."""
    t = int(now_ts or time.time())
    got = {}
    for ak, live in ACCTS.items():
        if not _ready(env, live):
            continue
        try:
            j = trading._call_acct(env, live, "GET", "/accounts/{acct}/positions")
            raw = trading._as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
            occs = [p["symbol"] for p in raw if trading.OCC.match(str(p.get("symbol", ""))) and trading._num(p.get("quantity"))]
            if not occs:
                continue
            q = trading._call_acct(env, live, "GET", "/markets/quotes", params={"symbols": ",".join(occs)})
            for x in trading._as_list((q.get("quotes") or {}).get("quote")):
                b, a = trading._num((x or {}).get("bid")), trading._num((x or {}).get("ask"))
                if b is not None and a is not None and a > 0 and a >= b:
                    got.setdefault(ak, {})[x["symbol"]] = round((b + a) / 2, 3)
        except trading.ApiError:
            continue
    if not got:
        return 0
    lim = t - KEEP_DAYS * 86400
    with LOCK:
        d = _load()
        for ak, mids in got.items():
            acc = d.setdefault(ak, {})
            for occ, m in mids.items():
                acc.setdefault(occ, []).append([t, m])
            for occ in list(acc):
                acc[occ] = [p for p in acc[occ] if p[0] >= lim][-3000:]
                if not acc[occ]:
                    del acc[occ]
        _save(d)
    return sum(len(v) for v in got.values())


def series(live, spec):
    """spec 'OCC*n,...' -> {t: [...], v: [...]} con v = suma de n x medio (+ compra). Solo minutos con TODAS las patas."""
    legs = []
    for part in (spec or "").split(","):
        occ, _, n = part.partition("*")
        try:
            n = int(n)
        except ValueError:
            raise trading.ApiError("Patas no válidas")
        if not trading.OCC.match(occ) or not n:
            raise trading.ApiError("Patas no válidas")
        legs.append((occ, n))
    with LOCK:
        acc = _load().get(_key(live), {})
    maps = [dict((p[0], p[1]) for p in acc.get(occ, [])) for occ, _ in legs]
    if not maps or not all(maps):
        return {"t": [], "v": []}
    ts = sorted(set.intersection(*[set(m) for m in maps]))
    return {"t": ts, "v": [round(sum(n * m[t] for (_, n), m in zip(legs, maps)), 3) for t in ts]}


def loop(get_env):
    last = 0
    while True:
        try:
            now = datetime.now(trading.ET)
            hm = now.strftime("%H:%M")
            if now.weekday() < 5 and "09:30" <= hm <= "16:15" and time.time() - last >= 58:
                last = time.time()
                record(get_env() or {})
        except Exception:
            pass
        time.sleep(5)
