"""Preferencias de las graficas compartidas entre tus computadoras (laptop y Mac mini).

Guarda en prefs.json (en tu Mac mini) los dibujos, indicadores, colores y opciones de las graficas,
para que lo que cambies en una computadora aparezca en la otra. No guarda tokens ni datos de la cuenta.
"""
import json
import os
import re
import threading

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prefs.json")
KEY_RE = re.compile(r"^(dr_|ind_|o_)[A-Za-z0-9_./^\-]{1,40}$|^(dstyle|c_ema|c_sma|w_ema|w_sma|gexh|gexon)$")
MAX_VAL = 200_000
_L = threading.Lock()
_S = {"ver": 0, "data": {}, "loaded": False}


def _load():
    if _S["loaded"]:
        return
    _S["loaded"] = True
    try:
        with open(FILE) as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get("data"), dict):
            _S["data"] = {k: v for k, v in d["data"].items() if KEY_RE.match(k) and isinstance(v, str)}
            _S["ver"] = int(d.get("ver") or 0)
    except (OSError, ValueError, TypeError):
        pass


def get(since=None):
    with _L:
        _load()
        if since is not None and str(since) == str(_S["ver"]):
            return {"ver": _S["ver"], "same": True}
        return {"ver": _S["ver"], "data": dict(_S["data"])}


def put(changes):
    """changes: {clave: texto o null (borrar)}. Devuelve la version nueva."""
    if not isinstance(changes, dict):
        return {"error": "Datos no válidos"}
    with _L:
        _load()
        n = 0
        for k, v in list(changes.items())[:200]:
            if not isinstance(k, str) or not KEY_RE.match(k):
                continue
            if v is None:
                if _S["data"].pop(k, None) is not None:
                    n += 1
            elif isinstance(v, str) and len(v) <= MAX_VAL and _S["data"].get(k) != v:
                _S["data"][k] = v
                n += 1
        if n:
            _S["ver"] += 1
            tmp = FILE + ".tmp"
            with open(tmp, "w") as f:
                json.dump({"ver": _S["ver"], "data": _S["data"]}, f)
            os.replace(tmp, FILE)
        return {"ver": _S["ver"]}
