"""ROBOT DE LINEAS SPY (terminal PRINCIPAL: simulado, papel o CUENTA REAL).

Tu dibujas en la grafica del SPY tres lineas: ENTRADA, STOP y GANANCIA, y el numero de contratos.
- Ganancia arriba y stop abajo  -> alcista -> PUT credit spread 0DTE, venta junto al dinero, 3 puntos de ancho.
- Ganancia abajo y stop arriba  -> bajista -> CALL credit spread 0DTE, igual.
Cuando el precio del SPY toca la ENTRADA, arma el spread y manda la orden; ya dentro, sale cuando el SPY
toca el STOP o la GANANCIA, a la hora de salida, o cuando tu le das "Cerrar ya".

SEGURIDAD (21-nov-2026, aprobado por Luis):
- Modo REAL solo si al crear la operacion escribes "REAL". Tope de contratos = el de tu cuenta real (TRADIER_LIVE_MAX_QTY).
- Los PRECIOS siempre vienen de tu cuenta real (en vivo), aunque la operacion sea simulada o de papel.
- Respeta la pausa de 30 min despues de 2 perdidas seguidas (no entra mientras dure; salir siempre puede).
- Avisa a tu Mac / celular al entrar, al salir y si algo falla con dinero real.
"""
import json
import os
import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import trading
import lineas_alt
import mkt_cal

NY = ZoneInfo("America/New_York")
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lineas.json")
SYM = "SPY"     # 20-nov-2026: Luis lo cambio de SPX a SPY
WIDTH = 3       # alas de 3 puntos (dolares de SPY)
# TODO con orden LIMITE.
# Entrada: empieza en el precio medio y cada 5 s cede 0.05 hasta el natural; en el natural espera 10 s mas y, si no, cancela.
# Salida:  empieza en el medio y cada 5 s paga 0.05 mas; puede pasar del natural (para salir SI o SI) hasta el ancho del spread.
FILL_WAIT, STEP_WAIT, NAT_WAIT, MAX_WAIT = 2, 5, 10, 60
CHASE_MAX = 0.30   # si el mercado se mueve, la entrada puede ceder hasta 0.30 menos que el natural inicial (no mas)
# Forma de ENTRAR (20-nov-2026, Luis: "rapida" por defecto para no perder entradas en un movimiento fuerte)
ENTRY_MODES = {
    "normal": {"name": "Normal", "start": "mid", "step": 5, "chase": 0.30, "natwait": 10},      # empieza en el medio, baja 0.05 cada 5 s
    "rapida": {"name": "Rápida", "start": "nat", "step": 2, "chase": 0.50, "natwait": 6},       # empieza en el natural y lo persigue cada 2 s
    "inmediata": {"name": "Inmediata", "start": "nat-", "step": 2, "chase": 0.50, "natwait": 6},  # un poco abajo del natural: se llena al instante
}
MIN_CREDIT_FRAC = 0.20   # nunca entra cobrando menos del 20% del ancho (en SPY de 3: $0.60)
_L = threading.Lock()
S = {"ops": [], "log": []}
_LOADED = [False]
NOTIFY = [None]   # funcion (titulo, texto) para avisos; la pone loop()
REAL_WORD = "REAL"   # 21-nov-2026: Luis pidio que solo sea la palabra REAL (cada operacion)


def _acct(op):
    """Cuenta de las ORDENES de esta operacion: True = tu cuenta real; False = papel (o simulada)."""
    return op.get("modo") == "real"


def _notify(op, title, txt):
    if op.get("modo") == "real" and NOTIFY[0]:
        try:
            NOTIFY[0](title, txt)
        except Exception:  # noqa: BLE001
            pass


class LineasError(Exception):
    pass


class _Skip(Exception):
    """No entra por ahora (pausa), pero la operacion sigue esperando."""


# ---------------- guardar / cargar ----------------
def _load():
    if _LOADED[0]:
        return
    _LOADED[0] = True
    try:
        with open(FILE) as f:
            d = json.load(f)
        if isinstance(d, dict):
            S["ops"] = d.get("ops") or []
            S["log"] = d.get("log") or []
    except (OSError, ValueError):
        pass


def _save():
    S["ops"] = S["ops"][-60:]
    S["log"] = S["log"][-200:]
    tmp = FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(S, f, indent=1)
    os.replace(tmp, FILE)


def _now():
    return datetime.now(NY)


def _ev(op, txt):
    h = _now().strftime("%H:%M:%S")
    op.setdefault("ev", []).append([h, txt])
    S["log"].append([_now().strftime("%Y-%m-%d ") + h, f"#{op['id']} {txt}"])
    if op.get("modo") == "real" and any(k in txt for k in ("ENTRÓ", "CERRADA", "SALIDA (", "no se llenó", "Tradier", "ya no está", "tocó la entrada")):
        _notify(op, "💵 Robot de líneas SPY (REAL)", txt[:180])


def _num(x):
    try:
        return round(float(x), 2)
    except (TypeError, ValueError):
        return None


# ---------------- crear / cambiar ----------------
def direction(entry, stop, tp):
    if tp > entry > stop:
        return "alcista"
    if tp < entry < stop:
        return "bajista"
    raise LineasError("Las líneas no cuadran: para ALCISTA la ganancia va arriba de la entrada y el stop abajo; "
                      "para BAJISTA, al revés.")


def _hm(x, d):
    x = str(x or d)
    try:
        datetime.strptime(x, "%H:%M")
        return x
    except ValueError:
        raise LineasError("Hora no válida (usa HH:MM, por ejemplo 15:00)")


def create(body, env=None):
    entry, stop, tp = _num(body.get("entry")), _num(body.get("stop")), _num(body.get("tp"))
    if None in (entry, stop, tp):
        raise LineasError("Faltan las tres líneas (entrada, stop y ganancia)")
    try:
        qty = int(body.get("qty"))
    except (TypeError, ValueError):
        raise LineasError("Número de contratos no válido")
    if not 1 <= qty <= trading.MAX_QTY:
        raise LineasError(f"Contratos entre 1 y {trading.MAX_QTY}")
    d = direction(entry, stop, tp)
    mode = body.get("strike") if body.get("strike") in ("otm1", "atm") else "otm1"
    entrada = body.get("entrada") if body.get("entrada") in ENTRY_MODES else "rapida"
    modo = body.get("modo") if body.get("modo") in ("sim", "papel", "real") else "sim"
    sim = modo == "sim"
    if modo == "real":
        if str(body.get("confirm", "")).strip().upper() != REAL_WORD:
            raise LineasError(f'Para operar con DINERO REAL escribe exactamente "{REAL_WORD}"')
        env = env or {}
        if not trading.live_ready(env):
            raise LineasError("No hay cuenta REAL configurada (⚙ Cuentas)")
        mx = trading._int_env(env, "TRADIER_LIVE_MAX_QTY", 3)
        if qty > mx:
            raise LineasError(f"Cuenta REAL: {qty} contratos supera tu tope de {mx}")   # SIMULADO (por defecto): no manda nada a Tradier, llena con los precios REALES
    until, out = _hm(body.get("until"), "15:00"), _hm(body.get("exit"), "15:45")
    if _now().strftime("%Y-%m-%d") in mkt_cal.CERRADO:
        raise LineasError("Hoy es día festivo: la bolsa está cerrada")
    if mkt_cal.temprano(_now()):   # medio dia: la bolsa cierra 1:00 pm
        until, out = min(until, mkt_cal.ENTRADA_TEMPRANO), min(out, mkt_cal.SALIDA_TEMPRANO)
    if out <= until:
        raise LineasError("La hora de salida debe ser después de la hora límite de entrada")
    with _L:
        _load()
        op = {"id": os.urandom(4).hex(), "sym": SYM, "entry": entry, "stop": stop, "tp": tp, "qty": qty,
              "dir": d, "strike": mode, "width": WIDTH, "until": until, "exit": out, "day": _now().strftime("%Y-%m-%d"),
              "status": "esperando", "px_prev": None, "ev": [], "sim": sim, "entrada": entrada, "modo": modo}
        _ev(op, {"sim": "🎮 SIMULADA · ", "papel": "📄 PAPEL · ", "real": "💵 REAL · "}[modo] + f"creada: {d} · entrada {entry} · stop {stop} · ganancia {tp} · {qty} contrato(s) · "
                f"{'PUT' if d == 'alcista' else 'CALL'} credit spread 0DTE de {WIDTH} pts · entrada {ENTRY_MODES[entrada]['name'].lower()} · entra hasta {until}, sale a más tardar {out}")
        S["ops"].append(op)
        _save()
        return op


def update(body):
    with _L:
        _load()
        op = _find(body.get("id"))
        act = body.get("action")
        if act == "cancel":
            if op["status"] != "esperando":
                raise LineasError("Solo se puede cancelar mientras espera la entrada (ya dentro: usa Cerrar ya)")
            op["status"] = "cancelada"
            _ev(op, "cancelada por ti")
        elif act == "close":
            if op["status"] not in ("dentro", "entrando"):
                raise LineasError("No está dentro de una operación")
            if op.get("ext_close"):
                raise LineasError(f"Tienes una orden de salida TUYA pendiente (#{op['ext_close']}) para este spread. "
                                  "Cancélala o ajústala en Trading manual → Órdenes; si la cancelas, el robot vuelve a manejar la salida")
            op["req_close"] = True
            if op.get("exit_err"):   # ya habia fallado: Cerrar ya lo vuelve a intentar (5 intentos mas)
                op.update(exit_err=0, exit_alert=False, t_sync=0)
            _ev(op, "pediste cerrar ya")
        elif act == "set":
            e = _num(body.get("entry")) if body.get("entry") is not None else op["entry"]
            s_ = _num(body.get("stop")) if body.get("stop") is not None else op["stop"]
            t = _num(body.get("tp")) if body.get("tp") is not None else op["tp"]
            if op["status"] not in ("esperando", "dentro"):
                raise LineasError("Ya no se puede cambiar")
            if op["status"] == "dentro" and e != op["entry"]:
                raise LineasError("Ya entró: solo puedes mover el stop y la ganancia")
            if direction(e, s_, t) != op["dir"]:
                raise LineasError("Ese cambio voltea la dirección de la operación: cancélala y crea otra")
            op.update(entry=e, stop=s_, tp=t)
            _ev(op, f"líneas movidas: entrada {e} · stop {s_} · ganancia {t}")
        else:
            raise LineasError("Acción no válida")
        _save()
        return op


def _find(oid):
    for op in S["ops"]:
        if op["id"] == str(oid):
            return op
    raise LineasError("No encontré esa operación")


def state():
    with _L:
        _load()
        today = _now().strftime("%Y-%m-%d")
        ops = [o for o in S["ops"] if o.get("day") == today or o["status"] in ("esperando", "entrando", "dentro", "saliendo")]
        return {"comparacion": lineas_alt.summary(S["ops"]), "ops": ops, "log": S["log"][-30:], "cuenta": "PRINCIPAL"}


# ---------------- precios (siempre EN VIVO de tu cuenta real) y ordenes (a la cuenta de cada operacion) ----------------
def _mkt(env, path, params):
    """Consultas de MERCADO: con tu cuenta real si existe (tiempo real); el sandbox de papel trae ~15 min de retraso."""
    return trading._call_acct(env, bool(trading.live_ready(env)), "GET", path, params, None)


_PX = [0.0, None]


def _price(env):
    try:
        import stream
        stream.want([SYM])
        p = stream.price(SYM, 3.0)
        if p:
            return p
    except Exception:   # noqa: BLE001
        pass
    if time.time() - _PX[0] < 2 and _PX[1]:   # sin streaming: maximo una consulta cada 2 s (no gastar el limite de Tradier)
        return _PX[1]
    try:
        j = _mkt(env, "/markets/quotes", {"symbols": SYM})
        q = (trading._as_list((j.get("quotes") or {}).get("quote")) or [{}])[0]
        _PX[:] = [time.time(), trading._num(q.get("last"))]
        return _PX[1]
    except trading.ApiError:
        return None


def _call(env, method, path, data=None, params=None, op=None):
    return trading._call_acct(env, _acct(op or {}), method, path, params, data)


def _chain_live(env, exp):
    j = _mkt(env, "/markets/options/chains", {"symbol": SYM, "expiration": exp, "greeks": "false"})
    rows = []
    for o in trading._as_list((j.get("options") or {}).get("option")) if isinstance(j.get("options"), dict) else []:
        k = trading._num(o.get("strike"))
        if k is None:
            continue
        rows.append({"occ": o.get("symbol"), "strike": k, "type": "C" if o.get("option_type") == "call" else "P",
                     "bid": trading._num(o.get("bid")), "ask": trading._num(o.get("ask"))})
    return {"options": rows}


def pick(chain_opts, spot, d, mode, width=WIDTH):
    """Elige los strikes: (venta, compra, filas). Alcista = puts; bajista = calls."""
    t = "P" if d == "alcista" else "C"
    rows = {o["strike"]: o for o in chain_opts if o.get("type") == t}
    ks = sorted(rows)
    if not ks:
        raise LineasError("La cadena 0DTE no trajo strikes")
    if mode == "atm":
        short = min(ks, key=lambda k: abs(k - spot))
    elif t == "P":
        below = [k for k in ks if k < spot]
        short = below[-1] if below else ks[0]
    else:
        above = [k for k in ks if k > spot]
        short = above[0] if above else ks[-1]
    long_ = short - width if t == "P" else short + width
    if long_ not in rows:
        raise LineasError(f"No existe el strike {long_:g} para el spread de {width} puntos")
    return short, long_, rows[short], rows[long_]


def _mid(r):
    b, a = trading._num(r.get("bid")), trading._num(r.get("ask"))
    return None if b is None or a is None else (b + a) / 2


def _enter(env, op, spot):
    today = _now().strftime("%Y-%m-%d")
    if op.get("modo") == "real":
        import pausa
        st = pausa.estado(True)
        if st["activa"]:
            raise _Skip(f"pausa activa después de pérdidas seguidas (hasta las {st['hasta']}): no entro con dinero real; si vuelve a tocar la línea después, entro")
    ch = _chain_live(env, today)
    short, long_, rs, rl = pick(ch.get("options") or [], spot, op["dir"], op["strike"])
    ms, ml = _mid(rs), _mid(rl)
    if ms is None or ml is None:
        raise LineasError("Las opciones no tienen bid/ask todavía")
    import math
    credit = round(math.floor((ms - ml) / 0.05 + 1e-9) * 0.05, 2)   # medio, redondeado hacia el lado que se llena
    nat = round((trading._num(rs.get("bid")) or 0) - (trading._num(rl.get("ask")) or 0), 2)
    em = ENTRY_MODES.get(op.get("entrada") or "normal", ENTRY_MODES["normal"])
    minc = round(MIN_CREDIT_FRAC * op["width"], 2)
    if credit < 0.10:
        raise LineasError(f"El crédito es muy chico ({credit:.2f}); no entro")
    if em["start"] != "mid":   # rapida / inmediata: empieza en el natural (o un poco abajo) para no quedarse atras
        start = nat if em["start"] == "nat" else nat - 0.05
        credit = round(min(credit, max(start, minc)), 2)
    if credit < minc:
        raise LineasError(f"El crédito ({credit:.2f}) es menor que el mínimo de seguridad ({minc:.2f} = 20% del ancho); no entro")
    legs = [{"occ": rs["occ"], "side": "sell_to_open"}, {"occ": rl["occ"], "side": "buy_to_open"}]
    if op.get("sim"):
        oid = "SIM"
    else:
        data = trading._build({"symbol": SYM, "type": "credit", "qty": op["qty"], "price": credit, "legs": legs})
        j = _call(env, "POST", "/accounts/{acct}/orders", data=data, op=op)
        oid = str((j.get("order") or {}).get("id") or "")
        if not oid:
            raise LineasError("Tradier no devolvió número de orden: " + str(j)[:120])
    op.update(status="entrando", legs=legs, short=short, long=long_, order_in=oid, limit=credit, nat=max(nat, 0.05),
              t_in=time.time(), t_step=time.time(), spot_in=spot, minc=minc)
    _ev(op, f"tocó la entrada ({spot:.2f}): {('PUT' if op['dir'] == 'alcista' else 'CALL')} credit spread {short:g}/{long_:g} · "
            f"{op['qty']} ctr · orden #{oid} a crédito {credit:.2f} (natural {nat:.2f} · entrada {em['name'].lower()})"
            + (" · PREMARKET (menos liquidez)" if _now().strftime("%H:%M") < "09:30" else ""))


def _nat(env, op):
    """Precios naturales REALES del spread ahora: (credito que te darian al abrir, debito que pagarias al cerrar)."""
    q = _leg_quotes(env, op)
    s_, l_ = q.get(op["legs"][0]["occ"], {}), q.get(op["legs"][1]["occ"], {})
    bs, as_, bl, al = (trading._num(s_.get("bid")), trading._num(s_.get("ask")), trading._num(l_.get("bid")), trading._num(l_.get("ask")))
    if None in (bs, as_, bl, al):
        return None, None
    return round(bs - al, 2), round(as_ - bl, 2)


def _order(env, oid, op=None):
    j = _call(env, "GET", "/accounts/{acct}/orders/" + str(oid), op=op)
    return j.get("order") or {}


def _check_entry(env, op):
    try:   # credito natural de AHORA (en un mercado rapido cambia cada segundo): el limite lo persigue
        nat_now, _ = _nat(env, op)
    except trading.ApiError:
        nat_now = None
    if nat_now is not None:
        op["nat_now"] = nat_now
        em = ENTRY_MODES.get(op.get("entrada") or "normal", ENTRY_MODES["normal"])
        op["floor"] = round(max(min(nat_now, op["nat"]), op["nat"] - em["chase"], op.get("minc", 0.10), 0.10), 2)   # hasta donde puede ceder
    if op.get("sim"):   # simulado: se "llena" cuando tu limite alcanza el credito natural REAL de ese momento
        nat = nat_now
        o = {"status": "filled", "avg_fill_price": -op["limit"]} if nat is not None and op["limit"] <= nat + 1e-9 else {"status": "open"}
    else:
        o = _order(env, op["order_in"], op)
    st = o.get("status")
    if st == "filled":
        px = abs(trading._num(o.get("avg_fill_price")) or op["limit"])
        op.update(status="dentro", credit=round(px, 2))
        lineas_alt.open_alt((lambda path, params: _mkt(env, path, params)), op, op.get("spot_in"), _L, _save)   # sombra: call/put de 100+ dias delta 0.20
        _ev(op, f"ENTRÓ: crédito {px:.2f} (${px * 100 * op['qty']:.0f}). Riesgo máximo ${(op['width'] - px) * 100 * op['qty']:.0f}")
        return
    if st in ("rejected", "canceled", "expired", "error"):
        op["status"] = "error"
        _ev(op, f"Tradier {st} la orden de entrada")
        return
    if op.get("req_close"):
        if not op.get("sim"):
            _call(env, "DELETE", "/accounts/{acct}/orders/" + op["order_in"], op=op)
        op["status"] = "cancelada"
        _ev(op, "cancelada antes de llenarse (Cerrar ya)")
        return
    now = time.time()
    em = ENTRY_MODES.get(op.get("entrada") or "normal", ENTRY_MODES["normal"])
    floor = op.get("floor", max(op["nat"], 0.10))
    at_nat = op["limit"] - 0.05 < floor - 1e-9
    if now - op["t_in"] > MAX_WAIT or (at_nat and now - op["t_step"] > em["natwait"]):
        if not op.get("sim"):
            _call(env, "DELETE", "/accounts/{acct}/orders/" + op["order_in"], op=op)
        op["status"] = "cancelada"
        _ev(op, f"no se llenó ni en el precio natural ({op['limit']:.2f}; natural ahora {op.get('nat_now', op['nat']):.2f}): cancelé la orden (no hay operación)")
    elif now - op["t_step"] > em["step"] and not at_nat:
        # baja 0.05, o de un jalon hasta el natural de ahora si el mercado ya se fue (sin bajar del piso)
        tgt = op["limit"] - 0.05
        nn = op.get("nat_now")
        if nn is not None and nn < op["nat"] - 1e-9 and nn < tgt:   # el mercado se alejo: ir directo al natural de ahora
            tgt = nn
        if em["start"] != "mid" and nn is not None and nn < tgt:   # rapida / inmediata: siempre directo al natural de ahora
            tgt = nn
        op["limit"] = round(max(floor, tgt), 2)
        op["t_step"] = now
        if not op.get("sim"):
            _call(env, "PUT", "/accounts/{acct}/orders/" + op["order_in"], data={"type": "credit", "duration": "day", "price": f"{op['limit']:.2f}"}, op=op)
        _ev(op, f"sin llenar: bajo el crédito a {op['limit']:.2f}")


def _leg_quotes(env, op):
    j = _mkt(env, "/markets/quotes", {"symbols": ",".join(l["occ"] for l in op["legs"])})
    qs = trading._as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
    return {q.get("symbol"): q for q in qs if isinstance(q, dict)}


def _held(env, op):
    """Cuantos spreads quedan de verdad en la cuenta (por si lo cerraste tu desde Tradier)."""
    j = _call(env, "GET", "/accounts/{acct}/positions", op=op)
    ps = trading._as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    q = {p.get("symbol"): trading._num(p.get("quantity")) or 0 for p in ps if isinstance(p, dict)}
    s_, l_ = op["legs"][0]["occ"], op["legs"][1]["occ"]
    return int(min(-q.get(s_, 0), q.get(l_, 0), op["qty"]))


SYNC_EVERY = 6   # s: con el spread dentro, revisa en Tradier si sigue en tu cuenta y si hay una orden de salida TUYA


def _after(o, t0):
    """La orden se creo despues de que entro el robot (para no confundirla con ordenes viejas)."""
    if not t0:
        return True
    try:
        return datetime.fromisoformat(str(o.get("create_date")).replace("Z", "+00:00")).timestamp() >= t0 - 60
    except (TypeError, ValueError):
        return True


def _close_orders(env, op):
    """Ordenes de HOY en tu cuenta que CIERRAN alguna pata de este spread y que NO mando el robot."""
    j = _call(env, "GET", "/accounts/{acct}/orders", op=op)
    raw = trading._as_list((j.get("orders") or {}).get("order")) if isinstance(j.get("orders"), dict) else []
    occs = {l["occ"] for l in op.get("legs") or []}
    mine = {str(x) for x in (op.get("robot_orders") or []) + [op.get("order_in"), op.get("order_out")] if x}
    out = []
    for o in raw:
        if not isinstance(o, dict) or str(o.get("id")) in mine or not _after(o, op.get("t_in")):
            continue
        legs = [l for l in (trading._as_list(o.get("leg")) or ([o] if o.get("option_symbol") else [])) if isinstance(l, dict)]
        if any(l.get("option_symbol") in occs and str(l.get("side", "")).endswith("_to_close") for l in legs):
            out.append(o)
    return out


def _sync(env, op):
    """Solo papel/real (24-nov: la orden de salida manual de Luis choco con la del robot).
    - Si el spread ya NO esta en tu cuenta: lo cerraste tu -> la doy por cerrada (con el precio de tu orden si la encuentro).
    - Si tienes una orden de salida TUYA pendiente: el robot no manda otra encima (Tradier la rechazaria) y espera.
    Devuelve True si la operacion quedo cerrada."""
    op["t_sync"] = time.time()
    n = _held(env, op)
    orders = _close_orders(env, op)
    if n <= 0:
        fills = [o for o in orders if o.get("status") == "filled"]
        px = trading._num(fills[-1].get("avg_fill_price")) if fills else None
        op.update(status="cerrada", reason="cerrada por ti", ext_close=None)
        if px is not None:
            px = abs(px)
            op.update(debit=round(px, 2), pnl=round((op.get("credit", 0) - px) * 100 * op["qty"], 2))
            _ev(op, f"CERRADA por ti (tu orden #{fills[-1].get('id')}): pagaste {px:.2f} · P&L {'+' if op['pnl'] >= 0 else '−'}${abs(op['pnl']):.2f} · el robot ya no hace nada con ella")
        else:
            _ev(op, "CERRADA por ti: el spread ya no está en tu cuenta (no encontré el precio de tu orden) · el robot ya no hace nada con ella")
        lineas_alt.close_alt((lambda path, params: _mkt(env, path, params)), op, _L, _save)
        return True
    pend = [o for o in orders if (o.get("status") or "") not in trading.DONE]
    ext = str(pend[-1].get("id")) if pend else None
    if ext and op.get("ext_close") != ext:
        _ev(op, f"✋ tienes una orden de salida TUYA pendiente (#{ext}) para este spread: el robot NO manda otra encima; "
                "cuando se llene la doy por cerrada. Si la cancelas, el robot vuelve a manejar la salida")
        _notify(op, "✋ Robot de líneas SPY", f"Tienes tu propia orden de salida (#{ext}) para este spread: el robot espera a que se llene.")
    elif not ext and op.get("ext_close"):
        _ev(op, f"tu orden de salida #{op['ext_close']} ya no está pendiente y el spread sigue en tu cuenta: el robot vuelve a manejar la salida")
        op.update(exit_err=0, exit_alert=False)
    op["ext_close"] = ext
    return False


def _exit(env, op, why):
    """Cierra con orden LIMITE de debito: empieza en el precio medio; _check_exit sube 0.05 cada 5 s hasta llenarse."""
    import math
    n = op["qty"] if op.get("sim") else _held(env, op)
    if n <= 0:   # ya no esta en la cuenta: lo cerraste tu (Tradier directo). NO mando nada (abriria una posicion nueva)
        op.update(status="cerrada", reason="cerrada fuera del robot")
        _ev(op, "la posición ya no está en tu cuenta (¿la cerraste en Tradier?): no mando ninguna orden")
        return
    if n < op["qty"]:
        _ev(op, f"en tu cuenta quedan {n} de {op['qty']} spreads: cierro solo esos {n}")
        op["qty"] = n
    legs = [{"occ": l["occ"], "side": "buy_to_close" if l["side"] == "sell_to_open" else "sell_to_close"} for l in op["legs"]]
    q = _leg_quotes(env, op)
    s_, l_ = q.get(op["legs"][0]["occ"], {}), q.get(op["legs"][1]["occ"], {})
    bs, as_, bl, al = (trading._num(s_.get("bid")), trading._num(s_.get("ask")), trading._num(l_.get("bid")), trading._num(l_.get("ask")))
    if None in (bs, as_, bl, al):
        mid = nat = op["width"] / 2   # sin precios: empieza a la mitad del ancho y sube
    else:
        mid, nat = ((bs + as_) - (bl + al)) / 2, as_ - bl
    lim = min(op["width"], max(0.05, math.ceil(mid / 0.05 - 1e-9) * 0.05))
    if op.get("sim"):
        oid = "SIM"
    else:
        data = trading._build({"symbol": SYM, "type": "debit", "qty": op["qty"], "price": round(lim, 2), "legs": legs})
        j = _call(env, "POST", "/accounts/{acct}/orders", data=data, op=op)
        oid = str((j.get("order") or {}).get("id") or "")
        op.setdefault("robot_orders", []).append(oid)
    op.update(status="saliendo", order_out=oid, reason=why, t_out=time.time(), t_ostep=time.time(), olimit=round(lim, 2), onat=round(nat, 2))
    _ev(op, f"SALIDA ({why}): orden #{oid} LÍMITE débito {lim:.2f} (natural {nat:.2f})")


def _check_exit(env, op):
    if op.get("sim"):   # simulado: se llena cuando tu limite alcanza el debito natural REAL
        _, nd = _nat(env, op)
        o = {"status": "filled", "avg_fill_price": op["olimit"]} if nd is not None and op["olimit"] >= nd - 1e-9 else {"status": "open"}
    else:
        o = _order(env, op["order_out"], op)
    st = o.get("status")
    if st == "filled":
        px = abs(trading._num(o.get("avg_fill_price")) or 0)
        op.update(status="cerrada", debit=round(px, 2), pnl=round((op.get("credit", 0) - px) * 100 * op["qty"], 2))
        lineas_alt.close_alt((lambda path, params: _mkt(env, path, params)), op, _L, _save)
        _ev(op, f"CERRADA: pagué {px:.2f} · P&L {'+' if op['pnl'] >= 0 else '−'}${abs(op['pnl']):.2f}")
    elif st in ("rejected", "canceled", "expired", "error"):
        op["status"] = "dentro"
        op["exit_err"] = op.get("exit_err", 0) + 1
        op["t_sync"] = 0   # revisar ya si el spread sigue en tu cuenta o si hay una orden tuya
        mot = str(o.get("reason_description") or o.get("reason") or "").strip()
        op["exit_motivo"] = mot[:200]
        _ev(op, f"Tradier {st} la orden de salida" + (f" (motivo de Tradier: {mot[:160]})" if mot else " (Tradier no dio motivo)") + ": sigo dentro y lo vuelvo a intentar")
    elif time.time() - op.get("t_ostep", 0) > STEP_WAIT and op.get("olimit", 0) + 0.05 <= op["width"]:
        op["olimit"] = round(op["olimit"] + 0.05, 2)   # pagar un poco mas para salir (puede pasar del natural: hay que salir)
        op["t_ostep"] = time.time()
        if not op.get("sim"):
            _call(env, "PUT", "/accounts/{acct}/orders/" + op["order_out"], data={"type": "debit", "duration": "day", "price": f"{op['olimit']:.2f}"}, op=op)
        _ev(op, f"salida sin llenar: subo el débito a {op['olimit']:.2f}")


PRE_INI, PRE_FIN = "07:30", "09:25"   # sesion extendida de Cboe para opciones del SPY (sin 9:25-9:30)


def step(env, now=None):
    now = now or _now()
    hm = now.strftime("%H:%M")
    if mkt_cal.cerrado(now) or not (PRE_INI <= hm < PRE_FIN or "09:30" <= hm < (mkt_cal.cierre(now) or "16:00")):
        return   # trabaja en el premarket de las opciones del SPY (7:30-9:25, desde oct-2026) y en el horario normal
    with _L:
        _load()
        live = [o for o in S["ops"] if o["status"] in ("esperando", "entrando", "dentro", "saliendo")]
        if not live:
            return
        p = _price(env)
        changed = False
        for op in live:
            try:
                st = op["status"]
                if st == "esperando":
                    if op.get("day") != now.strftime("%Y-%m-%d") or hm >= mkt_cal.tope(op["until"], now, mkt_cal.ENTRADA_TEMPRANO):
                        op["status"] = "cancelada"
                        _ev(op, "pasó la hora límite de entrada sin tocar la línea")
                        changed = True
                        continue
                    if p is None:
                        continue
                    prev, e = op.get("px_prev"), op["entry"]
                    op["px_prev"] = p
                    if prev is None:
                        continue
                    if (prev - e) * (p - e) <= 0:   # cruzo o toco la linea de entrada
                        past_stop = p <= op["stop"] if op["dir"] == "alcista" else p >= op["stop"]
                        if past_stop:
                            op["status"] = "cancelada"
                            _ev(op, f"el precio brincó hasta más allá del stop ({p:.2f}): NO entro")
                        else:
                            _enter(env, op, p)
                        changed = True
                elif st == "entrando":
                    if time.time() - op.get("t_chk", 0) >= FILL_WAIT:
                        op["t_chk"] = time.time()
                        _check_entry(env, op)
                        changed = True
                elif st == "dentro":
                    if not op.get("sim") and time.time() - op.get("t_sync", 0) >= SYNC_EVERY:
                        try:
                            if _sync(env, op):
                                changed = True
                                continue
                        except trading.ApiError:
                            pass   # sin respuesta de Tradier: lo intento en la siguiente vuelta
                        changed = True
                    if time.time() - op.get("t_pnl", 0) >= 5:   # P&L de ahorita (con el debito natural: lo que costaria salir ya)
                        op["t_pnl"] = time.time()
                        try:
                            _, nd = _nat(env, op)
                            if nd is not None:
                                op["pnl_now"] = round((op.get("credit", 0) - nd) * 100 * op["qty"], 2)
                                changed = True
                        except trading.ApiError:
                            pass
                    why = None
                    if op.get("req_close"):
                        why = "cierre manual"
                    elif hm >= mkt_cal.tope(op["exit"], now):
                        why = f"hora de salida {mkt_cal.tope(op['exit'], now)}" + (" (hoy la bolsa cierra a la 1:00 pm)" if mkt_cal.temprano(now) else "")
                    elif p is not None:
                        up = op["dir"] == "alcista"
                        if (p <= op["stop"]) if up else (p >= op["stop"]):
                            why = f"tocó el STOP ({p:.2f})"
                        elif (p >= op["tp"]) if up else (p <= op["tp"]):
                            why = f"tocó la GANANCIA ({p:.2f})"
                    if why and op.get("ext_close"):
                        if not op.get("ext_note"):
                            op["ext_note"] = True
                            _ev(op, f"{why}, pero tu orden de salida #{op['ext_close']} está pendiente: espero la tuya (no mando otra)")
                            changed = True
                    elif why and op.get("exit_err", 0) < 5:
                        _exit(env, op, why)
                        changed = True
                    elif why and not op.get("exit_alert"):
                        op["exit_alert"] = True
                        mot = op.get("exit_motivo") or ""
                        _ev(op, "⚠️ No pude salir después de 5 intentos" + (f" (Tradier: {mot[:120]})" if mot else "") + ": CIERRA TÚ la posición en Tradier o en Trading manual "
                                "(o dale Cerrar ya para que lo intente otra vez). Si la cierras tú, el robot lo detecta solo")
                        _notify(op, "🚨 Robot de líneas SPY: NO PUDE SALIR", "Después de 5 intentos sigo dentro. Cierra tú la posición YA (Tradier o Trading manual)." + (f" Tradier: {mot[:100]}" if mot else ""))
                        changed = True
                elif st == "saliendo":
                    if time.time() - op.get("t_chk", 0) >= FILL_WAIT:
                        op["t_chk"] = time.time()
                        _check_exit(env, op)
                        changed = True
            except _Skip as ex:
                if not op.get("skip_note"):
                    op["skip_note"] = True
                    _ev(op, str(ex))
                    _notify(op, "⏸ Robot de líneas SPY", str(ex))
                    changed = True
            except (trading.ApiError, LineasError) as ex:
                if op["status"] == "esperando":
                    op["status"] = "error"
                op["err"] = str(ex)[:200]
                _ev(op, "ERROR: " + str(ex)[:160])
                _notify(op, "⚠️ Robot de líneas SPY (REAL)", "Error: " + str(ex)[:160] + (" · REVISA tu posición en Tradier" if op["status"] in ("dentro", "saliendo") else ""))
                changed = True
        if changed:
            _save()


def loop(env_fn, notify=None):
    NOTIFY[0] = notify
    while True:
        try:
            step(env_fn())
        except Exception as ex:   # noqa: BLE001 - nunca tumbar el panel
            S["log"].append([_now().strftime("%Y-%m-%d %H:%M:%S"), "error del robot: " + str(ex)[:160]])
        time.sleep(1)
