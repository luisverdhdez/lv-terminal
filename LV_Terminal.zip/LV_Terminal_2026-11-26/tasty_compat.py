"""tastytrade etapa 2: la terminal funciona con tastytrade cuando NO hay cuenta de Tradier.
Traduce las consultas que la terminal le hace a Tradier (precios, cadenas, vencimientos, velas, posiciones,
saldo) a tastytrade y devuelve la respuesta con la MISMA forma que Tradier. Asi todas las paginas funcionan igual.
- Precios y cadenas: tastytrade (REST /market-data/by-type, /option-chains/{sym}/nested). Griegas: Black-Scholes con la IV
  que sale del precio medio (tastytrade no las da por REST).
- Velas: Yahoo Finance (igual que el respaldo que ya usa la terminal).
- Ordenes (etapa 3, 25-nov-2026): las ordenes de la terminal (forma de Tradier) se traducen a tastytrade:
  vista previa = /orders/dry-run, enviar, ver las de hoy (/orders/live), una orden, cancelar y cambiar precio (cancel-replace).
  Necesita el permiso 'trade' del grant de tastytrade."""
import math
import re
import time
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import tasty

ET = ZoneInfo("America/New_York")
INDEX = {"SPX", "NDX", "RUT", "VIX", "XSP", "DJX"}
OCC = re.compile(r"^([A-Z]{1,6})(\d{6})([CP])(\d{8})$")
_CH = {}     # cache de cadenas anidadas por simbolo (5 min)


class NoDisponible(Exception):
    pass


def tt_occ(occ):
    """SPY261123C00650000 (Tradier) -> 'SPY   261123C00650000' (tastytrade, raiz de 6)."""
    m = OCC.match(occ)
    return f"{m.group(1):<6}{m.group(2)}{m.group(3)}{m.group(4)}" if m else occ


def tr_occ(sym):
    return str(sym or "").replace(" ", "")


def _f(x):
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


_QC = {}            # simbolo -> (ts, quote)   precios recientes (2 s): varias tablas piden lo mismo a la vez
_QL = __import__("threading").Lock()
_BC = {}            # velas de Yahoo en cache


QTTL_OPT = 4.0      # 26-nov: precios de OPCIONES por REST se guardan 4 s (antes 2): la cadena de SPX son ~700 opciones


def _quotes_raw(env, syms):
    now = time.time()
    want = [str(s).strip().upper() for s in syms if str(s).strip()]
    with _QL:
        have = {s: _QC[s][1] for s in want if s in _QC and now - _QC[s][0] < (QTTL_OPT if OCC.match(s) else 2.0)}
    miss = [s for s in want if s not in have]
    if miss:
        got = _quotes_fetch(env, miss)
        with _QL:
            for k, v in got.items():
                _QC[k] = (now, v)
            if len(_QC) > 5000:
                _QC.clear()
        have.update(got)
    return have


def _quotes_fetch(env, syms):
    eq, ix, op = [], [], []
    for s in syms:
        s = str(s).strip().upper()
        if not s:
            continue
        if OCC.match(s):
            op.append(tt_occ(s))
        elif s in INDEX:
            ix.append(s)
        else:
            eq.append(s.replace(".", "/"))   # BRK.B -> BRK/B (formato de tastytrade)
    out = {}
    allp = [("equity", x) for x in eq] + [("index", x) for x in ix] + [("equity-option", x) for x in op]
    parts = [allp[i:i + 90] for i in range(0, len(allp), 90)]
    if len(parts) <= 1:
        for part in parts:
            _lote(env, part, out)
        return out
    # 26-nov: los lotes se piden AL MISMO TIEMPO (antes uno tras otro: la cadena de SPX tardaba ~8 consultas seguidas)
    from concurrent.futures import ThreadPoolExecutor
    res = [{} for _ in parts]
    with ThreadPoolExecutor(max_workers=min(4, len(parts))) as ex:
        list(ex.map(lambda ip: _lote(env, ip[1], res[ip[0]]), enumerate(parts)))
    for r in res:
        out.update(r)
    return out


def _lote(env, part, out, nivel=0):
    """Pide un lote; si tastytrade lo rechaza (por ejemplo un simbolo que no conoce), lo parte en dos y reintenta."""
    params = {}
    for k, v in part:
        params.setdefault(k, []).append(v)
    params = {k: ",".join(v) for k, v in params.items()}
    try:
        j = tasty._get(env, "/market-data/by-type", params=params)
    except tasty.TastyError as e:
        if "400" in str(e) and len(part) > 1 and nivel < 7:   # solo si algun simbolo no es valido (no si es limite de consultas)
            h = len(part) // 2
            _lote(env, part[:h], out, nivel + 1)
            _lote(env, part[h:], out, nivel + 1)
        return
    d = j.get("data") if isinstance(j, dict) else None
    items = (d.get("items") if isinstance(d, dict) and "items" in d else [d]) if d else []
    for q in items or []:
        if isinstance(q, dict) and q.get("symbol"):
            out[tr_occ(q["symbol"]).replace("/", ".")] = q


# ───────── Black-Scholes (para las griegas) ─────────
def _N(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _bs(S, K, T, s, call, r=0.04):
    if T <= 0 or s <= 0:
        return max(0.0, (S - K) if call else (K - S))
    d1 = (math.log(S / K) + (r + s * s / 2) * T) / (s * math.sqrt(T))
    d2 = d1 - s * math.sqrt(T)
    return S * _N(d1) - K * math.exp(-r * T) * _N(d2) if call else K * math.exp(-r * T) * _N(-d2) - S * _N(-d1)


def greeks(S, K, T, price, call, r=0.04):
    if not (S and K and price and price > 0 and T > 0):
        return {}
    lo, hi = 0.01, 5.0
    if price <= max(0.0, (S - K) if call else (K - S)) + 1e-6:
        return {}
    for _ in range(60):
        mid = (lo + hi) / 2
        if _bs(S, K, T, mid, call, r) > price:
            hi = mid
        else:
            lo = mid
    s = (lo + hi) / 2
    d1 = (math.log(S / K) + (r + s * s / 2) * T) / (s * math.sqrt(T))
    d2 = d1 - s * math.sqrt(T)
    pdf = math.exp(-d1 * d1 / 2) / math.sqrt(2 * math.pi)
    delta = _N(d1) if call else _N(d1) - 1
    gamma = pdf / (S * s * math.sqrt(T))
    theta = (-S * pdf * s / (2 * math.sqrt(T)) - (r * K * math.exp(-r * T) * (_N(d2) if call else -_N(-d2)))) / 365
    vega = S * pdf * math.sqrt(T) / 100
    return {"delta": round(delta, 4), "gamma": round(gamma, 5), "theta": round(theta, 4), "vega": round(vega, 4),
            "mid_iv": round(s, 4), "smv_vol": round(s, 4)}


def _T(exp):
    try:
        close = datetime.fromisoformat(exp + "T16:00:00").replace(tzinfo=ET)
    except ValueError:
        return 0
    return max((close - datetime.now(ET)).total_seconds(), 60) / (365 * 86400)


def _quote_tr(sym, q, spot=None):
    bid, ask, last = _f(q.get("bid")), _f(q.get("ask")), _f(q.get("last"))
    prev = _f(q.get("prevClose")) or _f(q.get("prevDayClose"))
    if last is None:
        last = _f(q.get("mark")) or _f(q.get("mid"))
    ch = (last - prev) if last is not None and prev else None
    out = {"symbol": sym, "description": ((q.get("instrument") or {}).get("description") if isinstance(q.get("instrument"), dict) else "") or sym,
           "last": last, "bid": bid, "ask": ask, "close": _f(q.get("close")) or _f(q.get("dayClose")), "prevclose": prev,
           "open": _f(q.get("open")) or _f(q.get("dayOpen")), "high": _f(q.get("dayHighPrice")) or _f(q.get("dayHigh")),
           "low": _f(q.get("dayLowPrice")) or _f(q.get("dayLow")), "volume": _f(q.get("volume")),
           "change": None if ch is None else round(ch, 4), "change_percentage": round(ch / prev * 100, 2) if ch is not None and prev else None}
    m = OCC.match(sym)
    if m:
        exp = f"20{m.group(2)[:2]}-{m.group(2)[2:4]}-{m.group(2)[4:6]}"
        out.update({"option_type": "call" if m.group(3) == "C" else "put", "strike": int(m.group(4)) / 1000,
                    "expiration_date": exp, "root_symbol": m.group(1), "underlying": "SPX" if m.group(1) == "SPXW" else m.group(1)})
        mid = (bid + ask) / 2 if bid is not None and ask is not None and ask > 0 else last
        if spot:
            out["greeks"] = greeks(spot, out["strike"], _T(exp), mid, m.group(3) == "C")
    return out


def _nested(env, sym):
    hit = _CH.get(sym)
    if hit and time.time() - hit[0] < 300:
        return hit[1]
    j = tasty._get(env, f"/option-chains/{sym}/nested")
    d = j.get("data") if isinstance(j, dict) else {}
    items = d.get("items") if isinstance(d, dict) else []
    _CH[sym] = (time.time(), items or [])
    return items or []


def _expirations(env, sym):
    dates = set()
    for it in _nested(env, sym):
        for e in it.get("expirations") or []:
            if e.get("expiration-date"):
                dates.add(e["expiration-date"])
    return {"expirations": {"date": sorted(dates)}}


_CHC = {}   # (simbolo, vencimiento) -> (ts, cadena)  varias tablas piden la misma cadena a la vez
_CHL = __import__("threading").Lock()


def _chain(env, sym, exp):
    k = (sym, exp)
    hit = _CHC.get(k)
    if hit and time.time() - hit[0] < 3.0:
        return hit[1]
    with _CHL:   # si ya la esta armando otra tabla, espera y usa la misma (no pide 700 precios dos veces)
        hit = _CHC.get(k)
        if hit and time.time() - hit[0] < 3.0:
            return hit[1]
        out = _chain_build(env, sym, exp)
        _CHC[k] = (time.time(), out)
        if len(_CHC) > 40:
            _CHC.clear()
        return out


def _chain_build(env, sym, exp):
    occs = []
    for it in _nested(env, sym):
        for e in it.get("expirations") or []:
            if e.get("expiration-date") != exp:
                continue
            for k in e.get("strikes") or []:
                for side in ("call", "put"):
                    if k.get(side):
                        occs.append(tr_occ(k[side]))
    sq = _quotes_raw(env, [sym])
    spot = None
    if sym in sq:
        q = sq[sym]
        spot = _f(q.get("last")) or _f(q.get("mark")) or _f(q.get("mid"))
    if spot:   # solo strikes cercanos (la terminal tampoco usa los lejanos): menos consultas
        occs = [o for o in occs if abs(int(OCC.match(o).group(4)) / 1000 - spot) <= max(40, spot * 0.12)] if all(OCC.match(o) for o in occs) else occs
    raw = _quotes_raw(env, occs)
    opts = []
    for o in occs:
        q = raw.get(o) or {"symbol": o}
        opts.append(_quote_tr(o, q, spot))
    return {"options": {"option": opts}}


def _bars(sym, interval, start=None):
    k = (sym.upper(), interval, start if interval in ("daily", "weekly", "monthly") else None)
    ttl = {"1min": 15, "5min": 30, "15min": 60}.get(interval, 900)
    hit = _BC.get(k)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    rows = _bars_fetch(sym, interval, start)
    if rows or not hit:
        _BC[k] = (time.time(), rows)
    return rows if rows else (hit[1] if hit else rows)


def _bars_fetch(sym, interval, start=None):
    import trading
    import fundamentales
    ysym = trading.YF_SYM.get(sym.upper(), sym.upper().replace(".", "-")) if hasattr(trading, "YF_SYM") else sym
    yf = fundamentales._yf()
    iv = {"1min": "1m", "5min": "5m", "15min": "15m", "daily": "1d", "weekly": "1wk", "monthly": "1mo"}.get(interval, "5m")
    if iv in ("1m", "5m", "15m"):
        df = yf.Ticker(ysym).history(period="5d" if iv == "1m" else "1mo", interval=iv, prepost=True, auto_adjust=False)
    else:
        df = yf.Ticker(ysym).history(start=start or (date.today() - timedelta(days=5 * 365 + 40)).isoformat(), interval=iv, auto_adjust=False)
    rows = []
    for idx, r in df.iterrows():
        try:
            o, h, l, c = float(r["Open"]), float(r["High"]), float(r["Low"]), float(r["Close"])
        except (TypeError, ValueError, KeyError):
            continue
        if not (o > 0 and c > 0):
            continue
        rows.append((idx, o, h, l, c, float(r.get("Volume") or 0)))
    return rows


def _positions(env):
    res = tasty.resumen(env)
    out = []
    for p in res["stocks"] + res["options"]:
        sym = tr_occ(p["sym"]) if "Option" in p["type"] else p["sym"]
        cost = (p["avg"] or 0) * p["qty"] * p["mult"]
        out.append({"symbol": sym, "quantity": p["qty"], "cost_basis": round(cost, 2), "date_acquired": None, "id": 0})
    return {"positions": {"position": out} if out else "null"}



# ───────────── ORDENES (etapa 3) ─────────────
TT_ST = {"Received": "pending", "Routed": "pending", "In Flight": "pending", "Contingent": "pending", "Live": "open",
         "Cancel Requested": "open", "Replace Requested": "open", "Filled": "filled", "Cancelled": "canceled",
         "Rejected": "rejected", "Expired": "expired", "Removed": "canceled", "Partially Removed": "canceled"}
OPT_TT = {"buy_to_open": "Buy to Open", "sell_to_open": "Sell to Open", "buy_to_close": "Buy to Close", "sell_to_close": "Sell to Close"}
EQ_TT = {"buy": "Buy to Open", "sell": "Sell to Close", "sell_short": "Sell to Open", "buy_to_cover": "Buy to Close"}
TT_OPT = {v: k for k, v in OPT_TT.items()}
TT_EQ = {v: k for k, v in EQ_TT.items()}
_REPL = {}   # orden vieja -> orden nueva (al cambiar el precio tastytrade crea otra orden)


def _acct(env):
    return tasty.account_id(env)


def _cur(oid):
    oid = str(oid)
    for _ in range(20):
        if oid not in _REPL:
            break
        oid = _REPL[oid]
    return oid


def _legs_in(data):
    """Patas de una orden con la forma de Tradier -> patas de tastytrade."""
    cls = data.get("class")
    out = []
    if cls == "option":
        out.append((str(data.get("option_symbol", "")), data.get("side"), data.get("quantity")))
    elif cls == "multileg":
        i = 0
        while f"option_symbol[{i}]" in data:
            out.append((str(data[f"option_symbol[{i}]"]), data.get(f"side[{i}]"), data.get(f"quantity[{i}]")))
            i += 1
    elif cls == "equity":
        side = data.get("side")
        if side not in EQ_TT:
            raise NoDisponible("Dirección no válida para acciones")
        return [{"instrument-type": "Equity", "symbol": str(data.get("symbol", "")).upper(), "quantity": int(float(data.get("quantity"))),
                 "action": EQ_TT[side]}]
    else:
        raise NoDisponible("Ese tipo de orden todavía no está disponible con tastytrade.")
    legs = []
    for occ, side, q in out:
        if not OCC.match(occ) or side not in OPT_TT:
            raise NoDisponible("Pata no válida para tastytrade")
        legs.append({"instrument-type": "Equity Option", "symbol": tt_occ(occ), "quantity": int(float(q)), "action": OPT_TT[side]})
    if not legs:
        raise NoDisponible("La orden no trae patas")
    return legs


def _order_in(data):
    """Orden de la terminal (forma de Tradier) -> JSON de tastytrade."""
    legs = _legs_in(data)
    typ = data.get("type")
    body = {"time-in-force": "GTC" if str(data.get("duration")) == "gtc" else "Day", "legs": legs, "source": "LVTerminal"}
    if typ == "market":
        body["order-type"] = "Market"
        return body
    if typ not in ("credit", "debit", "limit"):
        raise NoDisponible("Ese tipo de precio todavía no está disponible con tastytrade (usa límite, crédito o débito).")
    try:
        px = float(data.get("price"))
    except (TypeError, ValueError):
        raise NoDisponible("Precio no válido")
    if typ == "limit":   # una sola pata o acciones: comprar = debito, vender = credito
        eff = "Debit" if legs[0]["action"].startswith("Buy") else "Credit"
    else:
        eff = "Credit" if typ == "credit" else "Debit"
    body.update({"order-type": "Limit", "price": f"{px:.2f}", "price-effect": eff})
    return body


def _money(x, eff):
    v = _f(x)
    if v is None:
        return None
    return round(-v if str(eff) == "Debit" else v, 2)


def _preview_out(d):
    """Respuesta del dry-run -> lo que muestra la vista previa de la terminal."""
    o = d.get("order") or {}
    fee = d.get("fee-calculation") or {}
    bp = d.get("buying-power-effect") or {}
    out = {"status": "ok", "type": str(o.get("order-type") or "").lower(), "quantity": o.get("size"),
           "strategy": o.get("underlying-symbol"), "commission": _f(fee.get("commission")),
           "fees": _f(fee.get("total-fees")), "margin_change": _money(bp.get("change-in-buying-power"), bp.get("change-in-buying-power-effect")),
           "broker": "tastytrade"}
    ws = [str(w.get("message") or w.get("code") or "") for w in (d.get("warnings") or []) if isinstance(w, dict)]
    if ws:
        out["warnings"] = " · ".join(x for x in ws if x)[:300]
    return {"order": {k: v for k, v in out.items() if v not in (None, "")}}


def _order_out(o):
    """Orden de tastytrade -> forma de Tradier (lo que leen Trading manual, el gestor y los registros)."""
    legs_tt = [l for l in (o.get("legs") or []) if isinstance(l, dict)]
    legs, net, size = [], 0.0, _f(o.get("size")) or 1
    any_fill = False
    for l in legs_tt:
        eq = l.get("instrument-type") == "Equity"
        act = l.get("action")
        side = (TT_EQ if eq else TT_OPT).get(act, str(act or "").lower().replace(" ", "_"))
        fills = [f for f in (l.get("fills") or []) if isinstance(f, dict)]
        fq = sum(_f(f.get("quantity")) or 0 for f in fills)
        avg = round(sum((_f(f.get("fill-price")) or 0) * (_f(f.get("quantity")) or 0) for f in fills) / fq, 4) if fq else None
        any_fill = any_fill or fq > 0
        q = _f(l.get("quantity")) or 0
        if avg is not None:
            net += (avg if str(act).startswith("Buy") else -avg) * (q / size)
        row = {"side": side, "quantity": q, "exec_quantity": fq, "remaining_quantity": _f(l.get("remaining-quantity")),
               "avg_fill_price": avg}
        if eq:
            row["symbol"] = l.get("symbol")
        else:
            row["option_symbol"] = tr_occ(l.get("symbol") or "")
        legs.append(row)
    st = TT_ST.get(o.get("status"), "pending")
    if st == "open" and any_fill:
        st = "partially_filled"
    eq_order = bool(legs_tt) and all(l.get("instrument-type") == "Equity" for l in legs_tt)
    ot = str(o.get("order-type") or "")
    if ot == "Market":
        typ = "market"
    elif len(legs) > 1:
        typ = "credit" if o.get("price-effect") == "Credit" else "debit"
    else:
        typ = "limit"
    out = {"id": o.get("id"), "status": st, "type": typ, "price": _f(o.get("price")), "duration": "gtc" if o.get("time-in-force") == "GTC" else "day",
           "symbol": o.get("underlying-symbol"), "quantity": size, "create_date": o.get("received-at") or o.get("updated-at"),
           "transaction_date": o.get("terminal-at") or o.get("updated-at"), "tt_status": o.get("status")}
    if any_fill and all(r["avg_fill_price"] is not None for r in legs):
        out["avg_fill_price"] = round(net, 4) if len(legs) > 1 else legs[0]["avg_fill_price"]
        out["exec_quantity"] = min(r["exec_quantity"] for r in legs) if len(legs) > 1 else legs[0]["exec_quantity"]
    why = o.get("reject-reason") or o.get("cancel-reason") or o.get("reason")
    if why:
        out["reason_description"] = str(why)[:200]
    if eq_order:
        out.update(cls="equity", side=legs[0]["side"])
    elif len(legs) == 1:
        out.update(option_symbol=legs[0]["option_symbol"], side=legs[0]["side"], exec_quantity=legs[0]["exec_quantity"])
    else:
        out["leg"] = legs
    out["class"] = out.pop("cls", "equity" if eq_order else ("option" if len(legs) == 1 else "multileg"))
    return out


def _orders_today(env):
    j = tasty.send(env, "GET", f"/accounts/{_acct(env)}/orders/live", params={"per-page": 200})
    items = (j.get("data") or {}).get("items") or []
    rows = [_order_out(o) for o in items if isinstance(o, dict)]
    rows.sort(key=lambda r: str(r.get("create_date") or ""))
    return {"orders": {"order": rows} if rows else "null"}


def _get_order(env, oid):
    j = tasty.send(env, "GET", f"/accounts/{_acct(env)}/orders/{_cur(oid)}")
    o = j.get("data") or {}
    return {"order": _order_out(o) if o else {}}


def _post_order(env, data):
    body = _order_in(data)
    a = _acct(env)
    if str(data.get("preview")) == "true":
        return _preview_out(tasty.send(env, "POST", f"/accounts/{a}/orders/dry-run", body).get("data") or {})
    d = tasty.send(env, "POST", f"/accounts/{a}/orders", body).get("data") or {}
    o = d.get("order") or {}
    if not o.get("id"):
        raise tasty.TastyError("tastytrade no devolvió número de orden: revisa en tastytrade si se mandó.")
    return {"order": {"id": o["id"], "status": "ok", "broker": "tastytrade"}}


def _put_order(env, oid, data):
    """Cambiar el precio (cancel-replace): tastytrade exige el resto de la orden IGUAL a la original."""
    a, cur = _acct(env), _cur(oid)
    o = (tasty.send(env, "GET", f"/accounts/{a}/orders/{cur}").get("data") or {})
    if not o:
        raise tasty.TastyError("No encontré esa orden en tastytrade.")
    body = {"time-in-force": o.get("time-in-force") or "Day", "order-type": o.get("order-type") or "Limit",
            "legs": [{"instrument-type": l.get("instrument-type"), "symbol": l.get("symbol"), "quantity": l.get("quantity"), "action": l.get("action")}
                     for l in (o.get("legs") or [])]}
    typ = data.get("type")
    if typ == "market":
        body["order-type"] = "Market"
    else:
        try:
            body["price"] = f"{float(data.get('price')):.2f}"
        except (TypeError, ValueError):
            raise NoDisponible("Precio no válido")
        body["order-type"] = "Limit"
        body["price-effect"] = "Credit" if typ == "credit" else "Debit" if typ == "debit" else (o.get("price-effect") or "Debit")
    d = tasty.send(env, "PUT", f"/accounts/{a}/orders/{cur}", body).get("data") or {}
    new = str(d.get("id") or cur)
    if new != cur:
        _REPL[cur] = new
    return {"order": {"id": new, "status": "ok"}}


def _del_order(env, oid):
    cur = _cur(oid)
    tasty.send(env, "DELETE", f"/accounts/{_acct(env)}/orders/{cur}")
    return {"order": {"id": cur, "status": "ok"}}


def call(env, method, path, params=None, data=None):
    """Responde como Tradier. path puede traer {acct} ya reemplazado o no."""
    params = params or {}
    p = re.sub(r"/accounts/[^/]+", "/accounts/{acct}", path)
    m_id = re.match(r"^/accounts/\{acct\}/orders/(\d+)$", p)
    if method == "POST" and p == "/accounts/{acct}/orders":
        return _post_order(env, data or {})
    if method == "PUT" and m_id:
        return _put_order(env, m_id.group(1), data or {})
    if method == "DELETE" and m_id:
        return _del_order(env, m_id.group(1))
    if method == "GET" and m_id:
        return _get_order(env, m_id.group(1))
    if method != "GET":
        raise NoDisponible("Esta función todavía no está disponible con tastytrade.")
    if p == "/markets/quotes":
        syms = [s for s in str(params.get("symbols", "")).split(",") if s]
        raw = _quotes_raw(env, syms)
        unds = {}
        for s in syms:   # precio del subyacente para las griegas de las opciones
            m = OCC.match(s.upper())
            if m:
                u = "SPX" if m.group(1) == "SPXW" else m.group(1)
                unds[u] = None
        if unds:
            ur = _quotes_raw(env, list(unds))
            for u in unds:
                q = ur.get(u) or {}
                unds[u] = _f(q.get("last")) or _f(q.get("mark"))
        qs = []
        for s in syms:
            S = s.upper()
            m = OCC.match(S)
            spot = unds.get("SPX" if m and m.group(1) == "SPXW" else (m.group(1) if m else ""))
            if S in raw:
                qs.append(_quote_tr(S, raw[S], spot))
        return {"quotes": {"quote": qs if len(qs) != 1 else qs[0]} if qs else {"unmatched_symbols": {"symbol": syms}}}
    if p == "/markets/options/expirations":
        return _expirations(env, str(params.get("symbol", "SPY")).upper())
    if p == "/markets/options/chains":
        return _chain(env, str(params.get("symbol", "SPY")).upper(), str(params.get("expiration", "")))
    if p == "/markets/timesales":
        rows = _bars(str(params.get("symbol", "SPY")), str(params.get("interval", "5min")))
        data = [{"time": idx.tz_convert(ET).strftime("%Y-%m-%dT%H:%M:%S"), "timestamp": int(idx.timestamp()), "open": o, "high": h,
                 "low": l, "close": c, "volume": v} for idx, o, h, l, c, v in rows]
        return {"series": {"data": data} if data else None}
    if p == "/markets/history":
        rows = _bars(str(params.get("symbol", "SPY")), str(params.get("interval", "daily")), params.get("start"))
        return {"history": {"day": [{"date": idx.strftime("%Y-%m-%d"), "open": o, "high": h, "low": l, "close": c, "volume": v}
                                    for idx, o, h, l, c, v in rows]}}
    if p == "/markets/lookup":
        q = str(params.get("q", "")).upper()
        return {"securities": {"security": [{"symbol": q, "description": q, "type": "stock"}]}} if q else {"securities": None}
    if p == "/markets/clock":
        now = datetime.now(ET)
        import mkt_cal
        st = "open" if not mkt_cal.cerrado(now) and "09:30" <= now.strftime("%H:%M") < (mkt_cal.cierre(now) or "16:00") else "closed"
        return {"clock": {"state": st, "date": now.strftime("%Y-%m-%d"), "timestamp": int(now.timestamp())}}
    if p == "/accounts/{acct}/positions":
        return _positions(env)
    if p == "/accounts/{acct}/balances":
        r = tasty.resumen(env)
        return {"balances": {"total_equity": r["nlv"], "total_cash": r["cash"], "option_buying_power": r["deriv_bp"],
                             "margin": {"option_buying_power": r["deriv_bp"], "stock_buying_power": r["equity_bp"]}}}
    if p == "/accounts/{acct}/orders":
        return _orders_today(env)
    if p == "/accounts/{acct}/history":
        return {"history": "null"}
    if p == "/accounts/{acct}/gainloss":
        return {"gainloss": "null"}
    if p == "/user/profile":
        return {"profile": {"account": {"account_number": "tastytrade"}}}
    raise NoDisponible("Esta función todavía no está disponible con tastytrade.")
