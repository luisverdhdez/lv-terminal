"""
Gestor automático de posiciones manuales de SPY: opciones sueltas (ORDEN RÁPIDA) y estrategias de
varias patas (iron condor, iron fly, spreads de crédito y de débito) enviadas desde Trading manual.

Cuando envías una entrada, el gestor la toma a su cargo:
  1. Espera a que la orden de entrada se ejecute (usa el precio real de ejecución).
  2. Vigila el precio de la opción cada pocos segundos desde tu Mac.
  3. Cierra a mercado (vender para cerrar) cuando se cumple una regla:
       stop loss · toma de ganancia · parcial (vende una parte y sube el stop a la entrada) ·
       trailing (stop que sube con el máximo) · cierre por hora (solo opciones que vencen hoy).

IMPORTANTE
  - Solo funciona mientras el panel esté corriendo en tu Mac (no deja órdenes en Tradier).
  - Solo CIERRA lo que abriste (mismas patas, nunca más de lo que tienes). Si falta alguna pata de una estrategia
    (por ejemplo cerraste una a mano), se detiene y te avisa: nunca manda un cierre que pueda abrir patas nuevas.
  - Actúa solo con el mercado abierto (9:30-16:00 NY).
  - El estado se guarda en gestor.json: si reinicias el panel, sigue vigilando.
Lo usan trading.py (registrar la entrada) y monitor_web.py (hilo de vigilancia).
"""
import math
import json
import os
import re
import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

import trading

ET = ZoneInfo("America/New_York")
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(DATA_DIR, "gestor.json")
LOCK = threading.RLock()
HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
MAX_ERRORS = 3

# REGLAS EN DOLARES (unit = "usd"): los montos son POR CONTRATO (o por spread). Con 3 contratos, un stop de $50 = -$150 en total.
#   stop_usd  = perdida maxima: al llegar a -stop_usd cierra todo.
#   tp_usd    = objetivo de ganancia. at_target decide que pasa al llegar:  "close" = cierra  |  "trail" = SIGUE dentro con trailing.
#   trail_usd = con trailing activo, cierra cuando la ganancia retrocede trail_usd desde su maximo (debe ser menor que tp_usd).
# unit = "pct" mantiene las reglas antiguas en porcentaje (posiciones ya abiertas con esa version).
DEFAULTS = {"auto": False, "unit": "usd", "stop_usd": 50.0, "tp_usd": 100.0, "at_target": "trail", "trail_usd": 40.0,
            "stop_pct": 30.0,                   # stop loss: pérdida % sobre el precio de entrada de la opción
            "tp_pct": 60.0,                     # toma de ganancia: ganancia % sobre la entrada
            "partial_on": False, "partial_at": 30.0, "partial_frac": 50.0,  # (solo modo %) parcial: a +30% vende el 50%
            "be_after_partial": True,           # (solo modo %) tras el parcial el stop sube al precio de entrada
            "trail_on": False, "trail_after": 30.0, "trail_giveback": 20.0,  # (solo modo %) trailing
            "time_on": True, "time_exit": "15:45"}   # cierre por hora (solo si vence hoy)

# Estrategias de varias patas. Precio de entrada = crédito (o débito) neto por spread.
#  crédito: stop = el costo de cerrar sube a (1 + stop_pct/100) × crédito; objetivo = costo de cerrar baja a (1 - tp_pct/100) × crédito
#  débito:  stop = el valor cae stop_pct %; objetivo = el valor sube tp_pct %
DEFAULTS_CREDIT = {"auto": False, "unit": "usd", "stop_usd": 60.0, "tp_usd": 30.0, "at_target": "trail", "trail_usd": 12.0, "stop_pct": 100.0, "tp_pct": 50.0, "partial_on": False, "partial_at": 25.0, "partial_frac": 50.0,
                   "be_after_partial": True, "trail_on": False, "trail_after": 30.0, "trail_giveback": 30.0,
                   "time_on": True, "time_exit": "15:30"}
DEFAULTS_DEBIT = {"auto": False, "unit": "usd", "stop_usd": 50.0, "tp_usd": 80.0, "at_target": "trail", "trail_usd": 30.0, "stop_pct": 50.0, "tp_pct": 80.0, "partial_on": False, "partial_at": 40.0, "partial_frac": 50.0,
                  "be_after_partial": True, "trail_on": False, "trail_after": 40.0, "trail_giveback": 30.0,
                  "time_on": True, "time_exit": "15:30"}
KINDS = ("single", "credit", "debit")
STOP_MAX = {"single": 95, "debit": 95, "credit": 1000}
LIMITS = {"stop_pct": (1, 95), "tp_pct": (1, 1000), "partial_at": (1, 1000), "partial_frac": (10, 90),
          "trail_after": (1, 1000), "trail_giveback": (1, 90)}
BOOLS = ("auto", "partial_on", "be_after_partial", "trail_on", "time_on")
USD_LIMITS = {"stop_usd": (1, 1000000), "tp_usd": (1, 1000000), "trail_usd": (1, 1000000)}

S = {"cfg": dict(DEFAULTS), "cfg_credit": dict(DEFAULTS_CREDIT), "cfg_debit": dict(DEFAULTS_DEBIT), "paused": False, "items": [], "log": []}


def _cfg_key(kind):
    return {"single": "cfg", "credit": "cfg_credit", "debit": "cfg_debit"}[kind]


class GestorError(Exception):
    pass


# ───────────── configuración y estado ─────────────
def _exit_day(exp, n):
    """Fecha de cierre por hora: el vencimiento, o n dias habiles antes."""
    from datetime import date as _d, timedelta as _td
    d = _d.fromisoformat(exp)
    while n > 0:
        d -= _td(days=1)
        if d.weekday() < 5:
            n -= 1
    return d.isoformat()


def _time_due(it, c, now):
    if not c.get("time_on") or not it.get("exp"):
        return False
    xd, today = _exit_day(it["exp"], int(c.get("time_days") or 0)), now.strftime("%Y-%m-%d")
    return today > xd or (today == xd and now.strftime("%H:%M") >= c["time_exit"])


def _time_name(c):
    n = int(c.get("time_days") or 0)
    return f"cierre por hora ({c['time_exit']}" + (f", {n} día{'s' if n > 1 else ''} hábil{'es' if n > 1 else ''} antes de vencer)" if n else ")")


def clean_cfg(new, base, kind="single"):
    """Valida y mezcla una configuración nueva sobre la base. Lanza GestorError si algo no es válido."""
    out = dict(base)
    for k in BOOLS:
        if k in new:
            out[k] = bool(new[k])
    for k, (lo, hi) in LIMITS.items():
        if k == "stop_pct":
            hi = STOP_MAX.get(kind, 95)
        if k in new:
            try:
                v = float(new[k])
            except (TypeError, ValueError):
                raise GestorError(f"Valor no válido en {k}")
            if not lo <= v <= hi:
                raise GestorError(f"{k} debe estar entre {lo} y {hi}")
            out[k] = v
    for k, (lo, hi) in USD_LIMITS.items():
        if k in new:
            try:
                v = float(new[k])
            except (TypeError, ValueError):
                raise GestorError(f"Valor no válido en {k}")
            if not lo <= v <= hi:
                raise GestorError(f"{'El stop' if k == 'stop_usd' else 'El objetivo' if k == 'tp_usd' else 'El retroceso del trailing'} debe estar entre ${lo:,} y ${hi:,}")
            out[k] = v
    if "at_target" in new:
        if new["at_target"] not in ("close", "trail"):
            raise GestorError("Al llegar al objetivo: elige cerrar o seguir con trailing")
        out["at_target"] = new["at_target"]
    if "unit" in new:
        if new["unit"] not in ("usd", "pct"):
            raise GestorError("Unidad no válida")
        out["unit"] = new["unit"]
    if "time_exit" in new:
        t = str(new["time_exit"])
        if not HHMM.match(t) or not "09:30" <= t <= "15:59":
            raise GestorError("La hora de cierre debe ser HH:MM entre 09:30 y 15:59 (hora de Nueva York)")
        out["time_exit"] = t
    if "time_days" in new:
        try:
            v = int(new["time_days"])
        except (TypeError, ValueError):
            raise GestorError("Días antes de vencer no válidos")
        if not 0 <= v <= 5:
            raise GestorError("El cierre por hora puede ser de 0 a 5 días hábiles antes de vencer")
        out["time_days"] = v
    if out.get("unit", "pct") == "usd":
        if out.get("at_target") == "trail" and out["trail_usd"] >= out["tp_usd"]:
            raise GestorError("El retroceso del trailing debe ser menor que el objetivo (si no, podría cerrar en pérdida)")
    elif out["partial_on"] and out["partial_at"] >= out["tp_pct"]:
        raise GestorError("El parcial debe ser menor que la toma de ganancia")
    return out


def load():
    try:
        with open(FILE, encoding="utf-8") as f:
            d = json.load(f)
        with LOCK:
            S["cfg"] = clean_cfg(d.get("cfg") or {}, DEFAULTS)
            S["cfg_credit"] = clean_cfg(d.get("cfg_credit") or {}, DEFAULTS_CREDIT, "credit")
            S["cfg_debit"] = clean_cfg(d.get("cfg_debit") or {}, DEFAULTS_DEBIT, "debit")
            S["paused"] = bool(d.get("paused"))
            S["items"] = [i for i in d.get("items", []) if isinstance(i, dict) and i.get("id")]
            S["log"] = d.get("log", [])[-60:]
    except (OSError, ValueError, GestorError):
        pass
    _restore_once()


def _restore_once():
    """Si existe gestor_restaurar.json (ids de posiciones que se dieron por cerradas por error), las vuelve a vigilar una vez."""
    rf = os.path.join(os.path.dirname(FILE), "gestor_restaurar.json")
    if not os.path.exists(rf):
        return
    try:
        ids = {str(x) for x in json.load(open(rf, encoding="utf-8"))}
        with LOCK:
            for it in S["items"]:
                if str(it.get("id")) in ids and it.get("status") == "cerrada" and it.get("close_reason") == "cerrada por ti":
                    it.update(status="activa", qty=it.get("qty_ordered") or 1, realized=0.0, close_reason="", estimated=False,
                              exit_px=None, hold=False, errors=0, miss=0, close_order=None)
                    it.pop("ts_end", None)
                    _ev(it, "REACTIVADA: se había dado por cerrada por error (Tradier respondió sin posiciones); vuelvo a vigilarla")
        os.replace(rf, rf + ".hecho")
    except Exception:
        pass


def save():
    with LOCK:
        keep = [i for i in S["items"] if i["status"] in ("entrada", "activa", "cerrando")
                or time.time() - i.get("ts_end", i.get("ts", 0)) < 3 * 86400]
        S["items"] = keep[-60:]
        tmp = FILE + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"cfg": S["cfg"], "cfg_credit": S["cfg_credit"], "cfg_debit": S["cfg_debit"], "paused": S["paused"], "items": S["items"], "log": S["log"][-60:]}, f)
            os.replace(tmp, FILE)
            S["save_err"] = None
        except OSError as e:   # sin permiso o disco lleno: las reglas valen ahora pero NO sobreviven a un reinicio
            S["save_err"] = f"No pude escribir {FILE}: {e.__class__.__name__} ({e.strerror or e})"


def _ev(it, text):
    stamp = datetime.now(ET).strftime("%H:%M:%S")
    it.setdefault("ev", []).append([stamp, text])
    it["ev"] = it["ev"][-15:]
    S["log"].append([datetime.now(ET).strftime("%m-%d %H:%M:%S"), f"{_name(it)}: {text}"])


def _nm(occ):
    m = trading.OCC.match(occ or "")
    return f"{int(m.group(3)) / 1000:g} {'Call' if m.group(2) == 'C' else 'Put'} {m.group(1)[2:4]}/{m.group(1)[4:6]}" if m else str(occ)


def _label(legs, kind):
    ms = [trading.OCC.match(l["occ"]) for l in legs]
    exp = f"{ms[0].group(1)[2:4]}/{ms[0].group(1)[4:6]}"
    root = trading.root_of(legs[0]["occ"])
    pre = "" if root == "SPY" else f"{root} "

    def ks(t):
        return "/".join(f"{int(m.group(3)) / 1000:g}" for m in sorted((m for m in ms if m.group(2) == t), key=lambda m: m.group(3)))
    if any(_r(l) > 1 for l in legs) or len(legs) == 3:   # combinacion libre (mariposa, broken wing...)
        t = {m.group(2) for m in ms}
        nm = "Mariposa" if len(legs) == 3 and [_r(l) for l in legs] == [1, 2, 1] else "Combinación"
        return f"{pre}{nm} {exp} " + " ".join(f"{'+' if l['side'] == 'buy_to_open' else '−'}{_r(l) if _r(l) > 1 else ''}{int(m.group(3)) / 1000:g}{m.group(2)}"
                                             for l, m in sorted(zip(legs, ms), key=lambda x: (x[1].group(2), x[1].group(3))))
    if len(legs) == 4 and ks("P") and ks("C"):
        return f"{pre}{'Iron condor' if kind == 'credit' else 'Iron condor (débito)'} {exp} {ks('P')}P {ks('C')}C"
    t = ms[0].group(2)
    return f"{pre}{'Put' if t == 'P' else 'Call'} {'credit' if kind == 'credit' else 'debit'} spread {exp} {ks(t)}{t}"


def _name(it):
    return it.get("label") or _nm(it["occ"])


def _r(l):
    """Proporcion de la pata (mariposa 1:2:1 -> la del centro es 2)."""
    try:
        return max(1, int(l.get("ratio") or 1))
    except (TypeError, ValueError):
        return 1


def _legs_of(it):
    return it.get("legs") or [{"occ": it["occ"], "side": "buy_to_open"}]


def _inv(side):
    return {"sell_to_open": "buy_to_close", "buy_to_open": "sell_to_close"}[side]


# ───────────── llamadas a Tradier (cuenta explícita: no dependen del selector del panel) ─────────────
def _api(env, live, method, path, params=None, data=None):
    base, tok, acct = trading.creds(env, live)   # papel, tu real o la cuenta 2
    if not tok or not acct:
        raise trading.ApiError("Faltan las claves de la cuenta " + ("REAL" if live else "de papel") + " en ~/.tradier_env")
    try:
        r = requests.request(method, base + path.replace("{acct}", acct), params=params, data=data, timeout=12,
                             headers={"Authorization": f"Bearer {tok}", "Accept": "application/json"})
    except requests.RequestException as e:
        raise trading.ApiError(f"No se pudo conectar con Tradier: {e.__class__.__name__}")
    if r.status_code >= 400:
        raise trading.ApiError(f"Tradier {r.status_code}: {(r.text or '')[:200]}")
    try:
        return r.json()
    except ValueError:
        raise trading.ApiError("Respuesta de Tradier no válida")


def _quotes(env, live, occs):
    j = _api(env, live, "GET", "/markets/quotes", params={"symbols": ",".join(occs)})
    qs = trading._as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
    out = {}
    for q in qs:
        if not isinstance(q, dict):
            continue
        bid, ask, last = trading._num(q.get("bid")), trading._num(q.get("ask")), trading._num(q.get("last"))
        # precio medio SOLO con bid/ask validos; el "ultimo" puede ser de horas antes (al abrir el mercado, sin bid)
        mark = (bid + ask) / 2 if bid is not None and ask is not None and ask > 0 and bid >= 0 and ask >= bid else None
        if mark is not None and (ask - bid) > max(0.30, 0.5 * mark):   # bid/ask demasiado separados: precio poco confiable
            mark = None
        out[q.get("symbol")] = {"mark": mark, "bid": bid, "ask": ask}
    return out


def _held(env, live, occ):
    j = _api(env, live, "GET", "/accounts/{acct}/positions")
    raw = trading._as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    return sum(trading._num(p.get("quantity")) or 0 for p in raw if p.get("symbol") == occ)


def _posmap(env, live):
    j = _api(env, live, "GET", "/accounts/{acct}/positions")
    raw = trading._as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    out = {}
    for p in raw:
        out[p.get("symbol")] = out.get(p.get("symbol"), 0) + (trading._num(p.get("quantity")) or 0)
    return out


def _closable(it, pm):
    """Cuantos contratos de CADA pata puedo cerrar hoy: [n1, n2, ...] (0 si falta o va al revés)."""
    out = []
    for l in _legs_of(it):
        h = pm.get(l["occ"], 0)
        out.append(max(0, int((h if l["side"] == "buy_to_open" else -h) // _r(l))))
    return out


def spread_value(it, qm):
    """Valor actual del spread por contrato: costo de cerrar (crédito) o valor de venta (débito). None si falta algún precio."""
    tot = 0.0
    for l in it["legs"]:
        q = qm.get(l["occ"])
        if not q or q.get("mark") is None:
            return None
        sign = 1 if (l["side"] == "sell_to_open") == (it["kind"] == "credit") else -1
        tot += sign * q["mark"] * _r(l)
    cap = _max_value(it)
    if cap is not None and tot > cap + 0.05:   # un spread no puede valer mas que su ancho: cotizacion mala
        return None
    return max(0.0, round(tot, 4))


def _max_value(it):
    """Lo maximo que puede valer el spread (suma de los anchos de cada lado). None si no se puede saber."""
    try:
        if any(_r(l) > 1 for l in it["legs"]) or len(it["legs"]) == 3:   # combinacion: lo maximo que puede valer al vencimiento
            ks, legs = [], []
            for l in it["legs"]:
                m = trading.OCC.match(l["occ"])
                k = int(m.group(3)) / 1000
                ks.append(k)
                legs.append((m.group(2), k, (1 if (l["side"] == "sell_to_open") == (it["kind"] == "credit") else -1) * _r(l)))
            pts = [0.0] + sorted(ks) + [max(ks) * 3]
            val = lambda S_: sum(sg * (max(S_ - k, 0) if t == "C" else max(k - S_, 0)) for t, k, sg in legs)
            return max(val(x) for x in pts)
        by = {"C": [], "P": []}
        for l in it["legs"]:
            m = trading.OCC.match(l["occ"])
            by[m.group(2)].append(int(m.group(3)) / 1000)
        ws = [max(v) - min(v) for v in by.values() if len(v) == 2]
        return sum(ws) if ws and len(ws) == sum(1 for v in by.values() if v) else None
    except Exception:
        return None


def _fill_px(o, legs=None):
    """Precio medio de ejecución por contrato/spread (siempre positivo)."""
    px = trading._num(o.get("avg_fill_price"))
    if px:
        return abs(px)
    ls = trading._as_list(o.get("leg"))
    if ls and all(trading._num(l.get("avg_fill_price")) is not None for l in ls):
        qs = [trading._num(l.get("quantity")) or 1 for l in ls]
        u = min(qs)   # proporcion de cada pata = su cantidad / la cantidad mas chica
        net = sum((1 if "sell" in str(l.get("side")) else -1) * trading._num(l.get("avg_fill_price")) * (q / u) for l, q in zip(ls, qs))
        return abs(net) or None
    return None


def _fill_qty(o):
    """Contratos ejecutados. En ordenes de varias patas Tradier puede sumar las patas en el campo de la orden
    (un spread de 1 contrato = 2), asi que se usa el de las patas: el MENOR (si una pata va atrasada, esa manda)."""
    ls = trading._as_list(o.get("leg"))
    qs = [trading._num(l.get("exec_quantity")) for l in ls] if ls else []
    qs = [q for q in qs if q]
    if qs and len(qs) == len(ls):
        return min(qs)
    return trading._num(o.get("exec_quantity")) or (min(qs) if qs else None)


def _order(env, live, oid):
    return (_api(env, live, "GET", "/accounts/{acct}/orders/" + str(oid)).get("order")) or {}


# ───────────── reglas (función pura: fácil de probar) ─────────────
def decide(it, mark, now):
    """Devuelve None o (cantidad, motivo). 'mark' es el precio actual de la opción y 'now' la hora de Nueva York."""
    c, e = it["cfg"], it.get("entry")
    if not e or mark is None:
        return None
    qty = int(it["qty"])
    if qty < 1:
        return None
    if c.get("unit", "pct") == "usd":
        return _decide_usd(it, c, mark, qty, now)
    if it.get("kind") == "credit":
        return _decide_credit(it, c, e, mark, qty, now)
    peak = max(it.get("peak") or e, mark)
    pct = (mark / e - 1) * 100
    stop = e * (1 - c["stop_pct"] / 100)
    stop_name = "stop loss"
    if it.get("partial_done") and c["be_after_partial"] and e > stop:
        stop, stop_name = e, "stop en entrada (tras parcial)"
    if mark <= stop:
        return qty, stop_name
    if _time_due(it, c, now):
        return qty, _time_name(c)
    if pct >= c["tp_pct"]:
        return qty, "toma de ganancia"
    if c["trail_on"] and (peak / e - 1) * 100 >= c["trail_after"] and mark <= peak * (1 - c["trail_giveback"] / 100):
        return qty, "trailing"
    if c["partial_on"] and not it.get("partial_done") and pct >= c["partial_at"] and qty >= 2:
        n = max(1, min(qty - 1, int(round(qty * c["partial_frac"] / 100))))
        return n, "parcial"
    return None


def _decide_usd(it, c, mark, qty, now):
    """Reglas en dolares. Devuelve (qty, motivo), (0, 'armar') al llegar al objetivo con trailing, o None."""
    if it.get("stop_u") is None:
        return None
    pnl = pnl_per_unit(it, mark)                       # ganancia por contrato/spread (en precio de la opcion)
    peak = max(it.get("peak_u") if it.get("peak_u") is not None else pnl, pnl)
    if pnl <= -it["stop_u"] + 1e-9:
        return qty, "stop loss"
    if _time_due(it, c, now):
        return qty, _time_name(c)
    if it.get("armed"):
        if pnl <= peak - it["trail_u"] + 1e-9:
            return (0, "desarmar") if pnl < 0 else (qty, "trailing")
        return None
    if pnl >= it["tp_u"] - 1e-9:
        return (0, "armar") if c.get("at_target") == "trail" else (qty, "toma de ganancia")
    return None


def _decide_credit(it, c, e, mark, qty, now):
    """Spread de crédito: 'mark' es el costo de cerrar. Ganas cuando baja, pierdes cuando sube."""
    pct = (e - mark) / e * 100                       # % del crédito ya ganado (negativo = pérdida)
    peak_pct = max(it.get("peak_pct") or 0.0, pct)
    stop, stop_name = e * (1 + c["stop_pct"] / 100), "stop loss"
    if it.get("partial_done") and c["be_after_partial"] and e < stop:
        stop, stop_name = e, "stop en entrada (tras parcial)"
    if mark >= stop:
        return qty, stop_name
    if _time_due(it, c, now):
        return qty, _time_name(c)
    if mark <= e * (1 - c["tp_pct"] / 100):
        return qty, "toma de ganancia"
    if c["trail_on"] and peak_pct >= c["trail_after"] and pct <= peak_pct * (1 - c["trail_giveback"] / 100):
        return qty, "trailing"
    if c["partial_on"] and not it.get("partial_done") and pct >= c["partial_at"] and qty >= 2:
        n = max(1, min(qty - 1, int(round(qty * c["partial_frac"] / 100))))
        return n, "parcial"
    return None


LT_WINDOW, LT_MIN_READS = 90, 5                       # posiciones de varios dias: mediana de los ultimos 90 s (min. 5 lecturas)
LT_QUIET = (("09:30", "09:45"), ("15:45", "16:00"))   # y no actuar por stop/objetivo/trailing en estos minutos (cotizaciones erraticas)
ST_WINDOW, ST_MIN_READS = 30, 3                       # posiciones que VENCEN HOY: mediana de 30 s (min. 3 lecturas)
ST_QUIET = (("09:30", "09:35"),)                      # y no actuar en los primeros 5 min de la apertura (al cierre SI puede salir)


def long_term(it, now):
    """True si la posicion NO vence hoy (de varios dias)."""
    return (it.get("exp") or "") > now.strftime("%Y-%m-%d")


def quiet(now, lt=True):
    hm = now.strftime("%H:%M")
    return any(a <= hm < b for a, b in (LT_QUIET if lt else ST_QUIET))


def _smooth(it, mark, now, lt=True):
    """MEDIANA de las lecturas recientes (un brinco de segundos no cuenta): 90 s en posiciones de varios dias, 30 s si vence hoy.
    None mientras no haya suficientes lecturas."""
    t = time.time()
    win, need = (LT_WINDOW, LT_MIN_READS) if lt else (ST_WINDOW, ST_MIN_READS)
    h = [x for x in it.get("mh", []) if x[0] >= t - LT_WINDOW] + [[t, mark]]
    it["mh"] = h[-60:]
    h = [x for x in h if x[0] >= t - win]
    if len(h) < need:
        return None
    v = sorted(x[1] for x in h)
    n = len(v)
    return v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2


def market_open(now):
    return now.weekday() < 5 and "09:30" <= now.strftime("%H:%M") < "16:00"


# ───────────── registro de entradas ─────────────
def on_entry(order, occ, qty, live, price=None):
    """Lo llama trading.scalp tras enviar una COMPRA. Devuelve True si el gestor tomó la posición."""
    oid = str((order or {}).get("id") or "")
    m = trading.OCC.match(occ or "")
    with LOCK:
        if not oid or not m or not S["cfg"]["auto"] or any(i["id"] == oid for i in S["items"]):
            return False
        d = m.group(1)
        it = {"id": oid, "live": trading.akey(live), "occ": occ, "exp": f"20{d[:2]}-{d[2:4]}-{d[4:6]}", "qty": 0, "qty_ordered": int(qty),
              "kind": "single", "limit": price, "status": "entrada", "entry": None, "peak": None, "partial_done": False, "realized": 0.0,
              "cfg": dict(S["cfg"]), "ts": time.time(), "errors": 0, "close_order": None, "close_qty": 0, "close_reason": "",
              "req_close": False, "hold": False, "mark": None, "ev": []}
        _ev(it, f"orden de entrada #{oid} enviada ({qty} contrato(s)); gestor en espera")
        S["items"].append(it)
        save()
    return True


def prepare(typ, managed, mgr_cfg):
    """Valida ANTES de enviar la orden. Devuelve (vigilar, cfg). Lanza GestorError si las reglas no son válidas."""
    if typ not in ("credit", "debit"):
        raise GestorError("Tipo de orden no válido")
    with LOCK:
        base = dict(S[_cfg_key(typ)])
    cfg = clean_cfg(mgr_cfg, base, typ) if isinstance(mgr_cfg, dict) and mgr_cfg else base
    watch = base["auto"] if managed is None else bool(managed)
    return watch, cfg


def on_spread_entry(order, legs, qty, live, typ, cfg, sym=None):
    """Lo llama trading.send tras enviar una ENTRADA de varias patas. Devuelve True si el gestor la tomó a su cargo."""
    oid = str((order or {}).get("id") or "")
    legs = [dict({"occ": l.get("occ"), "side": l.get("side")}, **({"ratio": _r(l)} if _r(l) > 1 else {})) for l in (legs or [])]
    ms = [trading.OCC.match(str(l["occ"])) for l in legs]
    if (not oid or typ not in ("credit", "debit") or len(legs) not in (2, 3, 4) or not all(ms)
            or not all(l["side"] in ("sell_to_open", "buy_to_open") for l in legs)):
        return False
    d = ms[0].group(1)
    with LOCK:
        if any(i["id"] == oid for i in S["items"]):
            return False
        it = {"id": oid, "live": trading.akey(live), "kind": typ, "legs": legs, "label": _label(legs, typ), "occ": legs[0]["occ"],
              "sym": sym or trading.root_of(legs[0]["occ"]),
              "exp": f"20{d[:2]}-{d[2:4]}-{d[4:6]}", "qty": 0, "qty_ordered": int(qty), "status": "entrada", "entry": None,
              "peak": None, "peak_pct": None, "partial_done": False, "realized": 0.0, "cfg": dict(cfg), "ts": time.time(),
              "errors": 0, "close_order": None, "close_qty": 0, "close_reason": "", "req_close": False, "hold": False,
              "mark": None, "ev": []}
        _ev(it, f"orden de entrada #{oid} enviada ({qty} × {len(legs)} patas); gestor en espera")
        S["items"].append(it)
        save()
    return True


def adopt(env, live, body):
    """Pone bajo el gestor una posicion que YA esta abierta en la cuenta (no envia ninguna orden).
    body: legs [{occ, side de apertura}], qty, entry (precio por contrato/spread), kind single|credit|debit, cfg."""
    kind = body.get("kind")
    legs = [{"occ": str(l.get("occ") or ""), "side": l.get("side")} for l in (body.get("legs") or [])]
    try:
        qty, entry = int(body.get("qty")), round(float(body.get("entry")), 2)
    except (TypeError, ValueError):
        raise GestorError("Cantidad o precio de entrada no válidos")
    if qty < 1 or entry <= 0:
        raise GestorError("La cantidad y el precio de entrada deben ser mayores que 0")
    ms = [trading.OCC.match(l["occ"]) for l in legs]
    if not legs or not all(ms) or not all(l["side"] in ("sell_to_open", "buy_to_open") for l in legs):
        raise GestorError("Patas no válidas")
    if kind == "single":
        if len(legs) != 1 or legs[0]["side"] != "buy_to_open":
            raise GestorError("El gestor solo vigila opciones sueltas COMPRADAS")
    elif kind in ("credit", "debit"):
        if len(legs) not in (2, 4):
            raise GestorError("El gestor vigila estrategias de 2 o 4 patas (las de 3 patas ciérralas a mano)")
    else:
        raise GestorError("Tipo no válido")
    if len({m.group(1) for m in ms}) != 1:
        raise GestorError("Todas las patas deben tener el mismo vencimiento")
    cap = _max_value({"legs": legs}) if kind != "single" else None
    if cap and entry >= cap:
        raise GestorError(f"El precio de entrada (${entry:.2f}) no puede ser igual o mayor que el ancho del spread (${cap:g})")
    occs = sorted(l["occ"] for l in legs)
    with LOCK:
        if any(trading.akey(i["live"]) == trading.akey(live) and i["status"] in ("entrada", "activa", "cerrando")
               and sorted(l["occ"] for l in _legs_of(i)) == occs for i in S["items"]):
            raise GestorError("Esa posición ya la está vigilando el gestor")
        base = dict(S[_cfg_key(kind)])
    cfg = clean_cfg(body.get("cfg") or {}, base, kind)
    pm = _posmap(env, live)   # seguridad: que de verdad tengas cada pata, en esa direccion y cantidad
    for l in legs:
        h = pm.get(l["occ"], 0)
        if (h < qty) if l["side"] == "buy_to_open" else (-h < qty):
            m = trading.OCC.match(l["occ"])
            raise GestorError(f"No tienes {qty} de la pata {int(m.group(3)) / 1000:g} {'Call' if m.group(2) == 'C' else 'Put'} "
                              f"{'comprada' if l['side'] == 'buy_to_open' else 'vendida'} en la cuenta {'REAL' if live else 'de papel'}")
    d = ms[0].group(1)
    it = {"id": f"adoptada-{int(time.time() * 1000)}", "live": trading.akey(live), "kind": kind, "occ": legs[0]["occ"],
          "exp": f"20{d[:2]}-{d[2:4]}-{d[4:6]}", "qty": 0, "qty_ordered": qty, "status": "entrada", "entry": None, "peak": None,
          "peak_pct": None, "partial_done": False, "realized": 0.0, "cfg": cfg, "ts": time.time(), "errors": 0,
          "close_order": None, "close_qty": 0, "close_reason": "", "req_close": False, "hold": False, "mark": None, "ev": [],
          "adopted": True}
    if kind != "single":
        it.update(legs=legs, label=_label(legs, kind), sym=trading.root_of(legs[0]["occ"]))
    else:
        it["limit"] = entry
    _activate(it, qty, entry, [], prefix="ADOPTADA (ya estaba abierta; entrada según Tradier): ")
    with LOCK:
        S["items"].append(it)
        save()
    return snapshot()


# ───────────── vigilancia ─────────────
def levels(it):
    e, c = it.get("entry"), it["cfg"]
    if not e:
        return {"stop": None, "tp": None, "trail": None}
    cr = it.get("kind") == "credit"
    if c.get("unit", "pct") == "usd":
        if it.get("stop_u") is None:
            return {"stop": None, "tp": None, "trail": None}
        sg = -1 if cr else 1
        tr = None
        if it.get("armed") and it.get("peak_u") is not None:
            tr = e + sg * (it["peak_u"] - it["trail_u"])
        return {"stop": e - sg * it["stop_u"], "tp": e + sg * it["tp_u"], "trail": tr}
    if cr:
        return {"stop": e * (1 + c["stop_pct"] / 100), "tp": e * (1 - c["tp_pct"] / 100), "trail": None}
    return {"stop": e * (1 - c["stop_pct"] / 100), "tp": e * (1 + c["tp_pct"] / 100), "trail": None}


def pnl_per_unit(it, px):
    """Ganancia por spread/contrato al salir (o al valor actual) 'px'."""
    return (it["entry"] - px) if it.get("kind") == "credit" else (px - it["entry"])


def _finish(it, status, notices, title, text):
    it["status"], it["ts_end"] = status, time.time()
    notices.append((title, text))


def _activate(it, exq, px, notices, prefix="ENTRADA ejecutada: "):
    """Pone la posicion en 'activa' con su precio de entrada y calcula stop / objetivo / trailing."""
    it.update(qty=int(exq), entry=px, peak=px, status="activa")
    c = it["cfg"]
    cr = it["kind"] == "credit"
    if c.get("unit", "pct") == "usd":
        per = 100.0                                  # los dolares son POR CONTRATO: el total se escala con los contratos abiertos
        tot = int(exq)
        it["stop_u"], it["tp_u"], it["trail_u"] = c["stop_usd"] / per, c["tp_usd"] / per, c["trail_usd"] / per
        it["peak_u"], it["armed"] = 0.0, False
        if not cr and it["stop_u"] >= px:            # perder mas de lo que pagaste es imposible: el stop seria inalcanzable
            it["stop_u"] = px * 0.95
            _ev(it, f"aviso: tu stop (${c['stop_usd']:g}) es mayor que lo que pagaste (${px * per:.0f} por contrato); lo dejo en 95% del costo")
        lv = levels(it)
        txt = (f"{int(exq)} × ${px:.2f} · stop −${c['stop_usd']:g}/contrato = −${c['stop_usd'] * tot:g} en total ({'si cerrar cuesta' if cr else 'si vale'} ${lv['stop']:.2f}) · "
               f"objetivo +${c['tp_usd']:g}/contrato = +${c['tp_usd'] * tot:g} (${lv['tp']:.2f})" + (f" y luego trailing −${c['trail_usd']:g}/contrato" if c.get("at_target") == "trail" else ""))
    else:
        lv = levels(it)
        txt = (f"{int(exq)} × ${px:.2f} · stop {'cuando cerrar cuesta' if cr else 'si vale'} ${lv['stop']:.2f} "
               f"({'-' if not cr else '+'}{c['stop_pct']:g}%) · objetivo ${lv['tp']:.2f}")
    if (it.get("exp") or "") > datetime.now(ET).strftime("%Y-%m-%d"):
        txt += (" · posición de varios días: decide con la mediana de 90 s (ignora brincos de segundos) y no actúa de "
                "9:30 a 9:45 ni de 15:45 a 16:00")
    else:
        txt += " · vence hoy: decide con la mediana de 30 s (ignora brincos de segundos) y no actúa de 9:30 a 9:35"
    _ev(it, prefix + txt)
    notices.append(("Gestor: posición vigilada", f"{_name(it)}: " + txt))


def _handle_entry(env, it, notices):
    o = _order(env, it["live"], it["id"])
    st = o.get("status")
    exq = _fill_qty(o) or 0
    px = _fill_px(o) if it.get("legs") else trading._num(o.get("avg_fill_price"))
    if st == "filled" or (st in ("canceled", "expired") and exq > 0):
        if not px:
            _ev(it, "ejecutada pero Tradier aún no da el precio; reintento")
            return
        _activate(it, exq, px, notices)
    elif st in ("canceled", "rejected", "expired", "error"):
        _finish(it, "cancelada", notices, "Gestor: entrada no ejecutada", f"{_name(it)}: orden {st}; no hay nada que vigilar")
        _ev(it, f"la entrada terminó como {st}; no se vigila")
    elif time.time() - it["ts"] > 4 * 86400:
        _finish(it, "cancelada", notices, "Gestor", f"{_name(it)}: entrada sin ejecutar por días; se deja de esperar")


def _external_exit(env, it):
    """La cerraste tu (o Tradier): busca en las ordenes ejecutadas de la cuenta el precio REAL de salida.
    Devuelve (precio_medio, contratos) o None si no lo encuentra."""
    j = _api(env, it["live"], "GET", "/accounts/{acct}/orders")
    raw = trading._as_list((j.get("orders") or {}).get("order")) if isinstance(j.get("orders"), dict) else []
    want = {l["occ"]: ("buy_to_close" if l["side"] == "sell_to_open" else "sell_to_close") for l in _legs_of(it)}
    got = []
    for o in raw:
        if str(o.get("id")) == str(it["id"]) or o.get("status") != "filled" or o.get("class") not in ("option", "multileg"):
            continue
        try:
            when = datetime.fromisoformat(str(o.get("create_date", "")).replace("Z", "+00:00")).timestamp()
        except ValueError:
            continue
        if when < it["ts"] - 5:
            continue
        ls = trading._as_list(o.get("leg")) or [o]
        sides = {(l.get("option_symbol") or o.get("option_symbol")): l.get("side") or o.get("side") for l in ls}
        if set(sides) != set(want) or any(sides[k] != want[k] for k in want):
            continue
        px = _fill_px(o) if len(ls) > 1 else trading._num(o.get("avg_fill_price"))
        q = _fill_qty(o) if len(ls) > 1 else (trading._num(o.get("exec_quantity")) or None)
        if px and q:
            got.append((when, px, q))
    if not got:
        return None
    tot_q = sum(g[2] for g in got)
    return sum(g[1] * g[2] for g in got) / tot_q, min(tot_q, it["qty"])


def _closed_by_user(env, it, notices):
    px = q = None
    try:
        r = _external_exit(env, it)
        if r:
            px, q = r
    except trading.ApiError:
        pass
    if px:
        pnl = pnl_per_unit(it, px) * q * 100
        it["realized"] = round(it.get("realized", 0.0) + pnl, 2)
        it["exit_px"], it["estimated"] = px, False
        txt = f"cerrada por ti a ${px:.2f} · P&L total {it['realized']:+,.2f} USD"
    else:   # no encontre la orden: estimo con el ultimo precio que vi y lo marco como estimado
        m = it.get("mark")
        it["realized"] = round(it.get("realized", 0.0) + (pnl_per_unit(it, m) * it["qty"] * 100 if m is not None else 0.0), 2)
        it["estimated"] = True
        txt = f"cerrada por ti (no encontré el precio real; P&L ESTIMADO con el último precio visto: {it['realized']:+,.2f} USD)"
    it["qty"] = 0
    it["close_reason"] = "cerrada por ti"
    _finish(it, "cerrada", notices, "Gestor: posición ya cerrada", f"{_name(it)}: {txt}")
    _ev(it, txt)


def tp_price(it):
    """Precio de cierre que da EXACTAMENTE tu objetivo de ganancia (redondeado a tu favor al tick)."""
    c, e = it["cfg"], it.get("entry")
    if not e:
        return None
    credit = it.get("kind") == "credit"
    if c.get("unit", "pct") == "usd":
        u = it.get("tp_u")
        if u is None:
            return None
        px = e - u if credit else e + u
    else:
        px = e * (1 - c["tp_pct"] / 100) if credit else e * (1 + c["tp_pct"] / 100)
    root = (it.get("sym") or trading.root_of(it.get("occ") or "") or "").upper()
    tick = 0.05 if root.startswith("SPX") else 0.01
    n = px / tick
    n = math.floor(n + 1e-6) if credit else math.ceil(n - 1e-6)   # recompra: mas barato; venta: mas caro
    return round(max(tick, n * tick), 2)


def _cancel_order(env, it, reason):
    """Cancela la orden limite del objetivo para salir por otra regla (stop, hora, trailing o cierre manual)."""
    _api(env, it["live"], "DELETE", "/accounts/{acct}/orders/" + str(it["close_order"]))
    it["cancel_for"] = reason
    _ev(it, f"{reason.upper()}: cancelo la orden límite del objetivo (#{it['close_order']}) para salir a mercado")


def _send_close(env, it, qty, reason, notices, limit=None):
    """Cierra a mercado; si 'limit' viene (toma de ganancia), cierra con orden LIMITE a ese precio."""
    live, legs = it["live"], _legs_of(it)
    pm = _posmap(env, live)
    can = _closable(it, pm)
    if max(can) <= 0:
        _closed_by_user(env, it, notices)
        return
    if min(can) <= 0:   # falta alguna pata: un cierre multipata abriria patas nuevas
        it["hold"] = True
        it["errors"] = MAX_ERRORS
        _ev(it, "estructura incompleta en la cuenta (falta alguna pata): NO envío cierre para no abrir patas nuevas")
        notices.append(("⚠️ Gestor: ATENCIÓN", f"{_name(it)}: falta alguna pata en tu cuenta. No envié nada; ciérrala a mano."))
        return
    qty = int(min(qty, min(can), it["qty"]))
    if it.get("legs"):
        data = {"class": "multileg", "symbol": it.get("sym") or trading.root_of(it["occ"]) or trading.SYMBOL, "type": "market", "duration": "day"}
        if limit:
            data.update(type="debit" if it.get("kind") == "credit" else "credit", price=f"{limit:.2f}")
        for i, l in enumerate(legs):
            data[f"option_symbol[{i}]"], data[f"side[{i}]"], data[f"quantity[{i}]"] = l["occ"], _inv(l["side"]), str(qty * _r(l))
        reg = [{"occ": l["occ"], "side": _inv(l["side"])} for l in legs]
        what = "cerrando"
    else:
        data = {"class": "option", "symbol": trading.SYMBOL, "option_symbol": it["occ"], "side": "sell_to_close",
                "quantity": str(qty), "type": "market", "duration": "day"}
        if limit:
            data.update(type="limit", price=f"{limit:.2f}")
        reg = [{"occ": it["occ"], "side": "sell_to_close"}]
        what = "vendiendo"
    pv = _api(env, live, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
    po = pv.get("order") or {}
    if po.get("result") is False or po.get("status") in ("rejected", "error"):
        raise trading.ApiError("Tradier no acepta el cierre: " + str(po.get("status") or po)[:150])
    j = _api(env, live, "POST", "/accounts/{acct}/orders", data=data)
    order = j.get("order") or {}
    trading._register(order, reg, live=live)   # entra al reporte manual (de la cuenta que corresponda)
    it.update(status="cerrando", close_order=str(order.get("id") or ""), close_qty=qty, close_reason=reason,
              close_type="limit" if limit else "market", close_px=limit)
    it.pop("cancel_for", None)
    modo = f"con orden LÍMITE a ${limit:.2f}" if limit else "a mercado"
    _ev(it, f"{reason.upper()}: {what} {qty} {modo} (orden #{order.get('id')})")


def _handle_closing(env, it, notices, mark=None, now=None):
    o = _order(env, it["live"], it["close_order"])
    st = o.get("status")
    if it.get("close_type") == "limit" and st in ("open", "pending", "partially_filled") and not it.get("cancel_for"):
        reason = None
        if it.get("req_close"):
            reason = "cierre manual"
        elif mark is not None and now is not None and not S["paused"] and market_open(now):
            act = decide(it, mark, now)
            if act and act[1] not in ("toma de ganancia", "parcial", "armar", "desarmar"):
                reason = act[1]
                if (reason.startswith("stop") or reason == "trailing") and it.get("confirm") != reason:
                    it["confirm"] = reason   # tambien aqui: confirmo con la siguiente lectura
                    _ev(it, f"{reason} tocado (valor {mark:.2f}) con el límite esperando; lo confirmo en la siguiente lectura")
                    return
            elif it.pop("confirm", None):
                _ev(it, "falsa alarma: en la siguiente lectura ya no se cumplía; el límite sigue esperando")
        if reason:
            it.pop("confirm", None)
            it["req_close"] = False
            _cancel_order(env, it, reason)
        return
    if st == "filled" or (st in ("canceled", "expired") and (_fill_qty(o) or 0) > 0):
        q = int(_fill_qty(o) or it["close_qty"])
        px = (_fill_px(o) if it.get("legs") else trading._num(o.get("avg_fill_price"))) or it.get("mark") or it["entry"]
        pnl = pnl_per_unit(it, px) * q * 100
        it["realized"] = round(it.get("realized", 0.0) + pnl, 2)
        it["qty"] -= q
        it["errors"] = 0
        why = it["close_reason"]
        follow = it.pop("cancel_for", None)
        it.pop("close_type", None)
        if follow and it["qty"] > 0:   # se lleno solo una parte del limite y luego salto otra regla: el resto a mercado
            it["status"] = "activa"
            _ev(it, f"límite llenado en parte ({q}); el resto sale a mercado por {follow}")
            _send_close(env, it, it["qty"], follow, notices)
            return
        if it["qty"] <= 0:
            it["exit_px"] = px
            _finish(it, "cerrada", notices, f"Gestor: cerrada ({why})",
                    f"{_name(it)}: salió a ${px:.2f} · P&L total {it['realized']:+,.2f} USD")
            _ev(it, f"CERRADA por {why} a ${px:.2f} · P&L total {it['realized']:+,.2f}")
        else:
            if why == "parcial":
                it["partial_done"] = True
            it["status"] = "activa"
            notices.append(("Gestor: venta parcial", f"{_name(it)}: cerré {q} a ${px:.2f} ({pnl:+,.2f} USD). Quedan {it['qty']}."))
            _ev(it, f"{why}: vendidos {q} a ${px:.2f} ({pnl:+,.2f}); quedan {it['qty']}")
    elif st == "canceled" and it.get("cancel_for"):   # la cancele yo para salir por otra regla
        follow = it.pop("cancel_for")
        it.pop("close_type", None)
        it["status"] = "activa"
        _send_close(env, it, it["qty"], follow, notices)
    elif st in ("rejected", "canceled", "expired", "error"):
        it.pop("close_type", None)
        it["status"] = "activa"
        it["errors"] += 1
        _ev(it, f"el cierre ({it['close_reason']}) terminó como {st}; intento {it['errors']}/{MAX_ERRORS}")
        if it["errors"] >= MAX_ERRORS:
            it["hold"] = True
            notices.append(("⚠️ Gestor: ATENCIÓN", f"{_name(it)}: no pude cerrarla {MAX_ERRORS} veces. Revísala a mano."))


SWEEP_SEC = 30
_SWEEP = {}


def _sweep_closed(env, work, notices):
    """Cada 30 s: si cerraste una posicion vigilada por fuera del gestor (boton Cerrar, otra plataforma),
    el gestor la da por cerrada solo (con su P&L) en lugar de seguir 'vigilando' algo que ya no tienes."""
    for live in (False, True, trading.H):
        act = [i for i in work if i["live"] == live and i["status"] == "activa" and not i.get("close_order")]
        if not act or time.time() - _SWEEP.get(live, 0) < SWEEP_SEC:
            continue
        _SWEEP[live] = time.time()
        try:
            pm = _posmap(env, live)
        except Exception:
            continue
        for it in act:
            try:
                if max(_closable(it, pm)) > 0:
                    if it.get("miss"):
                        it["miss"] = 0
                        if it.get("hold_sweep"):
                            it["hold"] = it["hold_sweep"] = False
                            it["errors"] = 0
                            _ev(it, "las patas volvieron a aparecer en Tradier: sigo vigilando")
                    continue
                # Tradier a veces responde SIN posiciones por un momento (sobre todo fuera de horario):
                # solo la doy por cerrada si falta 3 veces seguidas (~90 s) Y encuentro la orden con que la cerraste.
                it["miss"] = it.get("miss", 0) + 1
                if it["miss"] < 3:
                    continue
                r = None
                try:
                    r = _external_exit(env, it)
                except trading.ApiError:
                    pass
                if r:
                    _closed_by_user(env, it, notices)
                elif not it.get("hold_sweep"):
                    it["hold"] = it["hold_sweep"] = True
                    _ev(it, "Tradier no muestra las patas pero NO encontré ninguna orden de cierre: no la doy por cerrada. "
                            "Pausada hasta que reaparezca; revisa tu cuenta en Tradier")
                    notices.append(("⚠️ Gestor: revisa tu cuenta", f"{_name(it)}: Tradier no muestra las patas y no hay orden de cierre. "
                                    "No la di por cerrada; la sigo esperando."))
            except Exception:
                pass


def tick(env, now=None):
    """Una pasada de vigilancia. Devuelve avisos [(titulo, texto)] para enviar a tus canales."""
    notices = []
    now = now or datetime.now(ET)
    with LOCK:
        work = [i for i in S["items"] if i["status"] in ("entrada", "activa", "cerrando")]
    if not work:
        return notices
    quotes = {}
    for live in (False, True, trading.H):
        occs = sorted({l["occ"] for i in work if i["live"] == live and (i["status"] == "activa" or i.get("close_type") == "limit")
                       for l in _legs_of(i)})
        if occs:
            try:
                quotes.update({(live, k): v for k, v in _quotes(env, live, occs).items()})
            except trading.ApiError:
                pass
    _sweep_closed(env, work, notices)
    for it in work:
        try:
            if it["status"] == "entrada":
                _handle_entry(env, it, notices)
            elif it["status"] == "cerrando":
                m = None
                if it.get("close_type") == "limit":
                    if it.get("legs"):
                        m = spread_value(it, {l["occ"]: quotes.get((it["live"], l["occ"])) for l in it["legs"]})
                    else:
                        m = (quotes.get((it["live"], it["occ"])) or {}).get("mark")
                    if m is not None:
                        lt_ = long_term(it, now)
                        m = None if quiet(now, lt_) else _smooth(it, m, now, lt_)
                    if m is not None:
                        it["mark"] = m
                _handle_closing(env, it, notices, m, now)
            elif it["status"] == "activa":
                if it.get("legs"):
                    v = spread_value(it, {l["occ"]: quotes.get((it["live"], l["occ"])) for l in it["legs"]})
                    q = {"mark": v} if v is not None else None
                else:
                    q = quotes.get((it["live"], it["occ"]))
                lt = long_term(it, now)
                if q and q["mark"] is not None:   # mediana: 90 s (varios dias) o 30 s (vence hoy)
                    sm = _smooth(it, q["mark"], now, lt)
                    q = {"mark": sm} if sm is not None else None
                if q and q["mark"] is not None:
                    it["mark"] = m = q["mark"]
                    prev = it.get("prev_mark")
                    it["prev_mark"] = m
                    # nivel CONFIRMADO: el peor de las dos ultimas lecturas (para credito, el costo mas alto)
                    cm = m if prev is None else (max(m, prev) if it.get("kind") == "credit" else min(m, prev))
                    if it.get("kind") == "credit":
                        it["peak"] = min(it.get("peak") or it["entry"], cm)
                        it["peak_pct"] = max(it.get("peak_pct") or 0.0, (it["entry"] - cm) / it["entry"] * 100)
                    else:
                        it["peak"] = max(it.get("peak") or it["entry"], cm)
                    if it.get("stop_u") is not None:
                        it["peak_u"] = max(it.get("peak_u") if it.get("peak_u") is not None else -1e9, pnl_per_unit(it, cm))
                manual = it.get("req_close")
                if it.get("hold") and not manual:
                    continue
                act = None
                if manual:
                    act = (it["qty"], "cierre manual")
                elif not S["paused"] and market_open(now) and q and not quiet(now, lt):
                    act = decide(it, q["mark"], now)
                if not act or not (act[1].startswith("stop") or act[1] in ("trailing", "armar")):
                    if it.pop("confirm", None):
                        _ev(it, "falsa alarma: en la siguiente lectura ya no se cumplía; sigo vigilando")
                if act and act[1] == "desarmar":
                    it["armed"], it["peak_u"] = False, pnl_per_unit(it, q["mark"])
                    _ev(it, "el trailing llegó a pérdida: el objetivo no se sostuvo, NO cierro (el stop sigue activo) y espero de nuevo el objetivo")
                elif act and act[1] == "armar" and it.get("confirm") == "armar":
                    it.pop("confirm", None)
                    it["armed"] = True
                    per = 100.0 * int(it["qty"])
                    _ev(it, f"OBJETIVO +${it['tp_u'] * per:.0f} alcanzado: sigo dentro con trailing (sale si retrocede ${it['trail_u'] * per:.0f} desde el máximo)")
                    notices.append(("Gestor: objetivo alcanzado 🎯", f"{_name(it)}: +${pnl_per_unit(it, q['mark']) * per:.0f}. Sigo dentro con trailing de ${it['trail_u'] * per:.0f}."))
                elif act and not manual and (act[1].startswith("stop") or act[1] in ("trailing", "armar")) and it.get("confirm") != act[1]:
                    it["confirm"] = act[1]   # primera lectura: espero la siguiente (3 s) para confirmar
                    _ev(it, f"{act[1]} tocado (valor {q['mark']:.2f}); lo confirmo con la siguiente lectura antes de cerrar")
                elif act:
                    it["req_close"] = False
                    it.pop("confirm", None)
                    lim = tp_price(it) if act[1] == "toma de ganancia" else None
                    _send_close(env, it, act[0], act[1], notices, limit=lim)
        except (trading.ApiError, GestorError) as e:
            it["errors"] = it.get("errors", 0) + 1
            _ev(it, f"error: {str(e)[:120]} ({it['errors']}/{MAX_ERRORS})")
            if it["errors"] >= MAX_ERRORS and not it.get("hold"):
                it["hold"] = True
                notices.append(("⚠️ Gestor: ATENCIÓN", f"{_name(it)}: {str(e)[:100]}. Dejé de actuar sobre ella: revísala a mano."))
        except Exception as e:  # nunca tumbar el hilo
            _ev(it, f"error inesperado: {e.__class__.__name__}")
    save()
    return notices


def loop(get_env, send_notice):
    """Hilo de fondo (lo arranca monitor_web.py). Cada 3 s si hay algo que vigilar."""
    load()
    while True:
        time.sleep(3)
        try:
            for title, text in tick(get_env()):
                send_notice(title, text)
        except Exception:
            pass


# ───────────── API para el panel ─────────────
def _pnl_bound(i, which):
    """P&L total (en $) al que saltaria el stop (negativo) o el objetivo (positivo) de esta posicion; None si aun no se conoce."""
    try:
        e, c, q = i.get("entry"), i["cfg"], i["qty"]
        if not e:
            return None
        if c.get("unit", "pct") == "usd":
            u = i.get("stop_u" if which == "stop" else "tp_u")
            if u is None:
                return None
            v = u * 100 * q
        else:
            v = e * c["stop_pct" if which == "stop" else "tp_pct"] / 100 * 100 * q
        return round(-v if which == "stop" else v, 2)
    except Exception:
        return None


def snapshot():
    with LOCK:
        items = []
        for i in sorted(S["items"], key=lambda x: (x["status"] not in ("entrada", "activa", "cerrando"), -x.get("ts", 0))):
            e, m = i.get("entry"), i.get("mark")
            kind = i.get("kind", "single")
            lv = levels(i)
            has = bool(e and m is not None)
            items.append({"id": i["id"], "live": i["live"], "occ": i["occ"], "name": _name(i), "kind": kind, "status": i["status"], "qty": i["qty"],
                          "qty_ordered": i.get("qty_ordered"), "entry": e, "mark": m, "peak": i.get("peak"),
                          "pct": (pnl_per_unit(i, m) / e * 100) if has else None,
                          "pnl": ((pnl_per_unit(i, m) * i["qty"] * 100 + i.get("realized", 0)) if has and i["status"] in ("entrada", "activa", "cerrando") else i.get("realized")),
                          "estimated": bool(i.get("estimated")), "exit_px": i.get("exit_px"),
                          "realized": i.get("realized", 0), "stop": lv["stop"], "tp": lv["tp"], "trail": lv.get("trail"), "armed": bool(i.get("armed")),
                          "unit": i["cfg"].get("unit", "pct"), "peak_usd": (i["peak_u"] * 100 * i["qty"]) if i.get("peak_u") is not None and i.get("stop_u") is not None else None,
                          "partial_done": i.get("partial_done"),
                          "hold": i.get("hold"), "req_close": i.get("req_close"), "cfg": i["cfg"], "ev": i.get("ev", [])[-6:],
                          "reason": i.get("close_reason"),
                          "legs": [l["occ"] for l in _legs_of(i)], "stop_pnl": _pnl_bound(i, "stop"), "tp_pnl": _pnl_bound(i, "tp")})
        return {"cfg": S["cfg"], "cfgs": {"single": S["cfg"], "credit": S["cfg_credit"], "debit": S["cfg_debit"]},
                "paused": S["paused"], "items": items[:20], "log": S["log"][-12:],
                "limits": {k: list(v) for k, v in LIMITS.items()}, "stop_max": STOP_MAX, "save_err": S.get("save_err"), "file": FILE}


def handle(method, path, body, env):
    """Rutas /api/gestor*. Devuelve el objeto JSON."""
    if method == "GET":
        return snapshot()
    if path == "/api/gestor_cfg":
        kind = body.get("kind", "single")
        if kind not in KINDS:
            raise GestorError("Tipo no válido")
        with LOCK:
            k = _cfg_key(kind)
            S[k] = clean_cfg(body.get("cfg") or {}, S[k], kind)
            save()
        return snapshot()
    if path == "/api/gestor_adopt":
        return adopt(env, trading.MODE["live"], body)
    if path == "/api/gestor_pause":
        with LOCK:
            S["paused"] = bool(body.get("paused"))
            save()
        return snapshot()
    if path == "/api/gestor_item":
        oid, action = str(body.get("id", "")), body.get("action")
        with LOCK:
            it = next((i for i in S["items"] if i["id"] == oid), None)
            if not it:
                raise GestorError("Posición no encontrada")
            if action == "close":
                if it["status"] != "activa":
                    raise GestorError("Solo se puede cerrar una posición activa (ya ejecutada y sin cierre en curso)")
                it["req_close"], it["hold"] = True, False
                _ev(it, "cierre manual pedido; se envía en unos segundos")
            elif action == "release":
                if it["status"] not in ("entrada", "activa"):
                    raise GestorError("No se puede soltar mientras hay un cierre en curso")
                it["status"], it["ts_end"] = "liberada", time.time()
                _ev(it, "liberada: el gestor ya no la vigila (queda abierta en tu cuenta)")
            elif action == "resume":
                it["hold"], it["errors"] = False, 0
                _ev(it, "reanudada")
            elif action == "set":
                if it["status"] not in ("entrada", "activa"):
                    raise GestorError("Solo se pueden editar las reglas de una posición vigilada (no cerrándose ni terminada)")
                it["cfg"] = clean_cfg(body.get("cfg") or {}, it["cfg"], it.get("kind", "single"))
                c = it["cfg"]
                if it["status"] == "activa" and c.get("unit") == "usd" and it.get("entry"):
                    it["stop_u"], it["tp_u"], it["trail_u"] = c["stop_usd"] / 100.0, c["tp_usd"] / 100.0, c["trail_usd"] / 100.0
                    if it["kind"] != "credit" and it["stop_u"] >= it["entry"]:
                        it["stop_u"] = it["entry"] * 0.95
                    if c.get("at_target") != "trail":
                        it["armed"] = False
                _ev(it, f"reglas editadas: stop −${c.get('stop_usd', 0):g} · objetivo +${c.get('tp_usd', 0):g}"
                        f"{' · trailing −$%g' % c['trail_usd'] if c.get('at_target') == 'trail' else ' · cerrar al objetivo'} (por contrato) · salida {c.get('time_exit')}")
            else:
                raise GestorError("Acción no válida")
            save()
        return snapshot()
    raise GestorError("No encontrado")
