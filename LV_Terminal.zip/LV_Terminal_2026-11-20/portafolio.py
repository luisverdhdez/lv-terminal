"""Pagina /portafolio: watchlist en vivo, acciones propias (con Vender / Liquidar), grafico y cadena del simbolo elegido.
Usa la cuenta del selector PAPEL/REAL (las ordenes reales piden confirmacion escrita). Lo sirve monitor_web.py; los datos vienen de /api/* de trading.py."""

PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portafolio · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}
.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 20px;margin-bottom:14px}
h1{font-size:20px;margin:0;letter-spacing:.06em}a{color:var(--cy);text-decoration:none;font-weight:700}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:14px}
.card.g{border-left-color:var(--ok)}.card.w{border-left-color:var(--warn)}
.lbl{color:var(--mut);font-size:12px;letter-spacing:.08em;margin-bottom:8px}
.grid2{display:grid;grid-template-columns:1fr 1.25fr;gap:14px}@media(max-width:1000px){.grid2{grid-template-columns:1fr}}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);text-align:right;font-weight:600;padding:5px 6px;white-space:nowrap}
td{padding:6px;text-align:right;border-top:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}
tr.clk{cursor:pointer}tr.clk:hover{background:#141418}tr.sel{background:#1a1a20}
.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}
button,.btn{background:var(--card);color:var(--mut);border:1px solid var(--line);border-radius:8px;padding:5px 11px;cursor:pointer;font-weight:700;font-size:12px}
button.on{color:var(--tx);border-color:var(--cy)}button.rollb{color:var(--cy);border-color:var(--cy)}
button.sell{color:var(--bad);border-color:var(--bad)}button.buy{color:var(--ok);border-color:var(--ok)}
input,select{background:#000000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px 8px;font-size:13px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.atm{background:#1c1c24}
#lw{height:clamp(420px,60vh,640px);border:1px solid transparent;border-radius:8px}
.tag{font-size:11px;color:var(--mut)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}
.kpi{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:10px 12px}.kpi span{display:block;font-size:11px;color:var(--mut);letter-spacing:.06em}.kpi b{font-size:20px}
.kpi small{display:block;font-size:11px;color:var(--mut);margin-top:2px}
.ltabs{display:flex;flex-wrap:wrap;gap:4px;align-items:center;margin:8px 0}.ltabs button{padding:3px 10px}
.soon{color:var(--warn);font-weight:700}.bell{color:var(--warn)!important;border-color:var(--warn)!important}
.al{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:4px 0;border-top:1px solid var(--line);font-size:12px}
.al.hit{color:var(--ok)}
.grid3{display:grid;grid-template-columns:1.3fr 1fr 1fr;gap:14px}@media(max-width:1100px){.grid3{grid-template-columns:1fr}}
.rng button{padding:3px 9px}
.card.w{position:relative}
.pane{position:relative}.pleg{position:absolute;left:6px;top:4px;z-index:11;display:flex;flex-direction:column;gap:2px;pointer-events:none;font:11px ui-monospace,Menlo,monospace;max-width:70%}
.pl{display:flex;gap:5px;align-items:center;background:rgba(12,12,15,.72);border-radius:5px;padding:1px 5px;color:#cfd8ea;pointer-events:auto;width:fit-content}.pl.off{opacity:.45}.pl i{width:8px;height:8px;border-radius:50%;display:inline-block}
.pl b{font-weight:600;color:#fff}.pl button{background:none;border:0;color:#7d8aa5;cursor:pointer;padding:0 2px;font-size:11px;display:none}.pl:hover button{display:inline}.pl button:hover{color:#fff}
.pmenu{position:absolute;top:34px;right:6px;width:min(360px,calc(100% - 12px));max-height:calc(100% - 44px);overflow:auto;z-index:40;background:#0c0c0f;border:1px solid #2b4a6b;border-radius:10px;padding:10px;box-shadow:0 8px 30px rgba(0,0,0,.6);font-size:12px}
.pmh{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.pms{color:#7d8aa5;font-size:11px;letter-spacing:.06em;margin:8px 0 4px;text-transform:uppercase}
.pmg{display:flex;flex-wrap:wrap;gap:5px}.pmenu button{background:#16161b;border:1px solid #202027;color:#e6ecf5;border-radius:7px;padding:4px 9px;cursor:pointer;font-size:12px}.pmenu button:hover{border-color:#5cc8ff}
.pmr{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:6px 0;border-top:1px solid #202027}.pmr label{display:flex;gap:4px;align-items:center;color:#9fb0cc}.pmr input[type=number]{width:56px;background:#000000;color:#e6ecf5;border:1px solid #202027;border-radius:6px;padding:3px 5px}.pmr input[type=color]{width:30px;height:24px;padding:0;border:1px solid #202027;background:none}

</style><script src="https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js"></script>
</head><body><main>
<header><h1 class="mono">PORTAFOLIO</h1>
 <div class="mono" style="font-size:13px"><span class="mut" id="acct"></span> &nbsp; <a href="/">← Inicio</a> &nbsp; <a href="/market">Market →</a> &nbsp; <a href="/fundamentales">Fundamentales →</a> &nbsp; <a href="/trade">Trading manual →</a></div></header>

<div class="card g" id="r_card">
 <div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">RESUMEN DE LA CUENTA · <b id="r_acct" style="color:var(--tx)"></b></div><span class="tag" id="r_note"></span></div>
 <div class="kpis" style="margin-top:10px">
  <div class="kpi"><span>VALOR DE LA CUENTA</span><b class="mono" id="r_eq">…</b><small id="r_cash"></small></div>
  <div class="kpi"><span>P&amp;L ABIERTO</span><b class="mono" id="r_open">…</b><small>posiciones que sigues teniendo</small></div>
  <div class="kpi"><span>REALIZADO HOY</span><b class="mono" id="r_hoy">…</b></div>
  <div class="kpi"><span>ESTA SEMANA</span><b class="mono" id="r_sem">…</b></div>
  <div class="kpi"><span>ESTE MES</span><b class="mono" id="r_mes">…</b></div>
  <div class="kpi"><span>ESTE AÑO</span><b class="mono" id="r_ano">…</b><small id="r_ntr"></small></div>
 </div>
 <div class="row" style="justify-content:space-between"><div class="tag">CRECIMIENTO: <span style="color:var(--ok)">━ ganancia realizada acumulada</span> <span id="r_eqleg" style="color:var(--cy);display:none">· ━ valor de la cuenta (desde hoy se guarda cada día)</span></div>
  <div class="row rng" id="r_rng"></div></div>
 <div id="r_chart" style="height:240px;margin-top:6px"></div>
</div>

<div class="card w" id="p_card">
 <div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">RESULTADO DE OPCIONES CERRADAS <span class="tag">(lo que ganaste o perdiste en opciones, según Tradier; las patas de un spread o condor cuentan como 1 operación)</span></div><span class="tag" id="p_note"></span></div>
 <div class="kpis" style="margin-top:10px">
  <div class="kpi"><span>ESTE MES</span><b class="mono" id="p_mes">…</b></div>
  <div class="kpi"><span>MES PASADO</span><b class="mono" id="p_pas">…</b></div>
  <div class="kpi"><span>ÚLTIMOS 30 DÍAS</span><b class="mono" id="p_30">…</b><small id="p_30n"></small></div>
  <div class="kpi"><span>PROMEDIO POR DÍA</span><b class="mono" id="p_ann">…</b><small id="p_anns">días operados en los últimos 30</small></div>
  <div class="kpi"><span>PRIMA EN JUEGO</span><b class="mono" id="p_open">…</b><small id="p_opens"></small></div>
 </div>
 <div class="grid3">
  <div><div class="tag">POR MES</div><div id="p_chart" style="height:200px"></div></div>
  <div style="border-left:2px solid var(--line);padding-left:14px"><div class="tag">TOTAL POR SEMANA (todos los activos)</div><table><thead><tr><th>Semana del</th><th>Ops</th><th>Gana %</th><th>P&amp;L de la semana</th></tr></thead><tbody id="p_wk"></tbody></table></div>
  <div style="border-left:2px solid var(--line);padding-left:14px"><div class="tag">TABLA APARTE · TOTAL POR ACTIVO, ÚLTIMOS 90 DÍAS (operaciones ya cerradas)</div><table><thead><tr><th>Activo</th><th>Ops</th><th>Gana %</th><th>P&amp;L 90 días</th></tr></thead><tbody id="p_un"></tbody></table></div>
 </div>
 <div id="p_obox" style="margin-top:12px;display:none"><div class="tag">POSICIONES A CRÉDITO ABIERTAS · cuánto de la prima ya capturaste</div>
  <table><thead><tr><th>Activo</th><th>Vence</th><th>Días</th><th>Prima cobrada</th><th>Cuesta cerrar</th><th>Capturado</th><th>%</th></tr></thead><tbody id="p_ob"></tbody></table></div>
</div>

<div class="grid2">
 <div class="card">
  <div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">WATCHLIST · EN VIVO <span class="tag" id="w_lag"></span></div>
   <form class="row" onsubmit="addSym();return false"><input id="w_new" placeholder="Símbolo, ej. AMD" maxlength="6" style="width:130px;text-transform:uppercase"><button class="buy">+ Agregar</button></form></div>
  <div class="ltabs" id="w_tabs"></div>
  <div style="overflow-x:auto"><table><thead><tr><th>Símbolo</th><th>Último</th><th>% Día</th><th>Bid</th><th>Ask</th><th>Volumen</th><th title="Próximo reporte de resultados">Earnings</th><th title="Fecha ex-dividendo">Ex-div</th><th></th></tr></thead><tbody id="w_body"><tr><td colspan="9" class="mut">Cargando…</td></tr></tbody></table></div>
  <div class="tag" id="w_msg" style="margin-top:6px">Haz clic en un símbolo para ver su gráfico. 🔔 = crear alerta de precio. <span class="soon">Amarillo</span> = en los próximos 7 días.</div>
  <div style="margin-top:10px;border-top:1px solid var(--line);padding-top:8px">
   <form class="row" onsubmit="alAdd();return false"><span class="tag">🔔 ALERTA</span><input id="a_sym" placeholder="Símbolo" maxlength="6" style="width:80px;text-transform:uppercase">
    <select id="a_op"><option value=">=">Cuando SUBA a</option><option value="<=">Cuando BAJE a</option></select>
    <input id="a_px" type="number" step="0.01" placeholder="Precio" style="width:100px"><input id="a_note" placeholder="Nota (opcional)" maxlength="60" style="width:140px"><button class="buy">Crear</button></form>
   <div id="a_list" style="margin-top:6px"></div>
   <div class="tag" id="a_msg"></div>
  </div>
 </div>

 <div class="card g" id="o_card" style="display:none">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div class="lbl">MIS OPCIONES (covered calls, puts, spreads) · <span id="o_tot"></span></div><span class="grpbar"></span></div>
  <div id="o_strat"></div>
  <div id="o_loose" style="overflow-x:auto"><table><thead><tr><th>Contrato</th><th>Cant.</th><th>Costo prom.</th><th>Último</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th><th>Vence</th><th></th></tr></thead><tbody id="o_body"></tbody></table></div>
  <div id="roll_box"></div>
  <div class="mut" style="font-size:11px;margin-top:6px">Para cerrar o gestionar opciones usa Trading manual.</div>
 </div>

 <div class="card g">
  <div class="lbl">MIS ACCIONES (STOCKS) · <span id="s_tot"></span></div>
  <div style="overflow-x:auto"><table><thead><tr><th>Ticker</th><th>Cant.</th><th>Costo prom.</th><th>Último</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th><th></th></tr></thead><tbody id="s_body"><tr><td colspan="8" class="mut">Cargando…</td></tr></tbody></table></div>
  <div class="row" style="margin-top:10px;border-top:1px solid var(--line);padding-top:10px"><span class="tag">COMPRAR (límite)</span>
   <input id="b_sym" placeholder="Ticker" maxlength="6" style="width:90px;text-transform:uppercase"><input id="b_qty" type="number" min="1" value="10" style="width:80px"><input id="b_px" type="number" step="0.01" placeholder="Precio límite" style="width:120px">
   <button onclick="fillPx()">Precio actual</button><button class="buy" onclick="buyStock()">Comprar</button></div>
  <div class="mono" id="s_msg" style="margin-top:8px;font-size:12px;min-height:16px"></div>
 </div>
</div>

<div class="card g" id="d_card">
 <div class="row" style="justify-content:space-between"><div class="lbl" style="margin:0">INGRESOS ESTIMADOS POR DIVIDENDOS · PRÓXIMOS 12 MESES · <b id="d_acct" style="color:var(--tx)"></b></div><span class="tag" id="d_note"></span></div>
 <div class="kpis" style="margin-top:10px">
  <div class="kpi"><span>ESTIMADO 12 MESES</span><b class="mono" id="d_tot">…</b><small id="d_yld"></small></div>
  <div class="kpi"><span><i style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#8b7cff;margin-right:4px"></i>ANUNCIADO</span><b class="mono" id="d_ann">…</b><small>fecha ya publicada por la empresa</small></div>
  <div class="kpi"><span><i style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#ff8c42;margin-right:4px"></i>ESTIMADO</span><b class="mono" id="d_est">…</b><small>repitiendo su último pago</small></div>
  <div class="kpi"><span>PROMEDIO AL MES</span><b class="mono" id="d_mes">…</b></div>
 </div>
 <div id="d_bars" style="display:flex;align-items:flex-end;gap:6px;height:170px;padding:8px 4px 0;border-bottom:1px solid var(--line)"></div>
 <div id="d_lbls" style="display:flex;gap:6px;padding:4px 4px 0" class="tag"></div>
 <div class="grid2" style="margin-top:12px;grid-template-columns:1fr 1.6fr">
  <div><div class="tag">POR ACCIÓN</div><table><thead><tr><th>Símbolo</th><th>Acciones</th><th>Frecuencia</th><th>Por acción</th><th>Rend. anual</th><th>12 meses</th></tr></thead><tbody id="d_sym"></tbody></table></div>
  <div><div class="tag">PAGOS ESPERADOS</div><div style="max-height:300px;overflow:auto"><table><thead><tr><th>Símbolo</th><th>Fecha ex-div.</th><th>Estado</th><th>Frecuencia</th><th>Por acción</th><th>Acciones</th><th>Ingreso</th></tr></thead><tbody id="d_rows"></tbody></table></div></div>
 </div>
 <div class="tag" style="margin-top:8px">Se calcula con las acciones y ETFs que tienes ahora en la cuenta del selector y el historial de pagos de cada uno (Yahoo Finance). La fecha es la <b>ex-dividendo</b> (debes tener la acción antes de ese día); el pago llega días después. Las empresas pueden subir, bajar o cancelar su dividendo: es un estimado.</div>
</div>

<div class="card w" id="gfull" style="display:none;padding:0;overflow:hidden">
 <iframe id="gframe" title="Gráfico completo" style="width:100%;height:860px;border:0;display:block;background:#000"></iframe>
</div>
<div class="card w">
 <div class="row" style="justify-content:space-between;margin-bottom:8px">
  <div class="lbl" style="margin:0"><b id="c_sym" style="color:var(--tx);font-size:16px">SPY</b> <span id="c_px" class="mono" style="color:var(--tx)"></span> <span id="c_chg" class="mono"></span></div>
  <div class="row"><button type="button" class="btn" id="c_ind" title="Indicadores (RSI, MACD, Bollinger, VWAP, medias…)">ƒx Indicadores</button><a id="c_fund" href="/fundamentales" class="btn" style="color:var(--cy)">📊 Fundamentales</a><button type="button" class="btn" id="c_full" onclick="gFull()" title="Abre el gráfico de Inicio con todas sus herramientas (más pesado)">🖥 Gráfico completo (como Inicio)</button><span id="c_tfs"></span></div></div>
 <div style="position:relative"><div id="lw"></div><div id="lk" class="mono" style="position:absolute;left:10px;top:8px;z-index:4;font-size:11px;color:var(--mut);background:rgba(0,0,0,.75);padding:3px 8px;border-radius:6px;pointer-events:none">🔒 Clic en el gráfico para mover / hacer zoom</div></div>
 <div class="tag" id="c_msg" style="margin-top:6px"></div>
</div>

</main>
<script>
const $=id=>document.getElementById(id);
const esc=x=>String(x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const money=v=>v==null?"–":(v>=0?"+$":"-$")+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const px=v=>v==null?"–":v.toFixed(2);
const cls=v=>v>0?"ok":v<0?"bad":"";
const vol=v=>v==null?"–":v>=1e6?(v/1e6).toFixed(1)+"M":v>=1e3?(v/1e3).toFixed(0)+"K":String(v);
const lsGet=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const getj=async p=>{const r=await fetch(p,{cache:"no-store"});return r.json()};
const post=async(p,b)=>{const r=await fetch(p,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});return r.json()};
let SYM=lsGet("p_sym","SPY"),TF=lsGet("p_tf","5"),WL=[],LAST={};
const TFS=[["1","1m"],["5","5m"],["15","15m"],["60","1h"],["D","1D"],["W","1S"],["M","1M"]];

/* ---------- watchlist ---------- */
let WCUR="",EV={},ALS=[];
const d7=d=>{if(!d)return false;const x=dte(d);return x>=0&&x<=7};
const shortD=d=>d?d.slice(5):"–";
async function loadWatch(){
  const j=await getj("/api/watch");if(j.error){$("w_msg").textContent=j.error;return}
  WL=j.rows.map(r=>r.sym);j.rows.forEach(r=>LAST[r.sym]=r.last);WCUR=j.cur||"";
  $("w_lag").textContent=j.live_data?"(precios en tiempo real)":"(papel: ~15 min de retraso)";
  if(j.lists)$("w_tabs").innerHTML=j.lists.map(n=>'<button class="'+(n===j.cur?"on":"")+'" onclick="wSel(\''+esc(n).replace(/'/g,"\\'")+'\')">'+esc(n)+'</button>').join("")
    +'<button onclick="wNew()" title="Nueva lista">＋ Lista</button>'+(j.lists.length?'<button onclick="wRen()" title="Cambiar nombre de esta lista">✎</button>':"")+(j.lists.length>1?'<button class="sell" onclick="wDel()" title="Borrar esta lista">🗑</button>':"");
  const act=new Set(ALS.filter(a=>!a.hit).map(a=>a.sym));
  $("w_body").innerHTML=j.rows.length?j.rows.map(r=>{const e=EV[r.sym]||{};
    return '<tr class="clk'+(r.sym===SYM?" sel":"")+'" onclick="pick(\''+r.sym+'\')"><td><b>'+esc(r.sym)+'</b> <span class="tag">'+esc((r.name||"").slice(0,18))+'</span></td><td class="mono"><b>'+px(r.last)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":(r.pct>0?"▲ +":r.pct<0?"▼ ":"")+r.pct.toFixed(2)+"%")+'</td><td class="mono">'+px(r.bid)+'</td><td class="mono">'+px(r.ask)+'</td><td class="mono">'+vol(r.vol)+'</td>'
     +'<td class="mono'+(d7(e.earn)?" soon":"")+'" title="'+(e.earn||"sin dato")+'">'+shortD(e.earn)+'</td>'
     +'<td class="mono'+(d7(e.exdiv)?" soon":"")+'" title="'+(e.exdiv?e.exdiv+(e.div?" · ~$"+e.div+" por acción":""):"sin dato")+'">'+(e.exdiv&&dte(e.exdiv)>=-3?shortD(e.exdiv):"–")+'</td>'
     +'<td><button class="'+(act.has(r.sym)?"bell":"")+'" onclick="event.stopPropagation();alFor(\''+r.sym+'\')" title="Crear alerta de precio">🔔</button> <button onclick="event.stopPropagation();rmSym(\''+r.sym+'\')" title="Quitar">✕</button></td></tr>'}).join("")
    :'<tr><td colspan="9" class="mut">Lista vacía: agrega un símbolo arriba.</td></tr>';
}
async function loadEv(){if(!WL.length)return;try{const j=await getj("/api/pf_eventos?syms="+WL.join(","));if(j.ev){EV=Object.assign(EV,j.ev);loadWatch()}}catch(e){}}
async function saveWatch(list){const j=await post("/api/watch_set",{symbols:list,list:WCUR});if(j.error){$("w_msg").textContent=j.error;return false}loadWatch();return true}
async function wAct(b){const j=await post("/api/watch_set",b);if(j.error){$("w_msg").textContent=j.error;return}await loadWatch();loadEv()}
function wSel(n){wAct({action:"select",list:n})}
function wNew(){const n=prompt("Nombre de la nueva lista (ej. Dividendos, Tecnología):");if(n)wAct({action:"new",name:n.trim()})}
function wRen(){const n=prompt("Nuevo nombre para la lista «"+WCUR+"»:",WCUR);if(n&&n.trim()!==WCUR)wAct({action:"rename",list:WCUR,name:n.trim()})}
function wDel(){if(confirm("¿Borrar la lista «"+WCUR+"»? (solo la lista, no toca tus posiciones)"))wAct({action:"delete",list:WCUR})}
async function addSym(){const s=$("w_new").value.trim().toUpperCase();if(!s)return;if(WL.includes(s)){$("w_msg").textContent=s+" ya está en la lista";return}
  if(await saveWatch(WL.concat([s]))){$("w_new").value="";$("w_msg").textContent=s+" agregado";loadEv()}}
async function rmSym(s){saveWatch(WL.filter(x=>x!==s))}
/* ---------- alertas ---------- */
function alFor(s){$("a_sym").value=s;if(LAST[s]!=null)$("a_px").value=LAST[s].toFixed(2);$("a_px").focus();$("a_px").select()}
function alRender(){const L=ALS.slice().sort((a,b)=>(!!a.hit)-(!!b.hit));
  $("a_list").innerHTML=L.map(a=>'<div class="al'+(a.hit?" hit":"")+'"><span class="mono"><b>'+esc(a.sym)+'</b> '+(a.op===">="?"sube a ≥ ":"baja a ≤ ")+a.px.toFixed(2)+(a.note?' <span class="tag">'+esc(a.note)+'</span>':"")+'</span><span>'
   +(a.hit?"✅ se cumplió "+esc(a.hit.slice(5))+" a "+(a.hit_px!=null?a.hit_px.toFixed(2):""):'<span class="tag">activa'+(LAST[a.sym]!=null?" · ahora "+LAST[a.sym].toFixed(2):"")+'</span>')
   +' <button onclick="alDel(\''+a.id+'\')" title="Borrar">✕</button></span></div>').join("")+(ALS.some(a=>a.hit)?'<div style="text-align:right;margin-top:4px"><button onclick="alPost({action:\'clear_hit\'})">Borrar las cumplidas</button></div>':"")
   +(ALS.length?"":'<div class="tag">Sin alertas. Te aviso con una notificación en la Mac (y Telegram/Discord si lo tienes) cuando el precio llegue.</div>')}
async function alLoad(){try{const j=await getj("/api/pf_alertas");if(j.alerts){ALS=j.alerts;alRender()}}catch(e){}}
async function alPost(b){const j=await post("/api/pf_alertas",b);if(j.error){$("a_msg").textContent=j.error;return false}ALS=j.alerts;$("a_msg").textContent="";alRender();loadWatch();return true}
async function alAdd(){const s=$("a_sym").value.trim().toUpperCase(),p=parseFloat($("a_px").value);
  if(!s||!(p>0)){$("a_msg").textContent="Escribe el símbolo y el precio";return}
  if(await alPost({action:"add",sym:s,op:$("a_op").value,px:p,note:$("a_note").value})){$("a_px").value="";$("a_note").value="";$("a_msg").textContent="Alerta creada para "+s}}
function alDel(id){alPost({action:"del",id})}
/* ---------- resumen + crecimiento ---------- */
let RC=null,RS=null,RE=null,RRANGE=lsGet("p_rng","3M"),RCUR=[];
const usd0=v=>v==null?"–":"$"+v.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const kset=(id,v,plain)=>{const e=$(id);e.textContent=plain?usd0(v):money(v);e.className="mono "+(plain?"":cls(v))};
function rInit(){if(RC||!window.LightweightCharts)return!!RC;
  RC=LightweightCharts.createChart($("r_chart"),{layout:{background:{color:"transparent"},textColor:"#7d8aa5"},grid:{vertLines:{color:"#15151a"},horzLines:{color:"#15151a"}},
    rightPriceScale:{borderColor:"#202027"},leftPriceScale:{visible:false,borderColor:"#202027"},timeScale:{borderColor:"#202027"},handleScroll:false,handleScale:false,autoSize:true});
  RS=RC.addAreaSeries({lineColor:"#4ff0b7",topColor:"rgba(79,240,183,.25)",bottomColor:"rgba(79,240,183,0)",lineWidth:2,priceFormat:{type:"price",precision:0,minMove:1}});
  RE=RC.addLineSeries({color:"#5cc8ff",lineWidth:2,priceScaleId:"left",priceFormat:{type:"price",precision:0,minMove:1}});
  $("r_rng").innerHTML=["1M","3M","6M","1A","Todo"].map(k=>'<button data-k="'+k+'">'+k+'</button>').join("");
  $("r_rng").onclick=e=>{const k=e.target.dataset&&e.target.dataset.k;if(k){RRANGE=k;lsSet("p_rng",k);rRange()}};return true}
function rRange(){[...$("r_rng").children].forEach(b=>b.className=b.dataset.k===RRANGE?"on":"");if(!RC||!RCUR.length)return;
  if(RRANGE==="Todo"){RC.timeScale().fitContent();return}
  const days={"1M":31,"3M":92,"6M":183,"1A":366}[RRANGE],to=new Date(),fr=new Date(Date.now()-days*864e5);const f=x=>x.toISOString().slice(0,10);
  try{RC.timeScale().setVisibleRange({from:f(fr),to:f(to)})}catch(e){RC.timeScale().fitContent()}}
async function loadRes(){let r;try{r=await getj("/api/pf_resumen")}catch(e){return}
  if(r.error){$("r_note").textContent=r.error;return}
  $("r_acct").textContent=r.acct||"";$("r_note").textContent=r.note||"";if(r.loading)setTimeout(loadRes,8000);
  kset("r_eq",r.equity,true);$("r_cash").textContent="Efectivo "+usd0(r.cash)+(r.option_bp!=null?" · BP opciones "+usd0(r.option_bp):"");
  kset("r_open",r.open_pnl);kset("r_hoy",r.realized.hoy);kset("r_sem",r.realized.semana);kset("r_mes",r.realized.mes);kset("r_ano",r.realized.ano);
  $("r_ntr").textContent=r.trades_year+" posiciones cerradas";
  if(!rInit())return;RCUR=r.curve||[];
  const t0=new Date().toISOString().slice(0,10);const cur=RCUR.length?RCUR:[{time:t0,value:0}];
  RS.setData(cur);const eh=r.equity_hist||[];RE.setData(eh.length>=2?eh:[]);
  RC.applyOptions({leftPriceScale:{visible:eh.length>=2}});$("r_eqleg").style.display=eh.length>=2?"inline":"none";rRange()}
/* ---------- dividendos ---------- */
const MES=["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
async function loadDiv(){let d;try{d=await getj("/api/pf_div")}catch(e){return}
  if(d.error){$("d_note").textContent=d.error;return}
  $("d_acct").textContent=d.acct||"";$("d_note").textContent=d.cargando?"⏳ buscando el historial de dividendos…":"";
  const u=v=>"$"+(v||0).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
  $("d_tot").textContent=u(d.total);$("d_ann").textContent=u(d.anunciado);$("d_est").textContent=u(d.estimado);$("d_mes").textContent=u(d.total/12);
  $("d_yld").textContent=d.yield!=null?d.yield+"% de lo que valen tus acciones ("+u(d.valor)+")":"";
  const M=d.meses||[],mx=Math.max(0.01,...M.map(m=>m.anunciado+m.estimado));
  $("d_bars").innerHTML=M.map(m=>{const a=m.anunciado/mx*150,e=m.estimado/mx*150,t=m.anunciado+m.estimado;
    return '<div style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center" title="'+m.m+': '+u(t)+'"><span class="tag mono" style="font-size:10px;margin-bottom:2px">'+(t?u(t):"")+'</span>'
     +'<div style="width:70%;height:'+e+'px;background:#ff8c42;border-radius:3px 3px 0 0"></div><div style="width:70%;height:'+a+'px;background:#8b7cff;'+(e?"":"border-radius:3px 3px 0 0")+'"></div></div>'}).join("");
  $("d_lbls").innerHTML=M.map(m=>'<div style="flex:1;text-align:center">'+MES[+m.m.slice(5)-1]+" "+m.m.slice(2,4)+'</div>').join("");
  $("d_sym").innerHTML=(d.por_simbolo||[]).map(b=>b.estado!=="ok"?'<tr><td><b>'+esc(b.sym)+'</b></td><td class="mono">'+b.qty+'</td><td colspan="4" class="mut" style="text-align:left">'+esc(b.estado)+'</td></tr>'
     :'<tr><td><b>'+esc(b.sym)+'</b></td><td class="mono">'+b.qty+'</td><td>'+esc(b.freq||"")+'</td><td class="mono">$'+b.rate.toFixed(4)+'</td><td class="mono">'+(b.yield!=null?b.yield+"%":"–")+'</td><td class="mono ok">'+u(b.anual)+'</td></tr>').join("")||'<tr><td colspan="6" class="mut">No tienes acciones en esta cuenta.</td></tr>';
  $("d_rows").innerHTML=(d.rows||[]).map(r=>'<tr><td><b>'+esc(r.sym)+'</b></td><td class="mono">'+r.fecha+'</td><td><span style="font-size:11px;padding:1px 7px;border-radius:99px;background:'+(r.estado==="Anunciado"?"rgba(139,124,255,.2);color:#b4abff":"rgba(255,140,66,.18);color:#ff9f5a")+'">'+r.estado+'</span></td><td>'+esc(r.freq)+'</td><td class="mono">$'+r.rate.toFixed(4)+'</td><td class="mono">'+r.qty+'</td><td class="mono"><b>'+u(r.monto)+'</b></td></tr>').join("")||'<tr><td colspan="7" class="mut">Sin pagos estimados.</td></tr>';
  if(d.cargando)setTimeout(loadDiv,8000)}
/* ---------- primas ---------- */
let PC=null,PS=null;
function pInit(){if(PC||!window.LightweightCharts)return!!PC;
  PC=LightweightCharts.createChart($("p_chart"),{layout:{background:{color:"transparent"},textColor:"#7d8aa5"},grid:{vertLines:{visible:false},horzLines:{color:"#15151a"}},
    rightPriceScale:{borderColor:"#202027"},timeScale:{borderColor:"#202027",tickMarkFormatter:t=>{const m=["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];return typeof t==="object"?m[t.month-1]:""}},handleScroll:false,handleScale:false,autoSize:true});
  PS=PC.addHistogramSeries({priceFormat:{type:"price",precision:0,minMove:1}});return true}
const wr=v=>v==null?"–":v+"%";
async function loadPrem(){let p;try{p=await getj("/api/pf_primas")}catch(e){return}
  if(p.error){$("p_note").textContent=p.error;return}$("p_note").textContent=p.note||"";if(p.loading)setTimeout(loadPrem,9000);
  kset("p_mes",p.this_month);kset("p_pas",p.last_month);kset("p_30",p.last30);$("p_30n").textContent=p.n30+" operaciones"+(p.wr30!=null?" · gana "+p.wr30+"%":"");
  kset("p_ann",p.per_day);$("p_anns").textContent=(p.days30||0)+" días operados"+(p.pct30!=null?" · 30 días = "+(p.pct30>0?"+":"")+p.pct30+"% de la cuenta":"");
  const O=p.open||[],cr=O.reduce((s,x)=>s+x.credit,0),cp=O.reduce((s,x)=>s+(x.captured||0),0);
  $("p_open").textContent=O.length?usd0(cr):"–";$("p_open").className="mono";$("p_opens").textContent=O.length?"ya capturado "+money(cp)+" ("+(cr?Math.round(cp/cr*100):0)+"%)":"sin posiciones a crédito";
  $("p_wk").innerHTML=p.weeks.slice().reverse().map(w=>'<tr><td class="mono">'+w.k.slice(5)+'</td><td class="mono">'+w.n+'</td><td class="mono">'+wr(w.wr)+'</td><td class="mono '+cls(w.pnl)+'">'+money(w.pnl)+'</td></tr>').join("")||'<tr><td colspan="4" class="mut">Sin operaciones</td></tr>';
  $("p_un").innerHTML=p.unders.map(u=>'<tr><td><b>'+esc(u.k)+'</b></td><td class="mono">'+u.n+'</td><td class="mono">'+wr(u.wr)+'</td><td class="mono '+cls(u.pnl)+'">'+money(u.pnl)+'</td></tr>').join("")||'<tr><td colspan="4" class="mut">Sin operaciones</td></tr>';
  $("p_obox").style.display=O.length?"block":"none";
  $("p_ob").innerHTML=O.map(x=>'<tr><td><b>'+esc(x.u)+'</b> <span class="tag">'+x.legs+' patas</span></td><td class="mono">'+x.exp+'</td><td class="mono">'+(x.dte==null?"–":x.dte)+'</td><td class="mono">'+usd0(x.credit)+'</td><td class="mono">'+(x.close==null?"–":usd0(x.close))+'</td><td class="mono '+cls(x.captured)+'">'+(x.captured==null?"–":money(x.captured))+'</td><td class="mono '+cls(x.pct)+'">'+(x.pct==null?"–":x.pct+"%")+'</td></tr>').join("");
  if(pInit()){PS.setData(p.months.map(m=>({time:m.k+"-01",value:m.pnl,color:m.pnl>=0?"rgba(79,240,183,.75)":"rgba(255,93,108,.75)"})));PC.timeScale().fitContent()}}
function pick(s){SYM=s;lsSet("p_sym",s);$("b_sym").value=s;loadWatch();
  firstFit=true;loadChart(true);
  if($("gframe").src)try{$("gframe").contentWindow.postMessage({sym:s},location.origin)}catch(e){}}
function gFull(){const f=$("gframe"),c=$("gfull"),on=c.style.display==="none";c.style.display=on?"block":"none";
  if(on&&!f.src)f.src="/grafico";if(!on)f.removeAttribute("src");$("c_full").textContent=on?"✕ Cerrar gráfico completo":"🖥 Gráfico completo (como Inicio)"}

/* ---------- agrupar patas en estrategias (igual que Inicio y Trading manual) ---------- */
function vname(v){return v.t==="P"?(v.s.strike>v.l.strike?"Put Credit Spread":"Put Debit Spread"):(v.s.strike<v.l.strike?"Call Credit Spread":"Call Debit Spread")}
function mkGroup(exp,vs,q){
  const legs=[];
  for(const v of vs)for(const l of [v.s,v.l])legs.push({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,q:v.q,frac:v.q/Math.abs(l.qty),l});
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0)*x.frac,0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark===null||x.l.mark===undefined)okv=false;else val+=x.sg*x.l.mark*x.q*100}
  const gr=k=>legs.reduce((a,x)=>a+((x.l[k]===null||x.l[k]===undefined)?0:x.sg*x.l[k]*x.q*100),0);
  let name;
  if(vs.length===2){const ps=vs.find(v=>v.t==="P").s.strike,cs=vs.find(v=>v.t==="C").s.strike;name=ps===cs?"Iron Fly":"Iron Condor"}
  else name=vname(vs[0]);
  return{name,exp,q,legs,entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,
    delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),strikes:legs.map(x=>x.strike).join(" / ")};
}
// Tradier no guarda que patas van juntas (solo cuantas unidades hay de cada opcion).
// Se empareja cada vendida con una comprada del mismo tipo minimizando la distancia total entre strikes.
function matchUnits(su,lu){
  const sw=su.length<=lu.length,A=sw?su:lu,B=sw?lu:su;
  if(!A.length)return[];
  const pair=(a,b)=>sw?[a,b]:[b,a];
  if(B.length<=6){
    let best=null,bc=1e18;const used=new Array(B.length).fill(false),cur=[];
    (function rec(i,c){
      if(c>=bc)return;
      if(i===A.length){bc=c;best=cur.slice();return}
      for(let j=0;j<B.length;j++){if(used[j])continue;used[j]=true;cur[i]=j;rec(i+1,c+Math.abs(A[i].strike-B[j].strike));used[j]=false}
    })(0,0);
    return A.map((a,i)=>pair(a,B[best[i]]));
  }
  const free=B.slice(),res=[];
  for(const a of A){let bi=0;for(let j=1;j<free.length;j++)if(Math.abs(free[j].strike-a.strike)<Math.abs(free[bi].strike-a.strike))bi=j;res.push(pair(a,free[bi]));free.splice(bi,1)}
  return res;
}
function groupPositions(legs){return grpApply(legs,groupAuto)}
function groupAuto(legs){
  const byExp={};for(const l of legs)(byExp[(l.root||"")+"|"+l.exp]=byExp[(l.root||"")+"|"+l.exp]||[]).push({...l,rem:Math.abs(l.qty)});
  const groups=[],loose=[];
  for(const key in byExp){
    const L=byExp[key],exp=L[0].exp,sym=L[0].root||"",verts=[];
    for(const t of ["P","C"]){
      const su=[],lu=[];
      for(const l of L.filter(x=>x.type===t)){const n=Math.floor(l.rem);for(let i=0;i<n;i++)(l.qty<0?su:lu).push(l)}
      const mp=new Map();
      for(const [s,c] of matchUnits(su,lu)){
        const key=s.occ+">"+c.occ;if(!mp.has(key))mp.set(key,{t,s,l:c,q:0});
        mp.get(key).q++;s.rem--;c.rem--;
      }
      for(const v of mp.values())verts.push(v);
    }
    const used=new Set(),pc=verts.filter(v=>v.t==="P"&&v.s.strike>v.l.strike),cc=verts.filter(v=>v.t==="C"&&v.s.strike<v.l.strike);
    for(const p of pc){const c=cc.find(x=>!used.has(x)&&x.q===p.q);if(c){used.add(p);used.add(c);groups.push(Object.assign(mkGroup(exp,[p,c],p.q),{sym}))}}
    for(const v of verts)if(!used.has(v))groups.push(Object.assign(mkGroup(exp,[v],v.q),{sym}));
    for(const l of L)if(l.rem>0)loose.push(l);
  }
  return{groups,loose};
}
const sgnc=v=>v===null||v===undefined?"":(v>0?"ok":v<0?"bad":"");
const usd=v=>v===null||v===undefined?"–":(v>=0?"+":"-")+"$"+Math.abs(v).toFixed(2);
function dte(exp){const et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  return Math.round((new Date(exp+"T00:00:00")-new Date(et.getFullYear(),et.getMonth(),et.getDate()))/86400000)}

/* ---------- acciones propias ---------- */
window.GRP_RENDER=()=>loadStocks();
async function loadStocks(){
  const j=await getj("/api/stocks");if(j.error){$("s_msg").textContent=j.error;return}
  $("s_tot").innerHTML='Valor <b class="mono">'+(j.value).toLocaleString("en-US",{style:"currency",currency:"USD"})+'</b> · P&L abierto <b class="mono '+cls(j.pnl)+'">'+money(j.pnl)+"</b>";
  const O=j.opts||[];$("o_card").style.display=O.length?"":"none";
  let loose=null,groups=[],sepd=new Set();
  if(O.length){try{const pj=await getj("/api/positions");if(!pj.error&&pj.legs){window.GRP_OSETS=pj.osets||[];const R=groupPositions(pj.legs.filter(l=>l.qty));groups=R.groups;loose=new Set(R.loose.map(l=>l.occ));sepd=new Set(R.loose.filter(l=>l.separada).map(l=>l.occ))}}catch(e){}}
  window.OPTS=O;
  if(O.length){$("o_tot").innerHTML='Valor <b class="mono">'+j.opt_value.toLocaleString("en-US",{style:"currency",currency:"USD"})+'</b> · P&L abierto <b class="mono '+cls(j.opt_pnl)+'">'+money(j.opt_pnl)+"</b>";
   $("o_strat").innerHTML=groups.length?'<div style="overflow-x:auto"><table><thead><tr><th>Estrategia</th><th>Vence</th><th>Cant.</th><th>Entrada</th><th>Cierre ahora</th><th>P&amp;L</th><th>Delta</th><th>Theta/día</th><th></th></tr></thead><tbody>'+groups.map(g=>{const cn=g.closeNow;return '<tr><td>'+grpChk(g.legs.map(x=>x.occ))+'<b>'+esc((g.sym?g.sym+" ":"")+g.name)+'</b><br><span class="mut">'+esc(g.strikes)+'</span></td><td class="mono">'+g.exp+" ("+dte(g.exp)+'d)</td><td class="mono">'+g.q+'</td><td class="mono">'+(g.entryNet>=0?"Crédito ":"Débito ")+Math.abs(g.entryNet).toFixed(2)+'</td><td class="mono">'+(cn===null?"–":(cn>=0?"Débito ":"Crédito ")+Math.abs(cn).toFixed(2))+'</td><td class="mono '+sgnc(g.pnl)+'"><b>'+usd(g.pnl)+'</b></td><td class="mono">'+g.delta.toFixed(1)+'</td><td class="mono '+sgnc(g.theta)+'">'+usd(g.theta)+'</td><td style="white-space:nowrap">'+grpSplitBtn(g.legs.map(x=>x.occ))+' <a class="btn" href="/trade#close='+encodeURIComponent(g.exp+"|"+g.strikes+"|"+g.q)+'">Cerrar</a></td></tr>'}).join("")+"</tbody></table></div>":"";
   const L=O.map((r,i)=>[r,i]).filter(([r])=>!loose||loose.has(r.sym));
   $("o_loose").style.display=L.length?"":"none";
   $("o_body").innerHTML=L.map(([r,i])=>'<tr><td>'+grpChk([r.sym])+'<b>'+esc(r.under)+'</b> '+r.strike+' '+(r.right=="CALL"?"Call":"Put")+(r.qty<0?' <span class="tag">corto</span>':"")+(sepd.has(r.sym)?grpLooseBtn({occ:r.sym,separada:true}):"")+'</td><td class="mono">'+r.qty+'</td><td class="mono">'+px(r.avg)+'</td><td class="mono">'+px(r.last)+'</td><td class="mono">'+(r.value==null?"–":r.value.toFixed(2))+'</td><td class="mono '+cls(r.pnl)+'"><b>'+money(r.pnl)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":r.pct.toFixed(2)+"%")+'</td><td class="mono">'+esc(r.exp||"–")+(r.dte==null?"":" ("+r.dte+"d)")+'</td><td><button class="rollb" onclick="openRoll('+i+')">⟳ Roll…</button></td></tr>').join("")}
  $("s_body").innerHTML=j.rows.length?j.rows.map(r=>{const short=r.qty<0;return '<tr class="clk" onclick="pick(\''+r.sym+'\')"><td><b>'+esc(r.sym)+'</b>'+(short?' <span class="tag">corto</span>':"")+'</td><td class="mono">'+r.qty+'</td><td class="mono">'+px(r.avg)+'</td><td class="mono">'+px(r.last)+'</td><td class="mono">'+(r.value==null?"–":r.value.toFixed(2))+'</td><td class="mono '+cls(r.pnl)+'"><b>'+money(r.pnl)+'</b></td><td class="mono '+cls(r.pct)+'">'+(r.pct==null?"–":r.pct.toFixed(2)+"%")+'</td><td><button class="sell" onclick="event.stopPropagation();sellStock(\''+r.sym+'\','+r.qty+',false)">Vender…</button> <button class="sell" onclick="event.stopPropagation();sellStock(\''+r.sym+'\','+r.qty+',true)">Liquidar</button></td></tr>'}).join(""):'<tr><td colspan="8" class="mut">No tienes acciones en esta cuenta. Puedes comprar abajo.</td></tr>';
}

/* ---------- roll de una opcion suelta (rueda) ---------- */
const RL={r:null,exps:[],chain:{},old:null};
function rlMid(o){return o&&o.bid!=null&&o.ask!=null&&o.ask>0?(o.bid+o.ask)/2:null}
async function rlChain(exp,under){const k=under+exp;if(!RL.chain[k]){const j=await getj("/api/chain?exp="+encodeURIComponent(exp)+"&sym="+encodeURIComponent(under));RL.chain[k]=j.error?{error:j.error}:j}return RL.chain[k]}
async function openRoll(i){
  const r=(window.OPTS||[])[i];if(!r)return;RL.r=r;RL.chain={};
  const box=$("roll_box");box.innerHTML='<div class="mut" style="margin-top:10px">Cargando vencimientos…</div>';
  const e=await getj("/api/expirations?sym="+encodeURIComponent(r.under));
  if(e.error){box.innerHTML='<div class="bad" style="margin-top:10px">'+esc(e.error)+"</div>";return}
  RL.exps=(e.dates||[]).filter(d=>d!==r.exp);
  if(!RL.exps.length){box.innerHTML='<div class="bad" style="margin-top:10px">No encontré otros vencimientos</div>';return}
  const later=RL.exps.find(d=>d>(r.exp||"")&&(new Date(d)-new Date(r.exp))/864e5>=5)||RL.exps.find(d=>d>(r.exp||""))||RL.exps[0];
  const short=r.qty<0,n=Math.abs(r.qty);
  box.innerHTML='<div style="border:1px solid var(--cy);border-radius:12px;padding:14px;margin-top:12px;background:#0a0a0d">'
   +'<div class="lbl" style="color:var(--cy)">ROLL · '+esc(r.under)+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+(short?" corto":" largo")+" ×"+n+" · vence "+esc(r.exp||"–")+"</div>"
   +'<div class="row" style="margin:8px 0"><span class="mut">Nuevo vencimiento</span><select id="rl_exp" onchange="rlLoad()">'+RL.exps.map(d=>'<option value="'+d+'"'+(d===later?" selected":"")+">"+d+"</option>").join("")+'</select>'
   +'<span class="mut">Nuevo strike</span><select id="rl_k" onchange="rlCalc(true)"></select>'
   +'<span class="mut">Cantidad</span><input id="rl_q" type="number" min="1" max="'+n+'" value="'+n+'" style="width:64px" oninput="rlCalc(true)"></div>'
   +'<div id="rl_legs" style="font-size:13px"></div>'
   +'<div class="row" style="margin:8px 0"><span id="rl_net"></span><select id="rl_t"><option value="credit">Crédito</option><option value="debit">Débito</option></select><span class="mut">Precio límite</span><input id="rl_p" type="number" step="0.01" min="0.01" style="width:90px"><button onclick="rlMidPx()">Usar mid</button></div>'
   +'<div class="row"><button class="buy" onclick="rlSend()">Enviar roll</button><button onclick="rlClose()">Cancelar</button><span class="tag">Una sola orden de 2 patas. Si no se llena, la modificas desde Órdenes.</span></div>'
   +'<div class="mono" id="rl_msg" style="font-size:12px;min-height:16px;margin-top:6px"></div></div>';
  rlLoad(true)}
function rlClose(){$("roll_box").innerHTML="";RL.r=null}
async function rlLoad(){
  const r=RL.r;if(!r)return;$("rl_msg").textContent="Cargando cadena…";
  const exp=$("rl_exp").value,[c,o]=await Promise.all([rlChain(exp,r.under),rlChain(r.exp,r.under)]);
  if(c.error){$("rl_msg").innerHTML='<span class="bad">'+esc(c.error)+"</span>";return}
  RL.old=((o.options||[]).find(x=>x.occ===r.sym))||null;
  const t=r.right=="CALL"?"C":"P",opts=(c.options||[]).filter(x=>x.type===t).sort((a,b)=>a.strike-b.strike);
  if(!opts.length){$("rl_msg").innerHTML='<span class="bad">Sin contratos para ese vencimiento</span>';return}
  let best=opts.reduce((a,b)=>Math.abs(b.strike-r.strike)<Math.abs(a.strike-r.strike)?b:a);
  $("rl_k").innerHTML=opts.map(x=>'<option value="'+x.occ+'"'+(x===best?" selected":"")+">"+x.strike+(x.delta!=null?" (Δ "+x.delta.toFixed(2)+")":"")+"</option>").join("");
  $("rl_msg").textContent="";rlCalc(true)}
function rlSel(){const c=RL.chain[RL.r.under+$("rl_exp").value];return c&&c.options?c.options.find(x=>x.occ===$("rl_k").value):null}
function rlCalc(setpx){
  const r=RL.r;if(!r)return;const nw=rlSel(),od=RL.old,short=r.qty<0;
  const oldB=od?od.bid:null,oldA=od?od.ask:null,oldM=od?rlMid(od):r.last;
  const nwM=rlMid(nw);let h="";
  const leg=(lbl,name,b,a)=>'<div style="display:grid;grid-template-columns:170px 1fr 1fr;gap:6px;padding:5px 0;border-top:1px solid var(--line)"><b class="mut">'+lbl+"</b><span>"+name+'</span><span class="mono mut">bid '+px(b)+" · ask "+px(a)+"</span></div>";
  h+=leg((short?"1. Comprar para cerrar":"1. Vender para cerrar"),esc(r.under)+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+" · "+esc(r.exp||""),oldB,oldA);
  h+=leg((short?"2. Vender para abrir":"2. Comprar para abrir"),nw?esc(r.under)+" "+nw.strike+" "+(r.right=="CALL"?"Call":"Put")+" · "+esc($("rl_exp").value):"–",nw?nw.bid:null,nw?nw.ask:null);
  $("rl_legs").innerHTML=h;
  let net=null;if(nwM!=null&&oldM!=null)net=short?(nwM-oldM):(oldM-nwM);
  RL.mid=net;
  $("rl_net").innerHTML=net==null?'<span class="mut">Sin precios para calcular el neto</span>':'Neto al mid: <b class="mono '+(net>=0?"ok":"bad")+'">'+(net>=0?"CRÉDITO $":"DÉBITO $")+Math.abs(net).toFixed(2)+'</b> <span class="mut">(≈ $'+Math.abs(net*100*(parseInt($("rl_q").value,10)||0)).toFixed(0)+" en total)</span>";
  if(setpx&&net!=null){$("rl_t").value=net>=0?"credit":"debit";$("rl_p").value=Math.max(0.01,Math.abs(net)).toFixed(2)}}
function rlMidPx(){if(RL.mid==null)return;$("rl_t").value=RL.mid>=0?"credit":"debit";$("rl_p").value=Math.max(0.01,Math.abs(RL.mid)).toFixed(2)}
async function rlSend(){
  const r=RL.r;if(!r)return;const q=parseInt($("rl_q").value,10),p=parseFloat($("rl_p").value),t=$("rl_t").value,nw=rlSel(),msg=$("rl_msg");
  if(!nw||!(q>=1)||!(p>0)){msg.innerHTML='<span class="bad">Revisa strike, cantidad y precio límite</span>';return}
  const body={old_occ:r.sym,new_occ:nw.occ,symbol:r.under,qty:q,price:p,type:t};
  msg.textContent="Revisando con el broker…";
  const pv=await post("/api/roll",Object.assign({preview:true},body));
  if(pv.error){msg.innerHTML='<span class="bad">'+esc(pv.error)+"</span>";return}
  const g=await guard("ROLL "+q+" × "+r.under+" "+r.strike+" "+(r.right=="CALL"?"Call":"Put")+" "+r.exp+"  →  "+nw.strike+" "+nw.occ.slice(-9,-8).replace("C","Call").replace("P","Put")+" "+$("rl_exp").value+"\n"+(t=="credit"?"Crédito":"Débito")+" límite $"+p.toFixed(2));if(!g)return;
  msg.textContent="Enviando…";
  const j=await post("/api/roll",Object.assign({},body,g));
  if(j.error){msg.innerHTML='<span class="bad">'+esc(j.error)+"</span>";return}
  msg.innerHTML='<span class="ok">Roll enviado (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+"). Míralo en Órdenes de Trading manual; si no se llena, usa Modificar.</span>";
  setTimeout(loadStocks,2000)}
async function sellStock(sym,qty,all){
  const short=qty<0,held=Math.abs(qty);let n=held;
  if(!all){const a=prompt((short?"Cubrir":"Vender")+" cuántas acciones de "+sym+"? (tienes "+held+")",String(held));if(a===null)return;n=parseInt(a,10);if(!(n>=1&&n<=held)){$("s_msg").innerHTML='<span class="bad">Cantidad no válida</span>';return}}
  const g=await guard((short?"CUBRIR ":"VENDER A MERCADO ")+n+" × "+sym+(all?" (liquidar toda la posición)":""));if(!g)return;
  $("s_msg").textContent="Enviando…";
  const j=await post("/api/stock_order",Object.assign({symbol:sym,side:short?"buy_to_cover":"sell",qty:n,type:"market"},g));
  $("s_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden enviada (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+")</span>";
  setTimeout(loadStocks,1500);loadStocks()}
function fillPx(){const s=($("b_sym").value||SYM).toUpperCase();const v=LAST[s];if(v!=null)$("b_px").value=v.toFixed(2);else $("s_msg").textContent="Ese símbolo no está en tu watchlist: escribe el precio a mano"}
async function buyStock(){
  const s=($("b_sym").value||"").trim().toUpperCase(),q=parseInt($("b_qty").value,10),p=parseFloat($("b_px").value);
  if(!s||!(q>=1)||!(p>0)){$("s_msg").innerHTML='<span class="bad">Escribe ticker, cantidad y precio límite</span>';return}
  const g=await guard("COMPRAR "+q+" × "+s+" a límite $"+p.toFixed(2)+" (≈ $"+(q*p).toFixed(0)+")");if(!g)return;
  $("s_msg").textContent="Enviando…";
  const j=await post("/api/stock_order",Object.assign({symbol:s,side:"buy",qty:q,type:"limit",price:p},g));
  $("s_msg").innerHTML=j.error?'<span class="bad">'+esc(j.error)+"</span>":'<span class="ok">Orden enviada (id '+esc((j.order||{}).id)+", "+esc((j.order||{}).status)+")</span>";
  setTimeout(loadStocks,1500)}

/* ===== matematica de indicadores (funciones puras; cada una devuelve arreglos alineados a las velas, null donde aun no hay dato) ===== */
const IM={
sma(v,n){const o=new Array(v.length).fill(null);let s=0;for(let i=0;i<v.length;i++){s+=v[i];if(i>=n)s-=v[i-n];if(i>=n-1)o[i]=s/n}return o},
ema(v,n){const o=new Array(v.length).fill(null);if(v.length<n)return o;const k=2/(n+1);let e=0;for(let i=0;i<n;i++)e+=v[i];e/=n;o[n-1]=e;for(let i=n;i<v.length;i++){e=v[i]*k+e*(1-k);o[i]=e}return o},
rsi(c,n){const o=new Array(c.length).fill(null);if(c.length<=n)return o;let g=0,l=0;for(let i=1;i<=n;i++){const d=c[i]-c[i-1];if(d>=0)g+=d;else l-=d}g/=n;l/=n;
  o[n]=l===0?100:100-100/(1+g/l);for(let i=n+1;i<c.length;i++){const d=c[i]-c[i-1];g=(g*(n-1)+(d>0?d:0))/n;l=(l*(n-1)+(d<0?-d:0))/n;o[i]=l===0?100:100-100/(1+g/l)}return o},
macd(c,f,s,g){const ef=IM.ema(c,f),es=IM.ema(c,s),m=c.map((_,i)=>ef[i]!=null&&es[i]!=null?ef[i]-es[i]:null);
  const idx=m.findIndex(x=>x!=null),sig=new Array(c.length).fill(null);if(idx>=0){const e=IM.ema(m.slice(idx),g);e.forEach((x,j)=>{sig[idx+j]=x})}
  return{macd:m,signal:sig,hist:m.map((x,i)=>x!=null&&sig[i]!=null?x-sig[i]:null)}},
bb(c,n,k){const m=IM.sma(c,n),u=[],l=[];for(let i=0;i<c.length;i++){if(m[i]==null){u.push(null);l.push(null);continue}let s=0;for(let j=i-n+1;j<=i;j++)s+=(c[j]-m[i])**2;const sd=Math.sqrt(s/n);u.push(m[i]+k*sd);l.push(m[i]-k*sd)}return{mid:m,up:u,lo:l}},
atr(b,n){const o=new Array(b.length).fill(null);if(b.length<=n)return o;const tr=b.map((x,i)=>i===0?x.high-x.low:Math.max(x.high-x.low,Math.abs(x.high-b[i-1].close),Math.abs(x.low-b[i-1].close)));
  let a=0;for(let i=1;i<=n;i++)a+=tr[i];a/=n;o[n]=a;for(let i=n+1;i<b.length;i++){a=(a*(n-1)+tr[i])/n;o[i]=a}return o},
stoch(b,k,d){const K=new Array(b.length).fill(null);for(let i=k-1;i<b.length;i++){let hi=-1e18,lo=1e18;for(let j=i-k+1;j<=i;j++){hi=Math.max(hi,b[j].high);lo=Math.min(lo,b[j].low)}K[i]=hi===lo?50:(b[i].close-lo)/(hi-lo)*100}
  const idx=K.findIndex(x=>x!=null),D=new Array(b.length).fill(null);if(idx>=0)IM.sma(K.slice(idx),d).forEach((x,j)=>{D[idx+j]=x});return{k:K,d:D}},
vwap(b){const o=[];let pv=0,vv=0,day=null;for(const x of b){const dk=Math.floor(x.time/86400);if(dk!==day){day=dk;pv=0;vv=0}const tp=(x.high+x.low+x.close)/3;pv+=tp*x.volume;vv+=x.volume;o.push(vv>0?pv/vv:null)}return o},
supertrend(b,n,m){const a=IM.atr(b,n),line=new Array(b.length).fill(null),dir=new Array(b.length).fill(0);let fu=0,fl=0,d=1;
  for(let i=0;i<b.length;i++){if(a[i]==null)continue;const hl=(b[i].high+b[i].low)/2,bu=hl+m*a[i],bl=hl-m*a[i];
    if(line[i-1]==null){fu=bu;fl=bl;d=b[i].close>=hl?1:-1}else{fu=(bu<fu||b[i-1].close>fu)?bu:fu;fl=(bl>fl||b[i-1].close<fl)?bl:fl;
      if(d===1&&b[i].close<fl)d=-1;else if(d===-1&&b[i].close>fu)d=1}
    line[i]=d===1?fl:fu;dir[i]=d}return{line,dir}}
};

/* ===== indicadores estilo TradingView (por grafico): superpuestos en el precio u osciladores en franjas debajo ===== */
const IND={
 sma:{n:"SMA",p:[["n","Período",20,2,500]],c:"#f5c542"},
 ema:{n:"EMA",p:[["n","Período",50,2,500]],c:"#ff8a65"},
 bb:{n:"Bollinger",p:[["n","Período",20,2,200],["k","Desv.",2,.5,5]],c:"#7c9cff"},
 vwap:{n:"VWAP",p:[],c:"#e040fb"},
 st:{n:"Supertrend",p:[["n","ATR",10,2,100],["m","Mult.",3,.5,10]],c:"#26c6da"},
 rsi:{n:"RSI",osc:1,p:[["n","Período",14,2,100]],c:"#b388ff",lv:[30,70],rng:[0,100]},
 macd:{n:"MACD",osc:1,p:[["f","Rápida",12,2,100],["s","Lenta",26,3,200],["g","Señal",9,2,50]],c:"#4fc3f7"},
 stoch:{n:"Estocástico",osc:1,p:[["k","%K",14,2,100],["d","%D",3,1,50]],c:"#ffb74d",lv:[20,80],rng:[0,100]},
 atr:{n:"ATR",osc:1,p:[["n","Período",14,2,100]],c:"#90a4ae"}
};
const IND_MAXOSC=3;
function indLabel(x){const d=IND[x.t];return d.n+(d.p.length?" "+d.p.map(q=>x.p[q[0]]).join(","):"")}
const IH={
 indLoad(){let a=[];try{a=JSON.parse(lsGet("ind"+this.i,"[]"))}catch(e){}
  this.ind=(Array.isArray(a)?a:[]).filter(x=>x&&IND[x.t]).map(x=>{const d=IND[x.t],p={};d.p.forEach(q=>{const v=+(x.p||{})[q[0]];p[q[0]]=isFinite(v)&&v>=q[3]&&v<=q[4]?v:q[2]});return{id:x.id||Math.random().toString(36).slice(2),t:x.t,p:p,c:/^#[0-9a-f]{6}$/i.test(x.c||"")?x.c:d.c,on:x.on!==false}})},
 indSave(){lsSet("ind"+this.i,JSON.stringify(this.ind.map(x=>({id:x.id,t:x.t,p:x.p,c:x.c,on:x.on}))))},
 indInit(){this.indLoad();const lg=document.createElement("div");lg.className="pleg";this.el.pc.appendChild(lg);this.el.leg=lg;
  this.el.ind.onclick=()=>this.indMenu();this.indRefresh()},
 indKill(){(this.indS||[]).forEach(s=>{try{this.chart.removeSeries(s)}catch(e){}});this.indS=[];(this.ind||[]).forEach(x=>{x.ss=[]})},
 indRefresh(){if(!this.chart)return;this.indKill();let slot=0;
  this.ind.forEach(x=>{x.ss=[];x.slot=null;if(!x.on)return;const d=IND[x.t],ch=this.chart;
   const reg=s=>{x.ss.push(s);this.indS.push(s);return s};
   const L=(o)=>reg(ch.addLineSeries(Object.assign({color:x.c,lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false},o)));
   if(d.osc){if(slot>=IND_MAXOSC){x.on=false;return}x.slot=slot;const id="os"+slot++;const base={priceScaleId:id,title:indLabel(x),lastValueVisible:true};
    if(x.t==="macd"){reg(ch.addHistogramSeries({priceScaleId:id,priceLineVisible:false,lastValueVisible:false}));L(Object.assign({},base,{lineWidth:2}));L({priceScaleId:id,color:"#ffa726"})}
    else if(x.t==="stoch"){L(Object.assign({},base,{lineWidth:2,autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})}));L({priceScaleId:id,color:"#ef5350",autoscaleInfoProvider:()=>({priceRange:{minValue:0,maxValue:100}})})}
    else{const o=Object.assign({},base,{lineWidth:2});if(d.rng)o.autoscaleInfoProvider=()=>({priceRange:{minValue:d.rng[0],maxValue:d.rng[1]}});L(o)}
    (d.lv||[]).forEach(v=>x.ss[x.ss.length-(x.t==="stoch"?2:1)].createPriceLine({price:v,color:"#3a4566",lineWidth:1,lineStyle:2,axisLabelVisible:false,title:""}))}
   else if(x.t==="bb"){L({lineWidth:1});L({lineWidth:1});L({lineWidth:1,lineStyle:2})}
   else if(x.t==="st"){L({lineWidth:2})}
   else L({lineWidth:2})});
  this.indLayout();this.indData();this.indLegend()},
 indLayout(){if(!this.chart)return;const k=this.ind.filter(x=>x.on&&IND[x.t].osc).length,H=0.17,V=k?0.07:0;
  this.cs.priceScale().applyOptions({scaleMargins:k?{top:0.06,bottom:V+k*H+0.02}:{top:0.2,bottom:0.1}});
  this.vs.priceScale().applyOptions({scaleMargins:{top:k?0.93:0.82,bottom:0}});
  this.ind.filter(x=>x.on&&x.slot!=null).forEach(x=>{const b=V+x.slot*H;try{this.chart.priceScale("os"+x.slot).applyOptions({scaleMargins:{top:1-b-H+0.01,bottom:b},visible:false,borderVisible:false})}catch(e){}})},
 indEmpty(){(this.ind||[]).forEach(x=>(x.ss||[]).forEach(s=>{try{s.setData([])}catch(e){}}));if(this.el.leg)this.el.leg.innerHTML=""},
 indData(){const B=this.bars||[];if(!this.chart||!B.length){this.indEmpty();return}
  const T=B.map(b=>b.time),C=B.map(b=>b.close),pts=(a,col)=>{const o=[];for(let i=0;i<a.length;i++)if(a[i]!=null&&isFinite(a[i]))o.push(col?{time:T[i],value:a[i],color:col(i)}:{time:T[i],value:a[i]});return o};
  this.ind.forEach(x=>{if(!x.on||!x.ss.length)return;const p=x.p;x.last=[];
   if(x.t==="sma"){const a=IM.sma(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="ema"){const a=IM.ema(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="vwap"){const a=(this.tf==="D"||this.tf==="240")?C.map(()=>null):IM.vwap(B);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="bb"){const r=IM.bb(C,p.n,p.k);x.ss[0].setData(pts(r.up));x.ss[1].setData(pts(r.lo));x.ss[2].setData(pts(r.mid));x.last=[r.up[B.length-1],r.mid[B.length-1],r.lo[B.length-1]]}
   else if(x.t==="st"){const r=IM.supertrend(B,p.n,p.m);x.ss[0].setData(pts(r.line,i=>r.dir[i]===1?"#4ff0b7":"#ff5d6c"));x.last=[r.line[B.length-1]]}
   else if(x.t==="rsi"){const a=IM.rsi(C,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="atr"){const a=IM.atr(B,p.n);x.ss[0].setData(pts(a));x.last=[a[a.length-1]]}
   else if(x.t==="macd"){const r=IM.macd(C,p.f,p.s,p.g);x.ss[0].setData(r.hist.map((v,i)=>v==null?null:{time:T[i],value:v,color:v>=0?"rgba(79,240,183,.55)":"rgba(255,93,108,.55)"}).filter(Boolean));
    x.ss[1].setData(pts(r.macd));x.ss[2].setData(pts(r.signal));const n=B.length-1;x.last=[r.macd[n],r.signal[n],r.hist[n]]}
   else if(x.t==="stoch"){const r=IM.stoch(B,p.k,p.d);x.ss[0].setData(pts(r.k));x.ss[1].setData(pts(r.d));const n=B.length-1;x.last=[r.k[n],r.d[n]]}});
  this.indLegend()},
 indLegend(){const lg=this.el.leg;if(!lg)return;const f=v=>v==null||!isFinite(v)?"–":(Math.abs(v)>=100?v.toFixed(1):v.toFixed(2));
  lg.innerHTML=(this.ind||[]).map(x=>'<div class="pl'+(x.on?"":" off")+'" data-id="'+x.id+'"><i style="background:'+x.c+'"></i><span>'+esc(indLabel(x))+'</span><b>'+(x.on&&x.last?x.last.map(f).join(" "):"")+'</b><button type="button" data-a="eye" title="Mostrar / ocultar">'+(x.on?"👁":"✕")+'</button><button type="button" data-a="set" title="Ajustes">⚙</button><button type="button" data-a="del" title="Quitar">🗑</button></div>').join("");
  lg.onclick=e=>{const b=e.target.closest("button"),r=e.target.closest(".pl");if(!b||!r)return;const x=this.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(b.dataset.a==="eye"){x.on=!x.on;this.indRefresh();this.indSave()}else if(b.dataset.a==="del"){this.ind=this.ind.filter(y=>y!==x);this.indRefresh();this.indSave()}else this.indMenu()}},
 indMenu(){const root=this.el.root;let m=root.querySelector(".pmenu");if(m){m.remove();return}
  m=document.createElement("div");m.className="pmenu";root.appendChild(m);const me=this;
  const draw=()=>{m.innerHTML='<div class="pmh"><b>ƒx Indicadores</b><button type="button" data-a="x">✕</button></div><div class="pms">Sobre el precio</div><div class="pmg">'+
    Object.keys(IND).filter(k=>!IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">En franja debajo (máx. '+IND_MAXOSC+')</div><div class="pmg">'+
    Object.keys(IND).filter(k=>IND[k].osc).map(k=>'<button type="button" data-add="'+k+'">+ '+IND[k].n+'</button>').join("")+'</div><div class="pms">Activos en este gráfico</div>'+
    (me.ind.length?me.ind.map(x=>'<div class="pmr" data-id="'+x.id+'"><b>'+IND[x.t].n+'</b>'+IND[x.t].p.map(q=>'<label>'+q[1]+' <input type="number" data-k="'+q[0]+'" value="'+x.p[q[0]]+'" min="'+q[3]+'" max="'+q[4]+'" step="'+(q[3]<1||q[0]==="k"&&x.t==="bb"||q[0]==="m"?0.5:1)+'"></label>').join("")+
     '<input type="color" data-k="c" value="'+x.c+'"><button type="button" data-a="del" title="Quitar">🗑</button></div>').join(""):'<div class="mut" style="font-size:12px">Ninguno todavía: elige uno arriba.</div>')+
    '<div class="pms" style="margin-top:8px"><button type="button" data-a="clr">Quitar todos</button></div>'};
  draw();
  m.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
   if(b.dataset.a==="x"){m.remove();return}
   if(b.dataset.add){const t=b.dataset.add,d=IND[t];if(d.osc&&me.ind.filter(y=>IND[y.t].osc&&y.on).length>=IND_MAXOSC){$("ch_hint")&&($("ch_hint").textContent="Máximo "+IND_MAXOSC+" indicadores en franja: quita uno");return}
    const p={};d.p.forEach(q=>p[q[0]]=q[2]);me.ind.push({id:Math.random().toString(36).slice(2),t:t,p:p,c:d.c,on:true})}
   else if(b.dataset.a==="del"){const id=b.closest(".pmr").dataset.id;me.ind=me.ind.filter(y=>y.id!==id)}
   else if(b.dataset.a==="clr")me.ind=[];else return;
   me.indRefresh();me.indSave();draw()});
  m.addEventListener("change",e=>{const i=e.target,r=i.closest(".pmr");if(!r||!i.dataset.k)return;const x=me.ind.find(y=>y.id===r.dataset.id);if(!x)return;
   if(i.dataset.k==="c")x.c=i.value;else{const q=IND[x.t].p.find(q=>q[0]===i.dataset.k),v=+i.value;if(isFinite(v)&&v>=q[3]&&v<=q[4])x.p[i.dataset.k]=v;else i.value=x.p[i.dataset.k]}
   me.indRefresh();me.indSave();draw()})}
};
/* ---------- grafico del simbolo elegido ---------- */
let LW=null,CS=null,VS=null,ES=null,SS=null,firstFit=true,busyC=false,CREQ=0,ZT=null;
function drawTfs(){$("c_tfs").innerHTML=TFS.map(t=>'<button class="'+(t[0]===TF?"on":"")+'" onclick="setTf(\''+t[0]+'\')">'+t[1]+"</button>").join(" ")}
function setTf(t){TF=t;lsSet("p_tf",t);drawTfs();firstFit=true;loadChart(true)}
function initChart(){
  if(LW||!window.LightweightCharts)return !!LW;
  LW=LightweightCharts.createChart($("lw"),{layout:{background:{color:"#0c0c0f"},textColor:"#9fb0cc"},grid:{vertLines:{color:"#1c1c22"},horzLines:{color:"#1c1c22"}},
    rightPriceScale:{borderColor:"#202027"},timeScale:{borderColor:"#202027",timeVisible:true,rightOffset:6},autoSize:true,
    handleScroll:{mouseWheel:false,pressedMouseMove:false,horzTouchDrag:true,vertTouchDrag:false},handleScale:{mouseWheel:false,pinch:true,axisPressedMouseMove:false,axisDoubleClickReset:true}});
  const box=$("lw"),setAct=on=>{LW.applyOptions({handleScroll:{mouseWheel:on,pressedMouseMove:on,horzTouchDrag:true,vertTouchDrag:false},handleScale:{mouseWheel:on,pinch:true,axisPressedMouseMove:on,axisDoubleClickReset:true}});
    box.style.borderColor=on?"#5cc8ff":"transparent";$("lk").textContent=on?"🔓 Zoom y mover activos · saca el ratón del gráfico para bloquear":"🔒 Clic en el gráfico para mover / hacer zoom"};
  box.addEventListener("mousedown",()=>setAct(true),true);box.addEventListener("mouseleave",()=>setAct(false));setAct(false);
  CS=LW.addCandlestickSeries({upColor:"#4ff0b7",downColor:"#ff5d6c",borderVisible:false,wickUpColor:"#4ff0b7",wickDownColor:"#ff5d6c"});
  ES=LW.addLineSeries({color:"#f5a03a",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
  SS=LW.addLineSeries({color:"#5cc8ff",lineWidth:2,priceLineVisible:false,lastValueVisible:false});
  VS=LW.addHistogramSeries({priceFormat:{type:"volume"},priceScaleId:""});VS.priceScale().applyOptions({scaleMargins:{top:0.82,bottom:0}});
  LW.timeScale().subscribeVisibleLogicalRangeChange(r=>{if(!r||firstFit||busyC)return;clearTimeout(ZT);
    ZT=setTimeout(()=>{const n=CS.data().length;if(n>1&&r.to>r.from)lsSet("pzoom_"+TF,JSON.stringify({w:+(r.to-r.from).toFixed(2),r:+(r.to-(n-1)).toFixed(2)}))},500)});
  IH.chart=LW;IH.cs=CS;IH.vs=VS;IH.i="pf";IH.bars=[];IH.tf=TF;IH.el={pc:$("lw").parentNode,root:document.querySelector(".card.w"),ind:$("c_ind")};
  IH.indInit();IH.el.leg.style.top="32px";
  return true}
async function loadChart(reset){
  /* la actualizacion de cada 10 s se salta si hay una carga en curso; un cambio de simbolo o temporalidad
     SIEMPRE carga, y las respuestas viejas (de un simbolo anterior) se descartan */
  if(busyC&&!reset)return;
  const my=++CREQ,sym=SYM,tf=TF;busyC=true;
  try{
    $("c_sym").textContent=sym;$("c_fund").href="/fundamentales?sym="+sym;
    if(reset)$("c_msg").textContent="Cargando "+sym+"…";
    if(!initChart()){$("c_msg").textContent="No cargó la librería del gráfico (¿sin internet?)";return}
    const c=await getj("/api/c?sym="+encodeURIComponent(sym)+"&i="+tf);
    if(my!==CREQ||sym!==SYM||tf!==TF)return;
    if(c.error){$("c_msg").textContent=c.error;return}
    $("c_msg").textContent=c.bars.length?"Línea naranja EMA 20 · azul SMA 50 · sandbox con ~15 min de retraso"+(c.vol_proxy?" · volumen de "+c.vol_proxy+" (el índice no tiene volumen)":""):"Sin velas (mercado cerrado o sin datos)";
    CS.setData(c.bars.map(b=>({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close})));
    VS.setData(c.bars.map(b=>({time:b.time,value:b.volume,color:b.close>=b.open?"rgba(79,240,183,.35)":"rgba(255,93,108,.35)"})));
    ES.setData(c.ema);SS.setData(c.sma);
    IH.bars=c.bars;IH.tf=TF;IH.indData();
    if(reset||firstFit){const N={"1":120,"5":100,"15":90,"60":90,"D":120,"W":104,"M":60}[TF]||100,n=c.bars.length;CS.priceScale().applyOptions({autoScale:true});
      let z=null;try{z=JSON.parse(lsGet("pzoom_"+TF,"null"))}catch(e){}
      if(z&&z.w>=5&&z.w<=5000&&Math.abs(z.r)<=500){const to=n-1+z.r;LW.timeScale().setVisibleLogicalRange({from:to-z.w,to})}   // como lo dejaste
      else LW.timeScale().setVisibleLogicalRange({from:Math.max(-1,n-N),to:n+6});firstFit=false}
    const l=c.bars[c.bars.length-1],p=c.bars[c.bars.length-2];
    if(l){$("c_px").textContent=l.close.toFixed(2);const d=p?l.close-p.close:0;$("c_chg").textContent=p?(d>=0?"▲ +":"▼ ")+d.toFixed(2):"";$("c_chg").className="mono "+cls(d)}
  }catch(e){if(my===CREQ)$("c_msg").textContent="Error del gráfico: "+e}finally{if(my===CREQ)busyC=false}}

async function acct(){try{const a=await getj("/api/account");if(a&&a.equity!=null)$("acct").textContent="Equity $"+a.equity.toLocaleString("en-US")+(a.option_bp!=null?" · BP opciones $"+a.option_bp.toLocaleString("en-US"):"")}catch(e){}}

drawTfs();
$("gframe").addEventListener("load",()=>setTimeout(()=>{try{$("gframe").contentWindow.postMessage({sym:SYM},location.origin)}catch(e){}},1500));   // el grafico ahora es el mismo de Inicio (marco /grafico)
$("b_sym").value=SYM;
alLoad().then(()=>loadWatch().then(loadEv));loadStocks();loadChart(true);setInterval(()=>loadChart(false),10000);acct();loadRes();loadPrem();loadDiv();setInterval(()=>{if(!document.hidden)loadDiv()},600000);
setInterval(loadWatch,5000);setInterval(alLoad,20000);setInterval(loadEv,120000);setInterval(()=>{if(!document.hidden)loadRes()},30000);setInterval(()=>{if(!document.hidden)loadPrem()},60000);setInterval(loadStocks,5000);
</script></body></html>
"""
