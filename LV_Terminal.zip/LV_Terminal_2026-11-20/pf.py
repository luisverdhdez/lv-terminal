"""Datos de la pagina Portafolio: resumen de la cuenta, crecimiento, ingresos por primas,
alertas de precio y eventos (earnings / ex-dividendo) de la watchlist.
Funciona con la cuenta del selector (PAPEL / REAL / cuenta 2). Solo LEE la cuenta: aqui no se manda ninguna orden."""
import json
import os
import re
import threading
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import trading
from trading import ApiError, _as_list, _num

ET = ZoneInfo("America/New_York")
D = trading.DATA_DIR
EQ_FILE = os.path.join(D, "pf_equity.json")
AL_FILE = os.path.join(D, "pf_alertas.json")
EV_FILE = os.path.join(D, "pf_eventos.json")
OPT = re.compile(r"^([A-Z.]{1,6}?)W?(\d{6})([CP])(\d{8})$")
_lock = threading.Lock()
_GL = {}


def mkey(live=None):
    k = trading.akey(trading.MODE["live"] if live is None else live)
    return "h" if k == trading.H else ("real" if k else "papel")


def _load(p, d):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return d


def _save(p, obj):
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, p)


def today():
    return datetime.now(ET).date()


def under(sym):
    m = re.match(r"^([A-Z.]+?)(\d{6})([CP])(\d{8})$", str(sym))
    if not m:
        return None
    u = m.group(1)
    return {"SPXW": "SPX", "XSPW": "XSP", "NDXP": "NDX", "RUTW": "RUT"}.get(u, u)


# ───────────── P&L realizado (gainloss de Tradier) ─────────────
def gainloss(env, days=400):
    """Posiciones cerradas del ultimo ~ano. Cache 10 min por cuenta; si Tradier falla, lo ultimo bueno."""
    k = mkey()
    hit = _GL.get(k)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    start = (today() - timedelta(days=days)).isoformat()
    rows, page = [], 1
    try:
        while page <= 20:
            j = trading._call(env, "GET", "/accounts/{acct}/gainloss",
                              params={"start": start, "end": today().isoformat(), "limit": 1000, "page": page, "sortBy": "closeDate", "sort": "asc"})
            gl = j.get("gainloss") if isinstance(j, dict) else None
            got = _as_list(gl.get("closed_position")) if isinstance(gl, dict) else []
            rows += got
            if len(got) < 1000:
                break
            page += 1
    except ApiError:
        if hit:
            return hit[1]
        disk = _load(os.path.join(D, f"pf_gl_{k}.json"), None)
        if disk is not None:
            return disk
        raise
    out = []
    for r in rows:
        cd = str(r.get("close_date", ""))[:10]
        g = _num(r.get("gain_loss"))
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", cd) or g is None:
            continue
        s = str(r.get("symbol", ""))
        u = under(s)
        out.append({"d": cd, "sym": s, "u": u or s, "opt": u is not None, "g": round(g, 2),
                    "cost": _num(r.get("cost")), "proceeds": _num(r.get("proceeds")), "qty": _num(r.get("quantity"))})
    _GL[k] = (time.time(), out)
    try:
        _save(os.path.join(D, f"pf_gl_{k}.json"), out)
    except OSError:
        pass
    return out


_GL_BUSY = set()


def gainloss_bg(env):
    """Historial SIN esperar: devuelve lo que haya (memoria o disco) y lo actualiza en segundo plano.
    -> (filas o None si todavia no hay nada, nota)"""
    k = mkey()
    hit = _GL.get(k)
    if hit and time.time() - hit[0] < 600:
        return hit[1], ""
    if k not in _GL_BUSY:
        _GL_BUSY.add(k)
        live = trading.MODE["live"]

        def run():
            try:
                if trading.MODE["live"] == live:
                    gainloss(env)
            except Exception:  # noqa: BLE001
                pass
            finally:
                _GL_BUSY.discard(k)
        threading.Thread(target=run, daemon=True).start()
    if hit:
        return hit[1], ""
    disk = _load(os.path.join(D, f"pf_gl_{k}.json"), None)
    if disk is not None:
        return disk, ""
    return None, "⏳ Pidiendo a Tradier tu historial (puede tardar si Tradier anda lento)…"


def _today_extra(env, rows):
    """Tradier publica lo cerrado HOY hasta el dia siguiente: se suma lo de hoy que da el panel."""
    t = today().isoformat()
    if any(r["d"] == t for r in rows):
        return 0.0
    try:
        return trading.summary(env).get("realized") or 0.0
    except Exception:  # noqa: BLE001
        return 0.0


def _week(d):
    x = date.fromisoformat(d)
    return (x - timedelta(days=x.weekday())).isoformat()


# ───────────── resumen + crecimiento ─────────────
def record_equity(eq, k=None, d=None):
    if eq is None:
        return
    with _lock:
        all_ = _load(EQ_FILE, {})
        cur = all_.setdefault(k or mkey(), {})
        cur[d or today().isoformat()] = round(eq, 2)
        for x in sorted(cur)[:-800]:
            cur.pop(x)
        try:
            _save(EQ_FILE, all_)
        except OSError:
            pass


def resumen(env):
    j = trading._call(env, "GET", "/accounts/{acct}/balances")
    b = j.get("balances") or {}
    m = b.get("margin") or {}
    eq = _num(b.get("total_equity"))
    record_equity(eq)
    rows, note = gainloss_bg(env)
    loading = rows is None
    rows = rows or []
    extra = _today_extra(env, rows)
    t = today()
    per = {"hoy": t.isoformat(), "semana": (t - timedelta(days=t.weekday())).isoformat(),
           "mes": t.replace(day=1).isoformat(), "ano": t.replace(month=1, day=1).isoformat()}
    real = {k: round(sum(r["g"] for r in rows if r["d"] >= v) + extra, 2) for k, v in per.items()}
    daily = {}
    for r in rows:
        daily[r["d"]] = daily.get(r["d"], 0) + r["g"]
    if extra:
        daily[t.isoformat()] = daily.get(t.isoformat(), 0) + extra
    curve, acc = [], 0.0
    for d in sorted(daily):
        acc += daily[d]
        curve.append({"time": d, "value": round(acc, 2)})
    eqs = _load(EQ_FILE, {}).get(mkey(), {})
    try:
        s = trading.summary(env)
        open_pnl = s.get("open")
    except Exception:  # noqa: BLE001
        open_pnl = None
    return {"acct": trading.acct_name(env, trading.MODE["live"]), "key": mkey(),
            "equity": eq, "cash": _num(b.get("total_cash")), "market_value": _num(b.get("market_value")),
            "option_bp": _num(m.get("option_buying_power", b.get("option_buying_power"))),
            "open_pnl": open_pnl, "realized": real, "curve": curve,
            "equity_hist": [{"time": d, "value": v} for d, v in sorted(eqs.items())],
            "trades_year": len([r for r in rows if r["d"] >= per["ano"]]), "note": note, "loading": loading}


# ───────────── ingresos por primas ─────────────
def primas(env):
    rows, note = gainloss_bg(env)
    loading = rows is None
    rows = [r for r in (rows or []) if r["opt"]]
    t = today()
    months, weeks, unders = {}, {}, {}
    rows = trades(rows)
    for r in rows:
        for bucket, key in ((months, r["d"][:7]), (weeks, _week(r["d"]))):
            x = bucket.setdefault(key, {"pnl": 0.0, "n": 0, "w": 0})
            x["pnl"] += r["g"]
            x["n"] += 1
            x["w"] += r["g"] > 0
        if r["d"] >= (t - timedelta(days=90)).isoformat():
            u = unders.setdefault(r["u"], {"pnl": 0.0, "n": 0, "w": 0})
            u["pnl"] += r["g"]
            u["n"] += 1
            u["w"] += r["g"] > 0
    extra = _today_extra(env, rows)
    if extra:
        for bucket, key in ((months, t.isoformat()[:7]), (weeks, _week(t.isoformat()))):
            x = bucket.setdefault(key, {"pnl": 0.0, "n": 0, "w": 0})
            x["pnl"] += extra
    fmt = lambda dct: [dict(k=k, pnl=round(v["pnl"], 2), n=v["n"], wr=round(v["w"] / v["n"] * 100) if v["n"] else None)
                       for k, v in sorted(dct.items())]
    d30 = (t - timedelta(days=30)).isoformat()
    last30 = round(sum(r["g"] for r in rows if r["d"] > d30) + extra, 2)
    try:
        eq = trading.account(env).get("equity")
    except ApiError:
        eq = None
    n30 = [r for r in rows if r["d"] > d30]
    days30 = len({r["d"] for r in n30})
    cm, pm = t.isoformat()[:7], (t.replace(day=1) - timedelta(days=1)).isoformat()[:7]
    mm = {x["k"]: x["pnl"] for x in fmt(months)}
    return {"months": fmt(months)[-13:], "weeks": fmt(weeks)[-10:],
            "unders": sorted(fmt(unders), key=lambda x: -abs(x["pnl"]))[:10],
            "this_month": mm.get(cm, 0.0), "last_month": mm.get(pm, 0.0), "last30": last30,
            "wr30": round(sum(r["g"] > 0 for r in n30) / len(n30) * 100) if n30 else None, "n30": len(n30),
            "annual_pct": round(last30 / eq * 12 * 100, 1) if eq else None, "equity": eq,
            "per_day": round(last30 / days30, 2) if days30 else None, "days30": days30,
            "pct30": round(last30 / eq * 100, 1) if eq else None,
            "open": open_premium(env), "note": note, "loading": loading}


def trades(rows):
    """Tradier da una fila por PATA (un spread = 2, un condor = 4). Se juntan las patas del mismo activo,
    mismo vencimiento y mismo dia de cierre en una sola operacion, para contar operaciones y % ganadoras de verdad."""
    g = {}
    for r in rows:
        m = re.match(r"^[A-Z.]+?(\d{6})[CP]\d{8}$", r["sym"])
        k = (r["d"], r["u"], m.group(1) if m else r["sym"])
        x = g.setdefault(k, {"d": r["d"], "u": r["u"], "sym": r["sym"], "opt": r["opt"], "g": 0.0, "legs": 0})
        x["g"] = round(x["g"] + r["g"], 2)
        x["legs"] += 1
    return list(g.values())


def open_premium(env):
    """Posiciones a credito abiertas: prima cobrada, lo que cuesta cerrar hoy y cuanto ya capturaste."""
    try:
        legs = trading.positions(env)["legs"]
    except ApiError:
        return []
    g = {}
    for l in legs:
        if not l.get("qty") or l.get("cost") is None:
            continue
        k = (l.get("root") or "", l.get("exp") or "")
        x = g.setdefault(k, {"cost": 0.0, "val": 0.0, "ok": True, "legs": 0})
        x["cost"] += l["cost"]
        x["legs"] += 1
        if l.get("mark") is None:
            x["ok"] = False
        else:
            x["val"] += l["mark"] * l["qty"] * 100
    out = []
    for (root, exp), x in g.items():
        credit = -x["cost"]
        if credit <= 0:
            continue
        close = -x["val"] if x["ok"] else None
        cap = credit - close if close is not None else None
        try:
            dte = (date.fromisoformat(exp) - today()).days
        except ValueError:
            dte = None
        out.append({"u": {"SPXW": "SPX", "XSPW": "XSP"}.get(root, root), "exp": exp, "dte": dte, "legs": x["legs"],
                    "credit": round(credit, 2), "close": None if close is None else round(close, 2),
                    "captured": None if cap is None else round(cap, 2),
                    "pct": None if cap is None else round(cap / credit * 100)})
    out.sort(key=lambda r: (r["exp"], r["u"]))
    return out


# ───────────── alertas de precio ─────────────
def alerts():
    return _load(AL_FILE, [])


def alerts_post(body):
    with _lock:
        lst = alerts()
        act = body.get("action")
        if act == "add":
            sym = str(body.get("sym", "")).strip().upper()
            if not trading.SYM_RE.match(sym):
                raise ApiError("Símbolo no válido")
            op = body.get("op")
            if op not in (">=", "<="):
                raise ApiError("Elige si avisa cuando SUBA o cuando BAJE al precio")
            try:
                px = round(float(body.get("px")), 2)
            except (TypeError, ValueError):
                raise ApiError("Precio no válido")
            if not 0 < px < 1_000_000:
                raise ApiError("Precio no válido")
            if len([a for a in lst if not a.get("hit")]) >= 50:
                raise ApiError("Máximo 50 alertas activas")
            lst.append({"id": os.urandom(4).hex(), "sym": sym, "op": op, "px": px,
                        "note": str(body.get("note", ""))[:60], "made": datetime.now(ET).strftime("%Y-%m-%d %H:%M")})
        elif act == "del":
            lst = [a for a in lst if a.get("id") != body.get("id")]
        elif act == "clear_hit":
            lst = [a for a in lst if not a.get("hit")]
        else:
            raise ApiError("Acción no válida")
        _save(AL_FILE, lst)
        return {"alerts": lst}


def check_alerts(quotes, now=None):
    """quotes {sym: last}. Marca y devuelve las alertas que se cumplieron (cada una avisa una sola vez)."""
    hits = []
    with _lock:
        lst = alerts()
        for a in lst:
            if a.get("hit"):
                continue
            last = quotes.get(a["sym"])
            if last is None:
                continue
            if (a["op"] == ">=" and last >= a["px"]) or (a["op"] == "<=" and last <= a["px"]):
                a["hit"] = (now or datetime.now(ET)).strftime("%Y-%m-%d %H:%M")
                a["hit_px"] = last
                hits.append(a)
        if hits:
            _save(AL_FILE, lst)
    return hits


def market_open(now=None):
    n = now or datetime.now(ET)
    return n.weekday() < 5 and (9, 30) <= (n.hour, n.minute) < (16, 0)


def snapshot_all(env, now=None):
    """Despues del cierre guarda el valor de cada cuenta configurada (para la grafica de crecimiento)."""
    n = now or datetime.now(ET)
    if n.weekday() >= 5 or (n.hour, n.minute) < (16, 5):
        return
    d = n.date().isoformat()
    have = _load(EQ_FILE, {})
    for live, ok in ((False, bool(env.get("TRADIER_TOKEN") and env.get("TRADIER_ACCOUNT_ID"))),
                     (True, trading.live_ready(env)), (trading.H, trading.h_ready(env))):
        k = mkey(live)
        if not ok or d in have.get(k, {}):
            continue
        try:
            j = trading._call_acct(env, live, "GET", "/accounts/{acct}/balances")
            record_equity(_num((j.get("balances") or {}).get("total_equity")), k, d)
        except Exception:  # noqa: BLE001
            pass


def alert_loop(env_fn, send):
    """Hilo: cada 20 s en horario revisa las alertas y avisa (macOS / Telegram / etc. con avisos.py)."""
    while True:
        time.sleep(20)
        try:
            snapshot_all(env_fn())
        except Exception:  # noqa: BLE001
            pass
        try:
            act = [a for a in alerts() if not a.get("hit")]
            if not act or not market_open():
                continue
            env = env_fn()
            q = trading._quotes(env, sorted({a["sym"] for a in act}))
            last = {s: (_num(v.get("last")) or None) for s, v in q.items()}
            for a in check_alerts({s: v for s, v in last.items() if v}):
                arrow = "subió a" if a["op"] == ">=" else "bajó a"
                send(env, f"🔔 Alerta {a['sym']}", f"{a['sym']} {arrow} {a['hit_px']:.2f} (tu alerta: {a['px']:.2f}). {a.get('note', '')}".strip())
        except Exception:  # noqa: BLE001 - nunca tumbar el panel
            pass


# ───────────── earnings y dividendos (yfinance, cache 12 h) ─────────────
_EV_BUSY = set()


def _fetch_event(sym):
    out = {"earn": None, "exdiv": None, "div": None}
    try:
        import fundamentales
        yf = fundamentales._yf()
        tk = yf.Ticker(sym)
        cal = tk.calendar
        if isinstance(cal, dict):
            t0 = today().isoformat()
            for x in _as_list(cal.get("Earnings Date")):
                s = str(x)[:10]
                if re.match(r"^\d{4}-\d{2}-\d{2}$", s) and s >= t0:
                    out["earn"] = s if out["earn"] is None else min(out["earn"], s)
            ex = cal.get("Ex-Dividend Date")
            if ex is not None and re.match(r"^\d{4}-\d{2}-\d{2}$", str(ex)[:10]):
                out["exdiv"] = str(ex)[:10]
        try:
            rate = (tk.info or {}).get("dividendRate")
            out["div"] = round(float(rate) / 4, 4) if rate else None
        except Exception:  # noqa: BLE001
            pass
    except Exception:  # noqa: BLE001
        pass
    return out


def _ev_worker(syms):
    for s in syms:
        try:
            ev = _fetch_event(s)
            with _lock:
                disk = _load(EV_FILE, {})
                disk[s] = dict(ev, t=time.time())
                _save(EV_FILE, disk)
        finally:
            _EV_BUSY.discard(s)


def eventos(syms):
    disk = _load(EV_FILE, {})
    now = time.time()
    need = [s for s in syms if s not in _EV_BUSY and (s not in disk or now - disk[s].get("t", 0) > 12 * 3600)]
    if need:
        _EV_BUSY.update(need)
        threading.Thread(target=_ev_worker, args=(need,), daemon=True).start()
    return {s: {k: disk[s].get(k) for k in ("earn", "exdiv", "div")} for s in syms if s in disk}


# ───────────── ingresos estimados por dividendos (proximos 12 meses) ─────────────
DIV_FILE = os.path.join(D, "pf_div.json")
_DIV_BUSY = set()
FREQ = {12: "Mensual", 4: "Trimestral", 2: "Semestral", 1: "Anual"}


def _fetch_div(sym):
    """Historial de dividendos (fecha ex-dividendo, monto) de los ultimos ~2 anos y la proxima fecha anunciada (yfinance)."""
    out = {"divs": [], "next_ex": None}
    try:
        import fundamentales
        tk = fundamentales._yf().Ticker(sym)
        s = tk.dividends
        cut = (today() - timedelta(days=760)).isoformat()
        for idx, val in s.items():
            d = str(idx)[:10]
            if d >= cut and val and float(val) > 0:
                out["divs"].append([d, round(float(val), 6)])
        try:
            cal = tk.calendar
            ex = cal.get("Ex-Dividend Date") if isinstance(cal, dict) else None
            if ex is not None and re.match(r"^\d{4}-\d{2}-\d{2}$", str(ex)[:10]):
                out["next_ex"] = str(ex)[:10]
        except Exception:  # noqa: BLE001
            pass
    except Exception:  # noqa: BLE001
        out["err"] = True
    return out


def _div_worker(syms):
    for s in syms:
        try:
            v = _fetch_div(s)
            with _lock:
                disk = _load(DIV_FILE, {})
                disk[s] = dict(v, t=time.time())
                _save(DIV_FILE, disk)
        finally:
            _DIV_BUSY.discard(s)


def _add_months(d, n):
    import calendar
    y, m = d.year + (d.month - 1 + n) // 12, (d.month - 1 + n) % 12 + 1
    return d.replace(year=y, month=m, day=min(d.day, calendar.monthrange(y, m)[1]))


def project(divs, next_ex, start, end):
    """Pagos estimados entre start y end a partir del historial. -> (frecuencia por ano, monto, [(fecha, anunciado)])"""
    if not divs:
        return None, None, []
    last_year = [x for x in divs if x[0] > (start - timedelta(days=370)).isoformat()]
    n = len(last_year)
    per = 12 if n >= 10 else 4 if n >= 3 else 2 if n == 2 else 1 if n == 1 else None
    if per is None:
        return None, None, []
    rate = divs[-1][1]
    step = 12 // per
    last = date.fromisoformat(divs[-1][0])
    dates = []
    k = 1
    while True:
        d = _add_months(last, step * k)
        if d > end:
            break
        if d >= start:
            dates.append([d, False])
        k += 1
        if k > 40:
            break
    if next_ex:
        nx = date.fromisoformat(next_ex)
        if start <= nx <= end and nx.isoformat() > divs[-1][0]:
            if dates:   # la anunciada reemplaza a la estimada mas cercana
                j = min(range(len(dates)), key=lambda i: abs((dates[i][0] - nx).days))
                if abs((dates[j][0] - nx).days) <= 20 * step:
                    dates[j] = [nx, True]
                else:
                    dates.append([nx, True])
            else:
                dates.append([nx, True])
    dates.sort()
    return per, rate, dates


def dividendos(env):
    st = trading.stocks(env)
    hold = [r for r in st["rows"] if r.get("qty")]
    syms = [r["sym"] for r in hold]
    disk = _load(DIV_FILE, {})
    now = time.time()
    need = [s for s in syms if s not in _DIV_BUSY and (s not in disk or now - disk[s].get("t", 0) > 12 * 3600)]
    if need:
        _DIV_BUSY.update(need)
        threading.Thread(target=_div_worker, args=(need,), daemon=True).start()
    t0 = today()
    end = _add_months(t0, 12)
    rows, by_sym, months = [], [], {}
    for k in range(13):
        m = _add_months(t0.replace(day=1), k).isoformat()[:7]
        months[m] = {"anunciado": 0.0, "estimado": 0.0}
    for h in hold:
        info = disk.get(h["sym"])
        if not info:
            by_sym.append({"sym": h["sym"], "qty": h["qty"], "estado": "cargando"})
            continue
        per, rate, dates = project(info.get("divs") or [], info.get("next_ex"), t0, end)
        if not per:
            by_sym.append({"sym": h["sym"], "qty": h["qty"], "estado": "no paga dividendos (o sin dato)"})
            continue
        inc = 0.0
        for d, ann in dates:
            v = round(rate * h["qty"], 2)
            inc += v
            m = d.isoformat()[:7]
            if m in months:
                months[m]["anunciado" if ann else "estimado"] += v
            rows.append({"sym": h["sym"], "fecha": d.isoformat(), "estado": "Anunciado" if ann else "Estimado",
                         "freq": FREQ.get(per, f"{per}/año"), "rate": rate, "qty": h["qty"], "monto": v})
        val = h.get("value")
        by_sym.append({"sym": h["sym"], "qty": h["qty"], "freq": FREQ.get(per), "rate": rate, "anual": round(inc, 2),
                       "yield": round(rate * per / h["last"] * 100, 2) if h.get("last") else None,
                       "ultimo": info["divs"][-1][0], "estado": "ok"})
    rows.sort(key=lambda r: (r["fecha"], r["sym"]))
    tot = round(sum(r["monto"] for r in rows), 2)
    ann = round(sum(r["monto"] for r in rows if r["estado"] == "Anunciado"), 2)
    value = st.get("value") or 0
    return {"total": tot, "anunciado": ann, "estimado": round(tot - ann, 2), "valor": value,
            "yield": round(tot / value * 100, 2) if value else None, "meses": [dict(m=k, **v) for k, v in months.items()][:13],
            "rows": rows, "por_simbolo": by_sym, "cargando": bool(need) or any(b["estado"] == "cargando" for b in by_sym),
            "acct": trading.acct_name(env, trading.MODE["live"])}
