# LV Options Terminal - instalacion en WINDOWS (se corre con doble clic en INSTALAR_WINDOWS.bat)
# 1) Revisa Python (si no esta, lo instala con winget)  2) Instala las librerias  3) Copia la terminal a tu carpeta
# 4) La deja arrancando sola al prender la computadora  5) Crea accesos directos  6) La abre en el navegador
$ErrorActionPreference = "Continue"   # pip y winget escriben avisos que no son errores
$SRC = Split-Path -Parent $MyInvocation.MyCommand.Path
$DEST = Join-Path $env:USERPROFILE "LVTerminal"
Write-Host ""
Write-Host "=== LV Options Terminal - instalacion para Windows ===" -ForegroundColor Cyan

function Find-Python {
  foreach ($c in @("py -3", "python")) {
    try {
      $parts = $c.Split(" ")
      if (-not (Get-Command $parts[0] -ErrorAction SilentlyContinue)) { continue }
      $exe = (& $parts[0] @($parts | Select-Object -Skip 1) -c "import sys;print(sys.executable)" 2>$null)
      if ($LASTEXITCODE -eq 0 -and $exe -and (Test-Path $exe) -and ($exe -notmatch "WindowsApps")) { return $exe.Trim() }
    } catch {}
  }
  $cand = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
  if ($cand) { return $cand.FullName }
  return $null
}

$PY = Find-Python
if (-not $PY) {
  Write-Host "No encontre Python. Lo instalo ahora (puede tardar 2-3 minutos)..." -ForegroundColor Yellow
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host "Tu Windows no tiene 'winget'. Instala Python desde https://www.python.org/downloads/ (marca 'Add python.exe to PATH') y vuelve a dar doble clic a INSTALAR_WINDOWS.bat" -ForegroundColor Red
    exit 1
  }
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  $PY = Find-Python
  if (-not $PY) {
    Write-Host "Python quedo instalado pero no lo encuentro todavia. Cierra esta ventana y vuelve a dar doble clic a INSTALAR_WINDOWS.bat" -ForegroundColor Red
    exit 1
  }
}
Write-Host "Python: $PY" -ForegroundColor Green
$PYW = Join-Path (Split-Path -Parent $PY) "pythonw.exe"
if (-not (Test-Path $PYW)) { $PYW = $PY }

Write-Host "Instalando librerias (requests, yfinance, numpy, tzdata)..."
& $PY -m pip install --quiet --upgrade pip 2>&1 | Out-Null
& $PY -m pip install --quiet --upgrade requests yfinance numpy tzdata 2>&1 | Out-Host
if ($LASTEXITCODE -ne 0) { Write-Host "Aviso: algunas librerias no se instalaron; sigo." -ForegroundColor Yellow }

# copia el programa a C:\Users\TU_USUARIO\LVTerminal (no toca tus datos si ya existia)
if ($SRC -ne $DEST) {
  New-Item -ItemType Directory -Force -Path $DEST | Out-Null
  Get-ChildItem $SRC -File | Where-Object { $_.Extension -in ".py", ".bat", ".ps1", ".txt" } | ForEach-Object { Copy-Item $_.FullName -Destination $DEST -Force }
  Write-Host "Terminal copiada a: $DEST" -ForegroundColor Green
}

Set-Content -Path (Join-Path $DEST "python_path.txt") -Value $PYW -Encoding ASCII
# arranque automatico al prender la computadora + accesos directos
$sh = New-Object -ComObject WScript.Shell
$startup = [Environment]::GetFolderPath("Startup")
$lnk = $sh.CreateShortcut((Join-Path $startup "LV Terminal.lnk"))
$lnk.TargetPath = $PYW; $lnk.Arguments = "`"$DEST\lanzador.py`""; $lnk.WorkingDirectory = $DEST; $lnk.Save()
$desk = [Environment]::GetFolderPath("Desktop")
$u = $sh.CreateShortcut((Join-Path $desk "LV Terminal.url"))
$u.TargetPath = "http://localhost:8765"; $u.Save()
$r = $sh.CreateShortcut((Join-Path $desk "Reiniciar LV Terminal.lnk"))
$r.TargetPath = Join-Path $DEST "reiniciar_windows.bat"; $r.WorkingDirectory = $DEST; $r.Save()
Write-Host "Listo el arranque automatico y los accesos directos del Escritorio." -ForegroundColor Green

# la abre ahora
Start-Process -FilePath $PYW -ArgumentList "`"$DEST\lanzador.py`"" -WorkingDirectory $DEST -WindowStyle Hidden
Write-Host "Abriendo la terminal (espera unos segundos)..."
$ok = $false
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  try { $null = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://localhost:8765/ ; $ok = $true; break } catch {}
}
if ($ok) {
  Start-Process "http://localhost:8765"
  Write-Host ""
  Write-Host "LISTO. La terminal esta abierta en tu navegador: http://localhost:8765" -ForegroundColor Green
  Write-Host "Siempre arranca en PAPEL. Desde ahora se abre sola al prender la computadora."
} else {
  Write-Host "La terminal no contesto todavia. Revisa el archivo $DEST\panel.log y manda una captura." -ForegroundColor Yellow
}
