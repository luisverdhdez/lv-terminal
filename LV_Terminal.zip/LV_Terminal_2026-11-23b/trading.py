"""
Trading manual de opciones (SPY por defecto; el constructor deja elegir otro activo) para el panel (iron condor, credit y debit spreads).

Dos cuentas: PAPEL (sandbox, por defecto) y REAL (api.tradier.com). Siempre arranca en PAPEL; para pasar a REAL hay que
tener TRADIER_LIVE_TOKEN y TRADIER_LIVE_ACCOUNT_ID en ~/.tradier_env y escribir REAL para confirmar. Estando en REAL, cada
orden exige escribir REAL otra vez y respeta limites (TRADIER_LIVE_MAX_QTY contratos, TRADIER_LIVE_MAX_BUY dolares en
acciones). El robot NO depende de este cambio: usa su propia configuracion (TRADIER_ENV).
Toda orden de varias patas exige una vista previa identica hecha antes (vale 5 minutos).
Lo usa monitor_web.py; no se ejecuta solo.
"""
import math
import csv
import json
import os
import re
import threading
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import requests

import reportes

SANDBOX = "https://sandbox.tradier.com/v1"
BASE = os.environ.get("TRADIER_TRADING_BASE", SANDBOX)  # solo para pruebas locales
if "api.tradier.com" in BASE:  # el modo papel nunca apunta a la cuenta real
    BASE = SANDBOX
LIVE_BASE = os.environ.get("TRADIER_LIVE_BASE", "https://api.tradier.com/v1")  # cambia solo en pruebas locales
MODE = {"live": False}  # siempre arranca en papel
SYMBOL = "SPY"
DATA_DIR = os.path.dirname(os.path.abspath(__file__))
MAN_ORDERS = os.path.join(DATA_DIR, "manual_orders.json")
MAN_FILLS = os.path.join(DATA_DIR, reportes.FILLS_CSV)
MAN_TRADES = os.path.join(DATA_DIR, reportes.MANUAL_CSV)
MAN_FILLS_LIVE = os.path.join(DATA_DIR, reportes.FILLS_LIVE_CSV)      # ordenes de la cuenta REAL (archivos aparte de las de papel)
MAN_TRADES_LIVE = os.path.join(DATA_DIR, reportes.MANUAL_LIVE_CSV)
MAN_FILLS_H = os.path.join(DATA_DIR, reportes.FILLS_H_CSV)            # cuenta REAL 2 (familiar): archivos propios, nunca se mezcla
MAN_TRADES_H = os.path.join(DATA_DIR, reportes.MANUAL_H_CSV)
H = "H"   # clave de la segunda cuenta real. Cuentas: False = papel · True = tu real · "H" = real 2
MAX_QTY = 10
PREVIEW_TTL = 300
PREVIEWED = {}
OCC = re.compile(r"^[A-Z]{1,6}(\d{6})([CP])(\d{8})$")      # grupos: 1 = fecha, 2 = C/P, 3 = strike (la raiz no captura)
OCC_ROOT = re.compile(r"^([A-Z]{1,6})\d{6}[CP]\d{8}$")


def root_of(occ):
    m = OCC_ROOT.match(str(occ or ""))
    return m.group(1) if m else None
SIDES = {"buy_to_open", "sell_to_open", "buy_to_close", "sell_to_close"}
DONE = {"filled", "canceled", "rejected", "expired", "error"}


class ApiError(Exception):
    pass


def _as_list(x):
    if x is None or x == "null" or x == "":
        return []
    return x if isinstance(x, list) else [x]


def live_ready(env):
    return bool(env.get("TRADIER_LIVE_TOKEN") and env.get("TRADIER_LIVE_ACCOUNT_ID"))


def h_ready(env):
    return bool(env.get("TRADIER_H_TOKEN") and env.get("TRADIER_H_ACCOUNT_ID"))


def akey(live):
    """Normaliza la cuenta: False (papel), True (tu real) o "H" (real 2)."""
    return H if live == H else bool(live)


def creds(env, live):
    """(url, token, numero de cuenta) de la cuenta pedida. Papel nunca apunta a la API real."""
    k = akey(live)
    if k == H:
        return LIVE_BASE, env.get("TRADIER_H_TOKEN"), env.get("TRADIER_H_ACCOUNT_ID")
    if k:
        return LIVE_BASE, env.get("TRADIER_LIVE_TOKEN"), env.get("TRADIER_LIVE_ACCOUNT_ID")
    return BASE, env.get("TRADIER_TOKEN"), env.get("TRADIER_ACCOUNT_ID")


def acct_name(env, live):
    k = akey(live)
    if k == H:
        return (env.get("TRADIER_H_NAME") or "Cuenta 2").strip()[:24]
    return "Real" if k else "Papel"


def _cfg(env):
    return creds(env, MODE["live"])


def _call(env, method, path, params=None, data=None):
    return _call_acct(env, MODE["live"], method, path, params, data)


def _call_acct(env, live, method, path, params=None, data=None):
    """Llamada a Tradier a una cuenta EXPLICITA (papel o real), sin depender del selector del panel."""
    base, tok, acct = creds(env, live)
    if not tok or not acct:
        raise ApiError(("No está configurada la cuenta " + acct_name(env, live) + ": agrégala en ⚙ Cuentas (/setup)") if akey(live) == H else
                       "No hay cuenta REAL configurada: agrégala en ⚙ Cuentas (/setup)" if live
                       else "No hay cuenta de PAPEL configurada: agrégala en ⚙ Cuentas (/setup) o cambia a REAL arriba")
    tpl, t_ini = path, time.time()
    if not akey(live) and method == "GET" and path.startswith("/markets/") and live_ready(env):
        # PAPEL con cuenta real configurada: precios, cadenas y velas EN TIEMPO REAL con el token real (solo lectura);
        # cuentas y ordenes siguen yendo a papel
        base, tok = LIVE_BASE, env.get("TRADIER_LIVE_TOKEN")
    path = path.replace("{acct}", acct)
    try:
        return _call_acct2(env, live, method, path, params, data, base, tok)
    finally:
        _lento(tpl, params, time.time() - t_ini)


_SLOW = []


def _lento(tpl, params, secs):
    """Guarda en tradier_lento.json las consultas que tardaron mas de 3 s (para saber si Tradier esta lento). Sin datos privados."""
    if secs < 3:
        return
    sym = (params or {}).get("symbol") or (params or {}).get("symbols") or ""
    _SLOW.append({"hora": datetime.now(ZoneInfo("America/New_York")).strftime("%H:%M:%S"), "seg": round(secs, 1),
                  "consulta": tpl, "simbolo": str(sym)[:40], "intervalo": (params or {}).get("interval", "")})
    del _SLOW[:-60]
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "tradier_lento.json"), "w") as f:
            json.dump(_SLOW, f, indent=1)
    except OSError:
        pass


def _call_acct2(env, live, method, path, params, data, base, tok):
    slow = "/markets/timesales" in path   # el historial de Tradier anda tardando 15-25 s: una sola espera larga en vez de dos cortas
    for intento in ((1,) if slow else (1, 2)):   # si Tradier falla de su lado (500-504) en una CONSULTA, reintenta una vez; las ordenes nunca se repiten
        try:
            r = requests.request(method, base + path, params=params, data=data, timeout=35 if slow else 12,
                                 headers={"Authorization": f"Bearer {tok}", "Accept": "application/json"})
        except requests.RequestException as e:
            if method == "GET" and intento == 1 and not slow:
                time.sleep(0.6)
                continue
            raise ApiError(f"No se pudo conectar con Tradier: {e.__class__.__name__}")
        if r.status_code in (500, 502, 503, 504) and method == "GET" and intento == 1:
            time.sleep(0.6)
            continue
        break
    if r.status_code in (500, 502, 503, 504):
        raise ApiError(f"Tradier está fallando de su lado (error {r.status_code}: su servidor no respondió a tiempo). "
                       "No es tu panel; se vuelve a intentar solo en unos segundos.")
    if r.status_code == 401:
        if akey(live) == H:
            raise ApiError(f"Tradier rechazó el token de la cuenta {acct_name(env, live)} (401). Que lo vuelva a pegar en ⚙ Cuentas (/setup).")
        if live:
            raise ApiError("Tradier rechazó el token de la cuenta REAL (401). Vuelve a pegarlo en ⚙ Cuentas (/setup).")
        raise ApiError("Tradier rechazó el token (401). Pega de nuevo el token del SANDBOX (no el de producción) en ⚙ Cuentas (/setup).")
    if r.status_code >= 400:
        raise ApiError(f"Tradier {r.status_code}: {(r.text or '')[:300]}")
    try:
        return r.json()
    except ValueError:
        raise ApiError("Respuesta de Tradier no válida")


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _int_env(env, k, d):
    try:
        return max(1, int(float(env.get(k) or d)))
    except (TypeError, ValueError):
        return d


def mode_info(env):
    k = akey(MODE["live"])
    return {"live": MODE["live"], "acct": "H" if k == H else ("live" if k else "paper"), "name": acct_name(env, k),
            "has_live": live_ready(env), "has_h": h_ready(env), "h_name": acct_name(env, H),
            "max_qty": _int_env(env, "TRADIER_LIVE_MAX_QTY", 3), "max_buy": _int_env(env, "TRADIER_LIVE_MAX_BUY", 5000)}


def set_mode(env, body):
    """Cambia entre papel y real. Pasar a REAL exige credenciales validas y la palabra REAL."""
    want = body.get("acct") or ("live" if body.get("live") else "paper")
    if want == "H":
        if not h_ready(env):
            raise ApiError("La cuenta 2 no está configurada: su token se pega en ⚙ Cuentas (/setup).")
        if body.get("confirm") != "REAL":
            raise ApiError("Falta la confirmación escrita (REAL).")
        old = MODE["live"]
        MODE["live"] = H
        try:
            _call(env, "GET", "/accounts/{acct}/balances")
        except ApiError:
            MODE["live"] = old
            raise
    elif want != "live":
        MODE["live"] = False
    else:
        if not live_ready(env):
            raise ApiError("Para usar la cuenta real agrega su token en ⚙ Cuentas (/setup).")
        if body.get("confirm") != "REAL":
            raise ApiError("Falta la confirmación escrita (REAL).")
        MODE["live"] = True
        try:
            _call(env, "GET", "/accounts/{acct}/balances")  # comprueba que token y cuenta sirven
        except ApiError:
            MODE["live"] = False
            raise
    _CC.clear()
    _TS.clear()
    PREVIEWED.clear()
    return mode_info(env)


def _live_guard(env, path, body):
    """En la cuenta REAL: confirmacion escrita en cada orden y topes de tamano contra errores de dedo."""
    if not MODE["live"] or path not in ("/api/order", "/api/stock_order", "/api/scalp", "/api/gestor_item", "/api/modify", "/api/roll"):
        return
    if path == "/api/gestor_item" and body.get("action") != "close":
        return  # soltar o cambiar reglas no es una orden; el cierre manual si pide REAL
    abre = (path == "/api/roll" or (path == "/api/stock_order" and body.get("side") == "buy") or
            (path == "/api/scalp" and body.get("side") == "buy_to_open") or
            (path == "/api/order" and any(str(l.get("side", "")).endswith("_to_open") for l in (body.get("legs") or []))))
    if abre:   # pausa de 30 min despues de 2 perdidas seguidas (solo para ABRIR; cerrar siempre se puede)
        import pausa
        st = pausa.estado(MODE["live"])
        if st["activa"]:
            raise ApiError(pausa.mensaje(st))
    if body.get("live_confirm") != "REAL":
        raise ApiError("Cuenta REAL: falta la confirmación escrita (REAL) de esta orden.")
    info = mode_info(env)
    try:
        qty = int(body.get("qty"))
    except (TypeError, ValueError):
        return  # la validacion normal de cada orden la rechazara
    if path == "/api/stock_order":
        if body.get("side") == "buy":
            try:
                notional = qty * float(body.get("price"))
            except (TypeError, ValueError):
                return
            if notional > info["max_buy"]:
                raise ApiError(f"Cuenta REAL: compra de ${notional:,.0f} supera el tope de ${info['max_buy']:,} "
                               "(sube TRADIER_LIVE_MAX_BUY en ~/.tradier_env si lo quieres).")
        return
    if path == "/api/roll":
        opening = True   # un roll siempre abre la posicion nueva
    else:
      opening = (body.get("side") == "buy_to_open") if path == "/api/scalp" else \
          any(str(l.get("side", "")).endswith("_to_open") for l in (body.get("legs") or []))
    if opening and qty > info["max_qty"]:
        raise ApiError(f"Cuenta REAL: {qty} contratos supera el tope de {info['max_qty']} "
                       "(sube TRADIER_LIVE_MAX_QTY en ~/.tradier_env si lo quieres).")


# ───────────── lecturas ─────────────
SYM_RE = re.compile(r"^[A-Z][A-Z.\-]{0,5}$")


# FUTUROS (casi 24 h): Tradier no los tiene; se leen de Yahoo Finance (ES=F...) con ~10 min de retraso, solo para graficar
FUT = {"/ES": ("ES=F", "Futuros S&P 500 (E-mini)"), "/MES": ("MES=F", "Futuros Micro S&P 500"),
       "/NQ": ("NQ=F", "Futuros Nasdaq 100 (E-mini)"), "/YM": ("YM=F", "Futuros Dow Jones (E-mini)"),
       "/RTY": ("RTY=F", "Futuros Russell 2000 (E-mini)"),
       "/SPX": ("ES=F", "SPX 24 h estimado (futuros /ES ajustados al precio del SPX, como el «SPX 500 Daily» de Spreadex)")}
_FC = {}


def _fut_bars(sym, iv):
    """Velas de un futuro desde Yahoo (cache 60 s). iv: '1m', '15m' o '1d'. Hora desplazada a Nueva York como las demas."""
    key = (sym, iv)
    hit = _FC.get(key)
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    try:
        import yfinance as yf
    except ImportError:
        raise ApiError("Para los futuros hace falta la librería yfinance (la misma de Fundamentales)")
    period = {"1m": "5d", "15m": "30d", "1d": "2y"}[iv]
    df = yf.Ticker(FUT[sym][0]).history(period=period, interval=iv, prepost=True, auto_adjust=False)
    out = []
    for idx, r in df.iterrows():
        try:
            ts = int(idx.timestamp())
            b = {"time": ts if iv == "1d" else _shift(ts), "open": float(r["Open"]), "high": float(r["High"]),
                 "low": float(r["Low"]), "close": float(r["Close"]), "volume": float(r.get("Volume") or 0)}
        except (TypeError, ValueError, KeyError):
            continue
        if iv == "1d":
            b["time"] = int(datetime(idx.year, idx.month, idx.day, tzinfo=ZoneInfo("UTC")).timestamp())
        if _vela_ok(b):
            out.append(b)
    out.sort(key=lambda b: b["time"])
    if not out:
        raise ApiError(f"Yahoo no devolvió datos de {sym}")
    _FC[key] = (time.time(), out)
    return out


def _spx_offsets(env):
    """Diferencia SPX − /ES en cada minuto en que operan los dos (horario normal). [(hora, diferencia)] ordenado."""
    es = {b["time"]: b["close"] for b in _fut_bars("/SPX", "1m")}
    spx = _timesales(env, "1min", 4, "SPX")
    out = [(b["time"], b["close"] - es[b["time"]]) for b in spx if b["time"] in es]
    if not out:
        raise ApiError("No pude calcular el ajuste del SPX 24 h: no hay minutos en que coincidan el SPX y el /ES")
    return out


def _spx_adjust(env, bars, daily=False):
    """Suma a cada vela del /ES la ultima diferencia SPX − /ES conocida (antes de la primera, la primera)."""
    offs = _spx_offsets(env)
    if daily:
        last = offs[-1][1]
        return [dict(b, open=b["open"] + last, high=b["high"] + last, low=b["low"] + last, close=b["close"] + last) for b in bars]
    import bisect as _bs
    ts = [t for t, _ in offs]
    out = []
    for b in bars:
        k = _bs.bisect_right(ts, b["time"]) - 1
        d = offs[max(k, 0)][1]
        out.append(dict(b, open=b["open"] + d, high=b["high"] + d, low=b["low"] + d, close=b["close"] + d))
    return out


def _sym(x, default=SYMBOL):
    x = (x or default).strip().upper()
    if x in FUT:
        return x
    if not SYM_RE.match(x):
        raise ApiError("Símbolo no válido")
    return x


_QC = {}


def quote(env, sym=SYMBOL):
    """Precio actual. Cache de 1.5 s: varios graficos del mismo simbolo comparten una sola consulta (cuida el limite de Tradier)."""
    if sym == "/SPX" and _rth():   # en horario normal: el SPX oficial de Tradier, en tiempo real
        try:
            q = quote(env, "SPX")
            if q.get("last"):
                return dict(q, fut=True, real=True)
        except ApiError:
            pass
    if sym in FUT:
        b = _fut_bars(sym, "1m")
        last = b[-1]["close"] + (_spx_offsets(env)[-1][1] if sym == "/SPX" else 0)
        return {"last": last, "bid": None, "ask": None, "chg": None, "t": None, "fut": True}
    key = (MODE["live"], sym)
    if MODE["live"] or live_ready(env):   # cuenta real (o papel con precios reales): si el streaming tiene el precio de hace menos de 2 s, ese es el bueno (mas nuevo que la consulta)
        try:
            import stream
            stream.want([sym])
            px = stream.price(sym, 2.0)
            if px:
                b = (_QC.get(key) or (0, {}))[1]
                return dict(b, last=px, live=True)
        except Exception:   # noqa: BLE001 - sin streaming sigue como antes
            pass
    hit = _QC.get(key)
    if hit and time.time() - hit[0] < 1.5:
        return hit[1]
    j = _call(env, "GET", "/markets/quotes", params={"symbols": sym})
    q = (j.get("quotes") or {}).get("quote") or {}
    out = {"last": _num(q.get("last")), "bid": _num(q.get("bid")), "ask": _num(q.get("ask")),
           "chg": _num(q.get("change_percentage")), "t": q.get("trade_date")}
    if len(_QC) > 50:
        _QC.clear()
    _QC[key] = (time.time(), out)
    return out


# indices con mensuales AM (raiz "estandar", se liquidan a la APERTURA) y semanales/diarias PM (se liquidan al cierre)
AM_PM = {"SPX": ("SPX", "SPXW"), "RUT": ("RUT", "RUTW"), "NDX": ("NDX", "NDXP")}


def _is_monthly(d, dates):
    """Tercer viernes del mes; o el jueves anterior si ese viernes no cotiza (feriado)."""
    try:
        x = datetime.strptime(d, "%Y-%m-%d")
    except ValueError:
        return False
    if x.weekday() == 4 and 15 <= x.day <= 21:
        return True
    nxt = (x + timedelta(days=1))
    return x.weekday() == 3 and 15 <= nxt.day <= 21 and nxt.strftime("%Y-%m-%d") not in dates


def expirations(env, sym=SYMBOL):
    """TODAS las fechas (diarias, semanales y mensuales). En SPX/RUT/NDX marca las mensuales AM."""
    j = _call(env, "GET", "/markets/options/expirations", params={"symbol": sym, "includeAllRoots": "true"})
    dates = _as_list((j.get("expirations") or {}).get("date")) if isinstance(j.get("expirations"), dict) else []
    dates = sorted({d for d in dates if isinstance(d, str)})
    today = datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d")
    fut = [d for d in dates if d >= today]
    # las 40 mas cercanas + las mensuales mas lejanas (para spreads de 30-60 dias)
    keep = fut[:40] + [d for d in fut[40:] if _is_monthly(d, dates)][:12]
    am = [d for d in keep if sym in AM_PM and _is_monthly(d, dates)]
    return {"dates": keep, "am": am, "am_root": AM_PM[sym][0] if sym in AM_PM else None,
            "pm_root": AM_PM[sym][1] if sym in AM_PM else None}


def chain(env, exp, sym=SYMBOL, root=""):
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", exp or ""):
        raise ApiError("Expiración no válida")
    spot = quote(env, sym).get("last")
    j = _call(env, "GET", "/markets/options/chains",
              params={"symbol": sym, "expiration": exp, "greeks": "true"})
    opts = _as_list((j.get("options") or {}).get("option")) if isinstance(j.get("options"), dict) else []
    if sym in AM_PM:   # el mismo dia pueden existir las AM (SPX) y las PM (SPXW): nunca mezclarlas
        want = AM_PM[sym][0] if root == "am" else AM_PM[sym][1]
        only = [o for o in opts if (o.get("root_symbol") or root_of(str(o.get("symbol") or ""))) == want]
        if only or root == "am":
            opts = only
    rows = []
    for o in opts:
        k = _num(o.get("strike"))
        if k is None or (spot and abs(k - spot) > max(40, spot * 0.12 if sym != SYMBOL else 40)):
            continue
        g = o.get("greeks") or {}
        rows.append({"occ": o.get("symbol"), "strike": k, "type": "C" if o.get("option_type") == "call" else "P",
                     "bid": _num(o.get("bid")), "ask": _num(o.get("ask")), "delta": _num(g.get("delta")), "iv": _num(g.get("mid_iv")) or _num(g.get("smv_vol")),
                     "gamma": _num(g.get("gamma")),
                     "oi": o.get("open_interest"), "vol": o.get("volume")})
    sq = _stream_q([r["occ"] for r in rows], subscribe=False)   # las patas que estas armando llegan por streaming
    for r in rows:
        if r["occ"] in sq:
            r["bid"], r["ask"] = sq[r["occ"]]
            r["src"] = "stream"
    _live_greeks(rows, spot, exp, root)
    return {"spot": spot, "options": rows}


def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _bs(S, K, T, v, call):
    if v <= 0 or T <= 0:
        return max(0.0, (S - K) if call else (K - S))
    sv = v * math.sqrt(T)
    d1 = (math.log(S / K) + 0.5 * v * v * T) / sv
    d2 = d1 - sv
    return S * _ncdf(d1) - K * _ncdf(d2) if call else K * _ncdf(-d2) - S * _ncdf(-d1)


def _live_greeks(rows, spot, exp, root=""):
    """Las griegas de Tradier se actualizan cada hora (en la apertura todavia traen las de ayer: deltas al reves).
    Aqui se recalculan AL MOMENTO: volatilidad implicita a partir del precio medio y, con ella, delta y gamma
    con el precio actual del subyacente. Si no se puede (sin bid/ask), se queda la de Tradier."""
    if not spot or not rows:
        return
    try:
        T = _years_to(exp, AM_PM.get(root.upper(), ("",))[0] if root == "am" else "", datetime.now(ZoneInfo("America/New_York")))
    except (ValueError, TypeError):
        return
    for r in rows:
        b, a, K = r.get("bid"), r.get("ask"), r.get("strike")
        if b is None or a is None or not K or a <= 0 or b < 0 or a < b:
            continue
        mid, call = (a + b) / 2, r["type"] == "C"
        intr = max(0.0, (spot - K) if call else (K - spot))
        if mid <= intr + 0.02:
            continue
        lo, hi = 0.005, 5.0
        if _bs(spot, K, T, hi, call) < mid:
            continue
        for _ in range(50):
            m = (lo + hi) / 2
            if _bs(spot, K, T, m, call) > mid:
                hi = m
            else:
                lo = m
        v = (lo + hi) / 2
        sv = v * math.sqrt(T)
        d1 = (math.log(spot / K) + 0.5 * v * v * T) / sv
        r["delta"] = round(_ncdf(d1) if call else _ncdf(d1) - 1, 3)
        r["gamma"] = math.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi) / (spot * sv)
        r["iv"] = round(v, 4)


# ---------------- niveles de gamma (GEX): call wall, put wall, gamma flip ----------------
# GEX por strike = gamma x open interest x 100 x precio^2 x 1%  (dolares de cobertura por cada 1% que se mueva).
# Convencion estandar: calls suman (+), puts restan (-) (se supone que los dealers estan al reves del publico).
# Solo LEE datos (cadenas de Tradier); nunca manda ordenes. El open interest se actualiza una vez al dia.
import threading as _th
_GEX = {}
GEX_SAVE = True   # las pruebas lo apagan
_GEX_LOCK = _th.Lock()


def _gex_sym(sym):
    s = (sym or "SPX").upper()
    return "SPX" if s in ("/SPX", "SPXW", "^SPX", "^GSPC") else s


def _bs_gamma(S, K, iv, T):
    if not (S and K and iv and T) or S <= 0 or K <= 0 or iv <= 0 or T <= 0:
        return 0.0
    v = iv * math.sqrt(T)
    d1 = (math.log(S / K) + 0.5 * iv * iv * T) / v
    return math.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi) / (S * v)


def _years_to(exp, root, now):
    """Anos que faltan al vencimiento: 16:00 NY (las mensuales AM del SPX/RUT/NDX, 9:30). Minimo 20 minutos."""
    ny = ZoneInfo("America/New_York")
    d = datetime.strptime(exp, "%Y-%m-%d")
    am = root in ("SPX", "RUT", "NDX")
    t = datetime(d.year, d.month, d.day, 9 if am else 16, 30 if am else 0, tzinfo=ny)
    return max((t - now).total_seconds(), 1200) / (365.0 * 86400)


def gex_calc(spot, opts, now=None):
    """opts: lista de {strike, type C/P, oi, iv, T, gamma}. Devuelve niveles y GEX por strike (sin red: se puede probar)."""
    if not spot or not opts:
        return {"error": "Sin datos de opciones para calcular la gamma"}
    use = [o for o in opts if (o.get("oi") or 0) > 0 and o.get("strike")]
    if not use:
        return {"error": "Las opciones no traen open interest todavía"}
    def g_at(o, S):
        if o.get("iv") and o.get("T"):
            return _bs_gamma(S, o["strike"], o["iv"], o["T"])
        return (o.get("gamma") or 0.0) if S == spot else 0.0
    by = {}
    for o in use:
        v = g_at(o, spot) * o["oi"] * 100 * spot * spot * 0.01
        r = by.setdefault(o["strike"], [0.0, 0.0])
        if o["type"] == "C":
            r[0] += v
        else:
            r[1] -= v
    ks = sorted(by)
    net = sum(c + p for c, p in by.values())
    # como los servicios de gamma: call wall ARRIBA del precio, put wall ABAJO (dentro de ±8%)
    up = [k for k in ks if spot <= k <= spot * 1.08] or ks
    dn = [k for k in ks if spot * 0.92 <= k <= spot] or ks
    cw = max(up, key=lambda k: by[k][0])
    pw = min(dn, key=lambda k: by[k][1])
    # gamma flip: precio donde la GEX total cambia de signo (se recalcula la gamma de cada opcion a cada precio)
    # precios de prueba: fino cerca del precio (cada 0.1%, hasta ±6%) y mas grueso hasta ±15%
    grid = sorted({round(spot * (1 + i * 0.001), 2) for i in range(-60, 61)} |
                  {round(spot * (1 + i * 0.0025), 2) for i in range(-60, 61)})
    ivs = [o for o in use if o.get("iv") and o.get("T")]
    try:
        import numpy as np
        K = np.array([o["strike"] for o in ivs], float); IV = np.array([o["iv"] for o in ivs], float)
        TT = np.array([o["T"] for o in ivs], float); OI = np.array([o["oi"] for o in ivs], float)
        SG = np.array([1.0 if o["type"] == "C" else -1.0 for o in ivs])
        tot = []
        for S in grid:
            v = IV * np.sqrt(TT); d1 = (np.log(S / K) + 0.5 * IV * IV * TT) / v
            g = np.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi) / (S * v)
            tot.append(float((SG * g * OI).sum() * 100 * S * S * 0.01))
    except ImportError:
        tot = [sum((1 if o["type"] == "C" else -1) * _bs_gamma(S, o["strike"], o["iv"], o["T"]) * o["oi"] for o in ivs) * 100 * S * S * 0.01
               for S in grid]
    flips = []
    for j in range(len(grid) - 1):
        a, b = tot[j], tot[j + 1]
        if a == 0 or (a < 0) != (b < 0):
            flips.append(grid[j] + (grid[j + 1] - grid[j]) * (0 - a) / ((b - a) or 1))
    flip = min(flips, key=lambda x: abs(x - spot)) if flips else None
    near = [k for k in ks if abs(k - spot) <= spot * 0.08]
    top = sorted(near, key=lambda k: -abs(by[k][0] + by[k][1]))[:6]
    # strike mas valioso: el de mas gamma en total (calls + puts, sin importar el signo) = donde mas cobertura hay
    close = [k for k in ks if abs(k - spot) <= spot * 0.03] or near or ks   # el strike clave se busca cerca del precio (±3%)
    key = max(close, key=lambda k: by[k][0] - by[k][1])
    return {"spot": spot, "call_wall": cw, "put_wall": pw, "key": key, "flip": round(flip, 2) if flip else None,
            "net": round(net), "regime": "positiva" if net >= 0 else "negativa",
            "top": [[k, round(by[k][0] + by[k][1])] for k in sorted(top)],
            "strikes": [[k, round(by[k][0]), round(by[k][1])] for k in near],
            "curve": [[round(S, 2), round(t)] for S, t in zip(grid, tot) if abs(S / spot - 1) <= 0.03]}


def _gex_fetch(env, sym, h):
    ny = ZoneInfo("America/New_York")
    now = datetime.now(ny)
    spot = quote(env, sym).get("last")
    if not spot:
        raise ApiError("Sin precio de " + sym)
    dates = expirations(env, sym)["dates"]
    lim = (now + timedelta(days=h)).strftime("%Y-%m-%d")
    pick = dates[:1] if h <= 0 else [d for d in dates if d <= lim][:40]
    opts = []
    for d in pick:
        j = _call(env, "GET", "/markets/options/chains", params={"symbol": sym, "expiration": d, "greeks": "true"})
        raw = _as_list((j.get("options") or {}).get("option")) if isinstance(j.get("options"), dict) else []
        for o in raw:
            k = _num(o.get("strike"))
            if k is None or abs(k - spot) > spot * 0.15:
                continue
            g = o.get("greeks") or {}
            root = o.get("root_symbol") or root_of(str(o.get("symbol") or ""))
            iv = _num(g.get("mid_iv")) or _num(g.get("smv_vol"))
            opts.append({"strike": k, "type": "C" if o.get("option_type") == "call" else "P",
                         "oi": int(_num(o.get("open_interest")) or 0), "iv": iv if iv and iv > 0.01 else None,
                         "T": _years_to(d, root, now), "gamma": _num(g.get("gamma"))})
        time.sleep(1.0)   # cuida el limite de consultas de Tradier (no competir con graficas y ordenes)
    out = gex_calc(spot, opts)
    out.update({"sym": sym, "h": h, "exps": len(pick), "first": pick[0] if pick else None, "last": pick[-1] if pick else None,
                "ts": time.time(), "hora": now.strftime("%H:%M")})
    return out


def gex(env, sym="SPX", h=45):
    """Niveles de gamma. Se calcula en segundo plano (muchas cadenas) y se guarda 10 min en horario, 1 h fuera."""
    sym = _gex_sym(sym)
    if sym.startswith("/") or not SYM_RE.match(sym):
        return {"error": "Gamma solo para acciones, ETF e índices con opciones"}
    h = 0 if h <= 0 else min(int(h), 60)
    key = (sym, h)
    with _GEX_LOCK:
        e = _GEX.get(key) or {}
        ttl = (180 if h <= 0 else 900) if _rth() else 3600   # solo hoy = 1 sola cadena: se puede recalcular cada 3 min
        fresh = e.get("data") and time.time() - e.get("ts", 0) < ttl
        if not fresh and not e.get("busy"):
            e["busy"] = True
            _GEX[key] = e
            def run():
                try:
                    d = _gex_fetch(env, sym, h)
                except Exception as ex:   # noqa: BLE001 - se muestra el mensaje en pantalla
                    d = {"error": str(ex)}
                try:   # copia para revisar/comparar (sin datos privados)
                    if not GEX_SAVE:
                        raise OSError
                    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "gex_%s_%s.json" % (sym, h)), "w") as f:
                        json.dump(d, f, indent=1)
                except OSError:
                    pass
                with _GEX_LOCK:
                    if not d.get("error") or not e.get("data"):
                        e["data"] = d
                    e["ts"] = time.time() if not d.get("error") else time.time() - ttl + 60
                    e["busy"] = False
            _th.Thread(target=run, daemon=True).start()
        if e.get("data"):
            return dict(e["data"], updating=bool(e.get("busy")))
        return {"loading": True, "sym": sym, "h": h}


def search(env, qtext):
    """Busca empresas/ETF por simbolo o nombre (autocompletar del grafico)."""
    qtext = (qtext or "").strip()[:30]
    if len(qtext) < 1:
        return {"results": []}
    qu = qtext.upper().lstrip("/")
    futs = [{"sym": k, "name": "🌙 " + v[1].split(" (")[0] + " · casi 24 h (Yahoo)", "ex": "futuros"} for k, v in FUT.items()
            if k[1:].startswith(qu) or (len(qu) >= 3 and qu in v[1].upper())]
    if qtext.startswith("/"):
        return {"results": futs}
    j = _call(env, "GET", "/markets/lookup", params={"q": qtext, "types": "stock,etf,index"})
    raw = _as_list((j.get("securities") or {}).get("security")) if isinstance(j.get("securities"), dict) else []
    out = []
    for r in raw:
        s_ = str(r.get("symbol", ""))
        if SYM_RE.match(s_):
            out.append({"sym": s_, "name": r.get("description") or "", "ex": r.get("exchange") or ""})
    out.sort(key=lambda r: (r["sym"] != qtext.upper(), not r["sym"].startswith(qtext.upper()), len(r["sym"])))
    return {"results": (futs + out)[:12]}


def orders(env):
    return _cached("ord", lambda: _orders(env))


def _orders(env):
    j = _call(env, "GET", "/accounts/{acct}/orders")
    raw = _as_list((j.get("orders") or {}).get("order")) if isinstance(j.get("orders"), dict) else []
    out = []
    for o in raw[-25:]:
        legs = [{"side": l.get("side"), "occ": l.get("option_symbol"), "qty": l.get("quantity")}
                for l in _as_list(o.get("leg"))]
        if not legs and o.get("option_symbol"):
            legs = [{"side": o.get("side"), "occ": o.get("option_symbol"), "qty": o.get("quantity")}]
        out.append({"id": o.get("id"), "status": o.get("status"), "type": o.get("type"), "class": o.get("class"),
                    "price": _num(o.get("price")), "qty": (legs[0]["qty"] if legs else o.get("quantity")), "legs": legs,
                    "open": (o.get("status") or "") not in DONE,
                    "sent": o.get("create_date"), "done_at": o.get("transaction_date") if (o.get("status") or "") in DONE else None,
                    "fill": _num(o.get("avg_fill_price"))})
    _live_px(env, out)
    return {"orders": list(reversed(out))}


def _live_px(env, out):
    """Ordenes PENDIENTES: precio de la combinacion AHORA (medio y natural), para saber si subir o bajar tu limite."""
    opn = [o for o in out if o["open"] and o.get("legs")]
    occs = sorted({l["occ"] for o in opn for l in o["legs"] if l.get("occ")})
    if not occs:
        return
    sq = _stream_q(occs)
    if len(sq) == len(occs):   # todo llega por streaming: no hace falta preguntarle a Tradier
        by = {}
    else:
        try:
            j = _call(env, "GET", "/markets/quotes", params={"symbols": ",".join(occs)})
            by = {q.get("symbol"): q for q in _as_list((j.get("quotes") or {}).get("quote")) if isinstance(q, dict)}
        except ApiError:
            if not sq:
                return
            by = {}
    for o_, (b_, a_) in sq.items():
        by[o_] = {"symbol": o_, "bid": b_, "ask": a_}
    for o in opn:
        qs = [_num(l.get("qty")) or 1 for l in o["legs"]]
        u = min(qs) or 1
        mid = nat = 0.0
        ok = True
        for l, q in zip(o["legs"], qs):
            b, a = _num((by.get(l["occ"]) or {}).get("bid")), _num((by.get(l["occ"]) or {}).get("ask"))
            if b is None or a is None:
                ok = False
                break
            r = q / u
            if str(l.get("side", "")).startswith("sell"):   # vendes: recibes (al bid si es natural)
                mid += r * (b + a) / 2
                nat += r * b
            else:                                            # compras: pagas (al ask si es natural)
                mid -= r * (b + a) / 2
                nat -= r * a
        if ok:
            # en la misma "moneda" de la orden: credito = lo que recibes; debito = lo que pagas
            sg = -1 if o.get("type") == "debit" or (o.get("type") in ("limit", "market") and mid < 0) else 1
            o["now_mid"], o["now_nat"] = round(sg * mid, 2), round(sg * nat, 2)


_PC = {}   # cache corta de posiciones y ordenes por cuenta: varias pestañas abiertas no multiplican las consultas a Tradier
CACHE_SEC = 1.5


def _cached(kind, fn):
    k = (kind, MODE["live"])
    hit = _PC.get(k)
    if hit and time.time() - hit[0] < CACHE_SEC:
        return hit[1]
    v = fn()
    _PC[k] = (time.time(), v)
    return v


def bust():
    """Borra la cache al mandar, cancelar o modificar una orden: lo siguiente que veas ya es nuevo."""
    _PC.clear()


def positions(env):
    return dict(_cached("pos", lambda: _positions(env)), osets=_order_sets(MODE["live"]))


def _order_sets(live, days=45):
    """Como abriste cada estrategia: las patas que entraron en la MISMA orden de apertura (y en que proporcion).
    Con esto el panel reconoce sola una broken wing, una mariposa o un ratio en vez de partirla en spreads.
    [{legs: [{occ, n}], units}] con n = contratos por unidad (+ compra, - venta)."""
    try:
        rows = _read_fills(live)
    except Exception:
        return []
    lim = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    by = {}
    for r in rows:
        if r["fecha"] >= lim:
            by.setdefault(r["order_id"], []).append(r)
    out = []
    for oid, rs in by.items():
        if len(rs) < 2 or not all(str(r["lado"]).endswith("_to_open") for r in rs):
            continue
        agg = {}
        for r in rs:
            agg[r["opcion"]] = agg.get(r["opcion"], 0) + (r["cantidad"] if r["lado"].startswith("buy") else -r["cantidad"])
        if len(agg) < 2 or len(agg) > 4 or any(not v for v in agg.values()):
            continue
        g = 0
        for v in agg.values():
            g = math.gcd(g, int(abs(v)))
        if not g:
            continue
        out.append({"id": oid, "units": g, "legs": [{"occ": o, "n": int(v / g)} for o, v in agg.items()]})
    return out[-60:]


OPT_STREAM_FILE = os.path.join(DATA_DIR, "opt_stream.json")


def opt_stream_on():
    """Interruptor "⚡ Precios de opciones por streaming" (apagado por defecto). Solo cambia los PRECIOS que se muestran."""
    try:
        with open(OPT_STREAM_FILE, encoding="utf-8") as f:
            return bool(json.load(f).get("on"))
    except (OSError, ValueError):
        return False


def opt_stream_set(on):
    with open(OPT_STREAM_FILE, "w", encoding="utf-8") as f:
        json.dump({"on": bool(on)}, f)
    return {"on": bool(on)}


def _stream_q(occs, subscribe=True):
    """{opcion: (bid, ask)} del streaming de Tradier (llegan solos, al instante). subscribe=True: tambien las pide.
    Con el interruptor apagado no hace nada: todo queda como antes."""
    if not opt_stream_on():
        return {}
    try:
        import stream
        if subscribe:
            return stream.quotes(list(occs))
        return {o: q for o in occs for q in [stream.quote(o)] if q}
    except Exception:  # noqa: BLE001 - sin streaming se usa la consulta normal
        return {}


def _positions(env):
    j = _call(env, "GET", "/accounts/{acct}/positions")
    raw = _as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    items = []
    shares = {}
    for p in raw:
        m = OCC.match(str(p.get("symbol", "")))
        if not m:
            q_ = _num(p.get("quantity")) or 0
            if p.get("symbol") and q_ > 0:
                shares[str(p["symbol"])] = shares.get(str(p["symbol"]), 0) + q_
            continue
        d = m.group(1)
        items.append({"occ": p["symbol"], "root": root_of(p["symbol"]), "qty": _num(p.get("quantity")) or 0, "cost": _num(p.get("cost_basis")),
                      "exp": f"20{d[:2]}-{d[2:4]}-{d[4:6]}", "type": m.group(2), "strike": int(m.group(3)) / 1000})
    spot, spots = None, {}
    if items:
        roots = sorted({x["root"] for x in items})
        # UNA sola consulta: el precio de cada subyacente y de cada opcion (antes eran dos, una tras otra)
        qs = _call(env, "GET", "/markets/quotes",
                   params={"symbols": ",".join(roots + [x["occ"] for x in items]), "greeks": "true"})
        by = {q.get("symbol"): q for q in _as_list((qs.get("quotes") or {}).get("quote")) if isinstance(q, dict)}
        for r_ in roots:
            if _num((by.get(r_) or {}).get("last")) is not None:
                spots[r_] = _num(by[r_]["last"])
        spot = spots.get("SPY") if "SPY" in spots else (next(iter(spots.values())) if spots else None)
        sq = _stream_q([x["occ"] for x in items])   # mismo precio que ordenes y constructor (streaming)
        for x in items:
            q = by.get(x["occ"], {})
            g = q.get("greeks") or {}
            bid, ask, last = _num(q.get("bid")), _num(q.get("ask")), _num(q.get("last"))
            if x["occ"] in sq:
                bid, ask = sq[x["occ"]]
                x["src"] = "stream"
            x["bid"], x["ask"] = bid, ask
            # precio NO confiable (tipico en la apertura o con el mercado cerrado): bid en 0 con ask alto, o bid/ask demasiado abiertos.
            # Mejor no mostrar un P&L inventado (ayer a las 9:31 salia -$1,325 en un condor que iba ganando)
            bad = (ask is not None and ask > 0.30 and (bid is None or bid <= 0)) or \
                  (bool(bid) and bool(ask) and ask - bid > max(1.0, 0.5 * ask))
            x["bad"] = bad
            x["mark"] = None if bad else ((bid + ask) / 2 if bid and ask else last)
            for k in ("delta", "theta", "vega", "gamma"):
                x[k] = _num(g.get(k))
    # covered calls: call VENDIDO cubierto por 100 acciones por contrato (de largo plazo, no del trading del dia)
    left = dict(shares)
    for x in sorted(items, key=lambda x: x["exp"]):
        if x["type"] == "C" and x["qty"] < 0 and left.get(x["root"], 0) >= 100 * abs(x["qty"]):
            left[x["root"]] -= 100 * abs(x["qty"])
            x["cc"] = True
    try:
        import cc as _ccmod
        _ccmod.mark([x["occ"] for x in items if x.get("cc")])
    except Exception:  # noqa: BLE001
        pass
    return {"legs": items, "spot": spot, "spots": spots, "shares": shares}


def account(env):
    j = _call(env, "GET", "/accounts/{acct}/balances")
    b = j.get("balances") or {}
    m = b.get("margin") or {}
    return {"equity": _num(b.get("total_equity")), "cash": _num(b.get("total_cash")),
            "option_bp": _num(m.get("option_buying_power", b.get("option_buying_power")))}


ET = ZoneInfo("America/New_York")
_CC = {}


def _shift(ts):
    return int(ts + datetime.fromtimestamp(ts, ET).utcoffset().total_seconds())


_TS = {}
_TTL = {"1min": 4, "5min": 20, "15min": 25}


_INFLIGHT = {}
_INFL_LOCK = threading.Lock()


WAIT_MAX = 6   # segundos que una consulta de la PAGINA espera a Tradier; lo demas sigue en segundo plano


def _timesales(env, iv, days, sym=SYMBOL, ext=False):
    """Velas crudas con cache corto: varios graficos del mismo simbolo comparten una sola consulta a Tradier.
    ext=True: incluye premarket (4:00) y aftermarket (hasta 20:00).
    NUNCA deja la pagina esperando mas de WAIT_MAX s: la descarga corre en segundo plano (una sola a la vez por consulta);
    mientras tanto se usan las ultimas velas buenas, o las de Yahoo si todavia no hay ninguna."""
    key = (MODE["live"], sym, iv, days) + (("ext",) if ext else ())
    hit = _TS.get(key)
    if hit and time.time() - hit[0] < _TTL.get(iv, 10):
        return hit[1]
    with _INFL_LOCK:
        ev = _INFLIGHT.get(key)
        if ev is None:
            ev = _INFLIGHT[key] = threading.Event()

            def run(hit=hit):
                try:
                    _timesales_fetch(env, iv, days, sym, ext, key, hit)
                except Exception:  # noqa: BLE001 - el error se ve cuando se vuelve a pedir
                    pass
                finally:
                    with _INFL_LOCK:
                        _INFLIGHT.pop(key, None)
                    ev.set()
            threading.Thread(target=run, daemon=True).start()
    if hit and hit[1] and time.time() - hit[0] < 900:   # ya hay velas: se muestran AL INSTANTE y se actualizan por detras
        return hit[1]
    ev.wait(WAIT_MAX)
    new = _TS.get(key)
    if new and new[1]:
        return new[1]
    if hit and hit[1]:
        return hit[1]
    _yahoo_soon(key, iv, days, sym, ext)   # primera carga y Tradier lento: velas de Yahoo mientras llega lo de Tradier
    raise ApiError("Tradier está tardando en mandar las velas; sigo intentando.")


_YF_PEND = set()


def _yahoo_soon(key, iv, days, sym, ext):
    if key in _YF_PEND:
        return
    _YF_PEND.add(key)

    def run():
        try:
            out = _yahoo_bars(iv, days, sym, ext)
            if out and not (_TS.get(key) or (0, None))[1]:
                _TS[key] = (time.time() - _TTL.get(iv, 10) + 1, out)   # provisional: se vuelve a pedir a Tradier enseguida
                YF_USED[sym] = time.time()
        except Exception:  # noqa: BLE001
            pass
        finally:
            _YF_PEND.discard(key)
    threading.Thread(target=run, daemon=True).start()


YF_SYM = {"SPX": "^GSPC", "VIX": "^VIX", "NDX": "^NDX", "RUT": "^RUT", "DJX": "^DJI"}
_YF_LOCK = threading.Lock()
YF_USED = {}


def _yahoo_bars(iv, days, sym, ext=False):
    """RESPALDO cuando Tradier no manda el historial: velas de Yahoo Finance (1, 5 o 15 min; maximo ~7 dias en 1 min)."""
    if sym.startswith("/") or iv not in ("1min", "5min", "15min"):
        return []
    import fundamentales
    ysym = YF_SYM.get(sym.upper(), sym.upper().replace(".", "-"))
    period = "5d" if iv == "1min" else ("1mo" if days > 7 else "5d")
    with _YF_LOCK:   # yfinance no es muy amigo de varios hilos a la vez
        df = fundamentales._yf().Ticker(ysym).history(period=period, interval=iv.replace("min", "m"), prepost=ext, auto_adjust=False)
    out = []
    for idx, r in df.iterrows():
        try:
            o, h, l, c = float(r["Open"]), float(r["High"]), float(r["Low"]), float(r["Close"])
            if not (o > 0 and h > 0 and l > 0 and c > 0):
                continue
            out.append({"time": _shift(int(idx.timestamp())), "open": o, "high": h, "low": l, "close": c, "volume": float(r.get("Volume") or 0)})
        except (TypeError, ValueError, KeyError):
            continue
    out.sort(key=lambda b: b["time"])
    return _clean_session(out, sym, ext)


def _stream_tail(bars, sym, step=60):
    """Agrega al final las velas armadas con el streaming (los minutos que Tradier o Yahoo todavia no mandan)."""
    try:
        import stream
        last = bars[-1]["time"] if bars else 0
        extra = [b for b in stream.bars(sym, last - step) if 34200 <= b["time"] % 86400 < 57600]
    except Exception:  # noqa: BLE001
        return bars
    if not extra:
        return bars
    if step > 60:
        extra = _agg(extra, step)
    out = list(bars)
    for e in extra:
        if out and e["time"] == out[-1]["time"]:
            o = out[-1]
            out[-1] = dict(o, high=max(o["high"], e["high"]), low=min(o["low"], e["low"]), close=e["close"])
        elif not out or e["time"] > out[-1]["time"]:
            out.append(dict(e))
    return out


def _timesales_fetch(env, iv, days, sym, ext, key, hit):
    try:
        out = _ts_split(env, iv, days, sym, ext) if iv == "1min" and days > 1 else _timesales_raw(env, iv, days, sym, ext)
        YF_USED.pop(sym, None)
    except ApiError:
        if hit and hit[1] and time.time() - hit[0] < 120:   # Tradier fallo/tardo: las ultimas velas buenas (la vela viva la mueve el streaming)
            return hit[1]
        try:   # Tradier no responde: velas de Yahoo para que el grafico no se quede vacio
            out = _yahoo_bars(iv, days, sym, ext)
        except Exception:  # noqa: BLE001
            out = []
        if not out:
            if hit and hit[1] and time.time() - hit[0] < 900:
                return hit[1]
            raise
        YF_USED[sym] = time.time()
    if not out and hit and hit[1] and time.time() - hit[0] < 900:   # Tradier mando la lista vacia un momento: no borrar la grafica
        return hit[1]
    if len(_TS) > 80:
        _TS.clear()
    _TS[key] = (time.time(), out)
    return out


def _ts_split(env, iv, days, sym, ext=False):
    """Velas de 1 min en dos partes, para pedirle MENOS a Tradier (su historial anda lento):
    los dias anteriores se piden cada 5 min; cada vez solo las velas de HOY (una consulta mucho mas chica)."""
    bkey = (MODE["live"], sym, iv, days, "base") + (("ext",) if ext else ())
    b = _TS.get(bkey)
    if not b or not b[1] or time.time() - b[0] > 300:
        try:
            base = _timesales_raw(env, iv, days, sym, ext)
        except ApiError:
            if b and b[1]:
                base = b[1]   # los dias anteriores de hace rato siguen sirviendo
            else:
                return _timesales_raw(env, iv, 0, sym, ext)   # primera vez y Tradier no manda los 4 dias: al menos las de hoy
        _TS[bkey] = (time.time(), base)
        if base is not (b or (0, None))[1]:
            return base
    base = b[1]
    now = datetime.now(ET)
    if now.weekday() >= 5 or now.strftime("%H:%M") < ("04:00" if ext else "09:30"):   # sin sesion hoy: lo de antes sirve
        return base
    today = _timesales_raw(env, iv, 0, sym, ext)
    if not today:
        return base
    day0 = int(datetime(now.year, now.month, now.day, tzinfo=ZoneInfo("UTC")).timestamp())   # 00:00 de hoy en la hora "desplazada" a NY
    merged = [x for x in base if x["time"] < day0] + today
    return _clean_session(merged, sym, ext)


def _timesales_raw(env, iv, days, sym=SYMBOL, ext=False):
    now = datetime.now(ET)
    p = {"symbol": sym, "interval": iv, "session_filter": "all" if ext else "open",
         "start": (now - timedelta(days=days)).strftime("%Y-%m-%d 04:00" if ext else "%Y-%m-%d 09:30"), "end": now.strftime("%Y-%m-%d %H:%M")}
    j = _call(env, "GET", "/markets/timesales", params=p)
    s = j.get("series") if isinstance(j, dict) else None
    out = []
    for d in _as_list(s.get("data") if isinstance(s, dict) else None):
        try:
            out.append({"time": _shift(int(d["timestamp"])), "open": float(d["open"]), "high": float(d["high"]),
                        "low": float(d["low"]), "close": float(d["close"]), "volume": float(d.get("volume") or 0)})
        except (KeyError, TypeError, ValueError):
            continue
    out.sort(key=lambda b: b["time"])
    if iv in ("1min", "5min", "15min"):
        out = _clean_session(out, sym, ext)
    return out


def is_index(sym):
    s = (sym or "").upper()
    return s in VOL_PROXY or s in ("VIX", "SPX", "NDX", "RUT")


def rth(t):
    return 34200 <= t % 86400 < 57600


def _clean_session(bars, sym, ext=False):
    """Velas como TradingView: solo 9:30-16:00 (Tradier manda unas velas planas despues del cierre en los indices)
    y en los indices sin la mecha falsa de la primera vela del dia (Tradier le pone el cierre de ayer como precio)."""
    if ext and not is_index(sym):   # premarket 4:00 a aftermarket 20:00 (los indices no cotizan fuera de horario)
        out = [b for b in bars if 14400 <= b["time"] % 86400 < 72000]
    else:
        out = [b for b in bars if 34200 <= b["time"] % 86400 < 57600]   # la hora ya viene desplazada a Nueva York
    if (sym or "").upper() in VOL_PROXY or (sym or "").upper() in ("VIX", "SPX", "NDX", "RUT"):
        prev = None
        for i, b in enumerate(out):
            day = b["time"] // 86400
            if prev is not None and prev["time"] // 86400 != day:   # primera vela del dia
                pc, lo, hi = prev["close"], min(b["open"], b["close"]), max(b["open"], b["close"])
                if abs(b["open"] - pc) < 0.05 and abs(b["close"] - pc) > 1:   # abre "en el cierre de ayer": no es un precio real de hoy
                    b = dict(b, open=b["close"] if b["close"] - pc else b["open"])
                    lo, hi = min(b["open"], b["close"]), max(b["open"], b["close"])
                if abs(b["low"] - pc) < 0.05 and b["low"] < lo - 1:
                    b = dict(b, low=lo)
                if abs(b["high"] - pc) < 0.05 and b["high"] > hi + 1:
                    b = dict(b, high=hi)
                out[i] = b
            prev = b
    return out


def spread_hist(env, spec):
    """Precio de una estrategia durante la ultima sesion, con velas de 5 min de cada pata (precio de la ultima operacion).
    spec: 'OCC*n,OCC*n' con n>0 compra y n<0 venta (mariposa: A*1,B*-2,C*1). Valor = suma de n x precio (+ = vale / pagas)."""
    legs = []
    for part in (spec or "").split(","):
        occ, _, n = part.partition("*")
        try:
            n = int(n)
        except ValueError:
            raise ApiError("Patas no válidas")
        if not OCC.match(occ) or not n or abs(n) > 20:
            raise ApiError("Patas no válidas")
        legs.append((occ, n))
    if not 1 <= len(legs) <= 4:
        raise ApiError("De 1 a 4 patas")
    series = {}
    for occ, n in legs:
        bars = _timesales(env, "5min", 4, occ)
        if not bars:
            raise ApiError(f"Sin operaciones recientes en {occ}: no se puede dibujar")
        series[occ] = bars
    last_day = max(b["time"] // 86400 for bs in series.values() for b in bs)   # ultima sesion con datos
    ts = sorted({b["time"] for bs in series.values() for b in bs if b["time"] // 86400 == last_day})
    cur, out_t, out_v = {}, [], []
    idx = {occ: 0 for occ, _ in legs}
    for t in ts:
        for occ, _ in legs:
            bs = series[occ]
            while idx[occ] < len(bs) and bs[idx[occ]]["time"] <= t:
                cur[occ] = bs[idx[occ]]["close"]
                idx[occ] += 1
        if len(cur) == len(legs):   # desde que todas las patas tienen al menos una operacion
            out_t.append(t)
            out_v.append(round(sum(n * cur[occ] for occ, n in legs), 3))
    return {"t": out_t, "v": out_v}


def _daily(env, sym=SYMBOL):
    key = (MODE["live"], sym, "D", 0)
    hit = _TS.get(key)
    if hit and time.time() - hit[0] < 300:
        return hit[1]
    out = _daily_raw(env, sym)
    _TS[key] = (time.time(), out)
    return out


def _daily_raw(env, sym=SYMBOL):
    now = datetime.now(ET)
    j = _call(env, "GET", "/markets/history", params={"symbol": sym, "interval": "daily",
              "start": (now - timedelta(days=5 * 365 + 40)).strftime("%Y-%m-%d"), "end": now.strftime("%Y-%m-%d")})   # 5 anos
    h = j.get("history") if isinstance(j, dict) else None
    out = []
    for d in _as_list(h.get("day") if isinstance(h, dict) else None):
        try:
            y, m, dd = map(int, d["date"].split("-"))
            ts = int(datetime(y, m, dd, tzinfo=ZoneInfo("UTC")).timestamp())
            out.append({"time": ts, "open": float(d["open"]), "high": float(d["high"]), "low": float(d["low"]),
                        "close": float(d["close"]), "volume": float(d.get("volume") or 0)})
        except (KeyError, TypeError, ValueError):
            continue
    out.sort(key=lambda b: b["time"])
    return out


def _wm(daily, kind):
    """Velas SEMANALES (W, empiezan el lunes) o MENSUALES (M, dia 1) a partir de las diarias."""
    out, cur, key = [], None, None
    for b in daily:
        d = datetime.fromtimestamp(b["time"], ZoneInfo("UTC")).date()
        k = (d - timedelta(days=d.weekday())) if kind == "W" else d.replace(day=1)
        if k != key:
            if cur:
                out.append(cur)
            key = k
            cur = dict(b, time=int(datetime(k.year, k.month, k.day, tzinfo=ZoneInfo("UTC")).timestamp()))
        else:
            cur["high"] = max(cur["high"], b["high"])
            cur["low"] = min(cur["low"], b["low"])
            cur["close"] = b["close"]
            cur["volume"] = cur.get("volume", 0) + (b.get("volume") or 0)
    if cur:
        out.append(cur)
    return out


def _bucket(t, step):
    day = t - t % 86400
    return day + 34200 + ((t - day - 34200) // step) * step  # velas ancladas a las 9:30 ET


def _agg(bars, step):
    agg = {}
    for b in bars:
        k = _bucket(b["time"], step)
        a = agg.get(k)
        if a is None:
            agg[k] = dict(b, time=k)
        else:
            a["high"] = max(a["high"], b["high"]); a["low"] = min(a["low"], b["low"])
            a["close"] = b["close"]; a["volume"] += b["volume"]
    return [agg[k] for k in sorted(agg)]


def _ut(bars, key=1.0, n=10):
    """UT Bot (ATR trailing stop) igual que el indicador de Pine. Devuelve stop, tendencia y señales."""
    c = [b["close"] for b in bars]
    m = len(c)
    tr = [bars[i]["high"] - bars[i]["low"] if i == 0 else
          max(bars[i]["high"] - bars[i]["low"], abs(bars[i]["high"] - c[i - 1]), abs(bars[i]["low"] - c[i - 1]))
          for i in range(m)]
    atr = [None] * m
    for i in range(m):
        if i == n - 1:
            atr[i] = sum(tr[:n]) / n
        elif i >= n:
            atr[i] = (atr[i - 1] * (n - 1) + tr[i]) / n
    stop, trend, sig = [None] * m, [0] * m, []
    for i in range(m):
        if atr[i] is None:
            continue
        nl = key * atr[i]
        prev = stop[i - 1] if i > 0 and stop[i - 1] is not None else c[i]
        p1 = c[i - 1] if i > 0 else None
        if c[i] > prev and p1 is not None and p1 > prev:
            s = max(prev, c[i] - nl)
        elif c[i] < prev and p1 is not None and p1 < prev:
            s = min(prev, c[i] + nl)
        elif c[i] > prev:
            s = c[i] - nl
        else:
            s = c[i] + nl
        stop[i] = s
        trend[i] = 1 if c[i] > s else -1 if c[i] < s else 0
        if i > 0 and stop[i - 1] is not None:
            if c[i] > s and c[i - 1] <= stop[i - 1]:
                sig.append({"time": bars[i]["time"], "side": "BUY"})
            elif c[i] < s and c[i - 1] >= stop[i - 1]:
                sig.append({"time": bars[i]["time"], "side": "SELL"})
    return stop, trend, sig


def _ma(bars, ema_n=20, sma_n=50):
    c = [b["close"] for b in bars]
    ema, sma, e, run = [], [], None, 0.0
    al = 2.0 / (ema_n + 1)
    for i, x in enumerate(c):
        e = x if e is None else al * x + (1 - al) * e
        if i >= ema_n - 1:
            ema.append({"time": bars[i]["time"], "value": round(e, 4)})
        run += x
        if i >= sma_n:
            run -= c[i - sma_n]
        if i >= sma_n - 1:
            sma.append({"time": bars[i]["time"], "value": round(run / sma_n, 4)})
    return ema, sma


def _crowns(raw1):
    """Corona: la tendencia UT Bot de 1, 3 y 5 minutos coincide (verde = las tres alcistas, roja = las tres bajistas)."""
    if len(raw1) < 60:
        return []
    _, t1, _ = _ut(raw1)
    tfs = []
    for step in (180, 300):
        ag = _agg(raw1, step)
        _, tr, _ = _ut(ag)
        tfs.append(({b["time"]: i for i, b in enumerate(ag)}, tr, step, ag))
    out, last = [], 0
    for i, b in enumerate(raw1):
        st = [t1[i]]
        for idx, tr, step, ag in tfs:
            j = idx.get(_bucket(b["time"], step))
            st.append(tr[j - 1] if j is not None and j > 0 else 0)  # velas ya cerradas: no se repinta
        s = st[0] if st[0] != 0 and all(x == st[0] for x in st) else 0
        if s != 0 and s != last:
            out.append({"time": b["time"], "dir": "UP" if s > 0 else "DOWN"})
        last = s
    return out


def _zigzag(bars, depth=7, dev_ticks=5, backstep=2, tick=0.01):
    """ZigZag con etiquetas HH/LH/HL/LL, igual que el indicador de Pine (depth 7, deviation 5 ticks, backstep 2)."""
    half = max(1, depth // 2)
    thr = dev_ticks * tick
    hi = [b["high"] for b in bars]
    lo = [b["low"] for b in bars]
    piv, last_dir, last_price, last_idx = [], 0, None, None
    last_hi = last_lo = None
    for j in range(2 * half, len(bars)):
        i = j - half
        ph = hi[i] if hi[i] > max(hi[i - half:i]) and hi[i] >= max(hi[i + 1:j + 1]) else None
        pl = lo[i] if lo[i] < min(lo[i - half:i]) and lo[i] <= min(lo[i + 1:j + 1]) else None
        if ph is not None:
            if last_dir == 1:
                ok = ph > last_price
            elif last_dir == -1:
                ok = (ph - last_price >= thr) and (i - last_idx >= backstep)
            else:
                ok = True
            if ok:
                if last_dir == -1:
                    last_lo = last_price
                lab = "HH" if (last_hi is None or ph > last_hi) else "LH"
                if last_dir == 1:
                    piv.pop()
                piv.append({"time": bars[i]["time"], "price": ph, "label": lab, "hi": True})
                last_price, last_idx, last_dir = ph, i, 1
        if pl is not None:
            if last_dir == -1:
                ok = pl < last_price
            elif last_dir == 1:
                ok = (last_price - pl >= thr) and (i - last_idx >= backstep)
            else:
                ok = True
            if ok:
                if last_dir == 1:
                    last_hi = last_price
                lab = "LL" if (last_lo is None or pl < last_lo) else "HL"
                if last_dir == -1:
                    piv.pop()
                piv.append({"time": bars[i]["time"], "price": pl, "label": lab, "hi": False})
                last_price, last_idx, last_dir = pl, i, -1
    return piv


def _opening_range(bars):
    """Rango de apertura de 15 min (9:30-9:45 NY): ORH/ORL/medio por dia, banda y rupturas (como el Pine)."""
    days, out_h, out_l, out_m, brk, bands = {}, [], [], [], [], []
    for b in bars:
        days.setdefault(b["time"] - b["time"] % 86400, []).append(b)
    for day, bs in sorted(days.items()):
        orb = [b for b in bs if 34200 <= b["time"] - day < 35100]
        if not orb:
            for b in bs:
                for o in (out_h, out_l, out_m):
                    o.append({"time": b["time"]})
            continue
        h, l = max(b["high"] for b in orb), min(b["low"] for b in orb)
        end = day + 35100
        prev = None
        for b in bs:
            if b["time"] < end:
                for o in (out_h, out_l, out_m):
                    o.append({"time": b["time"]})
            else:
                out_h.append({"time": b["time"], "value": h})
                out_l.append({"time": b["time"], "value": l})
                out_m.append({"time": b["time"], "value": round((h + l) / 2, 4)})
                if prev is not None:
                    if prev <= h < b["close"]:
                        brk.append({"time": b["time"], "dir": "UP"})
                    elif prev >= l > b["close"]:
                        brk.append({"time": b["time"], "dir": "DOWN"})
            prev = b["close"]
        bands.append({"t1": bs[0]["time"], "t2": bs[-1]["time"], "hi": h, "lo": l})
        # que la linea de un dia NO se una con la del dia siguiente: primer y ultimo punto de cada dia transparentes
        for o in (out_h, out_l, out_m):
            pts = [x for x in o if "value" in x and day <= x["time"] < day + 86400]
            for x in pts[:1] + pts[-1:]:
                x["color"] = "rgba(0,0,0,0)"
    return {"h": out_h, "l": out_l, "m": out_m, "brk": brk, "bands": bands}


_STEP = {"1": 60, "3": 180, "5": 300, "15": 900, "60": 3600, "240": 14400}


VOL_PROXY = {"SPX": "SPY", "SPXW": "SPY", "XSP": "SPY", "NDX": "QQQ", "XND": "QQQ", "RUT": "IWM", "DJX": "DIA"}


def _vol_proxy(sym, bars):
    """ETF cuyo volumen se usa si el simbolo es un indice sin volumen (Tradier manda 0)."""
    p = VOL_PROXY.get((sym or "").upper())
    return p if p and bars and not any((b.get("volume") or 0) > 0 for b in bars) else None


def _with_volume(bars, pbars):
    """Copia el volumen del ETF a cada vela del indice con la misma hora."""
    vol = {b["time"]: b.get("volume") or 0 for b in pbars}
    return [dict(b, volume=vol.get(b["time"], 0)) for b in bars]


def _rth(now=None):
    """Horario normal del mercado de acciones (lun-vie 9:30-16:00 ET)."""
    now = now or datetime.now(ET)
    return now.weekday() < 5 and "09:30" <= now.strftime("%H:%M") < "16:00"


def _spx_real(env, bars, iv):
    """/SPX: las velas del ULTIMO dia en que el SPX oficial opero se toman del SPX de Tradier (tiempo real)
    y reemplazan a las estimadas con /ES; fuera de ese horario se queda el estimado."""
    try:
        real = _timesales(env, iv, 4, "SPX")
    except ApiError:
        return bars, False
    if not real:
        return bars, False
    day = real[-1]["time"] // 86400
    real = [b for b in real if b["time"] // 86400 == day]
    t0, t1 = real[0]["time"], real[-1]["time"]
    out = [b for b in bars if not (t0 <= b["time"] <= t1)] + real
    out.sort(key=lambda b: b["time"])
    return out, True


def _candles_fut(sym, iv, env=None):
    """Grafico de un futuro: mismas medias, señales Buy/Sell, ZigZag y Corona; sin rango de apertura (opera casi 24 h)."""
    ckey = (sym, iv)
    ck = _CC.get(ckey)
    live = sym == "/SPX" and env is not None and _rth()
    if ck and time.time() - ck[0] < (4 if live else 20):
        return ck[1]
    adj = (lambda b, daily=False: _spx_adjust(env, b, daily)) if sym == "/SPX" else (lambda b, daily=False: b)
    raw1 = adj(_fut_bars(sym, "1m"))
    real = False
    if live:
        raw1, real = _spx_real(env, raw1, "1min")
    if iv == "D":
        full = adj(_fut_bars(sym, "1d"), True)
        if live and full:
            q = quote(env, "SPX")
            if q.get("last"):
                full[-1] = dict(full[-1], close=q["last"], high=max(full[-1]["high"], q["last"]), low=min(full[-1]["low"], q["last"]))
                real = True
    elif iv in ("1", "3", "5"):
        full = raw1 if iv == "1" else _agg(raw1, _STEP[iv])
    else:
        b15 = adj(_fut_bars(sym, "15m"))
        if live:
            b15, real = _spx_real(env, b15, "15min")
        full = _agg(b15, _STEP[iv]) if iv != "15" else b15
    last20 = raw1[-20:]
    _, _, sig = _ut(full)
    ema, sma = _ma(full)
    keep = {"1": 900, "3": 600, "5": 500, "15": 500, "60": 400, "240": 300, "D": 300}[iv]
    bars = full[-keep:]
    t0 = bars[0]["time"] if bars else 0
    out = {"sym": sym, "bars": bars, "interval": iv, "fut": FUT[sym][1], "real": real,
           "hh": max((b["high"] for b in last20), default=None), "ll": min((b["low"] for b in last20), default=None),
           "signals": [s for s in sig if s["time"] >= t0], "ema": [p for p in ema if p["time"] >= t0],
           "sma": [p for p in sma if p["time"] >= t0], "crowns": [c for c in _crowns(raw1) if c["time"] >= t0],
           "zz": [p for p in _zigzag(full) if p["time"] >= t0]}
    _CC[ckey] = (time.time(), out)
    return out


def _prefetch(env, sym, iv, ext=False):
    """Lanza en paralelo las consultas de velas que va a necesitar el grafico (quedan en el cache)."""
    from concurrent.futures import ThreadPoolExecutor
    syms = [sym] + ([VOL_PROXY[sym.upper()]] if VOL_PROXY.get(sym.upper()) else [])
    jobs = [(lambda: _timesales(env, "1min", 4, sym, ext))]
    for s_ in syms:
        if iv in ("D", "W", "M"):
            jobs.append(lambda s_=s_: _daily(env, s_))
        elif iv in ("15", "60", "240"):
            jobs.append(lambda s_=s_: _timesales(env, "15min", 35, s_, ext and s_ == sym))
        elif s_ != sym:
            jobs.append(lambda s_=s_: _timesales(env, "1min", 4, s_))
    def run(f):
        try:
            f()
        except Exception:   # noqa: BLE001 - el error real se muestra cuando se vuelve a pedir
            pass
    with ThreadPoolExecutor(max_workers=4) as ex:
        list(ex.map(run, jobs))


def candles(env, interval="1", sym=SYMBOL, ext=False):
    """Velas de cualquier simbolo (SPY por defecto) con volumen, HH/LL de 20 velas de 1m, UT Bot (Buy/Sell),
    medias moviles y corona 1·3·5. La hora va desplazada a hora de Nueva York para el grafico."""
    iv = str(interval) if str(interval) in _STEP or str(interval) in ("D", "W", "M") else "1"
    ext = bool(ext) and not is_index(sym) and iv not in ("D", "W", "M")
    ckey = (sym, iv, ext)
    ck = _CC.get(ckey)
    if ck and time.time() - ck[0] < 3:
        return ck[1]
    if sym in FUT:
        return _candles_fut(sym, "D" if iv in ("W", "M") else iv, env)
    _prefetch(env, sym, iv, ext)   # pide a Tradier todo lo necesario AL MISMO TIEMPO (antes iba uno por uno: lento si Tradier tarda)
    raw1 = _stream_tail(_timesales(env, "1min", 4, sym, ext), sym)
    last20 = [b for b in raw1 if rth(b["time"])][-20:]
    hh = max((b["high"] for b in last20), default=None)
    ll = min((b["low"] for b in last20), default=None)
    def full_for(s, r1):
        if iv == "D":
            return _daily(env, s)
        if iv in ("W", "M"):
            return _wm(_daily(env, s), iv)
        if iv in ("1", "3", "5"):
            return r1 if iv == "1" else _agg(r1, _STEP[iv])
        b15 = _timesales(env, "15min", 35, s, ext and s == sym)
        if s == sym:
            b15 = _stream_tail(b15, s, 900)
        return _agg(b15, _STEP[iv]) if iv != "15" else b15
    full = full_for(sym, raw1)
    proxy = _vol_proxy(sym, full)
    if proxy:   # indice sin volumen: usa el volumen de su ETF (para el VWAP y las barras de volumen)
        try:
            full = _with_volume(full, full_for(proxy, None if iv in ("D", "W", "M") else _timesales(env, "1min", 4, proxy)))
        except ApiError:
            proxy = None
    _, _, sig = _ut(full)
    ema, sma = _ma(full)
    keep = {"1": 900, "3": 600, "5": 500, "15": 500, "60": 400, "240": 300, "D": 1300, "W": 270, "M": 62}[iv]   # D/W/M: 5 anos
    bars = full[-keep:]
    t0 = bars[0]["time"] if bars else 0
    out = {"sym": sym, "bars": bars, "hh": hh, "ll": ll, "interval": iv, "vol_proxy": proxy, "ext": ext,
           "yahoo": bool(YF_USED.get(sym) and time.time() - YF_USED[sym] < 300),
           "signals": [s for s in sig if s["time"] >= t0],
           "ema": [p for p in ema if p["time"] >= t0], "sma": [p for p in sma if p["time"] >= t0],
           "crowns": [c for c in _crowns(raw1) if c["time"] >= t0],
           "zz": [p for p in _zigzag(full) if p["time"] >= t0]}
    if iv in ("1", "3", "5", "15"):
        orr = _opening_range([b for b in full if rth(b["time"])])   # la banda de apertura solo con el horario normal
        out["or"] = {"h": [p for p in orr["h"] if p["time"] >= t0], "l": [p for p in orr["l"] if p["time"] >= t0],
                     "m": [p for p in orr["m"] if p["time"] >= t0], "brk": [p for p in orr["brk"] if p["time"] >= t0],
                     "bands": [x for x in orr["bands"] if x["t2"] >= t0]}
    if len(_CC) > 60:
        _CC.clear()
    _CC[ckey] = (time.time(), out)
    return out


_RZ = {}


def summary(env):
    """P&L de la cuenta sandbox: abierto (precio medio vs costo) y realizado hoy (gainloss de Tradier)."""
    open_pnl, legs = 0.0, 0
    for l in positions(env)["legs"]:
        legs += 1
        if l.get("mark") is not None and l.get("cost") is not None:
            open_pnl += l["mark"] * l["qty"] * 100 - l["cost"]
    realized, note = None, ""
    ck = _RZ.get(MODE["live"])
    if ck and time.time() - ck[0] < 20:
        return {"open": round(open_pnl, 2), "realized": ck[1], "legs": legs, "note": ck[2]}
    try:
        today = datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d")
        j = _call(env, "GET", "/accounts/{acct}/gainloss", params={"start": today, "end": today})
        gl = j.get("gainloss") if isinstance(j, dict) else None
        rows = _as_list(gl.get("closed_position")) if isinstance(gl, dict) else []
        tr = [r for r in rows if str(r.get("close_date", ""))[:10] == today]
        realized = round(sum(_num(r.get("gain_loss")) or 0 for r in tr), 2)
    except ApiError as e:
        tr = []
        note = "Realizado no disponible: " + str(e)[:100]
    if not tr:   # Tradier publica lo cerrado HOY hasta el dia siguiente: mientras, se suma con tus operaciones de hoy (robot + manuales)
        try:
            rows_ = reportes.load_rows(os.path.dirname(os.path.abspath(__file__)), "all", MODE["live"])
            hoy = [r for r in rows_ if r.get("fecha") == today]
            if hoy:
                realized, note = round(sum(r.get("pnl") or 0 for r in hoy), 2), ""
        except Exception:   # noqa: BLE001 - si no se puede, se queda lo de Tradier
            pass
    _RZ[MODE["live"]] = (time.time(), realized, note)
    return {"open": round(open_pnl, 2), "realized": realized, "legs": legs, "note": note}


# ───────────── ordenes ─────────────
def _ratio(l):
    """Contratos de esta pata por cada 'unidad' de la posicion (mariposa 1:2:1, 3 spreads + 1 call = 3:3:1...)."""
    try:
        r = int(l.get("ratio") or 1)
    except (TypeError, ValueError):
        raise ApiError("Proporción de pata no válida")
    if not 1 <= r <= 20:
        raise ApiError("Proporción de pata no válida")
    return r


def _build(body):
    legs = body.get("legs") or []
    if len(legs) not in (1, 2, 3, 4):
        raise ApiError("La orden debe tener de 1 a 4 patas")
    cierre = all(str(l.get("side", "")).endswith("_to_close") for l in legs)
    libre = bool(body.get("free")) and all(str(l.get("side", "")).endswith("_to_open") for l in legs)
    if libre:
        _check_free(legs)
    if any(_ratio(l) != 1 for l in legs) and not cierre and not libre:
        raise ApiError("Las proporciones (por ejemplo 1:2:1) solo se usan para cerrar posiciones que ya tienes")
    solo_cierre = len(legs) in (1, 3) or (cierre and body.get("combo"))   # patas sueltas, 3 patas o personalizadas: solo CERRAR
    if solo_cierre and not cierre and not libre:
        raise ApiError("Las órdenes de 1 o 3 patas solo se permiten para cerrar posiciones que ya tienes")
    typ = body.get("type")
    if typ not in ("credit", "debit", "market"):
        raise ApiError("Tipo de orden no válido")
    mkt = typ == "market"
    try:
        qty = int(body.get("qty"))
        price = 0.0 if mkt else round(float(body.get("price")), 2)
    except (TypeError, ValueError):
        raise ApiError("Cantidad o precio no válidos")
    if not 1 <= qty <= MAX_QTY:
        raise ApiError(f"Cantidad entre 1 y {MAX_QTY} contratos")
    if price <= 0 and not mkt:
        raise ApiError("El precio límite debe ser mayor que 0")
    sym = _sym(body.get("symbol"))
    data = {"class": "multileg", "symbol": sym, "type": typ, "duration": "day"}
    if not mkt:
        data["price"] = f"{price:.2f}"
    exps, strikes = set(), {"C": [], "P": []}
    for i, l in enumerate(legs):
        m = OCC.match(str(l.get("occ", "")))
        if not m or l.get("side") not in SIDES:
            raise ApiError("Pata no válida")
        root = root_of(l["occ"])
        if not root or not root.startswith(sym) or len(root) > len(sym) + 1:
            raise ApiError(f"La pata {l['occ']} no es una opción de {sym}")
        exps.add(m.group(1))
        strikes[m.group(2)].append(int(m.group(3)) / 1000)
        data[f"option_symbol[{i}]"] = l["occ"]
        data[f"side[{i}]"] = l["side"]
        data[f"quantity[{i}]"] = str(qty * _ratio(l))
    if len(exps) != 1:
        raise ApiError("Todas las patas deben tener la misma expiración")
    if len(legs) == 1:   # pata suelta: orden simple de opcion
        side = legs[0]["side"]
        if not mkt and (side == "sell_to_close") != (typ == "credit"):
            raise ApiError("Tipo de orden no válido para esa pata")
        one = {"class": "option", "symbol": sym, "option_symbol": legs[0]["occ"], "side": side,
               "quantity": str(qty * _ratio(legs[0])), "type": "market" if mkt else "limit", "duration": "day"}
        if not mkt:
            one["price"] = f"{price:.2f}"
        return one
    if solo_cierre or libre or mkt:      # combinacion de 3 patas o libre (riesgo ya revisado): no hay "ancho" unico; Tradier y tu vista previa validan el precio
        return data
    widths = [abs(v[0] - v[1]) for v in strikes.values() if len(v) == 2]
    if not widths or min(widths) <= 0:
        raise ApiError("Los strikes de cada lado deben ser distintos")
    if price > max(widths) + 1e-9:
        raise ApiError("El precio no puede ser mayor que el ancho del spread")
    return data


def _check_free(legs):
    """Combinacion libre para ABRIR (mariposas, broken wing, ratios...): 2 a 4 patas y RIESGO DEFINIDO:
    en calls y en puts tienes que COMPRAR al menos tantos contratos como VENDES (nada descubierto)."""
    if len(legs) not in (2, 3, 4):
        raise ApiError("Una combinación libre lleva de 2 a 4 patas")
    if len({l.get("occ") for l in legs}) != len(legs):
        raise ApiError("No repitas la misma opción en dos patas (usa la proporción)")
    for t, nom in (("C", "calls"), ("P", "puts")):
        lo = sh = 0
        for l in legs:
            m = OCC.match(str(l.get("occ", "")))
            if m and m.group(2) == t:
                q = _ratio(l)
                if l.get("side") == "buy_to_open":
                    lo += q
                elif l.get("side") == "sell_to_open":
                    sh += q
        if sh > lo:
            raise ApiError(f"Riesgo sin límite: vendes {sh} {nom} y solo compras {lo}. "
                           "En una combinación libre cada opción vendida debe estar cubierta por una comprada del mismo tipo.")


def _key(data):
    return json.dumps(data, sort_keys=True)


def _held(env):
    j = _call(env, "GET", "/accounts/{acct}/positions")
    raw = _as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    return {p.get("symbol"): _num(p.get("quantity")) or 0 for p in raw}


def _check_close(env, body):
    """Una orden de cierre solo es valida si TIENES esa pata, en esa direccion y con esa cantidad."""
    closing = [l for l in (body.get("legs") or []) if str(l.get("side", "")).endswith("_to_close")]
    if not closing:
        return
    held, qty = _held(env), int(body.get("qty"))
    for l in closing:
        h = held.get(l.get("occ"), 0)
        need = qty * _ratio(l)
        ok = (h >= need) if l["side"] == "sell_to_close" else (-h >= need)
        if not ok:
            m = OCC.match(l.get("occ", ""))
            nombre = f"{int(m.group(3)) / 1000:g} {'Call' if m.group(2) == 'C' else 'Put'}" if m else l.get("occ")
            raise ApiError(f"No tienes la pata {nombre} (o no en esa cantidad/dirección), así que no se puede cerrar. "
                           "Usa el botón Cerrar de la tabla de Posiciones: carga tus patas exactas.")


def preview(env, body):
    data = _build(body)
    _check_close(env, body)
    j = _call(env, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
    PREVIEWED[_key(data)] = time.time()
    return {"preview": j.get("order") or j}


# ───────────── registro automatico de ordenes manuales (papel Y real, en archivos separados) ─────────────
def _fills_path(live):
    return MAN_FILLS_H if akey(live) == H else (MAN_FILLS_LIVE if live else MAN_FILLS)


def _trades_path(live):
    return MAN_TRADES_H if akey(live) == H else (MAN_TRADES_LIVE if live else MAN_TRADES)


def _load_orders():
    try:
        with open(MAN_ORDERS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_orders(lst):
    tmp = MAN_ORDERS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(lst[-3000:], f)
    os.replace(tmp, MAN_ORDERS)


def _register(order, legs, live=None):
    """Anota una orden enviada para que sync_manual guarde sus ejecuciones y calcule el P&L de la cuenta que corresponda."""
    live = akey(MODE["live"] if live is None else live)
    oid = (order or {}).get("id")
    if not oid:
        return
    lst = _load_orders()
    if any(str(e.get("id")) == str(oid) and akey(e.get("live")) == live for e in lst):
        return
    lst.append({"id": str(oid), "ts": time.time(), "legs": legs, "done": False, "live": live})
    _save_orders(lst)


def _fills_from(o):
    items = _as_list(o.get("leg")) or [o]
    out = []
    for l in items:
        q, px = _num(l.get("exec_quantity")), _num(l.get("avg_fill_price"))
        occ, side = l.get("option_symbol") or o.get("option_symbol"), l.get("side") or o.get("side")
        if q and q > 0 and px is not None and occ and side:
            out.append({"opcion": occ, "lado": side, "cantidad": q, "precio": px})
    return out


def _read_fills(live=False):
    rows = []
    path = _fills_path(live)
    if os.path.exists(path):
        with open(path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                try:
                    rows.append({"order_id": r["order_id"], "fecha": r["fecha"], "hora": r["hora"], "opcion": r["opcion"],
                                 "lado": r["lado"], "cantidad": float(r["cantidad"]), "precio": float(r["precio"])})
                except (KeyError, ValueError):
                    pass
    return rows


_BACKFILL = {"done": set(), "ts": 0.0}
QUIET_AGE = 600     # una orden de fuera del panel ejecutada hace mas de 10 min se registra SIN avisar


def _order_time(o):
    raw = str(o.get("transaction_date") or o.get("create_date") or "")
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def backfill_live(env, is_robot=None):
    n = _backfill(env, True, is_robot)
    if h_ready(env):
        n += _backfill(env, H, None)   # cuenta 2: tambien las ordenes que se hagan desde otra plataforma
    return n


def _backfill(env, who, is_robot=None):
    """Cada 15 s en horario de mercado (8:00-17:05 ET; si no, cada minuto): registra las ordenes de opciones YA EJECUTADAS en la cuenta real que no salieron del panel
    (las hiciste en otra plataforma). Solo avisa de las recientes (< 10 min); las viejas (por ejemplo las de todo el
    dia al reiniciar el panel) se registran en silencio. Las del robot (is_robot(contrato, hora)) no cuentan como manuales."""
    ny = datetime.now(ZoneInfo("America/New_York"))
    every = 15 if ny.weekday() < 5 and "08:00" <= ny.strftime("%H:%M") <= "17:05" else 60   # en horario: cada 15 s
    tk = "ts_" + str(who)
    if not (h_ready(env) if who == H else live_ready(env)) or time.time() - _BACKFILL.get(tk, 0) < every:
        return 0
    j = _call_acct(env, who, "GET", "/accounts/{acct}/orders")
    _BACKFILL[tk] = time.time()
    _BACKFILL["done"].add("live" if who is True else "H")
    raw = _as_list((j.get("orders") or {}).get("order")) if isinstance(j.get("orders"), dict) else []
    lst = _load_orders()
    have = {str(e.get("id")) for e in lst if akey(e.get("live")) == who}
    add = []
    for o in raw:
        oid = str(o.get("id") or "")
        if not oid or oid in have or o.get("status") != "filled" or o.get("class") not in ("option", "multileg"):
            continue
        ts = _order_time(o)
        if ts is not None and time.time() - ts > 4 * 86400:
            continue
        if is_robot and o.get("class") == "option" and is_robot(o.get("option_symbol"), ts):
            add.append({"id": oid, "ts": time.time(), "legs": [], "done": True, "live": who, "imported": True, "robot": True})
            continue
        add.append({"id": oid, "ts": time.time(), "legs": [], "done": False, "live": who, "imported": True,
                    "quiet": ts is None or time.time() - ts > QUIET_AGE})
    if add:
        _merge_orders(add)
    return len(add)


def _merge_orders(changed):
    """Guarda cambios SIN pisar ordenes registradas mientras tanto (el panel puede anotar una orden en ese momento)."""
    cur = _load_orders()
    idx = {(str(e.get("id")), akey(e.get("live"))): i for i, e in enumerate(cur)}
    for e in changed:
        k = (str(e.get("id")), akey(e.get("live")))
        if k in idx:
            cur[idx[k]] = e
        else:
            idx[k] = len(cur)
            cur.append(e)
    _save_orders(cur)


def _write_trades(live):
    trades = reportes.fifo_trades(_read_fills(live))
    path = _trades_path(live)
    tmp = path + ".tmp"
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=reportes.TRADE_COLS)
        w.writeheader()
        w.writerows(trades)
    os.replace(tmp, path)


def sync_manual(env, is_robot=None):
    """Revisa las ordenes enviadas desde el panel (cuenta de papel Y cuenta real); las ejecutadas se guardan en
    manual_fills[_real].csv y de ahi se recalcula manual_trades[_real].csv (P&L realizado por cierre).
    Devuelve {'new': [fills nuevos (con 'live')], 'warn': [...]}."""
    warn = []
    try:
        backfill_live(env, is_robot)
    except ApiError as e:
        warn.append("No pude importar las órdenes ya ejecutadas de la cuenta real: " + str(e)[:100])
    lst = _load_orders()
    new, changed, touched = [], [], set()
    for e in lst:
        if e.get("done"):
            continue
        live = akey(e.get("live"))
        if time.time() - e.get("ts", 0) > 4 * 86400:
            e["done"] = True; changed.append(e)
            continue
        try:
            j = _call_acct(env, live, "GET", "/accounts/{acct}/orders/" + e["id"])
        except ApiError:
            continue
        o = j.get("order") or {}
        st = o.get("status")
        if st in ("pending", "open", "partially_filled", "accepted", "calculated", None):
            continue
        e["done"] = True; changed.append(e)
        fl = _fills_from(o)
        if st in ("filled", "canceled", "expired") and fl:
            when = datetime.now()
            raw = str(o.get("transaction_date") or o.get("create_date") or "")
            try:
                when = datetime.fromisoformat(raw.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)
            except ValueError:
                pass
            rows = [dict(f, order_id=e["id"], fecha=when.strftime("%Y-%m-%d"), hora=when.strftime("%H:%M:%S")) for f in fl]
            path = _fills_path(live)
            first = not os.path.exists(path)
            with open(path, "a", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=reportes.FILL_COLS)
                if first:
                    w.writeheader()
                for r in rows:
                    w.writerow(r)
            if not e.get("quiet"):   # las de fuera del panel ya viejas se registran sin avisar
                new += [dict(r, live=live, fuera=bool(e.get("imported"))) for r in rows]
            touched.add(live)
        elif st == "filled":
            warn.append(f"Orden {e['id']} ejecutada pero Tradier no dio el precio de cada pata")
    if changed:
        _merge_orders(changed)
    for live in (False, True, H):
        stale = False
        try:
            with open(_trades_path(live), encoding="utf-8") as f:
                stale = "capital" not in (f.readline() or "")
        except OSError:
            stale = os.path.exists(_fills_path(live))
        if live in touched or stale:
            _write_trades(live)
    return {"new": new, "warn": warn}


def send(env, body):
    data = _build(body)
    _check_close(env, body)
    ts = PREVIEWED.get(_key(data))
    if not ts or time.time() - ts > PREVIEW_TTL:
        raise ApiError("Primero haz la vista previa de esta misma orden (vale 5 minutos)")
    legs = body.get("legs") or []
    opening = all(str(l.get("side", "")).endswith("_to_open") for l in legs)
    watch, gcfg = False, None
    if opening and body.get("managed") and len(legs) not in (2, 3, 4):
        raise ApiError("El gestor vigila estrategias de 2 a 4 patas")
    if opening:  # valida las reglas del gestor ANTES de enviar: si estan mal, no sale ninguna orden
        try:
            import gestor
            gk = body.get("kind") if data.get("type") == "market" else data["type"]   # a mercado: credito/debito segun la estrategia
            watch, gcfg = gestor.prepare(gk, body.get("managed"), body.get("mgr_cfg"))
        except gestor.GestorError as e:
            raise ApiError("Reglas del gestor: " + str(e))
    j = _call(env, "POST", "/accounts/{acct}/orders", data=data)
    PREVIEWED.pop(_key(data), None)
    _register(j.get("order"), [{"occ": l.get("occ"), "side": l.get("side")} for l in legs])
    managed = False
    if watch:
        try:
            managed = gestor.on_spread_entry(j.get("order"), legs, int(body.get("qty")), MODE["live"], gk, gcfg, data["symbol"])
        except Exception:
            managed = False
    return {"order": j.get("order") or j, "managed": managed}


def _roll_build(env, body):
    """Roll de una opcion suelta (rueda: covered call / cash-secured put): cierra la pata vieja y abre la nueva en UNA orden de 2 patas."""
    old, new = str(body.get("old_occ", "")), str(body.get("new_occ", ""))
    mo, mn = OCC.match(old), OCC.match(new)
    if not mo or not mn:
        raise ApiError("Contrato no válido")
    if old == new:
        raise ApiError("El contrato nuevo es igual al actual: cambia el vencimiento o el strike")
    if root_of(old) != root_of(new) or mo.group(2) != mn.group(2):
        raise ApiError("El roll debe ser del mismo activo y del mismo tipo (Call con Call, Put con Put)")
    try:
        qty = int(body.get("qty"))
        price = round(float(body.get("price")), 2)
    except (TypeError, ValueError):
        raise ApiError("Cantidad o precio no válidos")
    if not 1 <= qty <= MAX_QTY:
        raise ApiError(f"Cantidad entre 1 y {MAX_QTY} contratos")
    if not 0 < price <= 50:
        raise ApiError("El precio límite debe estar entre 0.01 y 50")
    typ = body.get("type")
    if typ not in ("credit", "debit"):
        raise ApiError("Tipo de orden no válido (crédito o débito)")
    h = _held(env).get(old, 0)
    if h < 0 and -h >= qty:
        s_old, s_new = "buy_to_close", "sell_to_open"
    elif h > 0 and h >= qty:
        s_old, s_new = "sell_to_close", "buy_to_open"
    else:
        raise ApiError("No tienes esa opción en esa cantidad: no se puede hacer roll")
    root = root_of(old)
    sym = str(body.get("symbol") or root).upper()
    if not SYM_RE.match(sym) or not root.startswith(sym) or len(root) > len(sym) + 1:
        sym = root
    data = {"class": "multileg", "symbol": sym, "type": typ, "duration": "day", "price": f"{price:.2f}",
            "option_symbol[0]": old, "side[0]": s_old, "quantity[0]": str(qty),
            "option_symbol[1]": new, "side[1]": s_new, "quantity[1]": str(qty)}
    return data, [{"occ": old, "side": s_old}, {"occ": new, "side": s_new}]


def roll(env, body):
    data, legs = _roll_build(env, body)
    if body.get("preview"):
        j = _call(env, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
        PREVIEWED[_key(data)] = time.time()
        return {"preview": j.get("order") or j}
    ts = PREVIEWED.get(_key(data))
    if not ts or time.time() - ts > PREVIEW_TTL:
        raise ApiError("Primero haz la vista previa de este mismo roll (vale 5 minutos)")
    j = _call(env, "POST", "/accounts/{acct}/orders", data=data)
    PREVIEWED.pop(_key(data), None)
    _register(j.get("order"), legs)
    return {"order": j.get("order") or j}


def scalp(env, body):
    """Orden de UNA sola opcion (comprar para abrir / vender para cerrar). Hace vista previa + envio en un paso."""
    occ, side = str(body.get("occ", "")), body.get("side")
    if not OCC.match(occ) or side not in ("buy_to_open", "sell_to_close"):
        raise ApiError("Opción o dirección no válida")
    if root_of(occ) != SYMBOL:
        raise ApiError("La orden rápida es solo para SPY (usa Trading manual para otros activos)")
    try:
        qty = int(body.get("qty"))
    except (TypeError, ValueError):
        raise ApiError("Cantidad no válida")
    if not 1 <= qty <= MAX_QTY:
        raise ApiError(f"Cantidad entre 1 y {MAX_QTY} contratos")
    typ = body.get("type", "limit")
    if typ not in ("limit", "market") or (side == "buy_to_open" and typ != "limit"):
        raise ApiError("Las compras deben ser con precio límite")
    data = {"class": "option", "symbol": SYMBOL, "option_symbol": occ, "side": side,
            "quantity": str(qty), "type": typ, "duration": "day"}
    if typ == "limit":
        try:
            price = round(float(body.get("price")), 2)
        except (TypeError, ValueError):
            raise ApiError("Precio no válido")
        if not 0 < price <= 50:
            raise ApiError("El precio límite debe estar entre 0.01 y 50")
        data["price"] = f"{price:.2f}"
    if side == "sell_to_close":
        _check_close(env, {"legs": [{"occ": occ, "side": side}], "qty": qty})
    pv = _call(env, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
    po = pv.get("order") or {}
    if po.get("result") is False or po.get("status") in ("rejected", "error"):
        raise ApiError("Tradier no acepta la orden: " + str(po.get("status") or po)[:200])
    j = _call(env, "POST", "/accounts/{acct}/orders", data=data)
    _register(j.get("order"), [{"occ": occ, "side": side}])
    managed = False
    if side == "buy_to_open":
        try:
            import gestor  # import tardio: gestor.py importa este modulo
            managed = gestor.on_entry(j.get("order"), occ, qty, MODE["live"], data.get("price"))
        except Exception:
            managed = False
    return {"order": j.get("order") or j, "preview": po, "managed": managed}


def modify(env, body):
    """Cambia el PRECIO de una orden limite que sigue pendiente (misma orden, mismo id: no se cancela ni pierde el gestor)."""
    oid = str(body.get("id", ""))
    if not oid.isdigit():
        raise ApiError("Id de orden no válido")
    if body.get("to_market"):   # convertir una orden pendiente en orden A MERCADO (misma orden, mismo id)
        o = (_call(env, "GET", "/accounts/{acct}/orders/" + oid).get("order")) or {}
        if not o.get("id"):
            raise ApiError("No encontré esa orden")
        if (o.get("status") or "") in DONE:
            raise ApiError(f"La orden ya está {o.get('status')}: no se puede modificar")
        j = _call(env, "PUT", "/accounts/{acct}/orders/" + oid, data={"type": "market", "duration": o.get("duration") or "day"})
        return {"order": j.get("order") or j, "price": None}
    try:
        price = round(float(body.get("price")), 2)
    except (TypeError, ValueError):
        raise ApiError("Precio no válido")
    if price <= 0:
        raise ApiError("El precio debe ser mayor que 0")
    o = (_call(env, "GET", "/accounts/{acct}/orders/" + oid).get("order")) or {}
    if not o.get("id"):
        raise ApiError("No encontré esa orden")
    if (o.get("status") or "") in DONE:
        raise ApiError(f"La orden ya está {o.get('status')}: no se puede modificar")
    typ = o.get("type")
    if o.get("class") == "multileg":
        if typ == "even":
            typ = body.get("type")
        if typ not in ("credit", "debit"):
            raise ApiError("Tipo de orden no modificable (elige crédito o débito)")
        strikes, exps = {"C": [], "P": []}, set()
        for l in _as_list(o.get("leg")):
            m = OCC.match(str(l.get("option_symbol", "")))
            if m:
                strikes[m.group(2)].append(int(m.group(3)) / 1000)
                exps.add(m.group(1))
        widths = [abs(v[0] - v[1]) for v in strikes.values() if len(v) == 2]
        if len(exps) == 1 and widths and price > max(widths) + 1e-9:
            raise ApiError("El precio no puede ser mayor que el ancho del spread")
    else:
        if typ not in ("limit", "stop_limit"):
            raise ApiError("Solo se puede cambiar el precio de órdenes límite")
        if price > 50:
            raise ApiError("El precio límite debe estar entre 0.01 y 50")
    data = {"type": typ, "duration": o.get("duration") or "day", "price": f"{price:.2f}"}
    if typ == "stop_limit" and o.get("stop") is not None:
        data["stop"] = str(o.get("stop"))
    j = _call(env, "PUT", "/accounts/{acct}/orders/" + oid, data=data)
    return {"order": j.get("order") or j, "price": price}


def cancel(env, body):
    oid = str(body.get("id", ""))
    if not oid.isdigit():
        raise ApiError("Id de orden no válido")
    j = _call(env, "DELETE", "/accounts/{acct}/orders/" + oid)
    return {"order": j.get("order") or j}


# ───────────── portafolio: acciones y watchlist ─────────────
WATCH_FILE = os.path.join(DATA_DIR, "watchlist.json")
WATCH_DEFAULT = ["SPY", "QQQ", "AAPL", "NVDA", "TSLA"]
OPT_RE = re.compile(r"^[A-Z.]{1,6}\d{6}[CP]\d{8}$")


LIST_RE = re.compile(r"^[\w ÁÉÍÓÚÑáéíóúñ.\-]{1,20}$")


def _watch_all():
    """{"lists": {nombre: [simbolos]}, "cur": nombre}. Acepta el formato viejo (una sola lista)."""
    try:
        with open(WATCH_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = None
    if isinstance(d, list):
        d = {"lists": {"Principal": d}, "cur": "Principal"}
    if not isinstance(d, dict) or not isinstance(d.get("lists"), dict) or not d["lists"]:
        d = {"lists": {"Principal": list(WATCH_DEFAULT)}, "cur": "Principal"}
    d["lists"] = {k: [s for s in v if isinstance(s, str) and SYM_RE.match(s)] for k, v in d["lists"].items()
                  if isinstance(k, str) and isinstance(v, list)} or {"Principal": list(WATCH_DEFAULT)}
    if d.get("cur") not in d["lists"]:
        d["cur"] = next(iter(d["lists"]))
    return d


def _watch_save(d):
    tmp = WATCH_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, WATCH_FILE)


def _watch_load(name=None):
    d = _watch_all()
    return list(d["lists"].get(name or d["cur"]) or d["lists"][d["cur"]])


def watch_set(body):
    d = _watch_all()
    name = body.get("list") or d["cur"]
    act = body.get("action")
    if act in ("new", "rename"):
        nn = str(body.get("name", "")).strip()
        if not LIST_RE.match(nn):
            raise ApiError("Nombre de lista no válido (hasta 20 letras o números)")
        if nn in d["lists"]:
            raise ApiError("Ya existe una lista con ese nombre")
        if act == "new":
            if len(d["lists"]) >= 12:
                raise ApiError("Máximo 12 listas")
            d["lists"][nn] = []
        else:
            if name not in d["lists"]:
                raise ApiError("Lista no encontrada")
            d["lists"] = {(nn if k == name else k): v for k, v in d["lists"].items()}
        d["cur"] = nn
    elif act == "delete":
        if len(d["lists"]) <= 1:
            raise ApiError("Deja al menos una lista")
        d["lists"].pop(name, None)
        d["cur"] = next(iter(d["lists"]))
    elif act == "select":
        if name not in d["lists"]:
            raise ApiError("Lista no encontrada")
        d["cur"] = name
    else:
        out = []
        for s in body.get("symbols") or []:
            s = str(s).strip().upper()
            if not SYM_RE.match(s):
                raise ApiError(f"Símbolo no válido: {s[:12]}")
            if s not in out:
                out.append(s)
        if len(out) > 40:
            raise ApiError("La lista puede tener hasta 40 símbolos")
        if name not in d["lists"]:
            raise ApiError("Lista no encontrada")
        d["lists"][name] = out
        d["cur"] = name
    _watch_save(d)
    return {"symbols": d["lists"][d["cur"]], "lists": list(d["lists"]), "cur": d["cur"]}


def live_data(env):
    """Precios de mercado: si tienes cuenta real, se piden con ella (en tiempo real) aunque estes en PAPEL.
    Solo CONSULTAS de precios; las ordenes siguen yendo a la cuenta del selector."""
    return live_ready(env)


def _quotes(env, syms):
    if not syms:
        return {}
    if live_data(env):
        j = _call_acct(env, True, "GET", "/markets/quotes", params={"symbols": ",".join(syms)})
    else:
        j = _call(env, "GET", "/markets/quotes", params={"symbols": ",".join(syms)})
    qs = _as_list((j.get("quotes") or {}).get("quote")) if isinstance(j.get("quotes"), dict) else []
    return {q.get("symbol"): q for q in qs if isinstance(q, dict)}


def watchlist(env):
    d = _watch_all()
    syms = d["lists"][d["cur"]]
    by = _quotes(env, syms)
    rows = []
    for s in syms:
        q = by.get(s) or {}
        rows.append({"sym": s, "name": q.get("description") or "", "last": _num(q.get("last")),
                     "chg": _num(q.get("change")), "pct": _num(q.get("change_percentage")),
                     "bid": _num(q.get("bid")), "ask": _num(q.get("ask")), "vol": _num(q.get("volume")),
                     "ok": bool(q)})
    return {"rows": rows, "lists": list(d["lists"]), "cur": d["cur"], "live_data": live_data(env)}


def stocks(env):
    """Acciones (no opciones) de la cuenta, con precio medio, ultimo precio y P&L abierto."""
    j = _call(env, "GET", "/accounts/{acct}/positions")
    raw = _as_list((j.get("positions") or {}).get("position")) if isinstance(j.get("positions"), dict) else []
    items = [p for p in raw if p.get("symbol") and not OPT_RE.match(str(p["symbol"]))]
    by = _quotes(env, [p["symbol"] for p in items])
    rows, tv, tp = [], 0.0, 0.0
    for p in items:
        q = by.get(p["symbol"]) or {}
        qty, cost = _num(p.get("quantity")) or 0, _num(p.get("cost_basis"))
        last = _num(q.get("last")) or _num(q.get("close"))
        avg = (cost / qty) if qty and cost is not None else None
        val = last * qty if last is not None else None
        pnl = (val - cost) if val is not None and cost is not None else None
        if val is not None:
            tv += val
        if pnl is not None:
            tp += pnl
        rows.append({"sym": p["symbol"], "qty": qty, "avg": avg, "last": last, "value": val, "pnl": pnl,
                     "pct": (pnl / abs(cost) * 100) if pnl is not None and cost else None,
                     "day": _num(q.get("change_percentage"))})
    # opciones (covered calls, puts, spreads...) de la misma cuenta
    oitems = [p for p in raw if p.get("symbol") and OPT_RE.match(str(p["symbol"]))]
    oq = _quotes(env, [p["symbol"] for p in oitems]) if oitems else {}
    orows, ov, op = [], 0.0, 0.0
    today = datetime.now().date()
    for p in oitems:
        s = p["symbol"]
        m = re.match(r"^([A-Z.]{1,6})(\d{2})(\d{2})(\d{2})([CP])(\d{8})$", s)
        q = oq.get(s) or {}
        qty, cost = _num(p.get("quantity")) or 0, _num(p.get("cost_basis"))
        bid, ask = _num(q.get("bid")), _num(q.get("ask"))
        last = (bid + ask) / 2 if bid is not None and ask is not None and ask > 0 else (_num(q.get("last")) or _num(q.get("close")))
        val = last * qty * 100 if last is not None else None
        pnl = (val - cost) if val is not None and cost is not None else None
        if val is not None:
            ov += val
        if pnl is not None:
            op += pnl
        try:
            exp = datetime(2000 + int(m.group(2)), int(m.group(3)), int(m.group(4))).date()
            dte = (exp - today).days
            exps = exp.isoformat()
        except Exception:
            exps, dte = None, None
        orows.append({"sym": s, "under": m.group(1) if m else s, "right": "CALL" if m and m.group(5) == "C" else "PUT",
                      "strike": int(m.group(6)) / 1000 if m else None, "exp": exps, "dte": dte,
                      "qty": qty, "avg": (cost / qty / 100) if qty and cost is not None else None,
                      "last": last, "value": val, "pnl": pnl,
                      "pct": (pnl / abs(cost) * 100) if pnl is not None and cost else None})
    orows.sort(key=lambda r: (r["under"], r["exp"] or "", r["strike"] or 0))
    return {"rows": rows, "value": round(tv, 2), "pnl": round(tp, 2),
            "opts": orows, "opt_value": round(ov, 2), "opt_pnl": round(op, 2)}


def stock_order(env, body):
    """Comprar (limite) o vender/cubrir (limite o mercado) acciones. Solo sandbox. Preview + envio en un paso."""
    sym = _sym(body.get("symbol"))
    side = body.get("side")
    if side not in ("buy", "sell", "buy_to_cover"):
        raise ApiError("Dirección no válida")
    try:
        qty = int(body.get("qty"))
    except (TypeError, ValueError):
        raise ApiError("Cantidad no válida")
    if not 1 <= qty <= 10000:
        raise ApiError("Cantidad entre 1 y 10000 acciones")
    typ = body.get("type", "limit")
    if typ not in ("limit", "market") or (side == "buy" and typ != "limit"):
        raise ApiError("Las compras deben ser con precio límite")
    data = {"class": "equity", "symbol": sym, "side": side, "quantity": str(qty), "type": typ, "duration": "day"}
    if typ == "limit":
        try:
            price = round(float(body.get("price")), 2)
        except (TypeError, ValueError):
            raise ApiError("Precio no válido")
        if not 0 < price <= 100000:
            raise ApiError("Precio límite no válido")
        data["price"] = f"{price:.2f}"
    if side in ("sell", "buy_to_cover"):
        held = {r["sym"]: r["qty"] for r in stocks(env)["rows"]}.get(sym, 0)
        ok = held >= qty if side == "sell" else -held >= qty
        if not ok:
            raise ApiError(f"No tienes {qty} acciones de {sym} para {'vender' if side == 'sell' else 'cubrir'} "
                           f"(tienes {held:g}).")
    pv = _call(env, "POST", "/accounts/{acct}/orders", data=dict(data, preview="true"))
    po = pv.get("order") or {}
    if po.get("result") is False or po.get("status") in ("rejected", "error"):
        raise ApiError("Tradier no acepta la orden: " + str(po.get("status") or po)[:200])
    j = _call(env, "POST", "/accounts/{acct}/orders", data=data)
    return {"order": j.get("order") or j, "preview": po}


def candles_any(env, sym, interval="5"):
    """Velas simples de cualquier simbolo (para el grafico del portafolio): 1m, 5m, 15m, 1h, 1D, 1S, 1M (5 anos) + EMA20 / SMA50."""
    iv = str(interval) if str(interval) in ("1", "5", "15", "60", "D", "W", "M") else "5"
    if iv in ("D", "W", "M"):
        bars = _daily(env, sym)   # 5 anos, con cache
        bars = (_wm(bars, iv) if iv != "D" else list(bars))[-{"D": 1300, "W": 270, "M": 62}[iv]:]
    else:
        src, days = {"1": ("1min", 4), "5": ("5min", 10), "15": ("15min", 30), "60": ("15min", 40)}[iv]
        raw = [x for x in _timesales(env, src, days, sym) if _vela_ok(x)]   # con cache: no repite consultas si Tradier anda lento
        bars = _agg(raw, 3600)[-300:] if iv == "60" else raw[-700:]
    bars = [x for x in bars if _vela_ok(x)]   # Tradier a veces manda NaN (p. ej. SPX diario) y eso rompe el JSON
    proxy = _vol_proxy(sym, bars)
    if proxy:
        try:
            pb = candles_any(env, proxy, iv)["bars"]
            bars = _with_volume(bars, pb)
        except ApiError:
            proxy = None
    ema, sma = _ma(bars)
    return {"sym": sym, "bars": bars, "ema": ema, "sma": sma, "interval": iv, "vol_proxy": proxy}


def _vela_ok(x):
    """Vela valida: open/high/low/close numeros reales y positivos; volumen NaN se vuelve 0."""
    try:
        if not all(math.isfinite(x[k]) and x[k] > 0 for k in ("open", "high", "low", "close")):
            return False
        if not math.isfinite(x.get("volume") or 0):
            x["volume"] = 0.0
        return True
    except (KeyError, TypeError):
        return False


def _gestor(method, path, body, env):
    import gestor
    try:
        return gestor.handle(method, path, body or {}, env)
    except gestor.GestorError as e:
        raise ApiError(str(e))


def handle(method, path, q, body, env):
    """Devuelve (codigo_http, objeto_json)."""
    try:
        if method == "GET":
            if path == "/api/quote":
                return 200, quote(env, _sym((q.get("sym") or [""])[0]))
            if path == "/api/pnl_hist":
                import pnl_rec
                return 200, pnl_rec.series(MODE["live"], (q.get("legs") or [""])[0])
            if path == "/api/spread_hist":
                return 200, spread_hist(env, (q.get("legs") or [""])[0])
            if path == "/api/expirations":
                return 200, expirations(env, _sym((q.get("sym") or [""])[0]))
            if path == "/api/gex":
                try:
                    hh = int((q.get("h") or ["45"])[0])
                except ValueError:
                    hh = 45
                return 200, gex(env, (q.get("sym") or ["SPX"])[0], hh)
            if path == "/api/chain":
                return 200, chain(env, (q.get("exp") or [""])[0], _sym((q.get("sym") or [""])[0]), (q.get("root") or [""])[0])
            if path == "/api/watch":
                return 200, watchlist(env)
            if path == "/api/stocks":
                return 200, stocks(env)
            if path.startswith("/api/pf_"):
                import pf
                if path == "/api/pf_resumen":
                    return 200, pf.resumen(env)
                if path == "/api/pf_primas":
                    return 200, pf.primas(env)
                if path == "/api/pf_alertas":
                    return 200, {"alerts": pf.alerts()}
                if path == "/api/pf_div":
                    return 200, pf.dividendos(env)
                if path == "/api/pf_cc":
                    return 200, pf.covered(env)
                if path == "/api/pf_eventos":
                    syms = [x for x in (q.get("syms") or [""])[0].upper().split(",") if SYM_RE.match(x)][:40]
                    return 200, {"ev": pf.eventos(syms)}
            if path == "/api/c":
                return 200, candles_any(env, _sym((q.get("sym") or [""])[0]), (q.get("i") or ["5"])[0])
            if path == "/api/orders":
                return 200, orders(env)
            if path == "/api/positions":
                return 200, positions(env)
            if path == "/api/grupos":
                return 200, grupos("GET", {})
            if path == "/api/account":
                return 200, account(env)
            if path == "/api/candles":
                return 200, candles(env, (q.get("i") or ["1"])[0], _sym((q.get("sym") or [""])[0]), (q.get("ext") or ["0"])[0] == "1")
            if path == "/api/search":
                return 200, search(env, (q.get("q") or [""])[0])
            if path == "/api/mode":
                return 200, mode_info(env)
            if path == "/api/opt_stream":
                import stream as _st
                return 200, dict(on=opt_stream_on(), stream=_st.status().get("on"))
            if path == "/api/stream_want":   # el constructor avisa que patas estas armando (para recibirlas por streaming)
                occs = [x for x in (q.get("syms") or [""])[0].split(",") if OCC.match(x)][:12]
                _stream_q(occs)
                return 200, {"ok": True, "n": len(occs)}
            if path == "/api/pausa":
                import pausa
                return 200, pausa.estado(MODE["live"])
            if path == "/api/summary":
                return 200, summary(env)
            if path == "/api/gestor":
                return 200, _gestor(method, path, None, env)
        elif method == "POST":
            _live_guard(env, path, body)
            if path in ("/api/order", "/api/stock_order", "/api/scalp", "/api/roll", "/api/gestor_item", "/api/gestor_adopt"):
                bust()   # despues de una orden, lo siguiente que pidas viene fresco de Tradier
            if path == "/api/mode":
                return 200, set_mode(env, body)
            if path == "/api/preview":
                return 200, preview(env, body)
            if path == "/api/order":
                try:
                    return 200, send(env, body)
                finally:
                    bust()
            if path == "/api/watch_set":
                return 200, watch_set(body)
            if path == "/api/opt_stream":
                return 200, opt_stream_set((body or {}).get("on"))
            if path == "/api/pf_alertas":
                import pf
                return 200, pf.alerts_post(body or {})
            if path == "/api/stock_order":
                return 200, stock_order(env, body)
            if path == "/api/scalp":
                return 200, scalp(env, body)
            if path == "/api/roll":
                return 200, roll(env, body)
            if path == "/api/cancel":
                try:
                    return 200, cancel(env, body)
                finally:
                    bust()
            if path == "/api/modify":
                bust()
                return 200, modify(env, body)
            if path == "/api/grupos":
                return 200, grupos("POST", body or {})
            if path in ("/api/gestor_cfg", "/api/gestor_pause", "/api/gestor_item", "/api/gestor_adopt"):
                return 200, _gestor(method, path, body, env)
        return 404, {"error": "No encontrado"}
    except ApiError as e:
        return 200, {"error": str(e)}
    except Exception as e:  # nunca tumbar el panel
        return 200, {"error": f"Error inesperado: {e.__class__.__name__}"}


# ───────────── selector PAPEL / REAL (se inyecta en todas las paginas con ordenes) ─────────────
# ───────────── agrupacion MANUAL de patas (juntar / desarmar), compartida por todas las paginas ─────────────
GRUPOS_FILE = os.path.join(DATA_DIR, "grupos.json")


def _grupos_load():
    try:
        with open(GRUPOS_FILE, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def grupos(method, body):
    """GET: {juntar: [[occ...]], separar: [[occ...]]} de la cuenta actual (papel o real).
    POST {action: juntar|separar|auto, occs: [...]}: juntar = una sola posicion; separar = patas sueltas; auto = como las agrupa el panel."""
    acct = "h" if akey(MODE["live"]) == H else ("real" if MODE["live"] else "papel")
    d = _grupos_load()
    cur = d.get(acct) or {"juntar": [], "separar": []}
    if method == "POST":
        act, occs = body.get("action"), body.get("occs") or []
        if act not in ("juntar", "separar", "auto") or not isinstance(occs, list) or not 1 <= len(occs) <= 8 \
                or not all(isinstance(o, str) and OCC.match(o) for o in occs):
            raise ApiError("Patas no válidas (de 1 a 8)")
        if act == "juntar":
            if len(occs) < 2:
                raise ApiError("Para juntar elige al menos 2 patas")
            if len({root_of(o) for o in occs}) != 1 or len({OCC.match(o).group(1) for o in occs}) != 1:
                raise ApiError("Solo se pueden juntar patas del mismo activo y el mismo vencimiento")
        s = set(occs)
        cur = {k: [g for g in cur.get(k, []) if not s & set(g)] for k in ("juntar", "separar")}
        if act != "auto":
            cur[act].append(sorted(s))
        d[acct] = cur
        tmp = GRUPOS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, GRUPOS_FILE)
    return cur


GRUPOS_JS = r"""
/* P&L sin brincos: el precio medio de las opciones del SPX brinca unos centavos con cada cambio de bid/ask.
   Para mostrarlo se usa la MEDIANA de los ultimos ~15 s de cada posicion (las ordenes y el gestor no usan esto). */
const PNLH={},PNLL={};
function smoothG(groups){const now=Date.now();
  for(const g of groups||[]){
    const k=(g.sym||"")+"|"+g.exp+"|"+(g.legs||[]).map(x=>x.occ+"*"+(x.qty||x.sg||"")).join(",");
    if(g.closeNow===null||g.closeNow===undefined){   // alguna pata sin precio confiable (apertura): ultimo P&L bueno, marcado con ⏳
      const L=PNLL[k];if(L&&now-L[0]<180000&&g.entryNet!=null){g.closeNow=L[1];g.pnl=(g.entryNet-L[1])*100*g.q;g.stale=true}continue}
    const h=(PNLH[k]=(PNLH[k]||[]).filter(x=>now-x[0]<15000));h.push([now,g.closeNow]);if(h.length>3)h.splice(0,h.length-3);   // mediana de las ultimas 3 lecturas: quita un precio malo suelto sin quedarse atras
    const v=h.map(x=>x[1]).sort((a,b)=>a-b),m=v.length%2?v[(v.length-1)/2]:(v[v.length/2-1]+v[v.length/2])/2;
    g.closeRaw=g.closeNow;g.closeNow=m;PNLL[k]=[now,m];if(g.entryNet!==null&&g.entryNet!==undefined)g.pnl=(g.entryNet-m)*100*g.q}}
function acctOf(x){return x==="H"?"H":(x?"live":"paper")}   /* cuenta de una posicion: papel / tu real / cuenta 2 */
/* ===== juntar / desarmar posiciones (se guarda en el servidor; igual en todas las paginas) ===== */
let GRP={juntar:[],separar:[]},GRPMODE=false,GRPSEL=new Set(),GRP_Q={};
/* cuanto cambia el P&L abierto si el subyacente se mueve +1% o -1% (delta + gamma, con el precio de cada subyacente) */
function moveBox(legs,spots){let up=0,dn=0,ok=false;
  for(const l of legs||[]){const S0=(spots||{})[l.root];if(!S0||l.delta==null)continue;ok=true;
    const sh=l.delta*l.qty*100,gm=(l.gamma||0)*l.qty*100,dS=S0*0.01;up+=sh*dS+0.5*gm*dS*dS;dn+=-sh*dS+0.5*gm*dS*dS}
  if(!ok)return"";const f=v=>'<b class="'+(v>=0?"ok":"bad")+'">'+(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(0)+'</b>';
  return'<div title="Estimado con delta y gamma de Tradier: cuánto cambia tu P&amp;L abierto si el subyacente sube o baja 1% ahora mismo (con el tiempo y la volatilidad cambia)"><span>SI SUBE 1% · SI BAJA 1%</span>'+f(up)+' <span style="display:inline;color:var(--mut)">·</span> '+f(dn)+'</div>'}
async function grpLoad(){try{const r=await fetch("/api/grupos",{cache:"no-store"});const j=await r.json();if(!j.error)GRP=j}catch(e){}}
grpLoad();setInterval(grpLoad,15000);
/* posiciones que vigila el gestor: se muestran tal como se abrieron (ej. 2 iron condors que comparten el mismo call spread) */
let GRP_GEST=[],GRP_GESTK="";
async function grpGest(){try{const r=await fetch("/api/gestor",{cache:"no-store"});const j=await r.json();
  const L=(j.items||[]).filter(i=>["activa","entrada","cerrando"].includes(i.status)&&acctOf(i.live)===(window.ACCT||"paper")&&(i.legs||[]).length>1&&i.qty>0).map(i=>({legs:i.legs,qty:i.qty}));
  const k=JSON.stringify(L);if(k!==GRP_GESTK){const first=GRP_GESTK==="";GRP_GEST=L;GRP_GESTK=k;if(!first&&typeof window.GRP_RENDER==="function")window.GRP_RENDER()}}catch(e){}}
grpGest();setInterval(grpGest,15000);
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",()=>grpPaint());else setTimeout(()=>grpPaint(),0);   // dibuja el boton al abrir la pagina
const grpGcd=(a,b)=>b?grpGcd(b,a%b):a;
/* nombre de la combinacion: mariposa 1:2:1 (normal o broken wing); si no, personalizada */
function grpName(legs){
  const n=legs.length,t=legs[0].type;
  if(n===3&&legs.every(x=>x.type===t)&&legs[0].ratio===1&&legs[1].ratio===2&&legs[2].ratio===1&&legs[0].sg===legs[2].sg&&legs[1].sg===-legs[0].sg){
    const w1=legs[1].strike-legs[0].strike,w2=legs[2].strike-legs[1].strike,tp=t==="P"?"Put":"Call";
    return(w1===w2?tp+" butterfly":tp+" broken wing butterfly")+(legs[1].sg<0?"":" (corta)")}
  return"Personalizada ("+n+" patas"+(legs.some(x=>x.ratio>1)?" · "+legs.map(x=>x.ratio).join(":"):"")+")"}
function grpCombo(L){
  const q=L.reduce((a,l)=>grpGcd(a,Math.abs(l.qty)),0)||1;   // unidades: maximo comun divisor de las cantidades
  const legs=L.map(l=>({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,ratio:Math.abs(l.qty)/q,q,frac:1,l}));
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0),0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark==null)okv=false;else val+=x.sg*x.l.mark*Math.abs(x.l.qty)*100}
  const gr=k=>legs.reduce((a,x)=>a+(x.l[k]==null?0:x.sg*x.l[k]*Math.abs(x.l.qty)*100),0);
  return{name:grpName(legs),combo:true,manual:true,exp:L[0].exp,sym:L[0].root||"",q,legs,
    entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),
    strikes:legs.map(x=>x.strike+(x.type==="C"?"C":"P")).join(" / ")}}
/* aplica tus agrupaciones manuales y deja que el panel agrupe el resto como siempre */
function grpApply(legs,auto){
  GRP_Q={};for(const l of legs)GRP_Q[l.occ]=l;
  let rest=legs.slice();const man=[],sep=[];
  for(const set of (GRP.juntar||[])){
    const L=set.map(o=>GRP_Q[o]);if(L.some(l=>!l||!rest.includes(l)))continue;
    rest=rest.filter(l=>!L.includes(l));man.push(grpCombo(L))}
  for(const set of (GRP.separar||[]))for(const o of set){const l=rest.find(x=>x.occ===o);if(l){rest=rest.filter(x=>x!==l);l.separada=true;sep.push(l)}}
  const gg=[];
  /* estrategias como se ABRIERON (misma orden): broken wing, mariposa, ratio... se reconocen solas */
  for(const os of (window.GRP_OSETS||[])){
    const L=os.legs.map(x=>rest.find(l=>l.occ===x.occ&&Math.sign(l.qty)===Math.sign(x.n)));if(L.some(l=>!l))continue;
    const u=Math.min(os.units,...L.map((l,i)=>Math.floor(Math.abs(l.qty)/Math.abs(os.legs[i].n))));if(u<1)continue;
    const part=L.map((l,i)=>{const q=u*Math.abs(os.legs[i].n),c={...l,qty:Math.sign(l.qty)*q};if(l.cost!=null)c.cost=l.cost*q/Math.abs(l.qty);return c});
    const R=auto(part);const g=(!R.loose.length&&R.groups.length===1)?R.groups[0]:Object.assign(grpCombo(part),{manual:false});
    gg.push(Object.assign(g,{fromOrder:os.id}));
    rest=rest.flatMap(l=>{const i=L.indexOf(l);if(i<0)return[l];const q=Math.abs(l.qty)-Math.abs(part[i].qty);if(!q)return[];
      const f=q/Math.abs(l.qty),c={...l,qty:Math.sign(l.qty)*q};if(l.cost!=null)c.cost=l.cost*f;return[c]})}
  for(const it of GRP_GEST){   // separa las unidades de cada posicion del gestor
    const L=it.legs.map(o=>rest.find(l=>l.occ===o));if(L.some(l=>!l||Math.abs(l.qty)<it.qty))continue;
    const part=L.map(l=>{const f=it.qty/Math.abs(l.qty),c={...l,qty:Math.sign(l.qty)*it.qty};if(l.cost!=null)c.cost=l.cost*f;return c});
    const R=auto(part);if(R.loose.length||R.groups.length!==1)continue;
    gg.push(Object.assign(R.groups[0],{gestor:true}));
    rest=rest.flatMap(l=>{const i=L.indexOf(l);if(i<0)return[l];const q=Math.abs(l.qty)-it.qty;if(!q)return[];
      const f=q/Math.abs(l.qty),c={...l,qty:Math.sign(l.qty)*q};if(l.cost!=null)c.cost=l.cost*f;return[c]})}
  const R=auto(rest);return{groups:man.concat(gg,R.groups),loose:R.loose.concat(sep)}}
const GRPB='style="margin-left:4px;padding:3px 8px;border-radius:7px;border:1px solid #3c3c46;background:transparent;color:#c9d4ea;font:600 11px -apple-system,sans-serif;cursor:pointer"';
function grpBar(){return GRPMODE
  ?'<button '+GRPB.replace("#3c3c46","#ffd23f").replace("#c9d4ea","#ffd23f")+' onclick="grpJoin()">🔗 Juntar seleccionadas ('+GRPSEL.size+')</button><button '+GRPB+' onclick="grpMode(false)">Cancelar</button>'
  :'<button '+GRPB+' onclick="grpMode(true)" title="Marca dos o más filas y júntalas en una sola posición (para verla y cerrarla junta)">🔗 Juntar contratos</button>'}
function grpPaint(){document.querySelectorAll(".grpbar").forEach(e=>e.innerHTML=grpBar())}
function grpRerender(){grpPaint();if(typeof window.GRP_RENDER==="function")window.GRP_RENDER()}
function grpMode(on){GRPMODE=on;GRPSEL=new Set();grpRerender()}
function grpChk(occs){if(!GRPMODE)return"";const k=occs.join(",");
  return'<input type="checkbox" style="width:auto;margin:0 6px 0 0;vertical-align:middle;accent-color:#ffd23f" '+(GRPSEL.has(k)?"checked ":"")+'onchange="grpSel(\''+k+'\',this.checked)">'}
function grpSel(k,on){if(on)GRPSEL.add(k);else GRPSEL.delete(k);grpPaint()}
function grpSplitBtn(occs){return'<button '+GRPB+' onclick="grpAct(\'separar\',\''+occs.join(",")+'\')" title="Separar esta posición en patas sueltas">✂ Desarmar</button>'}
function grpLooseBtn(l){return l&&l.separada?'<button '+GRPB+' onclick="grpAct(\'auto\',\''+l.occ+'\')" title="Que el panel la vuelva a agrupar solo">↺ Auto</button>':""}
async function grpPost(b){const r=await fetch("/api/grupos",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});return r.json()}
async function grpAct(action,csv){const occs=csv.split(",");
  if(action==="separar"){const d=GRP.juntar.find(g=>g.join(",")===occs.slice().sort().join(","));if(d){action="auto"}}   // desarmar una personalizada = volver a automatico
  const j=await grpPost({action,occs});if(j.error){alert(j.error);return}GRP=j;
  if(action==="auto"&&occs.length>1){const j2=await grpPost({action:"separar",occs});if(!j2.error)GRP=j2}
  grpRerender()}
async function grpJoin(){
  const occs=[...new Set([...GRPSEL].flatMap(k=>k.split(",")))];
  if(occs.length<2){alert("Marca al menos dos filas (o una pata suelta y una estrategia) para juntarlas.");return}
  if(occs.length>8){alert("Se pueden juntar como máximo 8 patas.");return}
  if(occs.length>4&&!confirm("Vas a juntar "+occs.length+" patas. Se verán como una sola posición, pero Tradier acepta máximo 4 patas por orden: para cerrarla tendrás que desarmarla y cerrar por partes. ¿Continuar?"))return;
  const j=await grpPost({action:"juntar",occs});if(j.error){alert(j.error);return}
  GRP=j;GRPMODE=false;GRPSEL=new Set();grpRerender()}
"""


PAUSA_JS = r"""<div id="pausaBar" style="display:none;position:sticky;top:0;z-index:400;background:#ffc04d;color:#2a1c00;font:700 14px -apple-system,BlinkMacSystemFont,sans-serif;text-align:center;padding:9px 12px;letter-spacing:.02em"></div>
<script>(function(){let P=null,T0=0;
  async function q(){try{const r=await fetch("/api/pausa",{cache:"no-store"});P=await r.json();T0=Date.now()}catch(e){}paint()}
  function paint(){const b=document.getElementById("pausaBar");if(!b)return;
    if(!P||!P.activa){b.style.display="none";return}
    const left=Math.max(0,P.faltan-Math.floor((Date.now()-T0)/1000));if(left<=0){b.style.display="none";q();return}
    const m=Math.floor(left/60),s=String(left%60).padStart(2,"0");
    b.textContent="⏸ Pausa después de "+P.perdidas+" pérdidas seguidas · faltan "+m+":"+s+" (hasta las "+P.hasta+") · puedes cerrar posiciones y mover stops, pero no abrir nuevas";
    b.style.display="block"}
  q();setInterval(q,10000);setInterval(paint,1000)})();</script>
"""

MODE_WIDGET = r"""<style>
#modeBtn{background:transparent;border:1px solid #ffc04d;color:#ffc04d;border-radius:99px;padding:5px 12px;font:700 12px ui-monospace,Menlo,monospace;letter-spacing:.06em;cursor:pointer;margin-left:10px}
#modeBtn.live{background:#ff9f43;border-color:#ff9f43;color:#2e1600}#modeBtn.hh{background:#b48cff;border-color:#b48cff;color:#1a0b33}
body.hh #liveBar{background:#b48cff;color:#1a0b33}#acctMenu{position:absolute;z-index:300;background:#0c0c0f;border:1px solid #3c3c46;border-radius:10px;padding:6px;min-width:220px;box-shadow:0 10px 30px rgba(0,0,0,.6)}
#acctMenu button{display:block;width:100%;text-align:left;background:transparent;border:0;color:#e6ecf5;padding:9px 10px;border-radius:7px;font:700 13px -apple-system,sans-serif;cursor:pointer}#acctMenu button:hover{background:#16161b}
#liveBar{display:none;position:fixed;top:0;left:0;right:0;height:22px;background:#ff9f43;color:#2e1600;font:700 12px/22px ui-monospace,Menlo,monospace;text-align:center;z-index:200;letter-spacing:.1em}
body.live{padding-top:22px}body.live #liveBar{display:block}
</style><div id="liveBar">🔴 CUENTA REAL · LAS ÓRDENES USAN DINERO REAL</div>
<script>
(function(){
  const w=window;w.LIVE=false;w.ACCT="paper";w.ACCTNAME="Papel";let INFO={};
  w.acctOf=x=>x==="H"?"H":(x?"live":"paper");w.isH=()=>w.ACCT==="H";
  const btn=document.createElement("button");btn.id="modeBtn";btn.title="Cambiar entre cuenta de papel y cuenta real";
  const hd=document.querySelector("header");
  if(hd){(hd.children[0]||hd).appendChild(btn)}else{const row=document.createElement("div");row.style.cssText="display:flex;justify-content:flex-end;margin:0 0 6px";row.appendChild(btn);document.body.insertBefore(row,document.body.firstChild)}
  const call=async b=>{const r=await fetch("/api/mode",b?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}:{cache:"no-store"});return r.json()};
  function paint(){const H_=w.ACCT==="H",nm=(w.ACCTNAME||"").toUpperCase();
    document.body.classList.toggle("live",w.LIVE);document.body.classList.toggle("hh",H_);btn.classList.toggle("live",w.LIVE&&!H_);btn.classList.toggle("hh",H_);
    btn.textContent=H_?"🟣 "+nm+" ▾":w.LIVE?"🔴 REAL ▾":"🧪 PAPEL ▾";
    const pre=H_?"🟣 "+nm+" · ":w.LIVE?"🔴 REAL · ":"";document.title=pre+document.title.replace(/^(🔴 REAL|🟣 [^·]+) · /,"");
    const lb=document.getElementById("liveBar");if(lb)lb.textContent=H_?"🟣 CUENTA REAL DE "+nm+" · LAS ÓRDENES USAN SU DINERO":"🔴 CUENTA REAL · LAS ÓRDENES USAN DINERO REAL";
    const p=document.getElementById("modepill");if(p){p.textContent=H_?"CUENTA "+nm:w.LIVE?"CUENTA REAL":"SANDBOX · PAPEL";p.style.cssText=H_?"border-color:#b48cff;color:#b48cff":w.LIVE?"border-color:#ff9f43;color:#ff9f43":""}
    const n=document.getElementById("modenote");if(n)n.style.display=w.LIVE?"none":""}
  async function sync(first){try{INFO=await call();if(INFO.error)return;const a=INFO.acct||(INFO.live?"live":"paper");
    if(!first&&a!==w.ACCT){location.reload();return}w.LIVE=!!INFO.live;w.ACCT=a;w.ACCTNAME=INFO.name||"";paint()}catch(e){}}
  async function go(a){const m=document.getElementById("acctMenu");if(m)m.remove();if(a===w.ACCT)return;
    if(a==="paper"){const j=await call({acct:"paper"});if(j.error){alert(j.error);return}location.reload();return}
    if(a==="live"&&!INFO.has_live){if(await (w.askOk||(m=>Promise.resolve(confirm(m))))("Aún no hay cuenta REAL configurada. ¿Abrir ⚙ Cuentas para agregarla?"))location.href="/setup";return}
    if(a==="H"&&!INFO.has_h){if(await (w.askOk||(m=>Promise.resolve(confirm(m))))("La cuenta 2 no está configurada. Su dueña pega su token en ⚙ Cuentas. ¿Abrir ⚙ Cuentas?"))location.href="/setup";return}
    const who=a==="H"?"la cuenta REAL de "+(INFO.h_name||"cuenta 2").toUpperCase():"tu cuenta REAL";
    const t=prompt("Vas a conectar "+who+" de Tradier. Las órdenes que envíes desde el panel usarán ese dinero real. El panel vuelve a papel cada vez que se reinicia.\n\nEscribe REAL para continuar:");
    if((t||"").trim()!=="REAL")return;
    const j=await call({acct:a,confirm:"REAL"});if(j.error){alert(j.error);return}location.reload()}
  btn.onclick=e=>{e.stopPropagation();const old=document.getElementById("acctMenu");if(old){old.remove();return}
    const m=document.createElement("div");m.id="acctMenu";const r=btn.getBoundingClientRect();m.style.left=(r.left+window.scrollX)+"px";m.style.top=(r.bottom+window.scrollY+6)+"px";
    const it=(a,txt)=>{const b=document.createElement("button");b.type="button";b.textContent=(w.ACCT===a?"✓ ":"   ")+txt;b.onclick=ev=>{ev.stopPropagation();go(a)};m.appendChild(b)};
    it("paper","🧪 Papel (práctica)");it("live","🔴 Mi cuenta REAL");if(INFO.has_h)it("H","🟣 "+(INFO.h_name||"Cuenta 2")+" · REAL");
    document.body.appendChild(m);setTimeout(()=>document.addEventListener("click",function f(){const x=document.getElementById("acctMenu");if(x)x.remove();document.removeEventListener("click",f)}),0)};
  /* Cuadro de confirmacion: boton Sí / No (en cuenta REAL ya no hay que escribir la palabra). Devuelve una promesa. */
  w.guard=function(txt){return new Promise(res=>{
    const live=w.LIVE,H_=w.ACCT==="H",col=H_?"#b48cff":live?"#ff9f43":"#5cc8ff",ov=document.createElement("div");
    ov.style.cssText="position:fixed;inset:0;background:rgba(3,6,12,.75);z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px";
    const box=document.createElement("div");
    box.style.cssText="max-width:480px;width:100%;max-height:90vh;overflow:auto;background:#0c0c0f;border:2px solid "+col+";border-radius:14px;padding:18px;box-shadow:0 20px 60px rgba(0,0,0,.7);font:14px -apple-system,BlinkMacSystemFont,sans-serif;color:#e6ecf5";
    const h=document.createElement("div");h.style.cssText="font-weight:800;font-size:15px;margin-bottom:10px;color:"+col;h.textContent=H_?"🟣 CUENTA REAL DE "+(w.ACCTNAME||"").toUpperCase()+" · su dinero real":live?"🔴 CUENTA REAL · dinero real":"🧪 Cuenta de PAPEL (práctica)";
    const p=document.createElement("div");p.style.cssText="white-space:pre-wrap;line-height:1.45;margin-bottom:8px";p.textContent=txt;
    const n=document.createElement("div");n.style.cssText="color:#7d8aa5;font-size:12px;margin-bottom:12px";
    n.textContent=live?"Topes por orden: "+(INFO.max_qty||3)+" contratos / $"+(INFO.max_buy||5000)+" en compras de acciones.":"Solo dinero de práctica.";
    const q=document.createElement("div");q.style.cssText="font-weight:800;margin-bottom:12px";q.textContent="¿Estás seguro?";
    const row=document.createElement("div");row.style.cssText="display:flex;gap:10px";
    const mk=(label,bg,fg)=>{const b=document.createElement("button");b.type="button";b.textContent=label;
      b.style.cssText="flex:1;padding:12px;border-radius:10px;border:2px solid "+bg+";background:"+bg+";color:"+fg+";font-weight:800;font-size:15px;cursor:pointer";return b};
    const no=mk("No","transparent","#e6ecf5");no.style.borderColor="#3c3c46";const yes=mk("Sí",H_?"#b48cff":live?"#ff9f43":"#4ff0b7","#0a0a0d");
    const done=v=>{document.removeEventListener("keydown",key,true);ov.remove();res(v?(live?{live_confirm:"REAL"}:{}):null)};
    const key=e=>{if(e.key==="Escape"){e.preventDefault();e.stopPropagation();done(false)}};
    no.onclick=()=>done(false);yes.onclick=()=>done(true);ov.addEventListener("click",e=>{if(e.target===ov)done(false)});
    document.addEventListener("keydown",key,true);
    row.append(no,yes);box.append(h,p,n,q,row);ov.appendChild(box);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(ov);yes.focus()})};

  /* avisos con sonido: orden llenada / rechazada y cierres del gestor */
  (function(){
    let snd=true;try{snd=localStorage.getItem("snd")!=="0"}catch(e){}
    let ac=null;const bell=document.createElement("button");bell.id="bellBtn";
    bell.style.cssText="background:transparent;border:1px solid #202027;color:#7d8aa5;border-radius:99px;padding:4px 9px;font:700 12px ui-monospace,Menlo,monospace;cursor:pointer;margin-left:6px";
    const paintB=()=>{bell.textContent=snd?"🔔":"🔕";bell.title=snd?"Avisos con sonido: activados (clic para silenciar)":"Avisos con sonido: silenciados (clic para activar)"};paintB();
    bell.onclick=()=>{snd=!snd;try{localStorage.setItem("snd",snd?"1":"0")}catch(e){}paintB();if(snd)beep("ok")};
    if(btn.parentNode)btn.parentNode.insertBefore(bell,btn.nextSibling);
    function beep(kind){if(!snd)return;try{ac=ac||new (w.AudioContext||w.webkitAudioContext)();if(ac.state==="suspended")ac.resume();
      (kind==="bad"?[330,220]:[660,880]).forEach((f,i)=>{const o=ac.createOscillator(),g=ac.createGain();o.type="sine";o.frequency.value=f;g.gain.value=.12;o.connect(g);g.connect(ac.destination);const t0=ac.currentTime+i*.16;o.start(t0);o.stop(t0+.14)})}catch(e){}}
    document.addEventListener("click",()=>{try{if(ac&&ac.state==="suspended")ac.resume()}catch(e){}},{once:true});
    let flash=null;const t0=document.title;
    w.evAlert=function(msg,kind){const col=kind==="bad"?"#ff5d6c":"#4ff0b7",n=document.createElement("div");n.textContent=msg;
      n.style.cssText="position:fixed;right:18px;top:"+(w.LIVE?50:18)+"px;max-width:360px;background:#0c0c0f;color:"+col+";border:1px solid "+col+";border-radius:10px;padding:10px 14px;font:13px ui-monospace,Menlo,monospace;z-index:99998;white-space:pre-wrap;box-shadow:0 8px 30px rgba(0,0,0,.6)";
      (document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(n);setTimeout(()=>n.remove(),9000);beep(kind);
      if(document.hidden){document.title="🔔 "+msg.split("\n")[0];clearInterval(flash);flash=setInterval(()=>{if(!document.hidden){document.title=t0;clearInterval(flash)}},1000)}};
    const OS={},GS={};let first=true,busy=false;
    const nm=o=>{const m=/^([A-Z.]{1,6})\d{2}(\d{2})(\d{2})([CP])(\d{8})$/.exec(o||"");return m?m[1]+" "+(+m[5]/1000)+(m[4]==="C"?"C":"P")+" "+m[2]+"/"+m[3]:(o||"")};
    async function poll(){if(busy)return;busy=true;
      try{const [o,g]=await Promise.all([fetch("/api/orders",{cache:"no-store"}).then(r=>r.json()),fetch("/api/gestor",{cache:"no-store"}).then(r=>r.json())]);
        if(!o.error)for(const x of o.orders||[]){const was=OS[x.id];OS[x.id]=x.status;if(first||was===x.status)continue;
          const d=(x.legs||[]).map(l=>(l.side||"").replace(/_/g," ")+" "+nm(l.occ)).join(" / ");
          if(x.status==="filled")w.evAlert("✅ Orden llenada #"+x.id+"\n"+d+(x.price!=null?"\nprecio "+x.price.toFixed(2):""),"ok");
          else if(x.status==="rejected")w.evAlert("⛔ Orden RECHAZADA #"+x.id+"\n"+d,"bad")}
        if(!g.error)for(const it of g.items||[]){const was=GS[it.id];GS[it.id]=it.status;if(first||was===it.status)continue;
          if(it.status==="cerrada"){const p=it.pnl==null?"":" · P&L "+(it.pnl>=0?"+":"-")+"$"+Math.abs(it.pnl).toFixed(2);w.evAlert("🤖 Gestor cerró "+it.name+"\n"+(it.reason||"")+p,(it.pnl!=null&&it.pnl<0)?"bad":"ok")}}
        first=false}catch(e){}finally{busy=false}}
    setTimeout(poll,1500);setInterval(poll,5000);
  })();
  sync(true);setInterval(()=>sync(false),10000);
})();
</script>"""


# ───────────── pagina ─────────────
PAGE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Trading manual · LV Options Terminal</title>
<style>
:root{--bg:#000000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px -apple-system,BlinkMacSystemFont,sans-serif}
main{max-width:2000px;margin:0 auto;padding:16px 24px}
.mono{font-family:ui-monospace,Menlo,monospace}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 20px;margin-bottom:12px}
h1{margin:0;font-size:22px;color:var(--ok);letter-spacing:.04em}
a{color:var(--cy);text-decoration:none;font-weight:600}
.pill{border:1px solid var(--warn);color:var(--warn);border-radius:99px;padding:5px 12px;font-size:12px;font-weight:700;letter-spacing:.06em}
.note{background:rgba(255,192,77,.08);border:1px solid var(--warn);color:var(--warn);border-radius:10px;padding:10px 14px;font-size:13px;margin-bottom:12px}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--cy);border-radius:14px;padding:16px;margin-bottom:12px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bgrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start}.bcol{min-width:0}@media(max-width:1000px){.bgrid{grid-template-columns:1fr}.bgrid .bcol+.bcol{border-left:0!important;padding-left:0!important}}
@media(max-width:900px){.two{grid-template-columns:1fr}}
h2{font-size:13px;letter-spacing:.08em;color:var(--mut);margin:0 0 10px;font-weight:600}
.ctl{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:10px}
label{display:block;font-size:12px;color:var(--mut);margin-bottom:3px}
select,input{width:100%;background:#08080a;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px;font-size:14px;font-family:inherit}
table{width:100%;border-collapse:collapse;font-size:13px}
th{color:var(--mut);font-weight:600;text-align:right;padding:4px 6px;border-bottom:1px solid var(--line)}
td{text-align:right;padding:5px 6px;border-bottom:1px solid var(--line)}
th:first-child,td:first-child{text-align:left}
.buy{color:var(--ok)}.sell{color:var(--bad)}
.kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:12px 0}
.kv div{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:8px 10px}
.kv span{display:block;font-size:11px;color:var(--mut);letter-spacing:.06em}
.kv b{font-size:17px}
.ok{color:var(--ok)}.bad{color:var(--bad)}.warn{color:var(--warn)}
.btn{border:1px solid var(--cy);background:transparent;color:var(--cy);border-radius:8px;padding:9px 16px;font-size:14px;font-weight:700;cursor:pointer}
.btn:disabled{opacity:.35;cursor:not-allowed}.btn.go{border-color:var(--ok);color:var(--ok)}.btn.x{border-color:var(--bad);color:var(--bad);padding:3px 10px;font-size:12px}
.btn.sm{padding:4px 10px;font-size:12px}
.sw{display:flex;gap:4px;align-items:stretch}.sw input{flex:1;min-width:0}
.stp{flex:none;width:36px;border:1px solid var(--line);background:#08080a;color:var(--tx);border-radius:8px;font-size:18px;font-weight:700;cursor:pointer;line-height:1;padding:0;user-select:none;touch-action:manipulation}
.stp:hover{border-color:var(--cy);color:var(--cy)}.stp:active{background:#1c1c22}
input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{opacity:1}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:end}
#res{margin-top:10px;font-size:13px;white-space:pre-wrap}
svg{width:100%;height:230px;display:block}
details summary{cursor:pointer;color:var(--mut);font-weight:600;font-size:13px;letter-spacing:.08em}
.atm{background:rgba(92,200,255,.12)}#chain td{text-align:center}#chain td.oiv{color:var(--mut);font-size:12px}#chain td.itm{background:rgba(255,210,63,.10);color:#c8b98a}#chain td.em{box-shadow:inset 4px 0 0 #b48cff,inset -4px 0 0 #b48cff;background:rgba(180,140,255,.14)}#chain td.emedge{box-shadow:inset 4px 0 0 #b48cff,inset -4px 0 0 #b48cff,inset 0 2px 0 #b48cff;background:rgba(180,140,255,.14)}#chain tr.spotrow td{background:#ffd23f;color:#2a2000;font:700 13px ui-monospace,Menlo,monospace;text-align:center;padding:5px 0;letter-spacing:.06em}.gxb{display:inline-block;margin-left:4px;padding:0 4px;border-radius:4px;color:#06101e;font:800 10px ui-monospace,Menlo,monospace;vertical-align:1px}.pk{cursor:pointer}.pk:hover{background:rgba(92,200,255,.22)}
.chainbox{max-height:400px;overflow:auto}.chainbox thead th{position:sticky;top:0;background:var(--card)}
#chain td.hb{background:rgba(79,240,183,.22);font-weight:700}#chain td.hs{background:rgba(255,93,108,.22);font-weight:700}
.pbar{display:inline-block;position:relative;width:140px;height:8px;border-radius:4px;background:linear-gradient(90deg,rgba(255,93,108,.55),rgba(255,192,77,.35) 50%,rgba(79,240,183,.55));vertical-align:middle}
.pbar i{position:absolute;top:-3px;width:3px;height:14px;background:#fff;border-radius:2px;margin-left:-1px}
.pbl{display:flex;justify-content:space-between;width:140px;font-size:10px;color:#7d8aa5;margin-top:3px}
tr.pr-warn td{background:rgba(255,192,77,.10)}tr.pr-bad td{background:rgba(255,93,108,.16)}
.frow{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:5px 0;border-bottom:1px solid var(--line)}.fe{background:#111116;border:1px solid var(--line);color:var(--tx);border-radius:7px;padding:4px 9px;font:700 12px ui-monospace,Menlo,monospace;cursor:pointer;min-width:30px}.fe:hover{border-color:var(--cy)}.fbuy{color:var(--ok);border-color:rgba(79,240,183,.45);min-width:78px}.fsell{color:var(--bad);border-color:rgba(255,93,108,.5);min-width:78px}.fput{color:#ffb547;min-width:56px}.fcall{color:#7fd6ff;min-width:56px}.fx{color:var(--mut);margin-left:auto}.fx:hover{color:var(--bad);border-color:var(--bad)}.fadd{color:var(--cy);font-weight:600}.fq,.fk{display:inline-flex;align-items:center;gap:3px}.fq b{min-width:22px;text-align:center;font-size:14px}.fk select{width:auto;padding:3px 6px;font-size:13px;font-weight:700}</style></head><body><main>
<header>
 <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><h1 class="mono" id="h1t">SPY · TRADING MANUAL</h1><span class="pill" id="modepill">SANDBOX · PAPEL</span><button type="button" class="btn sm" id="osBtn" onclick="osToggle()" title="Prendido: el bid/ask de tus posiciones, órdenes y de las patas del constructor llega por streaming de Tradier (al instante y el mismo en todas las tablas). Solo cambia los precios que se muestran; las órdenes siguen igual. Apágalo si algo se ve raro.">⚡ Streaming de opciones: …</button>
  <span class="mono" id="spot" style="font-size:18px">SPY …</span></div>
 <div><span id="acct" class="mono" style="color:var(--mut);font-size:13px;margin-right:16px"></span><a href="/">← Inicio</a> &nbsp; <a href="/market">Market →</a> &nbsp; <a href="/portafolio">Portafolio →</a></div>
</header>
<div class="note" id="modenote">Cuenta de práctica (sandbox): las órdenes son de papel y los precios llevan unos 15 minutos de retraso. Sirve para practicar el flujo, no para decidir entradas en tiempo real. Toda orden pide vista previa antes de enviarse.</div>

<div id="apierr" class="note" style="display:none;border-color:var(--bad);color:var(--bad);background:rgba(255,93,108,.08)"></div>
<div class="card"><h2 style="display:flex;justify-content:space-between;align-items:center;gap:8px">POSICIONES <span class="grpbar"></span></h2><div class="kv" id="posum"></div>
 <div style="overflow-x:auto"><table><thead><tr><th>Estrategia</th><th>Exp. (DTE)</th><th>Cant.</th><th>Entrada</th><th>Cierre ahora</th><th>P&amp;L</th><th>Delta</th><th>Theta/día</th><th>Vega</th><th>Stop ◄ ahora ► Objetivo</th><th></th></tr></thead><tbody id="pos"><tr><td colspan="11">Cargando…</td></tr></tbody></table></div>
 <div class="mono" id="posnote" style="color:var(--mut);font-size:12px;margin-top:8px"></div></div>
<div class="card">
 <div class="bgrid">
  <div class="bcol">
  <h2>CONSTRUCTOR DE ESTRATEGIA · GANANCIA / PÉRDIDA</h2>
  <div id="custombar" class="note" style="display:none;border-color:var(--cy);color:var(--cy);background:rgba(92,200,255,.08)"><span id="customtxt"></span> <button class="btn sm" id="bexit" style="margin-left:10px">Salir del cierre</button></div>
  <div class="ctl">
   <div><label>Activo</label><input id="usym" list="usl" value="SPY" spellcheck="false" autocomplete="off" title="Símbolo o nombre de la empresa (SPY, QQQ, IWM, AAPL…)" style="text-transform:uppercase;font-weight:700"><datalist id="usl"></datalist></div>
   <div><label>Estrategia</label><select id="strat">
     <option value="ic">Iron Condor (crédito)</option>
     <option value="if">Iron Fly (crédito)</option>
     <option value="pcs">Put Credit Spread (alcista)</option>
     <option value="ccs">Call Credit Spread (bajista)</option>
     <option value="pds">Put Debit Spread (bajista)</option>
     <option value="cds">Call Debit Spread (alcista)</option>
     <option value="bfc">Mariposa de calls (débito)</option>
     <option value="bwp">Broken wing de puts (crédito, alcista)</option>
     <option value="free">🧩 Libre: toca la cadena (mariposas, ratios…)</option></select></div>
   <div><label>Acción</label><select id="mode"><option value="open">Abrir posición</option><option value="close">Cerrar posición</option></select></div>
   <div><label>Expiración</label><select id="exp"></select></div>
   <div><label>Contratos (máx 10)</label><div class="sw"><button type="button" class="stp" data-for="qty" data-d="-1" data-min="1" data-max="10" data-dec="0" title="Restar">−</button><input id="qty" type="number" min="1" max="10" step="1" value="1"><button type="button" class="stp" data-for="qty" data-d="1" data-min="1" data-max="10" data-dec="0" title="Sumar">+</button></div></div>
   <div><label>Ancho del spread ($)</label><select id="width"><option>1</option><option selected>2</option><option>3</option><option>5</option><option>10</option><option>15</option></select></div>
   <div id="minibox" style="display:none;grid-column:span 2;min-width:0;border:1px solid var(--line);border-radius:10px;padding:4px 6px;background:rgba(0,0,0,.5)">
    <svg id="minichart" viewBox="0 0 600 150" style="width:100%;height:auto;display:block"></svg></div>
  </div>
  <div class="ctl">
   <div id="g_ct"><label>Strike central (put y call vendidos)</label><select id="ct"></select></div>
   <div id="g_sp"><label>Put vendido (strike)</label><select id="sp"></select></div>
   <div id="g_sc"><label>Call vendido (strike)</label><select id="sc"></select></div>
   <div id="g_lp"><label>Put comprado (strike)</label><select id="lp"></select></div>
   <div id="g_lc"><label>Call comprado (strike)</label><select id="lc"></select></div>
  </div>
  <div id="freebox" style="display:none;border:1px dashed var(--cy);border-radius:10px;padding:8px 10px;margin:8px 0">
   <div style="font-size:13px;margin-bottom:4px">🧩 <b>Libre:</b> toca el <b>Bid</b> en la cadena para <b class="bad">vender</b> o el <b>Ask</b> para <b class="ok">comprar</b>, o agrega patas aquí. Cambia <b>compra/venta</b>, <b>cantidad</b>, <b>put/call</b> y <b>strike</b> con un clic. Hasta 4 patas, mismo vencimiento.</div>
   <div id="freechips"></div><div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:6px"><span class="tag" style="color:var(--mut);font-size:11px">ARMAR RÁPIDO:</span>
    <button type="button" class="btn sm" onclick="freePreset('bfc')" title="Compra 1 call abajo, vende 2 en el centro, compra 1 arriba (centro = strike más cercano, ancho = el del selector)">Mariposa calls</button>
    <button type="button" class="btn sm" onclick="freePreset('bfp')" title="Igual pero con puts">Mariposa puts</button>
    <button type="button" class="btn sm" onclick="freePreset('bwp')" title="Mariposa de puts con el ala de abajo al doble de ancho (sesgo alcista, cobra crédito o casi)">Broken wing puts</button>
    <button type="button" class="btn sm" onclick="freePreset('bwc')" title="Mariposa de calls con el ala de arriba al doble de ancho (sesgo bajista)">Broken wing calls</button>
    <button type="button" class="btn sm x" onclick="freeClear()">Limpiar todo</button></div></div>
  <table><thead><tr><th>Pata</th><th>Opción</th><th>Bid</th><th>Ask</th><th>Delta</th></tr></thead><tbody id="legs"></tbody></table>
  <div id="gbox" style="margin-top:12px;border:1px dashed var(--line);border-radius:10px;padding:8px 10px">
   <label style="display:flex;gap:8px;align-items:center;color:var(--tx);font-size:13px;margin:0"><input type="checkbox" id="g_on" style="width:auto"> 🤖 Que el gestor vigile esta posición y la cierre solo</label>
   <div class="mono" style="color:var(--mut);font-size:12px;margin:4px 0 2px">Montos en dólares POR CONTRATO: se multiplican por los contratos abiertos.</div>
   <div class="row" style="margin-top:6px">
    <div style="width:150px"><label>Stop: pérdida máx. ($/contrato)</label><input id="g_stop" type="number" step="5" min="1"></div>
    <div style="width:150px"><label>Objetivo: ganancia ($/contrato)</label><input id="g_tp" type="number" step="5" min="1"></div>
    <div style="width:230px"><label>Al llegar al objetivo…</label><select id="g_at"><option value="trail">Seguir dentro con trailing</option><option value="close">Cerrar y cobrar</option></select></div>
    <div style="width:170px" id="g_trw"><label>Trailing: devolver máx. ($/contrato)</label><input id="g_trl" type="number" step="5" min="1"></div>
    <div style="width:110px"><label>Cerrar a las (NY)</label><input id="g_hex" type="text" placeholder="15:30"></div>
   </div>
   <div class="mono" id="g_hint" style="color:var(--mut);font-size:12px;margin-top:6px"></div></div>
  <div class="row" style="margin-top:12px">
   <div style="width:210px"><label id="plabel">Precio límite</label><div class="sw"><button type="button" class="stp" data-for="price" data-d="-0.01" data-min="0.01" data-max="1000" data-dec="2" title="Restar">−</button><input id="price" type="number" step="0.01" min="0.01"><button type="button" class="stp" data-for="price" data-d="0.01" data-min="0.01" data-max="1000" data-dec="2" title="Sumar">+</button></div></div>
   <button class="btn sm" id="bmid">Mid</button><button class="btn sm" id="bnat">Natural</button><button class="btn sm" id="bmkt" title="Orden A MERCADO: se llena al precio que haya en ese momento (sin precio límite). Otra vez para volver a límite">⚡ Mercado</button>
   <button class="btn" id="bprev" style="margin-left:auto">Vista previa</button>
   <button class="btn go" id="bsend" disabled>Enviar orden</button>
  </div>
  <div id="res"></div>
  </div>
  <div class="bcol" style="border-left:1px solid var(--line);padding-left:16px">
   <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px"><label style="margin:0;font-size:12px;white-space:nowrap">👁 Ver en la gráfica:</label><select id="posview" style="flex:1" onchange="posView(this.value)"><option value="">La estrategia del constructor</option></select></div>
   <h2 id="ctitle">GANANCIA / PÉRDIDA AL VENCIMIENTO</h2>
   <svg id="chart" viewBox="0 0 600 230" preserveAspectRatio="none"></svg>
   <div class="kv" id="kv"></div>
   <div class="mono" style="color:var(--mut);font-size:12px" id="kvnote"></div>

  </div>
 </div>
</div>
<div class="card">
   <h2 style="display:flex;align-items:center;gap:8px">CADENA DE OPCIONES · toca un precio para usar ese strike <span style="margin-left:auto;font-size:12px;font-weight:400;color:var(--mut)">Vence</span><select id="exp2" title="Cambia el vencimiento de la cadena (es la misma lista que Expiración del constructor)" style="width:auto;padding:3px 6px;font-size:12px"></select><span style="font-size:12px;font-weight:400;color:var(--mut);margin-left:6px">Strikes</span><span id="nkbar"></span><button type="button" class="btn sm x" style="margin-right:40px" onclick="clearStrikes()" title="Borra los strikes y pasa a modo Libre para armar desde la cadena">🧹 Limpiar strikes</button></h2>
   <div class="mono" id="emline" style="font-size:12px;color:var(--mut);margin:-4px 0 8px">Calls a la izquierda · puts a la derecha · sombreado = dentro del dinero (ITM)</div>
   <div class="mono" id="gexline" style="font-size:12px;color:var(--mut);margin:-4px 0 8px"></div>
   <div class="chainbox" style="max-height:none"><table><thead><tr><th style="text-align:center" title="Open interest: contratos abiertos (dato del cierre de ayer)">Call OI</th><th style="text-align:center" title="Volumen de hoy">Call Vol</th><th style="text-align:center">Call Δ</th><th style="text-align:center">Call Bid</th><th style="text-align:center">Call Ask</th><th style="text-align:center">Strike</th><th style="text-align:center">Put Ask</th><th style="text-align:center">Put Bid</th><th style="text-align:center">Put Δ</th><th style="text-align:center" title="Volumen de hoy">Put Vol</th><th style="text-align:center" title="Open interest: contratos abiertos (dato del cierre de ayer)">Put OI</th><th style="text-align:center" title="GEX neta de ESTE vencimiento en ese strike (gamma × open interest × 100 × precio² × 1%). Verde = domina gamma de calls (los dealers frenan el precio); rojo = domina gamma de puts (lo aceleran)">GEX</th></tr></thead><tbody id="chain"><tr><td colspan="12" style="color:#7d8aa5">Esperando datos…</td></tr></tbody></table></div>
  </div>
<div class="card"><h2 style="display:flex;align-items:center;gap:8px">ÓRDENES <button type="button" class="btn sm x" id="bcanall" style="display:none;margin-left:auto;margin-right:40px" onclick="cancelAll()">Cancelar todas</button></h2><div style="overflow-x:auto"><table><thead><tr><th>Id</th><th>Enviada</th><th>Orden</th><th>Estado</th><th>Tipo · precio</th><th title="Precio medio de la combinación en este momento (se actualiza cada 3 s)">Ahora</th><th>Llenada a</th><th>Cant.</th><th style="text-align:left">Patas <span style="font-weight:400;font-size:11px;color:var(--mut)">(+ compra · − venta · <sup>c</sup> cierre)</span></th><th></th></tr></thead><tbody id="orders"><tr><td colspan="11">Cargando…</td></tr></tbody></table></div></div>
 <div class="card"><h2>🤖 GESTOR AUTOMÁTICO <span id="gs" style="margin-left:6px"></span></h2>
  <div class="mono" style="color:var(--mut);font-size:12px;margin-bottom:8px">Vigila tus posiciones con el panel abierto en tu Mac y las cierra con tus reglas: el objetivo con orden límite a tu precio; stop, hora y trailing a mercado. Si apagas la Mac o cierras el panel, NO hay stop.</div>
  <div id="glist"></div>
  <details style="margin-top:8px"><summary>Reglas por defecto (en dólares por contrato)</summary>
   <div class="row" style="margin-top:8px;align-items:start">
    <div style="flex:1;min-width:250px"><b style="font-size:13px">Estrategias de CRÉDITO</b>
     <div class="ctl" style="margin-top:6px"><div><label>Stop: pérdida máx. ($/contrato)</label><input id="d_cr_stop" type="number" min="1"></div><div><label>Objetivo: ganancia ($/contrato)</label><input id="d_cr_tp" type="number" min="1"></div>
      <div><label>Al llegar al objetivo…</label><select id="d_cr_at"><option value="trail">Seguir con trailing</option><option value="close">Cerrar y cobrar</option></select></div><div><label>Trailing: devolver máx. ($/contrato)</label><input id="d_cr_trl" type="number" min="1"></div>
      <div><label>Cerrar a las (NY, si vence hoy)</label><input id="d_cr_hex" type="text"></div></div>
     <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="d_cr_auto" style="width:auto"> Vigilar cada orden nueva</label></div>
    <div style="flex:1;min-width:250px"><b style="font-size:13px">Estrategias de DÉBITO</b>
     <div class="ctl" style="margin-top:6px"><div><label>Stop: pérdida máx. ($/contrato)</label><input id="d_db_stop" type="number" min="1"></div><div><label>Objetivo: ganancia ($/contrato)</label><input id="d_db_tp" type="number" min="1"></div>
      <div><label>Al llegar al objetivo…</label><select id="d_db_at"><option value="trail">Seguir con trailing</option><option value="close">Cerrar y cobrar</option></select></div><div><label>Trailing: devolver máx. ($/contrato)</label><input id="d_db_trl" type="number" min="1"></div>
      <div><label>Cerrar a las (NY, si vence hoy)</label><input id="d_db_hex" type="text"></div></div>
     <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="d_db_auto" style="width:auto"> Vigilar cada orden nueva</label></div>
   </div>
   <div class="row" style="margin-top:8px"><button class="btn sm go" onclick="gSaveDef()">Guardar reglas</button><button class="btn sm" id="g_pause" onclick="gPause()">Pausar todo</button><span class="mono" id="g_dmsg" style="font-size:12px"></span></div>
  </details></div>


<div class="mono" style="color:var(--mut);font-size:12px" id="foot"></div>
</main>
<script>
/* botones − / + con repeticion al mantener presionado */
(function(){let t=null,iv=null;
  const go=b=>{const e=document.getElementById(b.dataset.for);if(!e)return;const d=+b.dataset.d,mn=+b.dataset.min,mx=+b.dataset.max,dec=+b.dataset.dec||0;
    let v=Math.round(((+e.value||0)+d)*1e4)/1e4;v=Math.min(mx,Math.max(mn,v));e.value=dec?v.toFixed(dec):String(Math.round(v));
    e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new Event("change",{bubbles:true}))};
  const stop=()=>{clearTimeout(t);clearInterval(iv);t=iv=null};
  document.addEventListener("pointerdown",e=>{const b=e.target.closest(".stp");if(!b)return;e.preventDefault();stop();go(b);t=setTimeout(()=>{iv=setInterval(()=>go(b),90)},450)});
  ["pointerup","pointercancel","blur"].forEach(x=>window.addEventListener(x,stop));
  document.addEventListener("pointerleave",stop,true)})();
const $=id=>document.getElementById(id);
const num=v=>(v===null||v===undefined||v===""||isNaN(+v))?null:+v;
const money=(v,d=2)=>(v<0?"-$":"$")+Math.abs(v).toFixed(d);
const f2=v=>v===null?"–":(+v).toFixed(2);
const STR={
 free:{type:"credit",inputs:[]},bfc:{type:"debit",inputs:[]},bwp:{type:"credit",inputs:[]},ic:{type:"credit",inputs:["sp","sc"]},if:{type:"credit",inputs:["ct"]},pcs:{type:"credit",inputs:["sp"]},ccs:{type:"credit",inputs:["sc"]},
 pds:{type:"debit",inputs:["lp"]},cds:{type:"debit",inputs:["lc"]}};
let SYM="SPY";try{const v=localStorage.getItem("tsym");if(v&&/^[A-Z][A-Z.\-]{0,5}$/.test(v))SYM=v}catch(e){}
let S={spot:null,by:{C:{},P:{}},strikes:[],lastKey:null,dirty:false,legsEff:null,custom:null};
let G=[];
async function api(path,body){
  const o=body?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}:{cache:"no-store"};
  const r=await fetch(path,o);const j=await r.json();
  if(!body){const e=$("apierr");if(j&&j.error&&/Tradier está fallando/.test(j.error))setErr("⚠️ "+j.error);else if(j&&!j.error&&e&&/Tradier está fallando|Tradier 50/.test(e.textContent))setErr("")}   // aviso de falla de Tradier: se borra solo
  return j;
}
function pretty(occ){const m=/^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d{8})$/.exec(occ||"");
  if(!m)return occ||"";return m[1]+" "+m[3]+"/"+m[4]+"/"+m[2]+" "+(+m[6]/1000)+" "+(m[5]==="C"?"Call":"Put")}
function nearest(x){let b=null,bd=1e9;for(const k of S.strikes){const d=Math.abs(k-x);if(d<bd){bd=d;b=k}}return b}
function pickDelta(t,target){let best=null,bd=9;
  for(const k of S.strikes){const r=S.by[t][k];if(!r)continue;const d=num(r.delta);if(d===null)continue;
    if(!(t==="P"?k<S.spot:k>S.spot))continue;const df=Math.abs(Math.abs(d)-target);if(df<bd){bd=df;best=k}}
  return best!==null?best:nearest(S.spot+(t==="P"?-5:5))}

async function loadExps(){
  const j=await api("/api/expirations?sym="+encodeURIComponent(SYM));if(j.error){setErr(j.error);return}setErr("");
  const sel=$("exp"),cur=sel.value;sel.innerHTML="";EXPI={am:new Set(j.am||[]),amRoot:j.am_root,pmRoot:j.pm_root};
  const DW=["dom","lun","mar","mié","jue","vie","sáb"],et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  const t0=new Date(et.getFullYear(),et.getMonth(),et.getDate());
  for(const d of j.dates){const dd=new Date(d+"T00:00:00"),n=Math.round((dd-t0)/86400000);
    const base=d+" "+DW[dd.getDay()]+"  ·  "+(n<=0?"0DTE":n+" d");
    const add=(v,t)=>{const o=document.createElement("option");o.value=v;o.textContent=t;sel.appendChild(o)};
    if(EXPI.am.has(d)){add(d,base+"  ·  PM ("+EXPI.pmRoot+")");add(d+"|AM",base+"  ·  ★ AM MENSUAL ("+EXPI.amRoot+", se liquida a la APERTURA)")}
    else add(d,base)}
  if(cur&&[...sel.options].some(o=>o.value===cur))sel.value=cur;
  if(sel.value)await loadChain();
}
let PVT=0;
async function pvRefresh(){const c=S.custom;if(!c||!c.exp||Date.now()-PVT<4000)return;PVT=Date.now();
  const [ed,eam]=c.exp.split("|");let j;try{j=await api("/api/chain?exp="+encodeURIComponent(ed)+"&sym="+encodeURIComponent(SYM)+(eam?"&root=am":""))}catch(e){return}
  if(j.error||S.custom!==c)return;const by={C:{},P:{}};for(const o of j.options)by[o.type][o.strike]=o;c.by=by;recompute()}
/* copia de la lista de Expiración arriba de la cadena: las dos siempre iguales */
function expSync(){const a=$("exp"),b=$("exp2");if(!a||!b)return;
  const sig=[...a.options].map(o=>o.value).join(",");if(b._sig!==sig){b.innerHTML=a.innerHTML;b._sig=sig}
  if(b.value!==a.value)b.value=a.value}
let OSON=false;
async function osLoad(){try{const j=await api("/api/opt_stream");OSON=!!j.on;const b=$("osBtn");if(!b)return;
  b.textContent="⚡ Streaming de opciones: "+(OSON?"PRENDIDO"+(j.stream?"":" (esperando conexión · solo cuenta REAL y en horario)"):"APAGADO");
  b.style.borderColor=OSON?"var(--ok)":"";b.style.color=OSON?"var(--ok)":""}catch(e){}}
async function osToggle(){try{const r=await fetch("/api/opt_stream",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({on:!OSON})});await r.json()}catch(e){}
  await osLoad();try{loadPos();loadOrders();loadChain()}catch(e){}}
osLoad();setInterval(()=>{if(!document.hidden)osLoad()},15000);
let CHSEQ=0,CHBUSY=0,SWK="",SWT=0;
function swant(occs){const k=occs.slice().sort().join(",");if(!k)return;const now=Date.now();if(k===SWK&&now-SWT<10000)return;SWK=k;SWT=now;
  fetch("/api/stream_want?syms="+encodeURIComponent(k),{cache:"no-store"}).catch(()=>{})}   // patas del constructor: por streaming
setInterval(()=>{if(SWK&&!document.hidden&&Date.now()-SWT>=10000){SWT=Date.now();fetch("/api/stream_want?syms="+encodeURIComponent(SWK),{cache:"no-store"}).catch(()=>{})}},5000);
async function loadChain(auto){expSync();
  if(auto&&CHBUSY&&Date.now()-CHBUSY<20000)return;   // la anterior sigue en camino (Tradier lento): no amontonar consultas
  const my=++CHSEQ;CHBUSY=Date.now();const sym0=SYM;
  const [ed,eam]=$("exp").value.split("|");
  let j;try{j=await api("/api/chain?exp="+encodeURIComponent(ed)+"&sym="+encodeURIComponent(SYM)+(eam?"&root=am":""));}finally{if(my===CHSEQ)CHBUSY=0}
  if(my!==CHSEQ)return;   // llego tarde: ya hay una consulta mas nueva (evita que el precio brinque entre dato viejo y nuevo)
  if(sym0!==SYM)return;
  if(j.error){if(S.strikes.length&&S.spot){setErr("La cadena tardó en actualizar ("+String(j.error).slice(0,90)+"); se muestra la última");return}
    setErr(j.error);$("chain")._h=null;$("chain").innerHTML='<tr><td colspan="12" class="warn">Sin datos de la cadena: '+j.error+'</td></tr>';return}
  setErr("");S.spot=j.spot;S.by={C:{},P:{}};const set=new Set();
  for(const o of j.options){S.by[o.type][o.strike]=o;set.add(o.strike)}
  S.strikes=[...set].sort((a,b)=>a-b);
  if(S.custom&&S.custom.exp){if(S.custom.exp===$("exp").value)S.custom.by=S.by;else pvRefresh()}   // el visor usa SIEMPRE el vencimiento de tu posicion
  fitWidths();fillSelects();renderChain();recompute();
  if(!GEX||GEX.sym!==gexSym(SYM))gexLoad();
}
/* ---------- niveles de gamma (GEX): call wall, put wall y gamma flip, de TODAS las cadenas hasta 45 dias (o solo la de hoy) ---------- */
let GEX=null,GEXH=0,GEXON=true,gexT=null;
try{const v=localStorage.getItem("gexh");if(v!==null)GEXH=+v;GEXON=localStorage.getItem("gexon")!=="0"}catch(e){}
window.onPrefsChanged=ch=>{if(ch.includes("gexh")||ch.includes("gexon")){try{const v=localStorage.getItem("gexh");if(v!==null)GEXH=+v;GEXON=localStorage.getItem("gexon")!=="0"}catch(e){}GEX=null;gexLoad()}};
function gexSym(s){return (s==="/SPX"||s==="SPXW")?"SPX":s}
function gfmt(v){return v>=1e9?(v/1e9).toFixed(1)+"B":v>=1e6?(v/1e6).toFixed(v>=1e8?0:1)+"M":v>=1e3?Math.round(v/1e3)+"k":String(Math.round(v))}
async function gexLoad(){clearTimeout(gexT);const sym=gexSym(SYM);if(!sym||sym[0]==="/"){GEX=null;gexPaint();return}
  if(!GEX||GEX.sym!==sym)GEX={loading:true,sym};gexPaint();
  let j;try{j=await api("/api/gex?sym="+encodeURIComponent(sym)+"&h="+GEXH)}catch(e){j={error:String(e)}}
  if(gexSym(SYM)!==sym)return;
  j.sym=j.sym||sym;GEX=j;gexPaint();renderChain();if(window.LASTC)drawChart(window.LASTC);
  gexT=setTimeout(gexLoad,(j.loading||j.updating)?5000:60000)}
function gexSet(h){if(h==="off"){GEXON=!GEXON}else{GEXH=+h;GEX=null}try{localStorage.setItem("gexh",String(GEXH));localStorage.setItem("gexon",GEXON?"1":"0")}catch(e){}
  if(h==="off"){gexPaint();renderChain();if(window.LASTC)drawChart(window.LASTC)}else gexLoad()}
function gexPaint(){const el=$("gexline");if(!el)return;
  const b=(v,t)=>'<button type="button" class="btn sm" style="padding:1px 7px;margin-left:3px;'+(v==="off"?(GEXON?"":"background:var(--cy);color:#06101e"):(GEXH===+v&&GEXON?"background:var(--cy);color:#06101e":""))+'" onclick="gexSet(\''+v+'\')">'+t+'</button>';
  const btns=b("0","Solo hoy")+b("7","7 días")+b("45","45 días")+b("off",GEXON?"Ocultar":"Oculto");
  const G=GEX,info=' <span title="GEX = gamma × open interest × 100 × precio² × 1%. Calls suman y puts restan (se supone que los dealers están al revés del público). Strike clave (⭐) = el de más gamma en total, calls + puts (donde más cobertura hay; el precio tiende a pegarse ahí). Call wall = strike con más gamma de calls; put wall = el de más gamma de puts; gamma flip = precio donde la GEX total cambia de signo: arriba suele moverse más calmado, abajo más brusco. El open interest solo se actualiza una vez al día. Es una guía, no una señal.">ⓘ</span>';
  if(!G||!GEXON){el.innerHTML='🧲 Niveles de gamma'+(GEXON?'':' ocultos')+btns+info;return}
  if(G.loading){el.innerHTML='🧲 Calculando niveles de gamma de '+G.sym+'… (lee las cadenas de cada vencimiento; tarda unos segundos)'+btns;return}
  if(G.error){el.innerHTML='🧲 Gamma: <span class="warn">'+G.error+'</span>'+btns;return}
  const pos=G.net>=0;
  el.innerHTML='🧲 <b style="color:var(--tx)">GAMMA '+G.sym+'</b> ('+(G.h?G.exps+' vencimientos hasta '+(G.last||"").slice(5):"solo "+(G.first||"").slice(5))+' · '+G.hora+(G.updating?' · actualizando…':'')+'): '
    +'<b style="color:#ffd23f">⭐ Strike clave '+(G.key||"–")+'</b> · <b style="color:#4ff0b7">Call wall '+G.call_wall+'</b> · <b style="color:#ff5d6c">Put wall '+G.put_wall+'</b> · <b style="color:#ffa726">Gamma flip '+(G.flip?Math.round(G.flip):"–")+'</b> · GEX total <b style="color:'+(pos?"#4ff0b7":"#ff5d6c")+'">'+(pos?"+":"−")+"$"+gfmt(Math.abs(G.net))+'</b> → '+(pos?'positiva (suele moverse más calmado)':'negativa (movimientos más bruscos)')+btns+info}
/* el ancho del spread tiene que ser multiplo de la separacion real entre strikes (SPY: 1; otros activos: 0.5, 2.5, 5...) */
function fitWidths(){
  const near=S.strikes.filter(k=>S.spot&&Math.abs(k-S.spot)<=S.spot*0.08);let step=0;
  for(let i=1;i<near.length;i++){const d=Math.round((near[i]-near[i-1])*1000)/1000;if(d>0&&(!step||d<step))step=d}
  if(!step)return;const sel=$("width"),cur=sel.value;
  let opts=step===1?[1,2,3,5,10,15]:[1,2,3,4,6,8].map(m=>Math.round(m*step*100)/100);
  sel.innerHTML=opts.map(w=>"<option>"+w+"</option>").join("");
  sel.value=opts.map(String).includes(cur)?cur:String(step===1?2:opts[1])}
function fillSelects(){
  for(const id of ["sp","sc","lp","lc","ct"]){
    const sel=$(id),t=(id==="sp"||id==="lp")?"P":"C",cur=sel.value;sel.innerHTML="";
    let mk=false;const sp=S.spot,sep=()=>{const o=document.createElement("option");o.disabled=true;
      o.textContent="━━━━ ▶ "+SYM+" AHORA "+sp.toFixed(2)+" ◀ ━━━━";sel.appendChild(o);mk=true};
    for(const k of S.strikes){const r=S.by[t][k];if(!r)continue;
      if(!mk&&sp&&k>sp)sep();
      const d=sp?k-sp:null,itm=sp&&(t==="C"?k<sp:k>sp);
      const o=document.createElement("option");o.value=k;
      o.textContent=k+"  ·  Δ "+(num(r.delta)===null?"–":r.delta.toFixed(2))
        +(d===null?"":"  ·  "+(d>=0?"+":"−")+Math.abs(d).toFixed(d%1?1:0)+" ("+(d>=0?"+":"−")+Math.abs(100*d/sp).toFixed(1)+"%)")+(itm?"  · ITM":"");
      sel.appendChild(o)}
    if(!mk&&sp)sep();
    if(cur&&S.by[t][cur]!==undefined)sel.value=cur;
    else{const d=id==="sp"?pickDelta("P",0.16):id==="sc"?pickDelta("C",0.16):nearest(S.spot);if(d!==null)sel.value=d}
  }
}
function buildLegs(){
  if(S.custom){const BY=S.custom.by||S.by,out=[];for(const c of S.custom.legs){const r=BY[c.t][c.k];
    if(!r)return{error:"El strike "+c.k+" no está en la cadena cargada (rango de ±40 del precio)."};out.push({row:r,t:c.t,k:c.k,act:c.act,ratio:c.ratio||1})}return{legs:out}}
  const st=$("strat").value,W=+$("width").value,v=id=>+$(id).value;let L;
  if(st==="free"){if(!S.free.length)return{error:"Toca en la cadena el Bid (vender) o el Ask (comprar) de cada pata, o usa un botón de mariposa."};
    const out=[];let net=0;for(const f of S.free){const r=S.by[f.t][f.k];if(!r)return{error:"El strike "+f.k+" ya no está en la cadena."};
      const b=num(r.bid),a=num(r.ask);net+=(f.act==="sell"?1:-1)*f.ratio*(((b||0)+(a||0))/2);out.push({row:r,t:f.t,k:f.k,act:f.act,ratio:f.ratio})}
    S.freeType=net>=0?"credit":"debit";return{legs:out}}
  if(st==="ic")L=[["P",v("sp")-W,"buy"],["P",v("sp"),"sell"],["C",v("sc"),"sell"],["C",v("sc")+W,"buy"]];
  else if(st==="if")L=[["P",v("ct")-W,"buy"],["P",v("ct"),"sell"],["C",v("ct"),"sell"],["C",v("ct")+W,"buy"]];
  else if(st==="pcs")L=[["P",v("sp"),"sell"],["P",v("sp")-W,"buy"]];
  else if(st==="ccs")L=[["C",v("sc"),"sell"],["C",v("sc")+W,"buy"]];
  else if(st==="pds")L=[["P",v("lp"),"buy"],["P",v("lp")-W,"sell"]];
  else L=[["C",v("lc"),"buy"],["C",v("lc")+W,"sell"]];
  const out=[];
  for(const [t,k,a] of L){const r=S.by[t][k];if(!r)return{error:"No existe el strike "+k+" ("+(t==="C"?"Call":"Put")+") en esta expiración. Cambia el ancho o el strike."};out.push({row:r,t,k,act:a})}
  return{legs:out};
}
function payoffAt(legs,P,typeOpen,S0){ // P y tipo de la orden de APERTURA
  let v=(typeOpen==="credit"?P:-P);
  for(const l of legs){const intr=l.t==="C"?Math.max(S0-l.k,0):Math.max(l.k-S0,0);v+=(l.act==="buy"?1:-1)*intr*(l.ratio||1)}
  return v;
}
function cdf(z){const t=1/(1+0.2316419*Math.abs(z)),d=0.3989423*Math.exp(-z*z/2);
  const p=d*t*(0.3193815+t*(-0.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));return z>0?1-p:p}
function yearsToExp(){
  const [ex,eam]=((S.custom&&S.custom.exp)||$("exp").value).split("|");if(!ex)return null;
  const et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  const d0=new Date(et.getFullYear(),et.getMonth(),et.getDate()),de=new Date(ex+"T00:00:00");
  const days=Math.round((de-d0)/86400000),minsNow=et.getHours()*60+et.getMinutes();
  return Math.max(days*1440+((eam?570:960)-minsNow),5)/525600;   // AM: vence a la apertura (9:30)
}
function probProfit(eff,P,typeEff){
  const T=yearsToExp();const ivs=eff.map(l=>num(l.row.iv)).filter(x=>x!==null&&x>0);
  if(!T||!ivs.length||!S.spot)return null;
  const sd=(ivs.reduce((a,b)=>a+b,0)/ivs.length)*Math.sqrt(T);
  const F=x=>cdf((Math.log(x/S.spot)+sd*sd/2)/sd);
  const ks=[...new Set(eff.map(l=>l.k))].sort((a,b)=>a-b),pts=[0.01,...ks,ks[ks.length-1]*3];
  const pn=pts.map(s=>payoffAt(eff,P,typeEff,s));let pr=0;
  for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],pa=pn[i],pb=pn[i+1];
    if(pa>0&&pb>0)pr+=F(b)-F(a);
    else if(pa>0&&pb<=0)pr+=F(a+(b-a)*pa/(pa-pb))-F(a);
    else if(pa<=0&&pb>0)pr+=F(b)-F(a+(b-a)*(-pa)/(pb-pa))}
  return Math.max(0,Math.min(1,pr));
}
function applyVis(){
  const fr=!S.custom&&$("strat").value==="free",fb=$("freebox");if(fb){fb.style.display=fr?"":"none";if(fr)freeChips()}
  if(fr&&$("mode").value!=="open")$("mode").value="open";
  const ins=S.custom?[]:STR[$("strat").value].inputs;
  for(const id of ["sp","sc","lp","lc","ct"])$("g_"+id).style.display=ins.includes(id)?"":"none";
}
function curType(){return S.custom?S.custom.openType:$("strat").value==="free"?(S.freeType||"debit"):STR[$("strat").value].type}
S.free=[];S.freeType="debit";
function freeAdd(t,k,act){freeSnap();S.custom=null;$("mode").value="open";const f=S.free.find(x=>x.t===t&&x.k===k);
  if(f){if(f.act===act)f.ratio=Math.min(10,f.ratio+1);else{f.ratio--;if(f.ratio<=0)S.free=S.free.filter(x=>x!==f)}}
  else{if(S.free.length>=4){notify("Máximo 4 patas");return}S.free.push({t,k,act,ratio:1})}
  S.free.sort((a,b)=>a.t===b.t?a.k-b.k:(a.t==="P"?-1:1));S.dirty=false;recompute()}
/* editor de patas del modo Libre: cada pata en su renglón, se cambia todo con un clic, con deshacer */
function freeSnap(){S.fh=S.fh||[];S.fh.push(JSON.stringify(S.free));if(S.fh.length>40)S.fh.shift()}
function freeAfter(){S.free.sort((a,b)=>a.t===b.t?a.k-b.k:(a.t==="P"?-1:1));S.custom=null;$("mode").value="open";S.dirty=false;S.lastKey=null;gBoxShow();recompute()}
function freeUndo(){if(!S.fh||!S.fh.length){notify("No hay nada que deshacer");return}S.free=JSON.parse(S.fh.pop());freeAfter()}
function freeClear(){if(!S.free.length)return;freeSnap();S.free=[];freeAfter()}
function freeDel(i){freeSnap();S.free.splice(i,1);freeAfter()}
function freeAct(i){const f=S.free[i];if(!f)return;freeSnap();f.act=f.act==="buy"?"sell":"buy";freeAfter()}
function freeQty(i,d){const f=S.free[i];if(!f)return;const n=Math.max(1,Math.min(10,f.ratio+d));if(n===f.ratio)return;freeSnap();f.ratio=n;freeAfter()}
function freeType(i){const f=S.free[i];if(!f)return;const t=f.t==="P"?"C":"P";
  if(!S.by[t][f.k]){notify("No hay "+(t==="C"?"call":"put")+" en el strike "+f.k);return}
  if(S.free.some((x,j)=>j!==i&&x.t===t&&x.k===f.k)){notify("Ese strike ya lo usa otra pata");return}freeSnap();f.t=t;freeAfter()}
function freeStrike(i,k){const f=S.free[i];k=+k;if(!f||k===f.k)return;
  if(S.free.some((x,j)=>j!==i&&x.t===f.t&&x.k===k)){notify("Ese strike ya lo usa otra pata");freeChips(true);return}freeSnap();f.k=k;freeAfter()}
function freeNew(t){if(S.free.length>=4){notify("Máximo 4 patas");return}if(!S.strikes.length){notify("Espera a que cargue la cadena");return}
  const ks=S.strikes.filter(k=>S.by[t][k]).sort((a,b)=>Math.abs(a-S.spot)-Math.abs(b-S.spot)),k=ks.find(k=>!S.free.some(x=>x.t===t&&x.k===k));
  if(k==null){notify("No hay strikes libres");return}freeSnap();S.free.push({t,k,act:"sell",ratio:1});freeAfter()}
function freeCheck(){if(!S.free.length)return"";const L=S.free;
  if(L.length<2)return'<span style="color:var(--mut)">Agrega al menos 2 patas.</span>';
  for(const t of["P","C"]){const sv=L.filter(x=>x.t===t&&x.act==="sell").reduce((a,x)=>a+x.ratio,0),bu=L.filter(x=>x.t===t&&x.act==="buy").reduce((a,x)=>a+x.ratio,0);
    if(sv>bu)return'<span class="warn">⚠ Tienes '+sv+' '+(t==="P"?"put":"call")+(sv>1?"s":"")+' vendido'+(sv>1?"s":"")+' y solo '+bu+' comprado'+(bu===1?"":"s")+': cada venta debe estar cubierta por una compra del mismo tipo (riesgo definido).</span>'}
  return'<span class="ok">✓ Riesgo definido · se puede enviar</span>'}
function freeChips(force){const e=$("freechips");if(!e)return;
  const key=JSON.stringify(S.free)+"|"+S.strikes.length;if(!force&&e._k===key)return;
  if(!force&&e.contains(document.activeElement)&&document.activeElement.tagName==="SELECT")return;   // no cerrar la lista si la tienes abierta
  e._k=key;
  const B=(on,txt,tip,c)=>'<button type="button" class="fe'+(c?" "+c:"")+'" title="'+tip+'" onclick="'+on+'">'+txt+'</button>';
  const rows=S.free.map((f,i)=>{const ks=S.strikes.filter(k=>S.by[f.t][k]),near=ks.filter(k=>Math.abs(k-f.k)<=40||k===f.k);
    return'<div class="frow">'
     +B("freeAct("+i+")",f.act==="buy"?"COMPRA":"VENTA","Cambiar entre comprar y vender",f.act==="buy"?"fbuy":"fsell")
     +'<span class="fq">'+B("freeQty("+i+",-1)","−","Uno menos")+'<b class="mono">'+f.ratio+'</b>'+B("freeQty("+i+",1)","+","Uno más")+'</span>'
     +B("freeType("+i+")",f.t==="P"?"PUT":"CALL","Cambiar entre put y call",f.t==="P"?"fput":"fcall")
     +'<span class="fk">'+B("freeMove("+i+",-1)","◀","Strike anterior")+'<select class="mono" onchange="freeStrike('+i+',this.value)" title="Escoge el strike">'+near.map(k=>'<option value="'+k+'"'+(k===f.k?" selected":"")+'>'+k+'</option>').join("")+'</select>'+B("freeMove("+i+",1)","▶","Strike siguiente")+'</span>'
     +B("freeDel("+i+")","✕","Quitar esta pata","fx")+'</div>'}).join("");
  e.innerHTML=(rows||'<div style="color:var(--mut);padding:4px 0">Sin patas todavía: toca Bid/Ask en la cadena, usa <b>＋ Put</b> / <b>＋ Call</b> o un botón de abajo.</div>')
   +'<div class="frow" style="border:0;padding-top:6px">'+B("freeNew('P')","＋ Put","Agrega un put cerca del precio (vendido; con un clic lo cambias a compra)","fadd")+B("freeNew('C')","＋ Call","Agrega un call cerca del precio (vendido; con un clic lo cambias a compra)","fadd")
   +B("freeUndo()","↶ Deshacer","Regresa al paso anterior","fadd")+'<span style="margin-left:auto;font-size:12px">'+freeCheck()+'</span></div>'}
/* ◀ ▶ en cada ficha: mueve esa pata al strike anterior/siguiente que exista en la cadena (no se brinca otra pata) */
function freeMove(i,d){const f=S.free[i];if(!f)return;const ks=S.strikes.filter(k=>S.by[f.t][k]);let p=ks.indexOf(f.k);
  p+=d;if(p<0||p>=ks.length){notify("No hay más strikes en la cadena cargada");return}
  const k=ks[p];if(S.free.some((x,j)=>j!==i&&x.t===f.t&&x.k===k)){notify("Ese strike ya lo usa otra pata");return}
  freeSnap();f.k=k;
  S.free.sort((a,b)=>a.t===b.t?a.k-b.k:(a.t==="P"?-1:1));S.dirty=false;S.lastKey=null;recompute()}
function freePreset(kind){const W=+$("width").value,c=nearest(S.spot),t=(kind==="bfc"||kind==="bwc")?"C":"P",bw=kind[0]==="b"&&kind[1]==="w";
  let lo=c-W,hi=c+W;if(bw&&t==="P")lo=c-2*W;if(bw&&t==="C")hi=c+2*W;
  const ks=[lo,c,hi].map(x=>S.strikes.reduce((a,b)=>Math.abs(b-x)<Math.abs(a-x)?b:a));
  if(new Set(ks).size<3||!ks.every(k=>S.by[t][k])){notify("No hay strikes para esa mariposa con ese ancho");return}
  $("strat").value="free";S.custom=null;$("mode").value="open";freeSnap();
  S.free=[{t,k:ks[0],act:"buy",ratio:1},{t,k:ks[1],act:"sell",ratio:2},{t,k:ks[2],act:"buy",ratio:1}];S.dirty=false;gFill();gBoxShow();recompute()}
function sameSet(a,b){return a.length===b.length&&[...a].sort().join()===[...b].sort().join()}
function recompute(){
  applyVis();
  $("custombar").style.display=S.custom?"":"none";
  if(S.custom)$("customtxt").textContent=(S.custom.view?"👁 Viendo: ":"Cerrando: ")+S.custom.name+" · entrada "+(S.custom.openType==="credit"?"crédito ":"débito ")+Math.abs(S.custom.entry).toFixed(2);
  if(!S.strikes.length)return;
  const close=$("mode").value==="close",otype=curType();
  const qty=Math.max(1,Math.min(10,Math.floor(+$("qty").value)||1));
  const B=buildLegs(),tb=$("legs");
  if(B.error){tb.innerHTML='<tr><td colspan="5" class="warn">'+B.error+'</td></tr>';$("bprev").disabled=true;$("bsend").disabled=true;S.legsEff=null;
    $("chart").innerHTML="";$("minichart").innerHTML="";$("kv").innerHTML="";renderChain();return}   // sin patas: no dejar la grafica vieja
  $("bprev").disabled=false;
  let typeEff=close?(otype==="credit"?"debit":"credit"):otype;
  const open=B.legs;   // acciones de APERTURA
  const eff=open.map(l=>({...l,act:close?(l.act==="buy"?"sell":"buy"):l.act}));
  S.legsEff=eff;renderChain();swant(eff.map(l=>l.row&&l.row.occ).filter(Boolean));
  let natS=0,midS=0,html="";
  for(const l of eff){
    const bid=num(l.row.bid),ask=num(l.row.ask),mid=(bid===null||ask===null)?null:(bid+ask)/2;
    const sgn=l.act==="sell"?1:-1;
    const rt=l.ratio||1;natS+=sgn*rt*(l.act==="sell"?(bid||0):(ask||0));midS+=sgn*rt*(mid===null?0:mid);
    html+='<tr><td class="'+(l.act==="buy"?"buy":"sell")+'">'+(l.act==="buy"?"Compra":"Venta")+(rt>1?" ×"+rt:"")+(close?" (cierre)":"")+'</td><td>'+pretty(l.row.occ)+'</td><td>'+f2(bid)+'</td><td>'+f2(ask)+'</td><td>'+(num(l.row.delta)===null?"–":l.row.delta.toFixed(2))+'</td></tr>';
  }
  if(eff.some(l=>{const b=num(l.row.bid),a=num(l.row.ask);return a!==null&&a>0.3&&(b===null||b<=0)}))
    html+='<tr><td colspan="5" class="warn">⚠ Alguna pata tiene bid en 0: los precios todavía no son confiables (pasa en la apertura). Los cálculos de cierre pueden salir muy mal; espera unos minutos.</td></tr>';
  tb.innerHTML=html;
  if(close&&S.custom&&(S.custom.combo||S.custom.legs.length===3))typeEff=midS>=0?"credit":"debit";   // combinacion: recibes o pagas segun el precio actual
  S.typeEff=typeEff;
  const nat=typeEff==="credit"?natS:-natS,mid=typeEff==="credit"?midS:-midS;
  $("plabel").textContent=(typeEff==="credit"?"Crédito":"Débito")+" límite ($ por acción)";
  S.nat=Math.max(0.01,Math.round(nat*100)/100);S.mid=Math.max(0.01,Math.round(mid*100)/100);
  if(!S.dirty)$("price").value=S.mid.toFixed(2);
  const P=+$("price").value||0;
  // prima de apertura: en "abrir" es el precio limite; en "cerrar" es la ENTRADA real de la posicion
  let kvP=P,note0="";
  if(close){
    let entry=null;
    if(S.custom)entry=Math.abs(S.custom.entry);
    else{const g=G.find(x=>sameSet(x.legs.map(l=>l.occ),open.map(l=>l.row.occ)));if(g)entry=Math.abs(g.entryNet)}
    if(entry===null){
      const m=open.reduce((a,l)=>{const bid=num(l.row.bid)||0,ask=num(l.row.ask)||0;return a+(l.act==="sell"?1:-1)*(bid+ask)/2},0);
      entry=Math.abs(m);note0=" Referencia: no encontré esta posición abierta, la gráfica usa el precio actual como entrada.";
    }
    kvP=entry;
  }
  $("ctitle").textContent=(S.custom&&S.custom.view)?"👁 VIENDO TU POSICIÓN · GANANCIA / PÉRDIDA (con tu entrada real)":close?"POSICIÓN QUE CIERRAS · GANANCIA / PÉRDIDA AL VENCIMIENTO":"GANANCIA / PÉRDIDA AL VENCIMIENTO";
  const ks=[...new Set(open.map(l=>l.k))].sort((a,b)=>a-b),pts=[0,...ks,ks[ks.length-1]+1000];
  const pn=pts.map(s=>payoffAt(open,kvP,otype,s)*100*qty);
  const maxP=Math.max(...pn),maxL=Math.min(...pn),bes=[];
  for(let i=0;i<pts.length-1;i++){const a=pn[i],b=pn[i+1];if((a<0&&b>0)||(a>0&&b<0))bes.push(pts[i]+(pts[i+1]-pts[i])*(0-a)/(b-a))}
  const pp=probProfit(open,kvP,otype),prob=pp===null?"–":Math.round(100*pp)+"%";
  const realized=otype==="credit"?(kvP-P)*100*qty:(P-kvP)*100*qty;
  const t4=close?'<div><span>P&L SI CIERRAS A $'+P.toFixed(2)+'</span><b class="'+(realized>=0?"ok":"bad")+'">'+money(realized)+'</b></div>'
              :'<div><span>RIESGO : BENEFICIO</span><b>'+(maxP>0?(Math.abs(maxL)/maxP).toFixed(2)+" : 1":"–")+'</b></div>';
  const t6=close?'<div><span>ENTRADA ('+(otype==="credit"?"CRÉDITO":"DÉBITO")+')</span><b>'+money(kvP*100*qty)+'</b></div>'
                :'<div><span>'+(otype==="credit"?"CRÉDITO":"DÉBITO")+' TOTAL</span><b>'+money(P*100*qty)+'</b></div>';
  $("kv").innerHTML='<div><span>'+(close?"MÁX. GANANCIA (SI MANTIENES)":"MÁX. GANANCIA")+'</span><b class="ok">'+money(maxP)+'</b></div><div><span>'+(close?"MÁX. PÉRDIDA (SI MANTIENES)":"MÁX. PÉRDIDA")+'</span><b class="bad">'+money(maxL)+'</b></div>'
   +'<div><span>BREAKEVEN</span><b>'+(bes.length?bes.map(x=>x.toFixed(2)).join(" / "):"–")+'</b></div>'+t4
   +'<div><span>PROB. APROX. DE GANAR</span><b>'+prob+'</b></div>'+t6;
  $("kvnote").textContent=(close?"Modo cierre: la gráfica es la posición que tienes abierta, con tu entrada real. ":"")+"Prob. aproximada: modelo lognormal con la volatilidad implícita, para terminar en ganancia al vencimiento. Es una estimación, no una garantía. Sin comisiones."+note0;
  drawChart({eff:open,P:kvP,typeEff:otype,qty,ks,spot:S.spot});

  const k=JSON.stringify(payload());
  if(k!==S.lastKey){$("bsend").disabled=true}
  if(S.mkt)mktPaint();
}
function bsPx(Sx,K,T,iv,call){if(!(T>0&&iv>0&&Sx>0&&K>0))return call?Math.max(Sx-K,0):Math.max(K-Sx,0);
  const r=0.04,sd=iv*Math.sqrt(T),d1=(Math.log(Sx/K)+(r+iv*iv/2)*T)/sd,d2=d1-sd;
  return call?Sx*cdf(d1)-K*Math.exp(-r*T)*cdf(d2):K*Math.exp(-r*T)*cdf(-d2)-Sx*cdf(-d1)}
/* delta con el precio de AHORA y la volatilidad de cada opcion (la de Tradier puede venir atrasada) */
function liveDelta(t,k){const r=S.by[t][k],iv=r&&num(r.iv),T=yearsToExp();
  if(!(iv>0&&T&&S.spot))return r?num(r.delta):null;
  const d1=(Math.log(S.spot/k)+(0.04+iv*iv/2)*T)/(iv*Math.sqrt(T));return t==="C"?cdf(d1):cdf(d1)-1}
function pickDeltaLive(t,target){let best=null,bd=9;
  for(const k of S.strikes){if(!S.by[t][k]||!(t==="P"?k<S.spot:k>S.spot))continue;const d=liveDelta(t,k);if(d===null)continue;
    const df=Math.abs(Math.abs(d)-target);if(df<bd){bd=df;best=k}}
  return best!==null?best:pickDelta(t,target)}
/* ===== grafica del precio de la estrategia (velas de 5 min de cada pata, ultima sesion) ===== */
const SH={key:"",data:null,ts:0,timer:null};
function legsSpec(legs){return legs.map(l=>l.occ+"*"+(l.n)).join(",")}
function shQueue(open){const legs=open.map(l=>({occ:l.row.occ,n:(l.act==="buy"?1:-1)*(l.ratio||1)}));const k=legsSpec(legs);
  if(k!==SH.key||Date.now()-SH.ts>60000){SH.key=k;clearTimeout(SH.timer);SH.timer=setTimeout(()=>shLoad(k),600)}else shDraw()}
async function shLoad(k){SH.ts=Date.now();let j;try{j=await api("/api/spread_hist?legs="+encodeURIComponent(k))}catch(e){j={error:String(e)}}
  if(k!==SH.key)return;SH.data=j;shDraw()}
function shDraw(){const el=$("shchart"),nt=$("shnote");if(!el)return;const j=SH.data;
  if(!j){return}if(j.error){el.innerHTML="";nt.textContent="No se pudo dibujar: "+j.error;return}
  const cur=S.typeEff&&S.mid?S.mid:null;
  drawHist(el,j,{ref:S.histRef,refLbl:S.histRefLbl,cur:S.mid,credit:curType()==="credit"});
  nt.textContent="Con el último precio operado de cada pata (velas de 5 min), no con el precio medio: en opciones con poco volumen puede brincar. Punto amarillo = precio medio de ahora.";}
/* dibuja la serie {t,v}; credit=true la muestra como lo que cuesta cerrar (positivo) */
function drawHist(svg,j,o){if(!j||!j.v||!j.v.length){svg.innerHTML='<text x="300" y="90" fill="#7d8aa5" font-size="13" text-anchor="middle">Sin operaciones en la última sesión</text>';return}
  const v=j.v.map(x=>o.credit?-x:x),pts=v.slice();if(o.ref>0)pts.push(o.ref);if(o.cur>0)pts.push(o.cur);
  let mn=Math.min(...pts),mx=Math.max(...pts);if(mx-mn<0.05){mx+=0.05;mn-=0.05}const pad=(mx-mn)*0.12;mn-=pad;mx+=pad;
  const N=v.length,X=i=>40+545*(N<=1?1:i/(N-1)),Y=y=>155-140*(y-mn)/(mx-mn);
  const hh=t=>{const d=new Date(t*1000);return String(d.getUTCHours()).padStart(2,"0")+":"+String(d.getUTCMinutes()).padStart(2,"0")};
  let h='';for(let g=0;g<=3;g++){const y=mn+(mx-mn)*g/3;h+='<line x1="40" x2="590" y1="'+Y(y)+'" y2="'+Y(y)+'" stroke="#202027"/><text x="2" y="'+(Y(y)+4)+'" fill="#7d8aa5" font-size="10">'+y.toFixed(2)+'</text>'}
  if(o.ref>0)h+='<line x1="40" x2="590" y1="'+Y(o.ref)+'" y2="'+Y(o.ref)+'" stroke="#b48cff" stroke-dasharray="5 4"/><text x="588" y="'+(Y(o.ref)-4)+'" fill="#b48cff" font-size="11" text-anchor="end">'+o.refLbl+' '+o.ref.toFixed(2)+'</text>';
  h+='<polyline fill="none" stroke="#5cc8ff" stroke-width="2" points="'+v.map((y,i)=>X(i).toFixed(1)+","+Y(y).toFixed(1)).join(" ")+'"/>';
  if(o.cur>0)h+='<circle cx="'+X(N-1)+'" cy="'+Y(o.cur)+'" r="4.5" fill="#ffd23f"/>';
  [0,Math.floor((N-1)/2),N-1].forEach(i=>{h+='<text x="'+X(i)+'" y="168" fill="#7d8aa5" font-size="10" text-anchor="middle">'+hh(j.t[i])+'</text>'});
  const lo=Math.min(...v),hi=Math.max(...v);
  h+='<text x="44" y="12" fill="#e6ecf5" font-size="11">'+(o.credit?"Lo que cuesta cerrarla (crédito)":"Lo que vale (débito)")+' · mín '+lo.toFixed(2)+' · máx '+hi.toFixed(2)+'</text>';
  svg.innerHTML=h}
/* 📈 de Posiciones: P&L en DOLARES de la posicion, con el precio medio que el panel grabo cada minuto */
async function histModal(g){if(!g)return;
  const legs=g.legs.map(x=>({occ:x.occ,n:(x.sg>0?1:-1)*(x.ratio||1)}));const it=gestFor(g.legs.map(x=>x.occ));
  const d=document.createElement("div");d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99998;display:flex;align-items:center;justify-content:center";
  d.innerHTML='<div style="background:#0c0c0f;border:1px solid #202027;border-radius:12px;padding:16px;width:min(860px,94vw)"><b>📈 P&amp;L de '+gesc((g.sym?g.sym+" ":"")+g.name+" "+g.strikes)+' · '+g.q+' ctr</b><div id="hm_st" style="color:#7d8aa5;font-size:13px;margin:4px 0 8px">Cargando…</div><svg viewBox="0 0 600 200" preserveAspectRatio="none" style="width:100%;height:260px"></svg><div style="color:#7d8aa5;font-size:12px;margin-top:6px">Con el precio MEDIO de cada pata que tu panel graba cada minuto (9:30–16:15) mientras la posición está abierta. Línea punteada blanca = sin ganar ni perder (tu entrada)'+(it?'; roja = stop del gestor; verde = objetivo':'')+'.</div><div style="text-align:right;margin-top:8px"><button type="button" class="btn sm">Cerrar</button></div></div>';
  d.onclick=e=>{if(e.target===d)d.remove()};d.querySelector("button").onclick=()=>d.remove();document.body.appendChild(d);
  const svg=d.querySelector("svg"),st=d.querySelector("#hm_st");
  let j;try{j=await api("/api/pnl_hist?legs="+encodeURIComponent(legsSpec(legs)))}catch(e){j={error:String(e)}}
  if(j.error){st.innerHTML='<span class="bad">'+gesc(j.error)+'</span>';svg.innerHTML="";return}
  const pnl=(j.v||[]).map(v=>(v+g.entryNet)*100*g.q);
  if(pnl.length<2){st.textContent="Todavía no hay datos grabados de esta posición: el panel empieza a grabar en el siguiente minuto de mercado (9:30–16:15) mientras siga abierta.";svg.innerHTML="";return}
  const t=j.t,hh=x=>new Date(x*1000).toLocaleTimeString("es-MX",{timeZone:"America/New_York",hour:"2-digit",minute:"2-digit",hour12:false}),
    dd=x=>new Date(x*1000).toLocaleDateString("es-MX",{timeZone:"America/New_York",day:"numeric",month:"short"});
  const multi=dd(t[0])!==dd(t[t.length-1]),lab=x=>(multi?dd(x)+" ":"")+hh(x),f=v=>(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(0);
  let iM=0,im=0;pnl.forEach((v,i)=>{if(v>pnl[iM])iM=i;if(v<pnl[im])im=i});
  const now=g.pnl!=null?g.pnl:pnl[pnl.length-1];
  st.innerHTML='Ahora <b class="'+(now>=0?"ok":"bad")+'">'+f(now)+'</b> · máximo <b class="ok">'+f(pnl[iM])+'</b> ('+lab(t[iM])+') · mínimo <b class="bad">'+f(pnl[im])+'</b> ('+lab(t[im])+')';
  const refs=[[0,"#e6ecf5","entrada"]];if(it&&it.stop_pnl!=null)refs.push([it.stop_pnl,"#ff5d6c","stop "+f(it.stop_pnl)]);if(it&&it.tp_pnl!=null)refs.push([it.tp_pnl,"#4ff0b7","objetivo "+f(it.tp_pnl)]);
  const all=pnl.concat(refs.map(r=>r[0]));let mn=Math.min(...all),mx=Math.max(...all);const pad=(mx-mn||10)*0.1;mn-=pad;mx+=pad;
  const N=pnl.length,X=i=>50+535*(N<=1?1:i/(N-1)),Y=y=>185-170*(y-mn)/(mx-mn),z=Y(0);
  let h='';for(let k=0;k<=4;k++){const y=mn+(mx-mn)*k/4;h+='<line x1="50" x2="585" y1="'+Y(y)+'" y2="'+Y(y)+'" stroke="#202027"/><text x="2" y="'+(Y(y)+4)+'" fill="#7d8aa5" font-size="10">'+f(y)+'</text>'}
  const pts=pnl.map((v,i)=>X(i).toFixed(1)+","+Y(v).toFixed(1)).join(" ");
  h+='<defs><clipPath id="hmu"><rect x="0" y="0" width="600" height="'+z+'"/></clipPath><clipPath id="hmd"><rect x="0" y="'+z+'" width="600" height="200"/></clipPath></defs>';
  const area=pts+" "+X(N-1).toFixed(1)+","+z+" "+X(0).toFixed(1)+","+z;
  h+='<polygon points="'+area+'" fill="rgba(79,240,183,.18)" clip-path="url(#hmu)"/><polygon points="'+area+'" fill="rgba(255,93,108,.18)" clip-path="url(#hmd)"/>';
  for(const [v,c,l] of refs)h+='<line x1="50" x2="585" y1="'+Y(v)+'" y2="'+Y(v)+'" stroke="'+c+'" stroke-dasharray="5 4" stroke-opacity=".8"/><text x="583" y="'+(Y(v)-4)+'" fill="'+c+'" font-size="10" text-anchor="end">'+l+'</text>';
  h+='<polyline fill="none" stroke="#5cc8ff" stroke-width="2" points="'+pts+'"/><circle cx="'+X(N-1)+'" cy="'+Y(pnl[N-1])+'" r="4.5" fill="#ffd23f"/>';
  [0,Math.floor((N-1)/2),N-1].forEach(i=>{h+='<text x="'+X(i)+'" y="198" fill="#7d8aa5" font-size="10" text-anchor="middle">'+lab(t[i])+'</text>'});
  svg.innerHTML=h}
function drawChart(c){
  const svg=$("chart");svg.innerHTML="";CHV=null;window.LASTC=c;if(!c)return;
  const T=yearsToExp(),okIv=T&&c.eff.every(l=>num(l.row.iv)>0);
  const ivs=c.eff.map(l=>num(l.row.iv)).filter(v=>v>0),sd=okIv&&ivs.length?(ivs.reduce((a,b)=>a+b,0)/ivs.length)*Math.sqrt(T):null;
  /* rango: los strikes y, si se puede, hasta 2 desviaciones del precio (como las plataformas de opciones) */
  let lo=c.ks[0],hi=c.ks[c.ks.length-1];
  if(c.spot){lo=Math.min(lo,c.spot);hi=Math.max(hi,c.spot);if(sd){lo=Math.min(lo,c.spot*Math.exp(-2.2*sd));hi=Math.max(hi,c.spot*Math.exp(2.2*sd))}}
  const pad=Math.max(6,(hi-lo)*0.06);lo-=pad;hi+=pad;
  const N=220,xs=[],ys=[];
  for(let i=0;i<=N;i++){const x=lo+(hi-lo)*i/N;xs.push(x);ys.push(payoffAt(c.eff,c.P,c.typeEff,x)*100*c.qty)}
  const tv=(x,t)=>{let v=(c.typeEff==="credit"?c.P:-c.P);for(const l of c.eff)v+=(l.act==="buy"?1:-1)*(l.ratio||1)*bsPx(x,l.k,t,num(l.row.iv),l.t==="C");return v*100*c.qty};
  const y0=okIv?xs.map(x=>tv(x,T)):[],yh=okIv?xs.map(x=>tv(x,T/2)):[];
  const mn=Math.min(...ys,...y0,0),mx=Math.max(...ys,...y0,0),rg=(mx-mn)||1;
  const X=x=>10+580*(x-lo)/(hi-lo),Y=y=>215-195*(y-mn)/rg,z=Y(0);
  const pts=xs.map((x,i)=>X(x).toFixed(1)+","+Y(ys[i]).toFixed(1)).join(" ");
  const area=pts+" "+X(hi).toFixed(1)+","+z+" "+X(lo).toFixed(1)+","+z;
  let h='<defs><clipPath id="up"><rect x="0" y="0" width="600" height="'+z+'"/></clipPath><clipPath id="dn"><rect x="0" y="'+z+'" width="600" height="230"/></clipPath></defs>';
  h+='<polygon points="'+area+'" fill="rgba(79,240,183,.25)" clip-path="url(#up)"/><polygon points="'+area+'" fill="rgba(255,93,108,.25)" clip-path="url(#dn)"/>';
  if(sd&&c.spot){   // campana de probabilidad del precio al vencimiento (azul) y marcas de 1σ / 2σ
    const pdf=x=>{const zz=(Math.log(x/c.spot)+sd*sd/2)/sd;return Math.exp(-zz*zz/2)/(x*sd)};const ds=xs.map(pdf),dm=Math.max(...ds)||1;
    h+='<polygon points="'+xs.map((x,i)=>X(x).toFixed(1)+","+(215-150*ds[i]/dm).toFixed(1)).join(" ")+' '+X(hi).toFixed(1)+',215 '+X(lo).toFixed(1)+',215" fill="rgba(92,140,255,.13)" stroke="rgba(92,140,255,.35)"/>';
    for(const [k,lb] of [[-2,"2σ"],[-1,"1σ"],[1,"1σ"],[2,"2σ"]]){const px=c.spot*Math.exp(k*sd);if(px>lo&&px<hi)h+='<line x1="'+X(px)+'" x2="'+X(px)+'" y1="28" y2="215" stroke="rgba(92,140,255,.35)" stroke-dasharray="2 4"/><text x="'+X(px)+'" y="190" fill="#5c8cff" font-size="10" text-anchor="middle">'+lb+'</text>'}}
  h+='<line x1="10" x2="590" y1="'+z+'" y2="'+z+'" stroke="#33333d"/>';
  if(c.spot&&c.spot>lo&&c.spot<hi)h+='<line x1="'+X(c.spot)+'" x2="'+X(c.spot)+'" y1="10" y2="220" stroke="#5cc8ff" stroke-dasharray="4"/><text x="'+(X(c.spot)+4)+'" y="22" fill="#5cc8ff" font-size="11">'+SYM+' '+c.spot.toFixed(2)+'</text>';
  if(GEXON&&GEX&&!GEX.error&&!GEX.loading&&GEX.sym===gexSym(SYM))   // niveles de gamma: put wall, call wall y gamma flip
    for(const [v,col,lb] of [[GEX.put_wall,"#ff5d6c","PW"],[GEX.call_wall,"#4ff0b7","CW"],[GEX.flip,"#ffa726","Flip"],[GEX.key,"#ffd23f","⭐"]])
      if(v&&v>lo&&v<hi)h+='<line x1="'+X(v)+'" x2="'+X(v)+'" y1="28" y2="215" stroke="'+col+'" stroke-opacity=".75" stroke-width="2" stroke-dasharray="1 3"/><text x="'+X(v)+'" y="40" fill="'+col+'" font-size="10" font-weight="700" text-anchor="middle" paint-order="stroke" stroke="#000" stroke-width="3">'+lb+' '+Math.round(v)+'</text>';
  h+='<polyline fill="none" stroke="#e6ecf5" stroke-width="2.5" points="'+pts+'"/>';
  if(okIv){const pl=(a,col,da)=>'<polyline fill="none" stroke="'+col+'" stroke-width="2" stroke-dasharray="'+da+'" points="'+xs.map((x,i)=>X(x).toFixed(1)+","+Y(a[i]).toFixed(1)).join(" ")+'"/>';
    h+=pl(yh,"#b48cff","2 4")+pl(y0,"#ffd23f","6 4");
    const now=c.spot?tv(c.spot,T):null;
    h+='<text x="14" y="16" font-size="11" fill="#e6ecf5">━ al vencimiento</text><text x="120" y="16" font-size="11" fill="#ffd23f">╌ hoy (T+0)'+(now==null?"":" · ahora "+(now>=0?"+":"−")+"$"+Math.abs(now).toFixed(0))+'</text><text x="300" y="16" font-size="11" fill="#b48cff">┈ a mitad del tiempo</text>';
    if(c.spot&&c.spot>lo&&c.spot<hi&&now!=null)h+='<circle cx="'+X(c.spot)+'" cy="'+Y(now)+'" r="4" fill="#ffd23f"/>'}
  for(const k of c.ks)h+='<text x="'+X(k)+'" y="228" fill="#7d8aa5" font-size="10" text-anchor="middle">'+k+'</text>';
  h+='<g id="hov" style="pointer-events:none"></g>';
  svg.innerHTML=h;drawMini(c);
  CHV={lo,hi,X,Y,spot:c.spot,exp:x=>payoffAt(c.eff,c.P,c.typeEff,x)*100*c.qty,now:okIv?(x=>tv(x,T)):null};
  if(!svg._hov){svg._hov=true;svg.style.cursor="crosshair";svg.addEventListener("mousemove",chHover);svg.addEventListener("mouseleave",()=>{const g=document.getElementById("hov");if(g)g.innerHTML=""})}
}
/* al pasar el mouse por la grafica: linea vertical con el precio del subyacente, su % contra el de ahora,
   y cuanto ganarias o perderias ahi al vencimiento (blanco) y hoy (amarillo) */
let CHV=null;
function chHover(e){const g=document.getElementById("hov");if(!g||!CHV)return;const svg=e.currentTarget,r=svg.getBoundingClientRect();
  const vx=(e.clientX-r.left)/r.width*600;if(vx<10||vx>590){g.innerHTML="";return}
  const x=CHV.lo+(CHV.hi-CHV.lo)*(vx-10)/580,ve=CHV.exp(x),vn=CHV.now?CHV.now(x):null;
  const pct=CHV.spot?(x/CHV.spot-1)*100:null,f=v=>(v>=0?"+":"−")+"$"+Math.abs(v).toFixed(2);
  const right=vx>430,ax=right?vx-6:vx+6,anc=right?"end":"start";
  let h='<line x1="'+vx+'" x2="'+vx+'" y1="22" y2="215" stroke="#e6ecf5" stroke-opacity=".55"/>';
  const bx=Math.min(535,Math.max(65,vx));
  h+='<rect x="'+(bx-58)+'" y="196" width="116" height="16" rx="3" fill="#16161b" stroke="#5cc8ff"/><text x="'+bx+'" y="208" fill="#e6ecf5" font-size="10.5" font-weight="700" text-anchor="middle">'+x.toFixed(2)+(pct==null?"":" ("+(pct>=0?"+":"")+pct.toFixed(1)+"%)")+'</text>';
  const ye=CHV.Y(ve),close=vn!=null&&Math.abs(ye-CHV.Y(vn))<18,ax2=close?(right?vx+6:vx-6):ax,anc2=close?(right?"start":"end"):anc;   // si quedan encimadas, una a cada lado
  h+='<circle cx="'+vx+'" cy="'+ye+'" r="4" fill="#e6ecf5"/><text x="'+ax2+'" y="'+(ye<45?ye+16:ye-6)+'" fill="'+(ve>=0?"#4ff0b7":"#ff5d6c")+'" font-size="12" font-weight="700" text-anchor="'+anc2+'" paint-order="stroke" stroke="#000" stroke-width="3">'+f(ve)+'</text>';
  if(vn!=null){const yn=CHV.Y(vn);h+='<circle cx="'+vx+'" cy="'+yn+'" r="4" fill="#ffd23f"/><text x="'+ax+'" y="'+(yn+15)+'" fill="#ffd23f" font-size="12" font-weight="700" text-anchor="'+anc+'" paint-order="stroke" stroke="#000" stroke-width="3">hoy '+f(vn)+'</text>'}
  g.innerHTML=h}
/* dibujo chico de la estrategia junto a los campos (cabe en la orden rapida) */
function drawMini(c){
  const svg=$("minichart");if(!svg)return;if(!c){svg.innerHTML="";return}
  const pad=Math.max(3,(c.ks[c.ks.length-1]-c.ks[0])*0.25)+2;
  let lo=c.ks[0]-pad,hi=c.ks[c.ks.length-1]+pad;
  if(c.spot){lo=Math.min(lo,c.spot-pad/2);hi=Math.max(hi,c.spot+pad/2)}   // que siempre se vea dónde está el precio
  const N=160,xs=[],ys=[];
  for(let i=0;i<=N;i++){const x=lo+(hi-lo)*i/N;xs.push(x);ys.push(payoffAt(c.eff,c.P,c.typeEff,x)*100*c.qty)}
  const mn=Math.min(...ys,0),mx=Math.max(...ys,0),rg=(mx-mn)||1;
  const X=x=>8+584*(x-lo)/(hi-lo),Y=y=>124-100*(y-mn)/rg,z=Y(0);
  const pts=xs.map((x,i)=>X(x).toFixed(1)+","+Y(ys[i]).toFixed(1)).join(" ");
  const area=pts+" "+X(hi).toFixed(1)+","+z+" "+X(lo).toFixed(1)+","+z;
  const be=[];for(let i=0;i<N;i++){const a=ys[i],b=ys[i+1];if((a<0&&b>=0)||(a>=0&&b<0))be.push(xs[i]+(xs[i+1]-xs[i])*(0-a)/(b-a))}
  const m$=v=>(v<0?"−$":"$")+Math.abs(Math.round(v)).toLocaleString("en-US");
  let h='<defs><clipPath id="mup"><rect x="0" y="0" width="600" height="'+z+'"/></clipPath><clipPath id="mdn"><rect x="0" y="'+z+'" width="600" height="150"/></clipPath></defs>';
  h+='<polygon points="'+area+'" fill="rgba(79,240,183,.28)" clip-path="url(#mup)"/><polygon points="'+area+'" fill="rgba(255,93,108,.28)" clip-path="url(#mdn)"/>';
  h+='<line x1="8" x2="592" y1="'+z+'" y2="'+z+'" stroke="#33333d"/>';
  for(const b of be)h+='<line x1="'+X(b)+'" x2="'+X(b)+'" y1="'+(z-5)+'" y2="'+(z+5)+'" stroke="#ffd23f" stroke-width="2"/>';
  if(c.spot&&c.spot>lo&&c.spot<hi)h+='<line x1="'+X(c.spot)+'" x2="'+X(c.spot)+'" y1="16" y2="128" stroke="#ffd23f" stroke-dasharray="4"/><rect x="'+(X(c.spot)-(X(c.spot)>480?96:-2))+'" y="'+(z>75?z+8:z-24)+'" width="94" height="16" rx="3" fill="#0c0c0f" opacity=".85"/><text x="'+(X(c.spot)+(X(c.spot)>480?-4:4))+'" y="'+(z>75?z+20:z-12)+'" fill="#ffd23f" font-size="12" font-weight="700" text-anchor="'+(X(c.spot)>480?"end":"start")+'">'+SYM+' '+c.spot.toFixed(2)+'</text>';
  h+='<polyline fill="none" stroke="#e6ecf5" stroke-width="2.5" points="'+pts+'"/>';
  const grp=[];for(const k of c.ks){const g=grp[grp.length-1];if(g&&X(k)-X(g[g.length-1])<46)g.push(k);else grp.push([k])}   // strikes pegados: una sola etiqueta
  for(const g of grp){const xm=(X(g[0])+X(g[g.length-1]))/2;h+='<text x="'+xm+'" y="144" fill="#9fb0cc" font-size="11" text-anchor="middle">'+(g.length>1?g[0]+"/"+g[g.length-1]:g[0])+'</text>'}
  h+='<text x="8" y="12" font-size="12" fill="#4ff0b7">Máx. '+m$(mx)+'</text><text x="110" y="12" font-size="12" fill="#ff5d6c">Pérdida máx. '+m$(mn)+'</text>'
    +(be.length?'<text x="592" y="12" font-size="12" fill="#ffd23f" text-anchor="end">BE '+be.map(b=>b.toFixed(2)).join(" / ")+'</text>':'');
  svg.innerHTML=h;
}
function sideName(act,close){return act+(close?"_to_close":"_to_open")}
function payload(){
  if(!S.legsEff)return null;
  const close=$("mode").value==="close",ot=curType(),lt=close?(S.typeEff||(ot==="credit"?"debit":"credit")):ot;
  if(S.mkt)return{symbol:SYM,type:"market",kind:lt,qty:Math.max(1,Math.min(10,Math.floor(+$("qty").value)||1)),
    legs:S.legsEff.map(l=>({occ:l.row.occ,side:sideName(l.act,close),ratio:l.ratio||1})),combo:!!(close&&S.custom&&S.custom.combo),free:!close&&!S.custom&&$("strat").value==="free"};
  return{symbol:SYM,type:lt,
    qty:Math.max(1,Math.min(10,Math.floor(+$("qty").value)||1)),price:+(+$("price").value).toFixed(2),
    legs:S.legsEff.map(l=>({occ:l.row.occ,side:sideName(l.act,close),ratio:l.ratio||1})),combo:!!(close&&S.custom&&S.custom.combo),
    free:!close&&!S.custom&&$("strat").value==="free"};
}
/* ===== GESTOR AUTOMATICO ===== */
const GC={d:null,cfgs:null,filled:false};
const gesc=x=>String(x).replace(/&/g,"&amp;").replace(/</g,"&lt;");
const gm=v=>v==null?"–":"$"+(+v).toFixed(2);
async function gLoad(){const j=await api("/api/gestor");if(j.error)return;GC.d=j;GC.cfgs=j.cfgs;if(!GC.filled){GC.filled=true;gFill();gDef()}gList()}
function gFill(){if(!GC.cfgs)return;const c=GC.cfgs[curType()];$("g_on").checked=c.auto;$("g_stop").value=c.stop_usd;$("g_tp").value=c.tp_usd;$("g_at").value=c.at_target;$("g_trl").value=c.trail_usd;$("g_hex").value=c.time_exit;gHint()}
function gDef(){for(const [p,k] of [["cr","credit"],["db","debit"]]){const c=GC.cfgs[k];$("d_"+p+"_stop").value=c.stop_usd;$("d_"+p+"_tp").value=c.tp_usd;$("d_"+p+"_at").value=c.at_target;$("d_"+p+"_trl").value=c.trail_usd;$("d_"+p+"_hex").value=c.time_exit;$("d_"+p+"_auto").checked=c.auto}}
function gHint(){const cr=curType()==="credit",p=+$("price").value,q=Math.max(1,+$("qty").value||1),s=+$("g_stop").value,t2=+$("g_tp").value,r=+$("g_trl").value,tr=$("g_at").value==="trail";
  $("g_trw").style.display=tr?"":"none";const per=100*q;
  if(!(p>0&&s>0&&t2>0)){$("g_hint").textContent="(usa el precio límite y los contratos de la orden como referencia; el real será el precio de ejecución)";return}
  const lvS=cr?p+s/per:p-s/per,lvT=cr?p-t2/per:p+t2/per;
  $("g_hint").textContent=(cr?"Con crédito "+gm(p)+" × "+q+": stop si cerrar cuesta "+gm(lvS)+" · objetivo cuando cerrar cuesta "+gm(Math.max(0,lvT)):"Con débito "+gm(p)+" × "+q+": stop si vale "+gm(Math.max(0,lvS))+" · objetivo cuando vale "+gm(lvT))
    +(tr?". Al llegar al objetivo sigue dentro y cierra si devuelve $"+r+" desde su máximo (mínimo asegurado ≈ +$"+Math.max(0,t2-r)+").":". Al llegar al objetivo cierra y cobra.")}
function gBoxShow(){const o=$("mode").value==="open",fr=!S.custom&&$("strat").value==="free",ok=!fr||(S.free.length>=2&&S.free.length<=4);
  $("gbox").style.display=o&&ok?"":"none";if(!ok)$("g_on").checked=false}
function gExtra(p){if(p.legs.some(l=>!/_to_open$/.test(l.side)))return{};
  return{managed:$("g_on").checked,mgr_cfg:{unit:"usd",stop_usd:+$("g_stop").value,tp_usd:+$("g_tp").value,at_target:$("g_at").value,trail_usd:+$("g_trl").value,time_exit:$("g_hex").value.trim()}}}
function gList(){if(!GC.d)return;const d=Object.assign({},GC.d,{items:(GC.d.items||[]).filter(i=>acctOf(i.live)===(window.ACCT||"paper"))});   // solo la cuenta que estás viendo
  const act=d.items.filter(i=>["entrada","activa","cerrando"].includes(i.status));
  $("gs").innerHTML='<span style="color:'+(d.paused?"var(--warn)":"var(--ok)")+'">'+(d.paused?"EN PAUSA":act.length+" vigilando")+"</span>";$("g_pause").textContent=d.paused?"Reanudar":"Pausar todo";
  const ST={entrada:"esperando ejecución",activa:"vigilando",cerrando:"cerrando…",cerrada:"cerrada",cancelada:"no ejecutada",liberada:"liberada"};
  $("glist").innerHTML=d.items.length?d.items.slice(0,10).map(i=>{const on=["entrada","activa","cerrando"].includes(i.status),cr=i.kind==="credit";
    return '<div style="border-top:1px solid var(--line);padding:8px 0;font-size:13px"><div style="display:flex;justify-content:space-between;gap:8px"><b>'+(i.live?"🔴 ":"")+(i.qty||i.qty_ordered)+"× "+gesc(i.name)+'</b><span style="color:'+(i.hold?"var(--bad)":on?"var(--ok)":"var(--mut)")+'">'+(i.hold?"⚠ DETENIDA":ST[i.status]||i.status)+"</span></div>"+
    (i.entry?'<div class="mono">'+(cr?"Crédito ":"Débito ")+gm(i.entry)+" → "+(cr?"cerrar cuesta ":"vale ")+(on||!i.exit_px?gm(i.mark):gm(i.exit_px))+(i.pct==null||!on?"":' <b class="'+(i.pct>=0?"ok":"bad")+'">'+(i.pct>=0?"+":"")+i.pct.toFixed(1)+"%</b>")+(on?" · P&amp;L ":" · P&amp;L FINAL ")+'<b class="'+((i.pnl||0)>=0?"ok":"bad")+'">'+((i.pnl||0)>=0?"+":"-")+"$"+Math.abs(i.pnl||0).toFixed(on?0:2)+"</b>"+(i.estimated?" (estimado)":"")+"</div>"+
      (on?(i.unit==="usd"?'<div class="mono" style="color:var(--mut)">Stop −$'+i.cfg.stop_usd+"/ctr ×"+i.qty+"="+(i.cfg.stop_usd*i.qty)+" ("+(cr?"si cerrar cuesta ":"si vale ")+gm(i.stop)+") · Objetivo +$"+i.cfg.tp_usd+" ("+gm(i.tp)+")"+(i.cfg.at_target==="trail"?" → trailing −$"+i.cfg.trail_usd:"")+"</div>"+(i.armed?'<div class="mono" style="color:var(--ok)">🎯 Trailing activo · máx +$'+(i.peak_usd==null?"–":i.peak_usd.toFixed(0))+" · sale si "+(cr?"cerrar cuesta ":"vale ")+(cr?"sube a ":"baja a ")+gm(i.trail)+"</div>":""):'<div class="mono" style="color:var(--mut)">Stop '+(cr?"si cerrar cuesta ":"si vale ")+gm(i.stop)+" · Objetivo "+gm(i.tp)+"</div>"):(i.reason?'<div style="color:var(--mut)">Salió por: '+gesc(i.reason)+"</div>":"")):"")+
    (i.ev.length?'<div class="mono" style="color:var(--mut);font-size:12px">'+gesc(i.ev[i.ev.length-1][0]+" "+i.ev[i.ev.length-1][1])+"</div>":"")+
    (i.status==="activa"?'<div style="margin-top:6px;display:flex;gap:6px"><button class="btn sm" onclick="gAct(\''+i.id+'\',\'close\')">Cerrar ya</button><button class="btn sm" onclick="gEdit(\''+i.id+'\')">✏️ Editar reglas</button><button class="btn sm" onclick="gAct(\''+i.id+'\',\'release\')">Soltar</button>'+(i.hold?'<button class="btn sm" onclick="gAct(\''+i.id+'\',\'resume\')">Reanudar</button>':"")+"</div>":"")+"</div>"}).join(""):'<div style="color:var(--mut);font-size:13px">Sin posiciones vigiladas. Las órdenes de ABRIR que envíes con la casilla 🤖 marcada quedarán aquí.</div>'}
function gEdit(id){
  const i=((GC.d||{}).items||[]).find(x=>x.id===id);if(!i)return;
  if(i.unit!=="usd"){notify("Esta posición usa reglas en % (versión anterior); no se puede editar. Ciérrala o suéltala.");return}
  const old=document.getElementById("gedit");if(old)old.remove();const c=i.cfg;
  const d=document.createElement("div");d.id="gedit";
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center";
  const f=(k,l,v,st)=>'<label style="display:block;font-size:12px;margin-top:8px">'+l+'</label><input id="ge_'+k+'" value="'+v+'" '+(st||'type="number" step="1" min="1"')+' style="width:100%;box-sizing:border-box">';
  d.innerHTML='<div style="background:var(--card,#141418);color:var(--tx,#e6edf3);border:1px solid var(--line,#30363d);border-radius:12px;padding:16px;width:min(340px,92vw)"><b>Editar reglas · '+(i.qty||i.qty_ordered)+'× '+gesc(i.name)+'</b><div style="font-size:12px;color:var(--mut,#8b949e);margin-top:4px">Montos en $ POR CONTRATO (× '+(i.qty||i.qty_ordered)+' contratos)</div>'
   +f("stop","Stop: pérdida máx. ($/contrato)",c.stop_usd)+f("tp","Objetivo: ganancia ($/contrato)",c.tp_usd)
   +'<label style="display:block;font-size:12px;margin-top:8px">Al llegar al objetivo…</label><select id="ge_at" style="width:100%"><option value="trail"'+(c.at_target==="trail"?" selected":"")+'>Seguir con trailing</option><option value="close"'+(c.at_target==="close"?" selected":"")+'>Cerrar y cobrar</option></select>'
   +f("trl","Trailing: devolver máx. ($/contrato)",c.trail_usd)+f("hex","Cerrar a las (NY, si vence hoy)",c.time_exit,'type="text"')
   +'<div id="ge_msg" style="color:#f85149;font-size:12px;min-height:16px;margin-top:6px"></div><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:6px"><button type="button" id="ge_no">Cancelar</button><button type="button" id="ge_ok">Guardar</button></div></div>';
  (document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);
  document.getElementById("ge_no").onclick=()=>d.remove();
  document.getElementById("ge_ok").onclick=async()=>{
    const cfg={unit:"usd",stop_usd:+document.getElementById("ge_stop").value,tp_usd:+document.getElementById("ge_tp").value,at_target:document.getElementById("ge_at").value,trail_usd:+document.getElementById("ge_trl").value,time_exit:document.getElementById("ge_hex").value.trim()};
    const j=await api("/api/gestor_item",{id:id,action:"set",cfg:cfg});
    if(j.error){document.getElementById("ge_msg").textContent=j.error;return}
    d.remove();GC.d=j;gList();}}
async function gAct(id,action){let g={};
  if(action==="close"){g=await guard("CERRAR YA (a mercado) la posición vigilada #"+id);if(!g)return}
  else if(action==="release"&&!(await askOk("¿Soltar esta posición? Seguirá abierta en tu cuenta pero el gestor ya no la vigila.")))return;
  const j=await api("/api/gestor_item",Object.assign({id:id,action:action},g));
  if(j.error)showRes("✖ "+j.error,"bad");else{GC.d=j;gList()}}
async function gSaveDef(){
  const mk=p=>({unit:"usd",stop_usd:+$("d_"+p+"_stop").value,tp_usd:+$("d_"+p+"_tp").value,at_target:$("d_"+p+"_at").value,trail_usd:+$("d_"+p+"_trl").value,time_exit:$("d_"+p+"_hex").value.trim(),auto:$("d_"+p+"_auto").checked});
  let j=await api("/api/gestor_cfg",{kind:"credit",cfg:mk("cr")});if(!j.error)j=await api("/api/gestor_cfg",{kind:"debit",cfg:mk("db")});
  $("g_dmsg").innerHTML=j.error?'<span class="bad">✖ NO guardado: '+gesc(j.error)+"</span>":j.save_err?'<span class="bad">⚠ '+gesc(j.save_err)+"</span>":'<span class="ok">✓ Reglas guardadas en el disco (valen para órdenes nuevas)</span>';
  if(!j.error){GC.d=j;GC.cfgs=j.cfgs;gFill();gList()}}
async function gPause(){const j=await api("/api/gestor_pause",{paused:!(GC.d&&GC.d.paused)});if(!j.error){GC.d=j;gList()}}
function setErr(m){const e=$("apierr");e.style.display=m?"":"none";e.textContent=m||""}
function showRes(html,cls){const r=$("res");r.className=cls||"";r.innerHTML=html}
async function doPreview(){
  const p=payload();if(!p)return;S.dirty=true;
  showRes("Consultando vista previa…","");
  const j=await api("/api/preview",p);
  if(j.error){showRes("✖ "+j.error,"bad");$("bsend").disabled=true;return}
  const o=j.preview||{},keys=[["status","Estado"],["strategy","Estrategia"],["type","Tipo"],["quantity","Cantidad"],["commission","Comisión"],["fees","Tarifas"],["cost","Costo"],["order_cost","Costo de la orden"],["margin_change","Cambio de margen"],["day_trades","Day trades"]];
  const lines=keys.filter(([k])=>o[k]!==undefined).map(([k,n])=>n+": "+o[k]);
  showRes("✔ Vista previa correcta\n"+(lines.join("\n")||JSON.stringify(o)),"ok");
  S.lastKey=JSON.stringify(payload());$("bsend").disabled=false;ctSave();
}
const AOHASH=location.hash.startsWith("#pcs=");
function ctSave(){try{localStorage.setItem("ct_last",JSON.stringify({q:$("qty").value,w:$("width").value,s:$("strat").value}))}catch(e){}}
function ctRestore(){try{const c=JSON.parse(localStorage.getItem("ct_last")||"null");if(!c||AOHASH||location.hash.startsWith("#close="))return;
  if(c.s&&[...$("strat").options].some(o=>o.value===c.s)&&$("strat").value!==c.s){$("strat").value=c.s;$("strat").dispatchEvent(new Event("change"))}
  if(c.w&&[...$("width").options].some(o=>o.value===c.w)){$("width").value=c.w;$("width").dispatchEvent(new Event("change"))}
  if(c.q){$("qty").value=c.q;$("qty").dispatchEvent(new Event("input"))}}catch(e){}}
setTimeout(ctRestore,900);setTimeout(autoOpen,900);
async function doSend(){
  const p=payload();if(!p||JSON.stringify(p)!==S.lastKey)return;
  const txt=p.legs.map(l=>l.side.replace(/_/g," ")+" "+pretty(l.occ)).join("\n");
  const ex=gExtra(p);
  const g=await guard("¿Enviar esta orden?\n\n"+(p.type==="market"?"⚡ A MERCADO (sin precio límite; se llena al precio que haya)":p.type.toUpperCase()+" límite $"+p.price.toFixed(2))+" × "+p.qty+" contrato(s)\n\n"+txt+(ex.managed?"\n\n🤖 El gestor la vigilará: stop −$"+ex.mgr_cfg.stop_usd+"/contrato (a mercado) · objetivo +$"+ex.mgr_cfg.tp_usd+"/contrato (orden límite)"+(ex.mgr_cfg.at_target==="trail"?" → trailing −$"+ex.mgr_cfg.trail_usd:""):"\n\n(sin gestor: no habrá stop ni objetivo automático)"));if(!g)return;
  $("bsend").disabled=true;
  const j=await api("/api/order",Object.assign({},p,ex,g));
  if(j.error){showRes("✖ "+j.error,"bad");return}
  showRes("✔ Orden enviada (id "+((j.order||{}).id||"?")+"). Revisa la tabla de órdenes."+(j.managed?" 🤖 El gestor la vigilará en cuanto se ejecute.":""),"ok");gLoad();S.lastKey=null;S.dirty=false;loadOrders();
}
let ORD=[];
/* precio AHORA de una orden pendiente y que hacer con tu limite */
function nowCell(o){if(!o.open||o.now_mid==null)return'<span style="color:var(--mut)">–</span>';return'<b>$'+o.now_mid.toFixed(2)+'</b>'}
const ST_ES={pending:"pendiente",open:"abierta",partially_filled:"parcial",filled:"ejecutada",canceled:"cancelada",rejected:"rechazada",expired:"vencida",calculated:"pendiente",accepted:"aceptada"};
const TY_ES={credit:"crédito",debit:"débito",even:"par",limit:"límite",market:"mercado",stop:"stop",stop_limit:"stop límite"};
/* hora de Nueva York de una fecha de Tradier (UTC); si no es de hoy, agrega el dia */
function hNY(iso){if(!iso)return'<span style="color:var(--mut)">–</span>';const d=new Date(iso);if(isNaN(d))return"–";
  const o={timeZone:"America/New_York"},hh=d.toLocaleTimeString("es-MX",Object.assign({hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false},o)),
    dd=d.toLocaleDateString("en-CA",o),td=new Date().toLocaleDateString("en-CA",o);
  return(dd===td?"":'<span style="color:var(--mut)">'+d.toLocaleDateString("es-MX",Object.assign({day:"numeric",month:"short"},o))+'</span> ')+hh}
/* patas en corto: "SPXW 16-nov" y luego +7540P −7570P (verde compra, rojo venta); el detalle completo al pasar el mouse */
function legsShort(L){const M=["","ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"],grp={};
  for(const l of L||[]){const m=/^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d{8})$/.exec(l.occ||"");
    if(!m){(grp[l.occ]=grp[l.occ]||[]).push('<span title="'+(l.side||"")+'">'+(l.occ||"")+'</span>');continue}
    const key=m[1]+" "+(+m[4])+"-"+M[+m[3]]+"|"+m[5],buy=/^buy/.test(l.side||""),cl=/_to_close$/.test(l.side||"");
    (grp[key]=grp[key]||[]).push('<span title="'+(l.side||"").replace(/_/g," ")+" "+pretty(l.occ)+'" style="white-space:nowrap;font-weight:700;color:'+(buy?"var(--ok)":"var(--bad)")+'">'+(buy?"+":"−")+(+m[6]/1000)+m[5]+(cl?"<sup style=\"color:var(--mut)\">c</sup>":"")+"</span>")}
  const ks=Object.keys(grp).sort((a,b)=>a.split("|")[0]===b.split("|")[0]?(a.endsWith("|P")?-1:1):a.localeCompare(b));   // puts arriba, calls abajo
  let prev="";return ks.map(k=>{const [d]=k.split("|"),lbl=d===prev?"":d;prev=d;
    return'<div style="white-space:nowrap"><span style="color:var(--mut);font-size:12px;'+(lbl?"":"visibility:hidden")+'">'+d+'</span> '+grp[k].join(" ")+"</div>"}).join("")}   // calls alineados bajo los puts
function nudgeBtns(o){const b=(dx,t)=>'<button class="btn sm" style="padding:3px 7px" title="Cambiar el precio '+(dx>0?"+":"")+dx.toFixed(2)+' (misma orden, no se cancela)" onclick="nudge('+o.id+',\''+o.type+'\','+o.price+','+dx+')">'+t+'</button>';
  return b(-0.05,"−.05")+b(-0.01,"−.01")+b(0.01,"+.01")+b(0.05,"+.05")+'<button class="btn sm" style="padding:3px 7px;border-color:#ff9f43;color:#ff9f43" title="Convertir esta orden en orden A MERCADO (se llena ya, al precio que haya)" onclick="toMarket('+o.id+')">⚡ Mercado</button>'}
async function toMarket(id){const g=await guard("Orden #"+id+": pasarla a ⚡ A MERCADO.\nSe llena ya, al precio que haya en ese momento (en spreads puede salir peor que el medio).");if(!g)return;
  let j;try{j=await api("/api/modify",Object.assign({id:String(id),to_market:true},g))}catch(e){j={error:String(e)}}
  notify(j.error?"No se pudo: "+j.error:"✓ Orden #"+id+" enviada a mercado");loadOrders()}
async function nudge(id,type,price,dx){const p=Math.round((price+dx)*100)/100;if(p<0.01)return;
  const help=type==="credit"?(dx<0?"(crédito: bajar = más fácil que se llene)":"(crédito: subir = cobras más, más difícil)"):type==="debit"?(dx>0?"(débito: subir = más fácil que se llene)":"(débito: bajar = pagas menos, más difícil)"):"";
  const g=await guard("Orden #"+id+": precio $"+price.toFixed(2)+" → $"+p.toFixed(2)+" "+help);if(!g)return;
  let j;try{j=await api("/api/modify",Object.assign({id:String(id),price:p,type:type},g))}catch(e){j={error:String(e)}}
  notify(j.error?"No se pudo modificar: "+j.error:"✓ Orden #"+id+" a $"+p.toFixed(2));loadOrders()}
async function cancelAll(){const op=ORD.filter(o=>o.open);if(!op.length){notify("No hay órdenes pendientes");return}
  if(!(await askOk("¿Cancelar TODAS las órdenes pendientes ("+op.length+")?\n\n"+op.map(o=>"#"+o.id+" "+(o.type||"")+" "+(o.price==null?"":"$"+o.price.toFixed(2))).join("\n"))))return;
  let bad=0;for(const o of op){try{const j=await api("/api/cancel",{id:o.id});if(j.error)bad++}catch(e){bad++}}
  notify(bad?bad+" orden(es) no se pudieron cancelar":"✓ "+op.length+" orden(es) canceladas");loadOrders()}
async function loadOrders(){
  const j=await api("/api/orders");const tb=$("orders");
  if(j.error){keepOrErr(tb,j.error,10);return}
  ORD=(j&&j.orders)||[];const cb=$("bcanall");if(cb)cb.style.display=ORD.some(o=>o.open)?"":"none";tb._ok=true;
  if(!j.orders.length){tb._h=null;tb.innerHTML='<tr><td colspan="10" style="color:#7d8aa5">Sin órdenes</td></tr>';return}
  tb.innerHTML=j.orders.map(o=>{const es=(o.legs||[]).every(l=>/_to_open$/.test(l.side||""))?'<b class="ok">Entrada</b>':(o.legs||[]).every(l=>/_to_close$/.test(l.side||""))?'<b class="bad">Salida</b>':'<span style="color:var(--mut)">Mixta</span>';
   return '<tr><td>'+o.id+'</td><td style="white-space:nowrap">'+hNY(o.sent)+'</td><td>'+es+'</td><td>'+(ST_ES[o.status]||o.status||"")+'</td><td style="white-space:nowrap">'+(TY_ES[o.type]||o.type||"")+'<br><b>'+(o.price===null?"–":"$"+o.price.toFixed(2))+'</b></td><td style="white-space:nowrap">'+nowCell(o)+'</td><td>'+(o.status==="filled"&&o.fill!=null?'<b>'+Math.abs(o.fill).toFixed(2)+'</b>':"–")+'</td><td>'+(o.qty||"")+'</td><td style="text-align:left">'+legsShort(o.legs)+'</td><td>'+(o.open?'<div style="display:flex;flex-wrap:nowrap;gap:4px;justify-content:flex-end">'+((o.price!=null&&["credit","debit","limit"].includes(o.type))?nudgeBtns(o)+'<button class="btn sm" onclick="modOrder('+o.id+',\''+o.type+'\','+o.price+').then(()=>loadOrders())">Modificar</button>':"")+'<button class="btn sm x" onclick="cancelOrder('+o.id+')">Cancelar</button></div>':"")+'</td></tr>'}).join("");
}
async function cancelOrder(id){if(!(await askOk("¿Cancelar la orden "+id+"?")))return;
  const bs=[...document.querySelectorAll("#orders button.x")];bs.forEach(b=>{b.disabled=true;b.textContent="…"});   // solo los botones de la tabla de ordenes
  let j;try{j=await api("/api/cancel",{id})}catch(e){j={error:String(e)}}
  notify(j.error?("No se pudo cancelar: "+j.error):"Orden "+id+" cancelada");loadOrders()}
function askOk(msg){return new Promise(res=>{const d=document.createElement("div");
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99998;display:flex;align-items:center;justify-content:center";
  const bx=document.createElement("div");bx.style.cssText="background:#0c0c0f;color:#e6ecf5;border:1px solid #202027;border-radius:12px;padding:18px;max-width:340px;font:14px -apple-system,sans-serif";
  const t=document.createElement("div");t.style.cssText="margin-bottom:14px;white-space:pre-wrap";t.textContent=msg;
  const r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
  const no=document.createElement("button"),ok=document.createElement("button");no.textContent="No";ok.textContent="Sí";
  [no,ok].forEach(b=>{b.type="button";b.style.cssText="padding:7px 16px;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer"});
  ok.style.borderColor="#ff5d6c";ok.style.color="#ff5d6c";
  const done=v=>{d.remove();res(v)};no.onclick=()=>done(false);ok.onclick=()=>done(true);d.onclick=e=>{if(e.target===d)done(false)};
  r.append(no,ok);bx.append(t,r);d.append(bx);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);no.focus()})}
function askPrice(title,hint,val,okLabel,extraLabel,live){return new Promise(res=>{const d=document.createElement("div");
  d.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99998;display:flex;align-items:center;justify-content:center";
  const bx=document.createElement("div");bx.style.cssText="background:#0c0c0f;color:#e6ecf5;border:1px solid #202027;border-radius:12px;padding:18px;width:340px;max-width:92vw;font:14px -apple-system,sans-serif";
  const t=document.createElement("div");t.style.cssText="font-weight:800;margin-bottom:6px";t.textContent=title;
  const h=document.createElement("div");h.style.cssText="color:#7d8aa5;font-size:12px;margin-bottom:10px;white-space:pre-wrap";h.textContent=hint||"";
  const inp=document.createElement("input");inp.type="number";inp.step="0.01";inp.min="0.01";inp.value=val==null?"":(+val).toFixed(2);
  inp.style.cssText="width:100%;box-sizing:border-box;background:#08080a;color:#e6ecf5;border:1px solid #202027;border-radius:8px;padding:10px;font:700 18px ui-monospace,Menlo,monospace;text-align:center;margin-bottom:8px";
  const st=document.createElement("div");st.style.cssText="display:flex;gap:6px;margin-bottom:12px";
  const bump=dx=>{const v=Math.max(0.01,Math.round(((+inp.value||0)+dx)*100)/100);inp.value=v.toFixed(2)};
  [[-0.05,"−0.05"],[-0.01,"−0.01"],[0.01,"+0.01"],[0.05,"+0.05"]].forEach(a=>{const b=document.createElement("button");b.type="button";b.textContent=a[1];
    b.style.cssText="flex:1;padding:8px 0;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer";b.onclick=()=>bump(a[0]);st.appendChild(b)});
  const r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
  const no=document.createElement("button"),ok=document.createElement("button");no.textContent="Cancelar";ok.textContent=okLabel||"Modificar";
  [no,ok].forEach(b=>{b.type="button";b.style.cssText="padding:8px 16px;border-radius:8px;border:1px solid #202027;background:#16161b;color:#e6ecf5;font-weight:700;cursor:pointer"});
  ok.style.borderColor="#4ff0b7";ok.style.color="#4ff0b7";
  let tmr=null;const done=v=>{clearInterval(tmr);d.remove();res(v)};no.onclick=()=>done(null);ok.onclick=()=>{const v=+inp.value;done(v>0?Math.round(v*100)/100:null)};
  if(live){   // precio EN VIVO dentro de la ventana: se actualiza cada 2 s (no cambia lo que tu escribiste)
    const lv=document.createElement("div");lv.style.cssText="border:1px solid #ffd23f;border-radius:8px;padding:8px 10px;margin:0 0 10px;font:13px ui-monospace,Menlo,monospace;color:#e6ecf5";
    lv.innerHTML='<span style="color:#7d8aa5">Cargando precio en vivo…</span>';
    const br=document.createElement("div");br.style.cssText="display:flex;gap:6px;margin-top:6px";
    const mkb=(t,f)=>{const b=document.createElement("button");b.type="button";b.textContent=t;b.style.cssText="flex:1;padding:6px 0;border-radius:7px;border:1px solid #ffd23f;background:transparent;color:#ffd23f;font-weight:700;cursor:pointer";b.onclick=f;return b};
    let last=null;const use=k=>{if(last&&last[k]>0){inp.value=last[k].toFixed(2);inp.focus()}};
    br.append(mkb("Usar medio",()=>use("mid")),mkb("Usar natural",()=>use("nat")));
    const box=document.createElement("div");box.append(lv,br);
    const tick=async()=>{try{const r=await live();if(!r)return;last=r;const t=new Date().toLocaleTimeString("es-MX",{timeZone:"America/New_York",hour12:false});
      const cur=+inp.value,pc=r.pnl?r.pnl(cur):null;
      lv.innerHTML='<b style="color:#ffd23f">● EN VIVO</b> <span style="color:#7d8aa5">'+t+'</span><br>Medio <b>$'+r.mid.toFixed(2)+'</b> <span style="color:#7d8aa5">('+r.pm+')</span> · Natural <b>$'+r.nat.toFixed(2)+'</b> <span style="color:#7d8aa5">('+r.pn+')</span>'
        +(pc!=null&&cur>0?'<br>Con tu precio $'+cur.toFixed(2)+': P&amp;L <b style="color:'+(pc>=0?"#4ff0b7":"#ff5d6c")+'">'+(pc>=0?"+":"−")+"$"+Math.abs(pc).toFixed(2)+'</b>':'')}catch(e){lv.innerHTML='<span style="color:#ff5d6c">Sin precio en vivo ahora</span>'}};
    tick();tmr=setInterval(tick,2000);inp.addEventListener("input",()=>{if(last)tick()});
    bx._live=box}
  if(extraLabel){const xb=document.createElement("button");xb.type="button";xb.textContent=extraLabel;
    xb.style.cssText="padding:8px 12px;border-radius:8px;border:1px solid #ff9f43;background:transparent;color:#ff9f43;font-weight:700;cursor:pointer;margin-right:auto";
    xb.onclick=()=>done("MKT");r.appendChild(xb)}
  d.onclick=e=>{if(e.target===d)done(null)};inp.onkeydown=e=>{if(e.key==="Enter")ok.click();if(e.key==="Escape")no.click()};
  r.append(no,ok);bx.append(t,h);if(bx._live)bx.append(bx._live);bx.append(inp,st,r);d.append(bx);(document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(d);inp.focus();inp.select()})}
async function modOrder(id,type,price){
  const hint=type==="credit"?"Crédito: BAJAR el precio lo hace más fácil de ejecutar.":type==="debit"?"Débito: SUBIR el precio lo hace más fácil de ejecutar.":"Límite: compra → subir ayuda; venta → bajar ayuda.";
  const p=await askPrice("Modificar orden #"+id,hint+"\nPrecio actual: "+(price==null?"–":"$"+(+price).toFixed(2))+". Es la misma orden: no se cancela.",price);
  if(p==null)return;
  if(price!=null&&Math.abs(p-price)<0.004){notify("Ese ya es el precio de la orden");return}
  const g=await guard("MODIFICAR la orden #"+id+"\nPrecio: "+(price==null?"–":"$"+(+price).toFixed(2))+" → $"+p.toFixed(2));
  if(!g)return;
  let j;try{j=await api("/api/modify",Object.assign({id:String(id),price:p,type:type},g))}catch(e){j={error:String(e)}}
  notify(j.error?"No se pudo modificar: "+j.error:"✓ Orden #"+id+" modificada a $"+p.toFixed(2));return j}
function notify(msg){const n=document.createElement("div");n.textContent=msg;
  n.style.cssText="position:fixed;left:50%;bottom:20px;transform:translateX(-50%);max-width:90vw;background:#0c0c0f;color:#ffc04d;border:1px solid #ffc04d;border-radius:10px;padding:10px 16px;font:13px ui-monospace,Menlo,monospace;z-index:99999;white-space:pre-wrap";
  (document.fullscreenElement||document.webkitFullscreenElement||document.body).appendChild(n);setTimeout(()=>n.remove(),7000)}

function vname(v){return v.t==="P"?(v.s.strike>v.l.strike?"Put Credit Spread":"Put Debit Spread"):(v.s.strike<v.l.strike?"Call Credit Spread":"Call Debit Spread")}
function mkCombo(exp,raw,q){
  const legs=raw.map(l=>({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,q,frac:1,l}));
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0),0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark===null||x.l.mark===undefined)okv=false;else val+=x.sg*x.l.mark*q*100}
  const gr=k=>legs.reduce((a,x)=>a+((x.l[k]===null||x.l[k]===undefined)?0:x.sg*x.l[k]*q*100),0);
  return{name:"Combinación ("+legs.length+" patas)",combo:true,exp,q,legs,entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,
    delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),strikes:legs.map(x=>x.strike+(x.type==="C"?"C":"P")).join(" / ")};
}
function mkGroup(exp,vs,q){
  const legs=[];
  for(const v of vs)for(const l of [v.s,v.l])legs.push({occ:l.occ,type:l.type,strike:l.strike,sg:l.qty<0?-1:1,q:v.q,frac:v.q/Math.abs(l.qty),l});
  legs.sort((a,b)=>a.type===b.type?a.strike-b.strike:(a.type==="P"?-1:1));
  const cost=legs.reduce((a,x)=>a+(x.l.cost||0)*x.frac,0);
  let val=0,okv=true;for(const x of legs){if(x.l.mark===null||x.l.mark===undefined)okv=false;else val+=x.sg*x.l.mark*x.q*100}
  const gr=k=>legs.reduce((a,x)=>a+((x.l[k]===null||x.l[k]===undefined)?0:x.sg*x.l[k]*x.q*100),0);
  let name;
  if(vs.length===2){const ps=vs.find(v=>v.t==="P").s.strike,cs=vs.find(v=>v.t==="C").s.strike;name=ps===cs?"Iron Fly":"Iron Condor"}
  else name=vname(vs[0]);
  return{name,exp,q,legs,entryNet:-cost/(100*q),closeNow:okv?-val/(100*q):null,pnl:okv?val-cost:null,
    delta:gr("delta"),theta:gr("theta"),vega:gr("vega"),strikes:legs.map(x=>x.strike).join(" / ")};
}
// Tradier no guarda que patas van juntas (solo cuantas unidades hay de cada opcion).
// Se empareja cada vendida con una comprada del mismo tipo minimizando la distancia total entre strikes.
function matchUnits(su,lu){
  const sw=su.length<=lu.length,A=sw?su:lu,B=sw?lu:su;
  if(!A.length)return[];
  const pair=(a,b)=>sw?[a,b]:[b,a];
  if(B.length<=6){
    let best=null,bc=1e18;const used=new Array(B.length).fill(false),cur=[];
    (function rec(i,c){
      if(c>=bc)return;
      if(i===A.length){bc=c;best=cur.slice();return}
      for(let j=0;j<B.length;j++){if(used[j])continue;used[j]=true;cur[i]=j;rec(i+1,c+Math.abs(A[i].strike-B[j].strike));used[j]=false}
    })(0,0);
    return A.map((a,i)=>pair(a,B[best[i]]));
  }
  const free=B.slice(),res=[];
  for(const a of A){let bi=0;for(let j=1;j<free.length;j++)if(Math.abs(free[j].strike-a.strike)<Math.abs(free[bi].strike-a.strike))bi=j;res.push(pair(a,free[bi]));free.splice(bi,1)}
  return res;
}
function groupPositions(legs){return grpApply(legs,groupAuto)}
function groupAuto(legs){
  const byExp={};for(const l of legs)(byExp[(l.root||"")+"|"+l.exp]=byExp[(l.root||"")+"|"+l.exp]||[]).push({...l,rem:Math.abs(l.qty)});
  const groups=[],loose=[];
  for(const key in byExp){
    const L=byExp[key],exp=L[0].exp,sym=L[0].root||"",verts=[];
    for(const t of ["P","C"]){
      const su=[],lu=[];
      for(const l of L.filter(x=>x.type===t)){const n=Math.floor(l.rem);for(let i=0;i<n;i++)(l.qty<0?su:lu).push(l)}
      const mp=new Map();
      for(const [s,c] of matchUnits(su,lu)){
        const key=s.occ+">"+c.occ;if(!mp.has(key))mp.set(key,{t,s,l:c,q:0});
        mp.get(key).q++;s.rem--;c.rem--;
      }
      for(const v of mp.values())verts.push(v);
    }
    const used=new Set(),pc=verts.filter(v=>v.t==="P"&&v.s.strike>v.l.strike),cc=verts.filter(v=>v.t==="C"&&v.s.strike<v.l.strike);
    for(const p of pc){const c=cc.find(x=>!used.has(x)&&x.q===p.q);if(c){used.add(p);used.add(c);groups.push(Object.assign(mkGroup(exp,[p,c],p.q),{sym}))}}
    const mine=[];
    for(const v of verts)if(!used.has(v))mine.push(Object.assign(mkGroup(exp,[v],v.q),{sym}));
    const lz=L.filter(l=>l.rem>0);
    /* patas sueltas + estrategia del mismo vencimiento: si en total son 3 o 4 patas con la misma cantidad, se juntan
       en una "Combinacion" para poder cerrarlas en una sola orden */
    const gk=groups.filter(g=>g.sym===sym&&g.exp===exp).concat(mine);
    const allLegs=gk.reduce((a,g)=>a+g.legs.length,0)+lz.length,q0=lz.length?Math.abs(lz[0].qty):0;
    if(lz.length&&gk.length&&allLegs<=4&&lz.every(l=>Math.abs(l.qty)===q0&&l.rem===q0)&&gk.every(g=>g.q===q0&&g.legs.every(x=>x.frac===1))){
      for(const g of gk){const ix=groups.indexOf(g);if(ix>=0)groups.splice(ix,1)}
      const raw=gk.flatMap(g=>g.legs.map(x=>x.l)).concat(lz);
      groups.push(Object.assign(mkCombo(exp,raw,q0),{sym}));
    }else{for(const g of mine)groups.push(g);for(const l of lz)loose.push(l)}
  }
  return{groups,loose};
}
const sgnc=v=>v===null||v===undefined?"":(v>0?"ok":v<0?"bad":"");
const usd=v=>v===null||v===undefined?"–":(v>=0?"+":"-")+"$"+Math.abs(v).toFixed(2);
/* ---- semaforo y barra de progreso stop -> objetivo (usa las reglas del gestor de cada posicion) ---- */
let GIT=[];
async function gestItems(){try{const r=await fetch("/api/gestor",{cache:"no-store"});const j=await r.json();return(j.items||[]).filter(i=>i.status==="activa"&&acctOf(i.live)===(window.ACCT||"paper"))}catch(e){return[]}}
function gestFor(occs){const k=occs.slice().sort().join("|");return GIT.find(i=>(i.legs||[]).slice().sort().join("|")===k)||null}
function gestState(it){if(!it||it.pnl==null||it.stop_pnl==null||it.tp_pnl==null)return null;
  const s=it.stop_pnl,t=it.tp_pnl,p=it.pnl,f=Math.max(0,Math.min(1,(p-s)/(t-s)));
  let st="ok";if(p<=s)st="bad";else if(p<=s*0.8||p>=t*0.85)st="warn";return{f,st,s,t,p}}
function rowCls(occs){const g=gestState(gestFor(occs));return g&&g.st!=="ok"?' class="pr-'+g.st+'"':""}
function barCell(occs){const g=gestState(gestFor(occs));
  if(!g)return'<td style="color:#7d8aa5;font-size:11px">sin gestor</td>';
  return'<td><span class="pbar"><i style="left:'+(g.f*100).toFixed(1)+'%"></i></span><div class="pbl"><span>'+usd(g.s)+'</span><span>'+usd(g.t)+'</span></div></td>'}

function dte(exp){const et=new Date(new Date().toLocaleString("en-US",{timeZone:"America/New_York"}));
  return Math.round((new Date(exp+"T00:00:00")-new Date(et.getFullYear(),et.getMonth(),et.getDate()))/86400000)}
window.GRP_RENDER=()=>loadPos();
/* evita el parpadeo: no reescribe una tabla si quedó igual, y si Tradier falla un momento conserva lo último bueno */
function H(el,html){if(el&&el._h!==html){el.innerHTML=html;el._h=html}}
function keepOrErr(el,err,cols){if(el&&el._ok){setErr("Tradier tardó en contestar ("+String(err).slice(0,90)+"); se muestra lo último que llegó");return}
  H(el,'<tr><td colspan="'+cols+'" class="warn">'+err+'</td></tr>')}
let POS_EMPTY=0;
async function loadPos(){
  const j=await api("/api/positions"),tb=$("pos");
  if(j.error){keepOrErr(tb,j.error,11);return}
  window.GRP_OSETS=j.osets||[];CCL=(j.legs||[]).filter(l=>l.cc);const R=groupPositions((j.legs||[]).filter(l=>!l.cc));G=R.groups;LOOSE=R.loose;GIT=await gestItems();
  for(const g of G){if(Math.abs(g.entryNet||0)<0.005){const it=gestFor(g.legs.map(x=>x.occ));   // Tradier a veces da costo 0 (orden de antes de la apertura)
    if(it&&it.entry){const e=it.kind==="credit"?it.entry:-it.entry;g.entryNet=e;g.entryFix=true;if(g.closeNow!==null)g.pnl=(e-g.closeNow)*100*g.q}}}
  smoothG(G);
  if(!G.length&&!R.loose.length&&!CCL.length&&tb._ok&&++POS_EMPTY<3)return;   // Tradier a veces manda la lista vacía un instante: espera a confirmarlo
  if(!G.length&&!R.loose.length&&!CCL.length){tb._ok=false;H(tb,'<tr><td colspan="11" style="color:#7d8aa5">Sin posiciones</td></tr>');$("posum").innerHTML="";$("posnote").textContent="";posViewFill();return}
  let tp=0,td=0,tt=0,rows="";
  G.forEach((g,i)=>{
    if(g.pnl!==null)tp+=g.pnl;td+=g.delta;tt+=g.theta;
    const cn=g.closeNow;
    rows+='<tr'+rowCls(g.legs.map(x=>x.occ))+'><td>'+grpChk(g.legs.map(x=>x.occ))+'<b>'+(g.sym?g.sym+" ":"")+g.name+'</b><br><span style="color:#7d8aa5">'+g.strikes+'</span></td><td>'+g.exp+' ('+dte(g.exp)+')</td><td>'+g.q+'</td>'
     +'<td>'+(g.entryNet>=0?"Crédito ":"Débito ")+Math.abs(g.entryNet).toFixed(2)+(g.entryFix?' <span title="Tradier dio costo 0; uso la entrada que registró el gestor" style="color:var(--mut)">*</span>':'')+'</td>'
     +'<td>'+(cn===null?"–":(cn>=0?"Débito ":"Crédito ")+Math.abs(cn).toFixed(2))+'</td>'
     +'<td class="'+sgnc(g.pnl)+'"'+(g.stale?' title="Precio de Tradier no confiable en este momento (apertura): se muestra el último P&L bueno"':'')+'><b>'+usd(g.pnl)+(g.stale?' ⏳':'')+'</b></td><td>'+g.delta.toFixed(1)+'</td><td class="'+sgnc(g.theta)+'">'+usd(g.theta)+'</td><td>'+g.vega.toFixed(1)+'</td>'
     +barCell(g.legs.map(x=>x.occ))+'<td style="white-space:nowrap">'+watchBtn(g.legs.map(x=>x.occ),g.combo?null:"adoptGroup("+i+")")+grpSplitBtn(g.legs.map(x=>x.occ))+'<button class="btn sm" title="P&L en dólares de esta posición a lo largo del tiempo (precio medio grabado cada minuto)" onclick="histModal(G['+i+'])">📈</button> <button class="btn x" style="border-color:var(--cy);color:var(--cy)" onclick="closeInline(G['+i+'])" title="Te pide el precio, hace la vista previa y confirmas aquí mismo">Cerrar</button></td></tr>';
  });
  R.loose.forEach((l,li)=>{
    const pnl=l.mark===null||l.mark===undefined?null:l.mark*l.qty*100-(l.cost||0),d=(l.delta||0)*l.qty*100,t=(l.theta||0)*l.qty*100;
    if(pnl!==null)tp+=pnl;td+=d;tt+=t;
    rows+='<tr'+rowCls([l.occ])+'><td>'+grpChk([l.occ])+'<b>Pata suelta</b><br><span style="color:#7d8aa5">'+pretty(l.occ)+'</span></td><td>'+l.exp+' ('+dte(l.exp)+')</td><td>'+l.qty+'</td><td colspan="2" style="color:#7d8aa5">'+(l.cost===null?"–":"Costo "+money(l.cost))+'</td><td class="'+sgnc(pnl)+'"><b>'+usd(pnl)+'</b></td><td>'+d.toFixed(1)+'</td><td class="'+sgnc(t)+'">'+usd(t)+'</td><td>'+((l.vega||0)*l.qty*100).toFixed(1)+'</td>'+barCell([l.occ])+'<td style="white-space:nowrap">'+watchBtn([l.occ],l.qty>0?"adoptLoose("+li+")":null)+grpLooseBtn(l)+'<button class="btn x" style="border-color:var(--cy);color:var(--cy)" onclick="closeInline(looseGroup(LOOSE['+li+']))" title="Te pide el precio, hace la vista previa y confirmas aquí mismo">Cerrar</button></td></tr>';
  });
  if(!G.length&&!R.loose.length)rows+='<tr><td colspan="11" style="color:#7d8aa5">Sin posiciones de trading abiertas</td></tr>';
  rows+=ccBlock();
  POS_EMPTY=0;tb._ok=true;H(tb,rows);posViewFill();
  $("posum").innerHTML='<div><span>'+(Object.keys(j.spots||{}).length>1?"PRECIOS AHORA":(Object.keys(j.spots||{})[0]||"SPY")+" AHORA")+'</span><b>'+(Object.keys(j.spots||{}).length>1?Object.entries(j.spots).map(([k,v])=>k+" "+v.toFixed(2)).join(" · "):(j.spot===null||j.spot===undefined?"–":j.spot.toFixed(2)))+'</b></div><div><span>P&L TOTAL ABIERTO</span><b class="'+sgnc(tp)+'">'+usd(tp)+'</b></div><div title="Dólares que ganas o pierdes por cada punto que se mueve el subyacente"><span>DELTA NETA ($/punto)</span><b>'+td.toFixed(1)+'</b></div><div><span>THETA NETA / DÍA</span><b class="'+sgnc(tt)+'">'+usd(tt)+'</b></div>'+moveBox(j.legs,j.spots);
  $("posnote").textContent="P&L con el precio medio (bid+ask)/2 de cada opción; griegas de Tradier por contrato×100. "+"«Cerrar» te pide el precio aquí mismo (con el medio y el natural de referencia), hace la vista previa y te pide confirmación; no te saca de la tabla.";
  if(S.legsEff)recompute();
  autoClose();
}
/* viene del Escaner: #pcs=SIMBOLO|vencimiento|strike vendido|ancho -> arma el put credit spread (NO envia nada: tu haces vista previa y confirmas) */
let AODONE=false;
async function autoOpen(){
  if(AODONE||!AOHASH)return;
  if(!$("exp").options.length&&(autoOpen.n=(autoOpen.n||0)+1)<20){setTimeout(autoOpen,700);return}
  AODONE=true;
  const p=decodeURIComponent(location.hash.slice(5)).split("|");history.replaceState(null,"",location.pathname);
  const sym=p[0],exp=p[1],short=+p[2],width=+p[3];
  if(!/^[A-Z][A-Z.\-]{0,5}$/.test(sym)||!/^\d{4}-\d{2}-\d{2}$/.test(exp)||!(short>=0)||!(width>0))return;
  try{
    if(SYM!==sym)await setSym(sym);
    if(![...$("exp").options].some(o=>o.value===exp)){notify("Ese vencimiento ("+exp+") ya no está disponible para "+sym+": elige uno cercano a 45 días.");return}
    $("mode").value="open";$("exp").value=exp;S.custom=null;S.dirty=false;await loadChain();
    $("strat").value="pcs";$("strat").dispatchEvent(new Event("change"));
    const ws=[...$("width").options].map(o=>+o.value),w=ws.reduce((a,b)=>Math.abs(b-width)<Math.abs(a-width)?b:a);
    $("width").value=String(w);$("width").dispatchEvent(new Event("change"));
    const ks=[...$("sp").options].map(o=>+o.value);
    if(!short){const k=pickDelta("P",0.25);if(k!==null&&ks.includes(k))$("sp").value=String(k)}else if(ks.includes(short))$("sp").value=String(short);else notify("El strike "+short+" ya no está en la lista: revisa el put vendido.");
    $("sp").dispatchEvent(new Event("change"));
    $("qty").value=1;$("qty").dispatchEvent(new Event("input"));
    for(let i=0;i<20&&!(GC&&GC.filled);i++)await new Promise(r=>setTimeout(r,250));
    S.dirty=false;recompute();
    const cr=S.mid||0;
    $("g_on").checked=true;$("g_at").value="close";$("g_at").dispatchEvent(new Event("change"));
    $("g_tp").value=Math.max(1,Math.round(cr*100*0.5));$("g_stop").value=Math.max(1,Math.round(cr*100));$("g_hex").value="";
    gHint();
    notify("🔭 Spread del escáner cargado ("+sym+" "+short+"/"+(short-w)+" · "+exp+"). Revisa el precio, las reglas del gestor (ganancia al 50% del crédito, stop = crédito) y pulsa Vista previa.");
  }catch(e){notify("No pude cargar el spread del escáner: "+(e&&e.message||e))}
}
/* viene de la pagina de inicio: #close=exp|strikes|cantidad -> carga esa posicion lista para cerrar */
let ACDONE=false;
function autoClose(){
  if(ACDONE||!location.hash.startsWith("#close="))return;
  let key="";try{key=decodeURIComponent(location.hash.slice(7))}catch(e){return}
  const i=G.findIndex(g=>g.exp+"|"+g.strikes+"|"+g.q===key);
  if(i<0){ACDONE=true;notify("Esa posición ya no está abierta (o cambió).");return}
  if(![...$("exp").options].some(o=>o.value===expVal(G[i].exp,(G[i].legs[0]||{}).occ))&&(autoClose.n=(autoClose.n||0)+1)<12){setTimeout(autoClose,700);return}
  ACDONE=true;history.replaceState(null,"",location.pathname);closeInline(G[i]);
}
let LOOSE=[],EXPI={am:new Set()};
/* valor de la lista de expiraciones para una posicion: las patas AM (raiz SPX) usan la opcion "fecha|AM" */
function expVal(exp,occ){const m=/^([A-Z]+)\d{6}[CP]/.exec(occ||"");return m&&EXPI.amRoot&&m[1]===EXPI.amRoot?exp+"|AM":exp}
/* ===== poner bajo el gestor una posicion que YA esta abierta ===== */
function watchBtn(occs,fn){
  if(gestFor(occs))return'<span style="color:#4ff0b7;font-size:12px;margin-right:6px" title="El gestor ya vigila esta posición">🤖 vigilada</span>';
  if(!fn)return'<span style="color:#7d8aa5;font-size:11px;margin-right:6px" title="El gestor no vigila combinaciones de 3 patas ni opciones vendidas sueltas">sin gestor</span>';
  return'<button class="btn x" style="border-color:#4ff0b7;color:#4ff0b7;margin-right:6px" onclick="'+fn+'" title="Que el gestor vigile esta posición con tus reglas">🤖 Vigilar</button>'}
function adoptGroup(i){const g=G[i];if(!g)return;
  adoptDlg({kind:g.entryNet>=0?"credit":"debit",qty:g.q,entry:Math.abs(g.entryNet),name:(g.sym?g.sym+" ":"")+g.name+" "+g.strikes+" · "+g.exp,
    legs:g.legs.map(x=>({occ:x.occ,side:x.sg<0?"sell_to_open":"buy_to_open"}))})}
function adoptLoose(i){const l=LOOSE[i];if(!l||l.qty<=0)return;
  adoptDlg({kind:"single",qty:l.qty,entry:(l.cost||0)/(100*l.qty),name:pretty(l.occ),legs:[{occ:l.occ,side:"buy_to_open"}]})}
function adoptDlg(P){
  const c=(GC.cfgs||{})[P.kind]||{},live=!!window.LIVE,col=live?"#ff9f43":"#5cc8ff",cr=P.kind==="credit";
  const ov=document.createElement("div");ov.style.cssText="position:fixed;inset:0;background:rgba(3,6,12,.75);z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px";
  const f=(id,lab,val,extra)=>'<label style="display:block;margin:8px 0 3px;color:#9fb0cc;font-size:12px">'+lab+'</label><input id="'+id+'" value="'+val+'" '+(extra||'type="number" step="1" min="1"')+' style="width:100%;padding:8px;border-radius:8px;border:1px solid #2a3756;background:#0a0a0d;color:#e6ecf5;font:14px ui-monospace,Menlo,monospace">';
  ov.innerHTML='<div style="max-width:440px;width:100%;max-height:90vh;overflow:auto;background:#0c0c0f;border:2px solid '+col+';border-radius:14px;padding:18px;color:#e6ecf5;font:14px -apple-system,BlinkMacSystemFont,sans-serif">'
   +'<div style="font-weight:800;color:'+col+';margin-bottom:6px">🤖 Vigilar posición ya abierta · '+(live?"CUENTA REAL":"PAPEL")+'</div>'
   +'<div style="margin-bottom:6px"><b></b></div><div style="color:#7d8aa5;font-size:12px;margin-bottom:4px">'+P.qty+' contrato(s) · '+(P.kind==="single"?"opción comprada":cr?"estrategia de crédito":"estrategia de débito")+'. No se envía ninguna orden ahora: el gestor solo empieza a vigilarla.</div>'
   +f("ad_e",(cr?"Crédito":"Precio")+" de entrada por "+(P.kind==="single"?"contrato":"spread")+" ($ por acción, según Tradier)",P.entry.toFixed(2),'type="number" step="0.01" min="0.01"')
   +f("ad_s","Stop: pérdida máx. ($ por contrato)",c.stop_usd??15)
   +f("ad_t","Objetivo: ganancia ($ por contrato)",c.tp_usd??20)
   +'<label style="display:block;margin:8px 0 3px;color:#9fb0cc;font-size:12px">Al llegar al objetivo</label><select id="ad_a" style="width:100%;padding:8px;border-radius:8px;border:1px solid #2a3756;background:#0a0a0d;color:#e6ecf5"><option value="close">Cerrar (orden límite a tu precio)</option><option value="trail">Seguir con trailing</option></select>'
   +f("ad_r","Trailing: cuánto puede devolver desde el máximo ($ por contrato)",c.trail_usd??6)
   +f("ad_h","Hora de salida el día que vence (HH:MM, Nueva York)",c.time_exit||"15:30",'type="text"')
   +'<div id="ad_err" style="color:#ff5d6c;font-size:13px;margin-top:8px"></div>'
   +'<div style="display:flex;gap:10px;margin-top:12px"><button id="ad_no" style="flex:1;padding:11px;border-radius:10px;border:2px solid #3c3c46;background:transparent;color:#e6ecf5;font-weight:800;cursor:pointer">Cancelar</button>'
   +'<button id="ad_ok" style="flex:1;padding:11px;border-radius:10px;border:2px solid '+col+';background:'+col+';color:#0a0a0d;font-weight:800;cursor:pointer">Vigilar</button></div></div>';
  ov.querySelector("b").textContent=P.name;document.body.appendChild(ov);
  const q=id=>ov.querySelector("#"+id);q("ad_a").value=c.at_target==="trail"?"trail":"close";
  const close=()=>ov.remove();q("ad_no").onclick=close;ov.addEventListener("click",e=>{if(e.target===ov)close()});
  q("ad_ok").onclick=async()=>{
    const e=+q("ad_e").value,hx=q("ad_h").value.trim();
    if(!(e>0)){q("ad_err").textContent="Escribe el precio de entrada";return}
    if(!/^\d{2}:\d{2}$/.test(hx)){q("ad_err").textContent="La hora debe ser HH:MM, por ejemplo 15:30";return}
    q("ad_ok").disabled=true;q("ad_err").textContent="";
    const j=await api("/api/gestor_adopt",{kind:P.kind,legs:P.legs,qty:P.qty,entry:e,
      cfg:{unit:"usd",stop_usd:+q("ad_s").value,tp_usd:+q("ad_t").value,at_target:q("ad_a").value,trail_usd:+q("ad_r").value,time_exit:hx}});
    if(j.error){q("ad_err").textContent=j.error;q("ad_ok").disabled=false;return}
    close();notify("🤖 El gestor ya vigila: "+P.name);if(j.cfgs){GC.d=j;GC.cfgs=j.cfgs}gLoad();loadPos()}}
/* covered calls: van aparte, plegados, y NO cuentan en el P&L / griegas del trading del día */
let CCL=[],CCOPEN=(()=>{try{return localStorage.getItem("cc_open")==="1"}catch(e){return false}})();
function ccTog(){CCOPEN=!CCOPEN;try{localStorage.setItem("cc_open",CCOPEN?"1":"0")}catch(e){}const tb=$("pos");if(tb){tb._h=null}loadPos()}
function ccBlock(){if(!CCL.length)return"";let tp=0;CCL.forEach(l=>{if(l.mark!=null)tp+=l.mark*l.qty*100-(l.cost||0)});
  let h='<tr style="background:#0b1016"><td colspan="11" style="cursor:pointer;color:#7d8aa5;font-size:12px" onclick="ccTog()">'+(CCOPEN?"▾":"▸")+' 📎 <b style="color:var(--cy)">Covered calls de tu portafolio</b> ('+CCL.length+') · '+CCL.map(l=>pretty(l.occ)).slice(0,3).join(" · ")+(CCL.length>3?" …":"")
   +' · P&L <b class="'+sgnc(tp)+'">'+usd(tp)+'</b> <span style="margin-left:6px">— son calls cubiertos por tus acciones, NO cuentan en el P&L de arriba. Se manejan en <a href="/portafolio" onclick="event.stopPropagation()">Portafolio</a>.</span></td></tr>';
  if(CCOPEN)CCL.forEach((l,ci)=>{const pnl=l.mark==null?null:l.mark*l.qty*100-(l.cost||0);
    h+='<tr style="background:#0b1016"><td><b style="color:var(--cy)">📎 Covered call</b><br><span style="color:#7d8aa5">'+pretty(l.occ)+'</span></td><td>'+l.exp+' ('+dte(l.exp)+')</td><td>'+l.qty+'</td><td colspan="2" style="color:#7d8aa5">'+(l.cost==null?"–":"Prima cobrada "+money(Math.abs(l.cost)))+'</td><td class="'+sgnc(pnl)+'"><b>'+usd(pnl)+'</b></td><td colspan="4" style="color:#7d8aa5;font-size:12px">cubierto con '+(100*Math.abs(l.qty))+' acciones de '+l.root+'</td><td style="white-space:nowrap"><button class="btn x" style="border-color:var(--cy);color:var(--cy)" onclick="closeInline(looseGroup(CCL['+ci+']))" title="Recomprar el call (te pide precio y confirmas)">Recomprar</button></td></tr>'});
  return h}
function looseGroup(l){if(!l)return null;const q=Math.abs(l.qty);
  return{sym:l.root||SYM,exp:l.exp,q,name:"Pata suelta",strikes:pretty(l.occ),entryNet:l.qty>0?-(l.cost||0)/(100*q):(Math.abs(l.cost||0))/(100*q),
    legs:[{type:l.type,strike:l.strike,sg:l.qty<0?-1:1,occ:l.occ,l}]}}
/* CERRAR AQUI MISMO: precio -> vista previa -> confirmacion, sin ir al constructor */
async function closeInline(g){
  if(!g)return;
  if(g.legs.length>4){notify("Esta posición tiene "+g.legs.length+" patas y Tradier acepta máximo 4 por orden. Desármala (✂) y ciérrala por partes.");return}
  const q=Math.min(10,g.q);if(g.q>10)notify("Tiene "+g.q+" contratos; se cierran 10 en esta orden (envía otra para el resto).");
  // valor de cierre por unidad: + recibes / − pagas
  let mid=0,nat=0,ok=true;
  for(const x of g.legs){const l=x.l||{},b=num(l.bid),a=num(l.ask),r=x.ratio||1;
    if(b===null||a===null){ok=false;break}
    if(x.sg>0){mid+=r*(b+a)/2;nat+=r*b}else{mid-=r*(b+a)/2;nat-=r*a}}
  if(!ok){notify("No hay precio de compra/venta para alguna pata; intenta en unos segundos.");return}
  const typ=mid>=0?"credit":"debit",am=Math.abs(mid),an=Math.abs(nat),tick=/^SPX|^NDX|^RUT/.test((g.legs[0].occ||""))?0.05:0.01;
  const rnd=v=>Math.max(0.01,Math.round(v/tick)*tick);
  const entry=g.entryNet;   // + credito cobrado / − debito pagado (por unidad)
  const pnlAt=p=>(entry+(typ==="credit"?p:-p))*100*q;
  const hint=(typ==="credit"?"Recibes CRÉDITO al cerrar":"Pagas DÉBITO al cerrar")+" · "+q+" contrato(s)\nMedio $"+am.toFixed(2)+" (P&L "+money(pnlAt(am))+") · Natural $"+an.toFixed(2)+" (P&L "+money(pnlAt(an))+")\n"+(typ==="credit"?"Bajar el precio = más fácil que se llene.":"Subir el precio = más fácil que se llene.");
  const occs=g.legs.map(x=>x.occ);
  const liveFn=async()=>{const j=await api("/api/positions");if(!j||j.error)return null;const by={};for(const l of j.legs||[])by[l.occ]=l;
    let m=0,n=0;for(const x of g.legs){const l=by[x.occ];if(!l)return null;const b=num(l.bid),a=num(l.ask),r=x.ratio||1;if(b===null||a===null)return null;
      if(x.sg>0){m+=r*(b+a)/2;n+=r*b}else{m-=r*(b+a)/2;n-=r*a}}
    const M=Math.abs(m),N=Math.abs(n);return{mid:M,nat:N,pm:"P&L "+money(pnlAt(M)),pn:"P&L "+money(pnlAt(N)),pnl:pnlAt}};
  const p=await askPrice("Cerrar "+(g.sym?g.sym+" ":"")+g.name+" "+g.strikes,hint,rnd(am),"Vista previa","⚡ A mercado",liveFn);if(p==null)return;
  const mk=p==="MKT";
  const legs=g.legs.map(x=>({occ:x.occ,side:x.sg>0?"sell_to_close":"buy_to_close",ratio:x.ratio||1}));
  const body=mk?{symbol:g.sym||SYM,type:"market",kind:typ,qty:q,legs,combo:!!g.combo||legs.length===3||legs.some(l=>l.ratio>1)}
               :{symbol:g.sym||SYM,type:typ,qty:q,price:+p.toFixed(2),legs,combo:!!g.combo||legs.length===3||legs.some(l=>l.ratio>1)};
  const pv=await api("/api/preview",body);if(pv.error){notify("✖ "+pv.error);return}
  const o=pv.preview||{};
  const gi=gestFor(g.legs.map(x=>x.occ));
  const txt="CERRAR "+q+"× "+(g.sym?g.sym+" ":"")+g.name+" "+g.strikes+"\n"+(mk?"⚡ A MERCADO: se llena al precio que haya.\nReferencia ahora: natural $"+an.toFixed(2)+" (P&L "+money(pnlAt(an))+")":(typ==="credit"?"Crédito":"Débito")+" límite $"+p.toFixed(2)+"\nP&L si se llena a ese precio: "+money(pnlAt(p)))
    +(o.commission!==undefined?"\nComisión: $"+o.commission:"")+(gi?"\n\n🤖 El gestor la vigila: cuando se cierre la dará por cerrada sola.":"");
  const gd=await guard(txt);if(!gd)return;
  const j=await api("/api/order",Object.assign({},body,gd));
  notify(j.error?"✖ No se envió: "+j.error:"✔ Orden de cierre enviada (#"+((j.order||{}).id||"?")+"). Mírala en Órdenes; ahí puedes ajustar el precio.");
  loadOrders();loadPos()}
function closeLoose(i){
  const l=LOOSE[i];if(!l)return;const q=Math.abs(l.qty);
  closeGroup(-1,{sym:l.root||SYM,exp:l.exp,q,name:"Pata suelta",strikes:pretty(l.occ),entryNet:l.qty>0?-(l.cost||0)/(100*q):(Math.abs(l.cost||0))/(100*q),
    legs:[{type:l.type,strike:l.strike,sg:l.qty<0?-1:1,occ:l.occ}]});
}
function undOf(r){return({SPXW:"SPX",RUTW:"RUT",NDXP:"NDX",VIXW:"VIX"})[r]||r}
/* selector "Ver en la grafica": muestra cualquier posicion abierta con su entrada real (vencimiento, hoy T+0 y precio del dia) */
let PVK="",PVMISS=0;
function pvKey(g){return (g.sym||"")+"|"+g.exp+"|"+g.strikes+"|"+g.q}
function posViewFill(){const sel=$("posview");if(!sel)return;const cur=PVK;
  const k=G.findIndex(g=>pvKey(g)===cur);
  if(cur&&k<0&&++PVMISS<3)return;   // si Tradier no la manda un instante, no quites el visor (espera a confirmarlo 3 veces)
  if(k>=0)PVMISS=0;
  const html='<option value="">La estrategia del constructor</option>'+G.map((g,i)=>'<option value="'+i+'">'+gesc((g.sym?g.sym+" ":"")+g.name+" "+g.strikes+" · "+g.exp+" · "+g.q+" ctr")+'</option>').join("");
  if(sel._h!==html){sel.innerHTML=html;sel._h=html}
  sel.value=k>=0?String(k):"";if(cur&&k<0){PVK="";PVMISS=0;if(S.custom&&S.custom.view){S.custom=null;$("mode").value="open";recompute()}}}
async function posView(v){if(v===""){PVK="";S.custom=null;$("mode").value="open";S.dirty=false;recompute();return}
  const g=G[+v];if(!g)return;PVK=pvKey(g);await closeGroup(+v,null,true);if(S.custom)S.custom.view=true;
  $("ctitle").textContent="VIENDO TU POSICIÓN · GANANCIA / PÉRDIDA";}
async function closeGroup(i,gx,noScroll){
  const g=gx||G[i];if(!g)return;
  if(g.legs.length>4){notify("Esta posición tiene "+g.legs.length+" patas y Tradier acepta máximo 4 por orden. Desármala (✂) y ciérrala por partes.");return}
  const und=undOf(g.sym);   // SPXW -> SPX, RUTW -> RUT, NDXP -> NDX (la cadena se pide por el indice)
  if(und&&und!==SYM){await setSym(und,true);for(let k=0;k<20&&!$("exp").options.length;k++)await new Promise(r=>setTimeout(r,250))}
  const ev=expVal(g.exp,(g.legs[0]||{}).occ);
  if(![...$("exp").options].some(o=>o.value===ev)){notify("La expiración "+g.exp+" no está en la lista cargada.");return}
  $("exp").value=ev;await loadChain();
  S.custom={exp:ev,by:S.by,name:g.name+" "+g.strikes,openType:g.entryNet>=0?"credit":"debit",entry:g.entryNet,combo:!!g.combo,
    legs:g.legs.map(x=>({t:x.type,k:x.strike,act:x.sg>0?"buy":"sell",ratio:x.ratio||1}))};
  $("mode").value="close";$("qty").value=Math.min(10,g.q);S.dirty=false;S.lastKey=null;showRes("","");
  recompute();if(!noScroll)window.scrollTo({top:0,behavior:"smooth"});
  if(g.q>10)notify("Esta posición tiene "+g.q+" contratos; la página envía máximo 10 por orden. Ciérrala en varias órdenes.");
}
function setHeadSym(){$("h1t").textContent=SYM+" · TRADING MANUAL";$("usym").value=SYM;document.title=SYM+" Trading Manual"}
async function setSym(v,keepClose){
  SYM=v;try{localStorage.setItem("tsym",v)}catch(e){}
  S.custom=null;S.by={C:{},P:{}};S.strikes=[];S.spot=null;S.legsEff=null;S.lastKey=null;S.dirty=false;$("bsend").disabled=true;showRes("","");
  $("exp").innerHTML="";$("chain")._h=null;$("chain").innerHTML='<tr><td colspan="12" style="color:#7d8aa5">Cargando '+v+'…</td></tr>';$("legs").innerHTML="";
  if(!keepClose)$("mode").value="open";
  setHeadSym();$("spot").textContent=v+" …";
  await loadExps();loadQuote()}
let usT=null;
$("usym").addEventListener("focus",()=>$("usym").select());
$("usym").addEventListener("input",()=>{clearTimeout(usT);const q=$("usym").value.trim();if(!q)return;
  usT=setTimeout(async()=>{try{const j=await api("/api/search?q="+encodeURIComponent(q));
    if(j.results)$("usl").innerHTML=j.results.map(r=>'<option value="'+r.sym+'" label="'+String(r.name+(r.ex?" · "+r.ex:"")).replace(/"/g,"")+'"></option>').join("")}catch(e){}},250)});
$("usym").addEventListener("change",()=>{const v=$("usym").value.trim().toUpperCase();
  if(/^[A-Z][A-Z.\-]{0,5}$/.test(v)){if(v!==SYM)setSym(v)}else{$("usym").value=SYM;setErr("Símbolo no válido")}});
$("usym").addEventListener("keydown",e=>{if(e.key==="Enter")$("usym").blur()});
async function loadQuote(){
  const sym0=SYM,j=await api("/api/quote?sym="+encodeURIComponent(SYM));if(sym0!==SYM)return;if(j.error){$("spot").textContent=SYM+" –";setErr(j.error);return}
  $("spot").innerHTML=SYM+" "+f2(j.last)+' <span class="'+((j.chg||0)>=0?"ok":"bad")+'" style="font-size:14px">'+((j.chg||0)>=0?"+":"")+f2(j.chg)+'%</span>';
}
async function loadAcct(){const j=await api("/api/account");if(!j.error)$("acct").textContent="Equity "+(j.equity===null?"–":money(j.equity,0))+(j.option_bp===null?"":" · Poder opciones "+money(j.option_bp,0))+USO}
/* contador de consultas a Tradier (para descartar que la terminal lo sature) */
let USO="";async function loadUso(){try{const u=await api("/api/uso");if(u&&u.ultimo_minuto!=null){const td=Object.values(u.tradier_dice||{});const q=td.length?Math.min(...td.map(x=>+x.quedan||1e9)):null;
  USO=" · Tradier: "+u.ultimo_minuto+" consultas/min"+(q!=null&&q<1e9?" (quedan "+q+")":"")+(u.limite_429_hoy?" · ⚠ "+u.limite_429_hoy+" rechazos por límite hoy":"");
  const e=$("acct");if(e){e.title="Consultas a Tradier en el último minuto: "+u.ultimo_minuto+" · máximo hoy "+u.maximo_hoy+" ("+(u.maximo_hoy_a_las||"–")+") · lentas (>3 s) en el último minuto: "+u.lentas_1min+" · más pedidas: "+(u.mas_pedidas_1min||[]).map(x=>x[0]+" "+x[1]).join(", ")}}}catch(e){}}
loadUso();setInterval(()=>{if(!document.hidden)loadUso()},10000);
let NK=20;try{const v=localStorage.getItem("nk");if(v)NK=v==="all"?"all":+v}catch(e){}
function nkPaint(){const e=$("nkbar");if(!e)return;e.innerHTML=[20,40,60,"all"].map(v=>'<button type="button" class="btn sm" style="padding:3px 9px;margin-left:3px;'+(NK===v?"background:var(--cy);color:#06101e":"")+'" onclick="nkSet(\''+v+'\')">'+(v==="all"?"Todos":v)+'</button>').join("")}
function nkSet(v){NK=v==="all"?"all":+v;try{localStorage.setItem("nk",String(NK))}catch(e){}S.centered=null;nkPaint();renderChain()}
function renderChain(){
  if(!S.strikes.length||!S.spot)return;nkPaint();
  const lm={};if(!(S.custom&&S.custom.exp&&S.custom.exp!==$("exp").value))for(const l of (S.legsEff||[]))lm[l.t+l.k]=l.act;
  const hc=(t,k)=>lm[t+k]?(lm[t+k]==="buy"?" hb":" hs"):"";
  /* movimiento esperado = precio del straddle en el strike mas cercano (call medio + put medio) */
  const ka=nearest(S.spot),ca=S.by.C[ka]||{},pa=S.by.P[ka]||{},md=r=>{const b=num(r.bid),a=num(r.ask);return b===null||a===null?null:(b+a)/2};
  const em=md(ca)!==null&&md(pa)!==null?md(ca)+md(pa):null,emLo=em?S.spot-em:null,emHi=em?S.spot+em:null;
  const el=$("emline");if(el)el.innerHTML='Calls a la izquierda · puts a la derecha · <span style="background:rgba(255,210,63,.18);padding:0 4px;border-radius:4px">sombreado</span> = dentro del dinero'+(em?' · <b style="color:#b48cff">▌ movimiento esperado ±'+em.toFixed(2)+' ('+(100*em/S.spot).toFixed(2)+'%): '+emLo.toFixed(2)+' a '+emHi.toFixed(2)+'</b> <span title="Precio del straddle en '+ka+' (call medio + put medio) para este vencimiento">ⓘ</span>':"");
  let spotDone=false;const spotRow=()=>'<tr class="spotrow" id="spotrow"><td colspan="12">▶ '+SYM+' AHORA '+S.spot.toFixed(2)+' ◀</td></tr>';
  /* cuantos strikes ver: los N mas cercanos al precio (mitad arriba, mitad abajo) + los que tengas marcados */
  let pick=S.strikes;if(NK!=="all"){const below=S.strikes.filter(k=>k<=S.spot),above=S.strikes.filter(k=>k>S.spot),h=NK/2;
    pick=below.slice(-Math.ceil(h)).concat(above.slice(0,Math.floor(h)))}
  const ps=new Set(pick);const rows=[];const near=S.strikes.filter(k=>ps.has(k)||lm["C"+k]||lm["P"+k]);
  const inEm=near.filter(k=>em&&k>=emLo&&k<=emHi);
  /* open interest y volumen: barrita de fondo proporcional al mayor de lo que se ve; el mayor de cada columna en negritas */
  const mx=(t,f)=>Math.max(1,...near.map(k=>num((S.by[t][k]||{})[f])||0));
  const MX={Coi:mx("C","oi"),Cvol:mx("C","vol"),Poi:mx("P","oi"),Pvol:mx("P","vol")};
  const fk=v=>v===null?"–":v>=1e6?(v/1e6).toFixed(1)+"M":v>=1e4?Math.round(v/1e3)+"k":v>=1e3?(v/1e3).toFixed(1)+"k":String(Math.round(v));
  const bar=(t,f,r,right)=>{const v=num(r[f]),m=MX[t+f],w=v?Math.round(100*v/m):0,col=f==="oi"?"92,200,255":"255,210,63";
    return'<td class="oiv" style="background:linear-gradient(to '+(right?"left":"right")+',rgba('+col+',.22) '+w+'%,transparent '+w+'%);'+(v&&v===m?"font-weight:800;color:var(--tx)":"")+'">'+fk(v)+'</td>'};
  const gx=r=>{const g=num(r.gamma),o=num(r.oi);return g&&o?g*o*100*S.spot*S.spot*0.01:0},GX={};let gm=1;
  for(const k of near){GX[k]=gx(S.by.C[k]||{})-gx(S.by.P[k]||{});gm=Math.max(gm,Math.abs(GX[k]))}
  const gok=GEXON&&GEX&&!GEX.error&&!GEX.loading&&GEX.sym===gexSym(SYM);
  const fl=gok&&GEX.flip?near.reduce((b,k)=>Math.abs(k-GEX.flip)<Math.abs(b-GEX.flip)?k:b,near[0]):null;
  const badge=k=>gok?((k===GEX.call_wall?' <span class="gxb" style="background:#4ff0b7" title="Call wall: strike con más gamma de calls">CW</span>':'')+(k===GEX.put_wall?' <span class="gxb" style="background:#ff5d6c" title="Put wall: strike con más gamma de puts">PW</span>':'')+(k===fl?' <span class="gxb" style="background:#ffa726" title="Gamma flip ≈ '+GEX.flip+'">⚖</span>':'')+(k===GEX.key?' <span class="gxb" style="background:#ffd23f" title="Strike clave: el de más gamma en total">⭐</span>':'')):'';
  const gcell=k=>{const v=GX[k],w=Math.round(100*Math.abs(v)/gm),col=v>=0?"79,240,183":"255,93,108";
    return '<td class="oiv" style="background:linear-gradient(to right,rgba('+col+',.25) '+w+'%,transparent '+w+'%);color:'+(v>=0?"#7fe8c4":"#ff8a95")+'">'+(v?(v<0?"−":"+")+gfmt(Math.abs(v)):"–")+'</td>'};
  for(const k of near){const c=S.by.C[k]||{},p=S.by.P[k]||{};const atm=Math.abs(k-S.spot)<Math.max(0.5,S.spot*0.0008);
    const cc='data-t="C" data-k="'+k+'"',pc='data-t="P" data-k="'+k+'"';
    if(!spotDone&&k>S.spot){rows.push(spotRow());spotDone=true}
    const ic=k<S.spot?" itm":"",ip=k>S.spot?" itm":"",cl=(t,extra)=>'class="pk'+(t==="C"?ic:ip)+hc(t,k)+(extra||"")+'"';
    const sk=em&&k>=emLo&&k<=emHi?(k===inEm[0]||k===inEm[inEm.length-1]?" emedge":" em"):"";
    const dl=r=>num(r.delta)===null?"–":r.delta.toFixed(2);
    rows.push('<tr class="'+(atm?"atm":"")+'">'
      +bar("C","oi",c,false)+bar("C","vol",c,false)+'<td '+cl("C")+' '+cc+'>'+dl(c)+'</td><td data-s="sell" '+cl("C")+' '+cc+'>'+f2(num(c.bid))+'</td><td data-s="buy" '+cl("C")+' '+cc+'>'+f2(num(c.ask))+'</td>'
      +'<td class="'+sk.trim()+'"><b>'+k+'</b>'+badge(k)+'</td>'
      +'<td data-s="buy" '+cl("P")+' '+pc+'>'+f2(num(p.ask))+'</td><td data-s="sell" '+cl("P")+' '+pc+'>'+f2(num(p.bid))+'</td><td '+cl("P")+' '+pc+'>'+dl(p)+'</td>'+bar("P","vol",p,true)+bar("P","oi",p,true)+gcell(k)+'</tr>')}
  if(!spotDone)rows.push(spotRow());
  H($("chain"),rows.join(""));
  const ck=SYM+"|"+$("exp").value;   // centra en el precio solo al cambiar simbolo o vencimiento (no en cada actualizacion)
  if(S.centered!==ck){const b=document.querySelector(".chainbox"),r=$("spotrow");if(b&&r){b.scrollTop=Math.max(0,r.offsetTop-b.clientHeight/2);S.centered=ck}}
}
/* boton Limpiar: borra todo y deja el constructor en modo Libre */
function clearStrikes(){if(!S.strikes.length)return;
  if(S.custom){S.custom=null;$("mode").value="open"}
  $("strat").value="free";S.free=[];   // siempre queda en modo Libre, listo para tocar la cadena
  S.dirty=false;S.lastKey=null;$("bsend").disabled=true;showRes("","");gFill();gBoxShow();recompute();notify("🧹 Strikes limpios · modo Libre: toca Bid para vender o Ask para comprar")}
function pickStrike(t,k){if(S.custom)return;const ins=STR[$("strat").value].inputs;const id=(t==="P"?["sp","lp","ct"]:["sc","lc","ct"]).find(x=>ins.includes(x));
  if(!id)return;$(id).value=k;S.dirty=false;recompute()}
$("chain").addEventListener("click",e=>{const td=e.target.closest("td[data-k]");if(!td)return;
  if(!S.custom&&$("strat").value==="free"){if(td.dataset.s)freeAdd(td.dataset.t,+td.dataset.k,td.dataset.s);return}
  pickStrike(td.dataset.t,+td.dataset.k)});
$("strat").addEventListener("change",()=>{const v=$("strat").value;if(v==="bfc"||v==="bwp"){if(S.strikes.length)freePreset(v);else $("strat").value="free"}});
for(const id of ["strat","mode","width","qty","sp","sc","lp","lc","ct"])$(id).addEventListener("change",()=>{
  if(id==="strat"||(id==="mode"&&$("mode").value==="open"))S.custom=null;S.dirty=false;recompute()});
$("bexit").onclick=()=>{S.custom=null;PVK="";const pv=$("posview");if(pv)pv.value="";$("mode").value="open";S.dirty=false;recompute()};
$("price").addEventListener("input",()=>{S.dirty=true;recompute();gHint()});
for(const id of ["strat","mode"])$(id).addEventListener("change",()=>{gFill();gBoxShow()});
for(const id of ["g_stop","g_tp","g_trl","g_at","qty"])$(id).addEventListener(id==="g_at"||id==="qty"?"change":"input",gHint);
gBoxShow();gLoad();setInterval(()=>{if(!document.hidden)gLoad()},3000);setInterval(gBoxShow,600);
$("exp").addEventListener("change",()=>{if(S.custom&&S.custom.view){S.dirty=false;loadChain();return}   // viendo tu posicion: solo cambia la cadena, el visor se queda
  S.custom=null;S.dirty=false;loadChain()});
$("exp2").addEventListener("change",()=>{const a=$("exp");a.value=$("exp2").value;a.dispatchEvent(new Event("change"))});
$("bmid").onclick=()=>{S.mkt=false;mktPaint();S.dirty=false;recompute()};
$("bnat").onclick=()=>{S.mkt=false;mktPaint();S.dirty=true;$("price").value=S.nat.toFixed(2);recompute()};
S.mkt=false;
function mktPaint(){const b=$("bmkt"),on=S.mkt;b.style.background=on?"#ff9f43":"";b.style.color=on?"#2e1600":"";b.textContent=on?"⚡ A MERCADO (activo)":"⚡ Mercado";
  $("price").disabled=on;$("price").style.opacity=on?".35":"";if(on)$("plabel").textContent="A MERCADO: sin precio límite"}
$("bmkt").onclick=()=>{S.mkt=!S.mkt;S.lastKey=null;$("bsend").disabled=true;showRes(S.mkt?"⚡ Orden A MERCADO: haz la vista previa. Se llena al precio que haya; en spreads de SPX puede salir bastante peor que el medio.":"","warn");recompute();mktPaint()};
$("bprev").onclick=doPreview;$("bsend").onclick=doSend;
setHeadSym();applyVis();loadQuote();loadAcct();loadExps();loadOrders();loadPos();
setInterval(()=>{if(!document.hidden)loadQuote()},5000);setInterval(()=>{if(!document.hidden){loadOrders();loadPos();loadAcct()}},3000);
document.addEventListener("visibilitychange",()=>{if(!document.hidden){loadQuote();loadOrders();loadPos();loadAcct();gLoad()}});   // al volver a la pestaña, actualiza enseguida
let CHT=0;setInterval(()=>{if(!$("exp").value||document.hidden)return;const near=$("exp").selectedIndex<=1,now=Date.now();if(now-CHT>=(near?5000:15000)){CHT=now;loadChain(true)}},1000);   // 0DTE / 1 día: cada 5 s; resto cada 15 s
</script>
<style>.card{position:relative}.cbtn{position:absolute;top:6px;right:8px;width:26px;height:22px;line-height:18px;padding:0;text-align:center;border:1px solid var(--line,#202027);border-radius:6px;background:transparent;color:var(--mut,#7d8aa5);font:700 15px ui-monospace,Menlo,monospace;cursor:pointer;z-index:3}.cbtn:hover{color:var(--tx,#e6ecf5);border-color:var(--cy,#5cc8ff)}
.card.mini>*:not(.kp):not(.cbtn){display:none!important}.card.mini{padding-bottom:10px}.card.mini .kp{margin-bottom:0!important}
.cbar{display:flex;gap:8px;justify-content:flex-end;margin:0 0 8px}.cbar button{background:transparent;border:1px solid var(--line,#202027);color:var(--mut,#7d8aa5);border-radius:7px;padding:3px 9px;font:600 12px ui-monospace,Menlo,monospace;cursor:pointer}.cbar button:hover{color:var(--tx,#e6ecf5)}</style>
<script>
(function(){
  const PG=location.pathname+(location.search.indexOf("embed")>=0?"?e":"");
  const get=k=>{try{return localStorage.getItem(k)}catch(e){return null}},set=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
  const cards=[...document.querySelectorAll(".card")].filter(c=>c.id!=="gcard"&&c.querySelector(":scope>h2,:scope>.lbl"));
  const apply=(c,mini,save)=>{c.classList.toggle("mini",mini);const b=c.querySelector(":scope>.cbtn");if(b){b.textContent=mini?"+":"_";b.title=mini?"Expandir":"Contraer"}if(save)set(c._k,mini?"1":"0")};
  cards.forEach(c=>{const h=c.querySelector(":scope>h2,:scope>.lbl");h.classList.add("kp");
    c._k="mini:"+PG+":"+h.textContent.trim().slice(0,28);
    const b=document.createElement("button");b.type="button";b.className="cbtn";b.onclick=()=>apply(c,!c.classList.contains("mini"),true);c.appendChild(b);
    apply(c,get(c._k)==="1",false)});
  const host=document.querySelector("main");
  if(host&&cards.length>2){const bar=document.createElement("div");bar.className="cbar";
    bar.innerHTML='<button type="button" id="cb_min">_ Contraer todo</button><button type="button" id="cb_max">+ Expandir todo</button>';
    host.insertBefore(bar,host.firstChild);
    bar.querySelector("#cb_min").onclick=()=>cards.forEach(c=>apply(c,true,true));bar.querySelector("#cb_max").onclick=()=>cards.forEach(c=>apply(c,false,true))}
})();
</script>
</body></html>"""
