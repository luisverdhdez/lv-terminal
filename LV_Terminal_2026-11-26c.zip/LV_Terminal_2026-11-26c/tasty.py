"""tastytrade: saldo, posiciones y (etapa 3, 25-nov-2026) ORDENES de tu cuenta de tastytrade.
Ver la cuenta necesita el permiso 'read'; mandar ordenes necesita tambien el permiso 'trade' del grant. Usa la API oficial con OAuth:
  TASTY_CLIENT_SECRET, TASTY_REFRESH_TOKEN (y opcional TASTY_CLIENT_ID, TASTY_ACCOUNT) en ~/.tradier_env.
El refresh token no vence; con el se pide un pase de 15 minutos (access token) que se renueva solo.
Los datos solo se mandan a tastytrade (api.tastyworks.com)."""
import re
import threading
import time
from datetime import date, datetime

import requests

PROD = "https://api.tastyworks.com"
CERT = "https://api.cert.tastyworks.com"
UA = "LVOptionsTerminal/1.0"
_lock = threading.Lock()
_TOK = {}        # (secret, refresh) -> (access_token, expira_ts)
_CACHE = {}      # clave -> (ts, datos)


class TastyError(Exception):
    pass


def ready(env):
    return bool(env.get("TASTY_CLIENT_SECRET") and env.get("TASTY_REFRESH_TOKEN"))


def _base(env):
    return CERT if env.get("TASTY_ENV") == "sandbox" else PROD


def _token(base, secret, refresh, force=False):
    k = (base, secret, refresh)
    with _lock:
        hit = _TOK.get(k)
        if hit and not force and time.time() < hit[1]:
            return hit[0]
        try:
            r = requests.post(base + "/oauth/token", timeout=15,
                              headers={"User-Agent": UA, "Content-Type": "application/json", "Accept": "application/json"},
                              json={"grant_type": "refresh_token", "refresh_token": refresh, "client_secret": secret})
        except requests.RequestException as e:
            raise TastyError(f"No pude conectar con tastytrade ({e.__class__.__name__}). Revisa tu internet.")
        if r.status_code in (400, 401, 403):
            raise TastyError("tastytrade rechazó los datos de acceso. Revisa que el Client Secret y el refresh token "
                             "estén bien copiados (completos, sin espacios). Si borraste el grant, crea uno nuevo.")
        if r.status_code >= 400:
            raise TastyError(f"tastytrade respondió con error {r.status_code} al pedir el acceso.")
        tok = (r.json() or {}).get("access_token")
        if not tok:
            raise TastyError("tastytrade no devolvió el pase de acceso.")
        _TOK[k] = (tok, time.time() + 13 * 60)   # dura 15 min; se renueva antes
        return tok


def _get(env, path, params=None, base=None, secret=None, refresh=None):
    base = base or _base(env)
    secret = secret or env.get("TASTY_CLIENT_SECRET", "")
    refresh = refresh or env.get("TASTY_REFRESH_TOKEN", "")
    for intento in (0, 1):
        tok = _token(base, secret, refresh, force=bool(intento))
        try:
            r = requests.get(base + path, params=params, timeout=20,
                             headers={"User-Agent": UA, "Authorization": "Bearer " + tok, "Accept": "application/json"})
        except requests.RequestException as e:
            raise TastyError(f"No pude conectar con tastytrade ({e.__class__.__name__}).")
        if r.status_code == 401 and not intento:
            continue          # el pase vencio: se pide otro una vez
        if r.status_code >= 400:
            raise TastyError(f"tastytrade respondió con error {r.status_code} en {path.split('?')[0]}.")
        return r.json() or {}
    raise TastyError("tastytrade no aceptó el pase de acceso.")


def _err_msg(r):
    """Texto del error que manda tastytrade (error.message y error.errors[].message)."""
    try:
        e = (r.json() or {}).get("error") or {}
    except ValueError:
        return ""
    if not isinstance(e, dict):
        return str(e)[:200]
    parts = [str(e.get("message") or "")] + [str(x.get("message") or x.get("code") or "") for x in (e.get("errors") or []) if isinstance(x, dict)]
    return " · ".join(p for p in parts if p)[:300]


def send(env, method, path, body=None, params=None):
    """POST / PUT / DELETE / GET a tastytrade con el mensaje de error de tastytrade (para ordenes)."""
    base = _base(env)
    secret, refresh = env.get("TASTY_CLIENT_SECRET", ""), env.get("TASTY_REFRESH_TOKEN", "")
    for intento in (0, 1):
        tok = _token(base, secret, refresh, force=bool(intento))
        try:
            r = requests.request(method, base + path, json=body, params=params, timeout=20,
                                 headers={"User-Agent": UA, "Authorization": "Bearer " + tok, "Accept": "application/json",
                                          "Content-Type": "application/json"})
        except requests.RequestException as e:
            raise TastyError(f"No pude conectar con tastytrade ({e.__class__.__name__}). La orden NO se mandó; revisa en tastytrade.")
        if r.status_code == 401 and not intento:
            continue
        if r.status_code == 403:
            m = _err_msg(r)
            raise TastyError("tastytrade no dejó hacer esto: tu acceso no tiene permiso para OPERAR. Crea un grant nuevo en tastytrade "
                             "con los permisos 'read' y 'trade' y pega el refresh token en /tasty." + (f" (tastytrade: {m})" if m else ""))
        if r.status_code >= 400:
            m = _err_msg(r)
            raise TastyError(f"tastytrade rechazó la orden: {m}" if m else f"tastytrade respondió con error {r.status_code}.")
        _CACHE.pop("res", None)   # despues de una orden, saldo y posiciones vienen frescos
        try:
            return r.json() or {}
        except ValueError:
            return {}
    raise TastyError("tastytrade no aceptó el pase de acceso.")


def account_id(env):
    """Numero de la cuenta de tastytrade con la que trabaja la terminal (TASTY_ACCOUNT o la primera)."""
    acc = accounts(env)
    if not acc:
        raise TastyError("No encontré cuentas abiertas en tastytrade.")
    want = env.get("TASTY_ACCOUNT") or ""
    return next((x for x in acc if x["id"] == want), acc[0])["id"]


def _items(j):
    d = j.get("data") if isinstance(j, dict) else None
    if isinstance(d, dict):
        return d.get("items") or []
    return []


def accounts(env, **kw):
    if not kw:
        hit = _CACHE.get("acc")
        if hit and time.time() - hit[0] < 600:
            return hit[1]
    out = []
    for it in _items(_get(env, "/customers/me/accounts", **kw)):
        a = it.get("account") or {}
        if a.get("account-number") and not a.get("is-closed"):
            out.append({"id": a["account-number"], "name": a.get("nickname") or a.get("account-type-name") or "",
                        "type": a.get("account-type-name") or "", "margin": a.get("margin-or-cash") or ""})
    if not kw:
        _CACHE["acc"] = (time.time(), out)
    return out


def verify(secret, refresh, sandbox=False):
    """Prueba los datos antes de guardarlos. -> lista de cuentas."""
    secret, refresh = str(secret or "").strip(), str(refresh or "").strip()
    if not re.match(r"^[A-Za-z0-9._\-]{8,600}$", secret) or not re.match(r"^[A-Za-z0-9._\-]{8,4000}$", refresh):
        raise TastyError("Pega el Client Secret y el refresh token completos (sin espacios).")
    base = CERT if sandbox else PROD
    acc = accounts({}, base=base, secret=secret, refresh=refresh)
    if not acc:
        raise TastyError("Los datos son correctos pero no encontré cuentas abiertas en tastytrade.")
    return acc


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


OCC_TT = re.compile(r"^([A-Z./]{1,6})\s*(\d{2})(\d{2})(\d{2})([CP])(\d{8})$")


def _norm(p):
    sym = str(p.get("symbol") or "")
    typ = p.get("instrument-type") or ""
    q = _f(p.get("quantity")) or 0
    if p.get("quantity-direction") == "Short":
        q = -abs(q)
    mult = _f(p.get("multiplier")) or (100 if "Option" in typ else 1)
    avg = _f(p.get("average-open-price"))
    mark = _f(p.get("mark-price")) or _f(p.get("mark")) or _f(p.get("close-price"))
    val = mark * q * mult if mark is not None else None
    cost = avg * q * mult if avg is not None else None
    pnl = (val - cost) if val is not None and cost is not None else None
    row = {"sym": sym, "type": typ, "under": p.get("underlying-symbol") or sym, "qty": q, "avg": avg, "mark": mark,
           "mult": mult, "value": None if val is None else round(val, 2), "pnl": None if pnl is None else round(pnl, 2),
           "pct": round(pnl / abs(cost) * 100, 2) if pnl is not None and cost else None,
           "day": _f(p.get("realized-day-gain"))}
    m = OCC_TT.match(sym)
    if m:
        row["exp"] = f"20{m.group(2)}-{m.group(3)}-{m.group(4)}"
        row["right"] = "CALL" if m.group(5) == "C" else "PUT"
        row["strike"] = int(m.group(6)) / 1000
        try:
            row["dte"] = (date.fromisoformat(row["exp"]) - date.today()).days
        except ValueError:
            pass
    return row


def resumen(env):
    """Saldo + posiciones de la cuenta de tastytrade (cache 20 s)."""
    if not ready(env):
        raise TastyError("Falta configurar tastytrade.")
    hit = _CACHE.get("res")
    if hit and time.time() - hit[0] < 8:
        return hit[1]
    acc = accounts(env)
    if not acc:
        raise TastyError("No encontré cuentas abiertas en tastytrade.")
    want = env.get("TASTY_ACCOUNT") or ""
    a = next((x for x in acc if x["id"] == want), acc[0])
    b = _get(env, f"/accounts/{a['id']}/balances")
    bd = b.get("data") if isinstance(b.get("data"), dict) else {}
    pos = [_norm(p) for p in _items(_get(env, f"/accounts/{a['id']}/positions", params={"include-marks": "true"}))]
    pos = [p for p in pos if p["qty"]]
    pos.sort(key=lambda p: (p["under"], "Option" in p["type"], p.get("exp") or "", p.get("strike") or 0))
    stk = [p for p in pos if "Option" not in p["type"]]
    opt = [p for p in pos if "Option" in p["type"]]
    tot = lambda L, k: round(sum(p[k] or 0 for p in L), 2)
    out = {"account": a["id"][:2] + "•••" + a["id"][-3:], "name": a["name"], "type": a["type"], "margin": a["margin"],
           "accounts": len(acc),
           "nlv": _f(bd.get("net-liquidating-value")), "cash": _f(bd.get("cash-balance")),
           "deriv_bp": _f(bd.get("derivative-buying-power")), "equity_bp": _f(bd.get("equity-buying-power")),
           "withdraw": _f(bd.get("cash-available-to-withdraw")),
           "stocks": stk, "options": opt, "stock_value": tot(stk, "value"), "stock_pnl": tot(stk, "pnl"),
           "opt_value": tot(opt, "value"), "opt_pnl": tot(opt, "pnl"),
           "t": datetime.now().strftime("%H:%M:%S")}
    _CACHE["res"] = (time.time(), out)
    return out


def save(path, body):
    """Verifica con tastytrade y guarda los datos en el archivo privado de claves."""
    import setup_wizard as sw
    lines = sw.read_env(path)
    if not sw._get(lines, "ACCEPTED_TERMS") and not body.get("accept"):
        raise TastyError("Debes aceptar el aviso de riesgo para continuar.")
    sandbox = bool(body.get("sandbox"))
    acc = verify(body.get("secret"), body.get("refresh"), sandbox)
    sw._set(lines, "TASTY_CLIENT_SECRET", str(body.get("secret")).strip())
    sw._set(lines, "TASTY_REFRESH_TOKEN", str(body.get("refresh")).strip())
    cid = str(body.get("client_id") or "").strip()
    if cid and re.match(r"^[A-Za-z0-9._\-]{4,200}$", cid):
        sw._set(lines, "TASTY_CLIENT_ID", cid)
    sw._set(lines, "TASTY_ENV", "sandbox" if sandbox else "prod")
    sw._set(lines, "TASTY_ACCOUNT", acc[0]["id"])
    if not sw._get(lines, "ACCEPTED_TERMS"):
        sw._set(lines, "ACCEPTED_TERMS", datetime.now().strftime("%Y-%m-%d"))
    sw._write(path, lines)
    _CACHE.clear()
    return {"ok": True, "accounts": len(acc)}


def remove(path):
    import setup_wizard as sw
    lines = sw.read_env(path)
    for k in ("TASTY_CLIENT_SECRET", "TASTY_REFRESH_TOKEN", "TASTY_CLIENT_ID", "TASTY_ENV", "TASTY_ACCOUNT"):
        sw._del(lines, k)
    sw._write(path, lines)
    _CACHE.clear()
    _TOK.clear()
    return {"ok": True}


PAGE = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>tastytrade · LV Options Terminal</title>
<style>
:root{--bg:#000;--card:#0c0c0f;--line:#202027;--tx:#e6ecf5;--mut:#7d8aa5;--ok:#4ff0b7;--bad:#ff5d6c;--warn:#ffc04d;--cy:#5cc8ff;--tt:#ff4f4f}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:14px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
main{max-width:1200px;margin:0 auto;padding:18px 16px 40px}.mono{font-family:ui-monospace,Menlo,Consolas,monospace}
header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px}
h1{margin:0;font-size:22px;letter-spacing:.04em}a{color:var(--cy);text-decoration:none;font-weight:700}
.card{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--tt);border-radius:14px;padding:16px;margin-bottom:14px}
.lbl{font-size:12px;color:var(--mut);letter-spacing:.08em;margin-bottom:8px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.kpi{background:#08080a;border:1px solid var(--line);border-radius:10px;padding:10px 12px}.kpi span{display:block;font-size:11px;color:var(--mut);letter-spacing:.06em}.kpi b{font-size:20px}
.kpi small{display:block;color:var(--mut);font-size:11.5px;margin-top:2px}
table{width:100%;border-collapse:collapse;font-size:13px}th{color:var(--mut);font-weight:600;text-align:right;padding:7px;border-bottom:1px solid var(--line)}td{padding:8px 7px;border-bottom:1px solid #15151a;text-align:right}
th:first-child,td:first-child{text-align:left}.ok{color:var(--ok)}.bad{color:var(--bad)}.mut{color:var(--mut)}.warn{color:var(--warn)}
.pill{display:inline-block;font-size:11px;padding:1px 8px;border-radius:99px;margin-left:6px}.pill.r{background:rgba(255,93,108,.18);color:#ff7380}.pill.b{background:rgba(92,200,255,.16);color:#7fd6ff}.gold{color:#ffc04d;font-weight:600}tr.kid td{background:#0a1418;font-size:12.5px}tr.kid td:first-child{border-left:2px solid #1f3b4a}tr.grp td{background:#0e0e13}.pill.g{background:rgba(79,240,183,.15);color:#4ff0b7}
input{width:100%;background:#000;color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:9px 10px;font:13px ui-monospace,Menlo,Consolas,monospace}
label{display:block;font-size:12.5px;color:var(--mut);margin:10px 0 4px}
button{background:#111116;border:1px solid var(--line);color:var(--tx);border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}button:hover{border-color:var(--cy)}
.go{border-color:var(--tt);color:#ff8a8a}.box{border:1px solid #4a3a10;background:#141005;border-radius:10px;padding:10px 12px;font-size:13px;line-height:1.55;margin:10px 0}
.err{color:var(--bad);font-size:13px;margin-top:8px;min-height:18px}.tag{font-size:12px;color:var(--mut)}
</style></head><body><main>
<header><h1 class="mono">tastytrade <span class="tag">· cuenta, precios y órdenes</span></h1>
 <div class="mono" style="font-size:13px"><a href="#" id="upd" onclick="upd();return false" title="Busca e instala la versión nueva de la terminal">🔄 Actualizar</a> &nbsp; <a href="/">← Inicio</a> &nbsp; <a href="/setup">⚙ Cuentas de Tradier</a></div></header>

<div class="card" id="cfg" style="display:none">
 <div class="lbl">CONECTAR TU CUENTA DE TASTYTRADE</div>
 <div style="font-size:13.5px;line-height:1.6">En <b>my.tastytrade.com → Manage → My Profile → API → OAuth Applications</b> crea tu aplicación (permiso <b>read</b> basta) y un <b>grant</b>. Pega aquí lo que te dio:</div>
 <label>Client Secret</label><input id="t_sec" type="password" autocomplete="off" placeholder="pega aquí el client secret">
 <label>Refresh token (el del grant)</label><input id="t_ref" type="password" autocomplete="off" placeholder="pega aquí el refresh token">
 <label>Client ID (opcional)</label><input id="t_cid" autocomplete="off" placeholder="opcional">
 <label style="display:flex;gap:8px;align-items:center;color:var(--tx)"><input id="t_sbx" type="checkbox" style="width:auto"> Es de la cuenta de pruebas (sandbox) de tastytrade</label>
 <div class="box">🔒 Estos datos se guardan <b>solo en tu computadora</b> (archivo privado) y solo se envían a tastytrade. <b>Nunca los compartas</b> con nadie, ni con quien te dé soporte. La terminal no los vuelve a mostrar. Con permiso <b>read</b> la terminal no puede mandar órdenes.</div>
 <label id="t_accw" style="display:flex;gap:8px;align-items:center;color:var(--tx)"><input id="t_acc" type="checkbox" style="width:auto"> Entiendo que operar opciones tiene riesgo y que esta terminal es una herramienta de ayuda.</label>
 <div style="margin-top:10px;display:flex;gap:8px"><button class="go" onclick="tSave()">Verificar y guardar</button><button id="t_cancel" onclick="show()" style="display:none">Cancelar</button></div>
 <div class="err" id="t_err"></div>
</div>

<div id="view" style="display:none">
 <div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><div class="lbl" style="margin:0">MI CUENTA · <b id="v_acct" style="color:var(--tx)"></b></div>
   <span class="tag">actualizado <span id="v_t"></span> · <a href="#" onclick="edit();return false" style="font-weight:600">cambiar datos</a> · <a href="#" onclick="tDel();return false" style="color:var(--mut);font-weight:600">desconectar</a></span></div>
  <div class="kpis" style="margin-top:10px" id="v_k"></div>
 </div>
 <div class="card"><div class="lbl">MIS ACCIONES</div><div style="overflow-x:auto"><table><thead><tr><th>Símbolo</th><th>Cant.</th><th>Costo prom.</th><th>Precio</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th></tr></thead><tbody id="v_s"></tbody></table></div></div>
 <div class="card"><div class="lbl">MIS OPCIONES <span class="tag">(estrategias agrupadas; los covered calls están arriba, debajo de su acción)</span></div><div style="overflow-x:auto"><table><thead><tr><th>Contrato</th><th>Cant.</th><th>Precio entrada</th><th>Precio ahora</th><th>Valor</th><th>P&amp;L</th><th>P&amp;L %</th></tr></thead><tbody id="v_o"></tbody></table></div></div>
 <div class="tag">Las órdenes se mandan desde Trading manual y Portafolio (roll de covered calls), con vista previa y confirmación de dinero real. Para mandar órdenes tu grant de tastytrade necesita el permiso 'trade'. Los robots todavía no operan con tastytrade.</div>
</div>
<div class="err" id="v_err"></div>
</main>
<script>
const $=id=>document.getElementById(id),esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const usd=v=>v==null?"–":(v<0?"-$":"$")+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const pm=v=>v==null?"–":(v>=0?"+":"-")+"$"+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const cls=v=>v>0?"ok":v<0?"bad":"",px=v=>v==null?"–":v.toFixed(2);
const MES=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"],fd=d=>d?(+d.slice(8,10))+" "+MES[+d.slice(5,7)-1]:"";
let D=null,TERMS=false;
async function load(){try{const r=await fetch("/api/tasty",{cache:"no-store"});D=await r.json()}catch(e){$("v_err").textContent="No pude hablar con la terminal.";return}
  TERMS=!!D.terms;if(!D.configured){edit(true);return}if(D.error){$("v_err").textContent="⚠ "+D.error;show();return}$("v_err").textContent="";show();paint()}
function edit(first){$("cfg").style.display="";$("view").style.display="none";$("t_cancel").style.display=first?"none":"";$("t_accw").style.display=TERMS?"none":"flex"}
function show(){$("cfg").style.display="none";$("view").style.display=""}
function paint(){const d=D.data;if(!d)return;$("v_acct").textContent=(d.name||"")+" "+d.account+(d.accounts>1?" (tienes "+d.accounts+" cuentas; muestro la primera)":"");$("v_t").textContent=d.t;
  const K=(t,v,c,s)=>'<div class="kpi"><span>'+t+'</span><b class="mono '+(c||"")+'">'+v+'</b>'+(s?'<small>'+s+'</small>':'')+'</div>';
  $("v_k").innerHTML=K("VALOR DE LA CUENTA",usd(d.nlv))+K("EFECTIVO",usd(d.cash),"",d.withdraw!=null?"disponible para retirar "+usd(d.withdraw):"")
   +K("PODER DE COMPRA OPCIONES",usd(d.deriv_bp))+K("ACCIONES",usd(d.stock_value),"",d.stocks.length+" posición"+(d.stocks.length===1?"":"es"))
   +K("P&L ACCIONES",pm(d.stock_pnl),cls(d.stock_pnl))+K("P&L OPCIONES",d.options.length?pm(d.opt_pnl):"–",cls(d.opt_pnl),d.options.length+" pata"+(d.options.length===1?"":"s"));
  /* covered calls: call VENDIDO del mismo activo, cubierto por 100 acciones por contrato -> debajo de la accion */
  const used=new Set(),ccOf={};
  for(const st of d.stocks){if(!(st.qty>=100))continue;let free=Math.floor(st.qty/100);
    for(const o of d.options.filter(o=>o.under===st.sym&&o.right==="CALL"&&o.qty<0).sort((a,b)=>(a.exp||"").localeCompare(b.exp||""))){
      if(free<=0)break;const n=Math.min(free,-o.qty);if(n<-o.qty)continue;free-=n;used.add(o.sym);(ccOf[st.sym]=ccOf[st.sym]||[]).push(o)}}
  const pct=v=>v==null?"–":v.toFixed(2)+"%";
  $("v_s").innerHTML=d.stocks.map(p=>{const C=ccOf[p.sym]||[];
    let h='<tr><td><b>'+esc(p.sym)+'</b>'+(p.qty<0?'<span class="pill r">corto</span>':'')+(C.length?'<span class="pill b">📎 '+C.length+' covered call'+(C.length>1?"s":"")+'</span>':(p.qty>=100?' <span class="tag">puedes vender '+Math.floor(p.qty/100)+' call cubierto</span>':''))+'</td><td class="mono">'+p.qty+'</td><td class="mono">'+px(p.avg)+'</td><td class="mono">'+px(p.mark)+'</td><td class="mono">'+usd(p.value)+'</td><td class="mono '+cls(p.pnl)+'"><b>'+pm(p.pnl)+'</b></td><td class="mono '+cls(p.pct)+'">'+pct(p.pct)+'</td></tr>';
    for(const o of C){const n=-o.qty,prima=o.avg!=null?o.avg*100*n:null,asig=(o.avg!=null&&p.avg!=null)?((o.strike-p.avg)*100*n+o.avg*100*n):null,dist=p.mark?(o.strike/p.mark-1)*100:null;
      h+='<tr class="kid"><td style="padding-left:22px"><span class="gold">'+esc(o.under)+' '+o.strike+'C · '+fd(o.exp)+'</span><span class="pill b">📎 covered call</span>'+(o.dte!=null?' <span class="tag">'+o.dte+' d</span>':'')
        +'<div class="tag" style="margin-top:2px">prima cobrada '+(prima==null?"–":usd(prima))+(dist!=null?' · strike '+(dist>=0?"+":"")+dist.toFixed(1)+'% del precio':'')+(asig!=null?' · si te asignan: <b class="'+cls(asig)+'">'+pm(asig)+'</b>':'')+'</div></td>'
        +'<td class="mono">'+o.qty+'</td><td class="mono" title="Prima cobrada por acción">'+px(o.avg)+'</td><td class="mono" title="Lo que cuesta recomprarlo">'+px(o.mark)+'</td><td class="mono">'+usd(o.value)+'</td><td class="mono '+cls(o.pnl)+'"><b>'+pm(o.pnl)+'</b></td><td class="mono '+cls(o.pct)+'">'+pct(o.pct)+'</td></tr>'}
    return h}).join("")||'<tr><td colspan="7" class="mut">No tienes acciones.</td></tr>';
  /* estrategias: patas del mismo activo y vencimiento -> iron condor / spread en una sola linea */
  const rest=d.options.filter(o=>!used.has(o.sym)),G={};rest.forEach(o=>{const k=o.under+"|"+(o.exp||o.sym);(G[k]=G[k]||[]).push(o)});
  const legName=o=>o.strike+(o.right==="CALL"?"C":"P");
  function stratOf(L){const q=Math.abs(L[0].qty);if(!L.every(o=>Math.abs(o.qty)===q))return null;
    const P=L.filter(o=>o.right==="PUT").sort((a,b)=>a.strike-b.strike),C=L.filter(o=>o.right==="CALL").sort((a,b)=>a.strike-b.strike);
    const sp=(A)=>A.length===2&&A[0].qty*A[1].qty<0;
    if(L.length===4&&sp(P)&&sp(C)){const credit=P[1].qty<0&&C[0].qty<0;return{name:P[1].strike===C[0].strike?"Iron Fly":"Iron Condor",credit,q}}
    if(L.length===2&&sp(P))return{name:"Put "+(P[1].qty<0?"credit":"debit")+" spread",credit:P[1].qty<0,q};
    if(L.length===2&&sp(C))return{name:"Call "+(C[0].qty<0?"credit":"debit")+" spread",credit:C[0].qty<0,q};
    return null}
  const legRow=(o,kid)=>'<tr'+(kid?' class="kid"':'')+'><td'+(kid?' style="padding-left:22px"':'')+'><b>'+esc(o.under)+'</b> '+(o.strike!=null?legName(o)+" · "+fd(o.exp):esc(o.sym))+(o.qty<0?'<span class="pill r">Vendido</span>':'<span class="pill g">Compra</span>')+(o.dte!=null&&!kid?' <span class="tag">'+o.dte+' d</span>':'')+'</td><td class="mono">'+o.qty+'</td><td class="mono">'+px(o.avg)+'</td><td class="mono">'+px(o.mark)+'</td><td class="mono">'+usd(o.value)+'</td><td class="mono '+cls(o.pnl)+'">'+(kid?'':'<b>')+pm(o.pnl)+(kid?'':'</b>')+'</td><td class="mono '+cls(o.pct)+'">'+pct(o.pct)+'</td></tr>';
  let oh="";
  for(const [k,L] of Object.entries(G).sort()){const S=L.length>1?stratOf(L):null;
    if(!S){oh+=L.map(o=>legRow(o,false)).join("");continue}
    const per=o=>(o.qty<0?1:-1)/S.q,entry=L.reduce((a,o)=>a+(o.avg||0)*per(o),0),now=L.every(o=>o.mark!=null)?L.reduce((a,o)=>a+o.mark*per(o),0):null;
    const pnl=L.reduce((a,o)=>a+(o.pnl||0),0),base=Math.abs(entry)*100*S.q,pp=base?pnl/base*100:null,o0=L[0];
    oh+='<tr class="grp"><td><b>'+esc(o0.under)+' '+S.name+'</b> · '+fd(o0.exp)+(o0.dte!=null?' <span class="tag">'+o0.dte+' d</span>':'')+'<span class="pill '+(S.credit?"r":"g")+'">'+(S.credit?"crédito":"débito")+'</span>'
      +'<div class="tag" style="margin-top:2px">'+L.slice().sort((a,b)=>a.strike-b.strike).map(legName).join(" / ")+'</div></td>'
      +'<td class="mono">'+S.q+'</td><td class="mono" title="Precio neto de entrada">'+Math.abs(entry).toFixed(2)+'</td><td class="mono" title="Lo que cuesta cerrarla ahora">'+(now==null?"–":Math.abs(now).toFixed(2))+'</td><td class="mono">–</td><td class="mono '+cls(pnl)+'"><b>'+pm(pnl)+'</b></td><td class="mono '+cls(pp)+'">'+pct(pp)+'</td></tr>'
      +L.slice().sort((a,b)=>a.strike-b.strike).map(o=>legRow(o,true)).join("")}
  $("v_o").innerHTML=oh||'<tr><td colspan="7" class="mut">'+(d.options.length?"Tus únicas opciones son covered calls (arriba, debajo de cada acción).":"No tienes opciones abiertas.")+'</td></tr>'}
async function tSave(){$("t_err").textContent="Verificando con tastytrade…";
  const b={secret:$("t_sec").value,refresh:$("t_ref").value,client_id:$("t_cid").value,sandbox:$("t_sbx").checked,accept:$("t_acc").checked};
  try{const r=await fetch("/api/tasty_save",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});const j=await r.json();
    if(j.error){$("t_err").textContent="⚠ "+j.error;return}$("t_sec").value=$("t_ref").value="";$("t_err").textContent="";load()}catch(e){$("t_err").textContent="Error: "+e}}
async function tDel(){if(!confirm("¿Desconectar tastytrade de esta terminal? (se borran los datos guardados; puedes volver a pegarlos)"))return;
  await fetch("/api/tasty_remove",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});load()}
async function upd(){const e=$("upd");e.textContent="🔄 buscando…";
  try{const c=await (await fetch("/api/update_check",{cache:"no-store"})).json();
    if(c.error){e.textContent="🔄 Actualizar";alert(c.error);return}
    if(!c.available){e.textContent="✓ ya tienes la última ("+(c.current||"")+")";return}
    if(!confirm("Hay una versión nueva ("+c.latest+"). ¿Instalarla ahora? La terminal se reinicia sola."))return;
    e.textContent="🔄 instalando…";const r=await (await fetch("/api/update_apply",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})).json();
    if(r.error){e.textContent="🔄 Actualizar";alert(r.error);return}
    e.textContent="✓ instalada, reiniciando…";setTimeout(()=>location.reload(),9000)}catch(x){e.textContent="🔄 Actualizar"}}
load();setInterval(()=>{if(!document.hidden&&$("view").style.display!=="none")load()},30000);
</script></body></html>"""
